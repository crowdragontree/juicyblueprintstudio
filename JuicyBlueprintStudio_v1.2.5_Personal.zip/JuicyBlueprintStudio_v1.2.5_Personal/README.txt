JUICY BLUEPRINT STUDIO v1.2.1
=================================

QUICK START
-----------
1. Extract all files into one folder.
2. Run START_JUICY_BLUEPRINT_STUDIO.bat on Windows.
3. Open WebP Maker to convert ONE MP4, or add more clips to merge them.
4. Open Bot Builder, then Build Introduction, to design your introduction visually.
5. In Introduction Designer, drag to move items, click an item to edit it, and use Fit content if the background is too tall.
6. Click Copy Introduction to paste the finished HTML into JuicyChat.

You do not need to know HTML or any website-building software.
The interface does not depend on Elementor or Cornerstone.

RELEASE NOTES FOR THIS BUILD
----------------------------
See CHANGELOG.txt. This release is v1.2.1 (a speed-up release: faster start-up and scoring, nothing else changed).

JUICY BLUEPRINT STUDIO v1.1.1
============================

UPDATING FROM AN EXISTING INSTALLATION
-------------------------------------
Close the app. Extract this edition into a new permanent folder, then run
START_JUICY_BLUEPRINT_STUDIO.bat. Keep the existing application data. Use the
same edition as before; Personal and Shareable retain their own application names.

Write with AI (Bot Builder) opens the Greeting planner before sending a request.
The planner's Dialogue share box sets what % of the Greeting is dialogue; it is sent
with every Greeting instruction and checked after writing.
Rewrite [section] with AI affects only that section after you review and apply it.
Save to card stores a local bot; it does not publish to JuicyChat or check off
publishing tasks. Separate cards can hold separate saved bots.


WEBP MAKER: VIDEO CROPPING (v1.1.1)
---------------------------------
Open WebP Maker inside Juicy Blueprint Studio and add two or more MP4 or WebM video clips (including AI-generated VP9 streams stored with .mp4 filenames).
Choose a crop preset: 16:9, 9:16, 3:4, 4:3 or 1:1. Center/Top/Bottom/Left/Right positions are supported; the crop preview shows the framing before conversion.
For different crops per file, select Freeform, choose a clip in the crop preview, then drag the crop box or its corner handles. Reset this clip's crop restores only that clip. Each clip keeps its own framing when reordered.
Choose Custom dimensions to set width and height independently, for example 480 x 640. Freeform selections preserve the output proportions to avoid stretching.
The file must remain under 9.99 MB. Video processing stays local; automatic quality/FPS adjustments retain their existing safeguards.

ORIGINAL INSTALLATION / OPERATION NOTES
--------------------------------------
THIS BUILD USES THE SUPPLIED WORKING MARKET SCAN
-------------------------------------------------
v0.10 no longer uses the old JavaScript/Electron collector.

The scanner is built directly around the Python Playwright collector from the
Blueprint Studio zip supplied by the user:

  scanner\scraper.py

That file is copied from the working Blueprint Studio Market Scan. The desktop
app calls it through scanner\worker.py and lib\pythonCollector.js.

The important behavioral difference from v0.9 is also preserved: if JuicyChat
loads bot data but the scanner cannot find a visible "Recent" or "Trending"
control, collection does NOT immediately fail. The supplied Market Scan keeps
reading the JSON and bot cards JuicyChat already loaded, so v0.10 does the same.

FIRST RUN
---------
1. Extract the zip into a NEW folder.
2. Double-click START_JUICY_BLUEPRINT_STUDIO.bat.
3. First launch installs:
   - the private Node/Electron desktop shell
   - a private Python virtual environment
   - the SAME full Python Playwright package used by the supplied Market Scan
   - Playwright Chromium
4. Let installation finish. The app opens automatically afterward.

SIGN IN
-------
1. Open JuicyChat Analysis.
2. Paste a fresh JuicyChat magic link.
3. Click Open Sign-in.
4. A normal Chromium window opens using the persistent Market Scan profile.
5. Finish signing in.
6. Return to Juicy Blueprint Studio and click Finish Sign-in.

COLLECT
-------
Use Collect Recent, Collect Trending, or Collect Both.

Collection uses a HEADED Chromium session, just like the supplied working
Market Scan, but its window is positioned far offscreen so you do not have to
watch or interact with it.

The progress window shows the number of bots captured, scan pass, visible card
count, network-response count, elapsed time, and whether collection is waiting
or stalled.

CANCEL
------
Cancel Collection creates the same stop signal used by the Python scanner loop.
The current scan exits, captured records are kept, and Collect Both will not
continue into the next list after cancellation.

SUCCESS ENGINE SUMMARY
----------------------
After bots are collected, analysis is local. No AI model or API is used.
The JuicyChat Analysis screen shows:
- dominant success engines
- Recent vs Trending prevalence
- relationship/setup patterns
- opening-hook patterns
- setting/archetype signals
- why each engine is likely working
- examples from the collected sample
- saturation/open-gap signals

SCENARIO GENERATION
-------------------
Weekly scenarios are built procedurally from:
- the collected success-engine statistics
- the uploaded Weekly Blueprint rules
- the JC Scenario Engine library
- weekly series/slot quotas
- active event requirements

No AI model is used to write the scenarios.

BOT BUILDER (v0.19)
-------------------
The Bot Builder tab fills a bot template by hand, with no AI.
- Templates live in resources\bot-templates. Use "+ Add template..." to add
  more .txt templates; they are copied into the app's private data folder.
- Template names follow the file names ("7._PigeonGuy_Template_Post-NTR_October_2026_V3.txt"
  shows as "7. PigeonGuy Template Post-NTR"), listed by number
  (1, 2 ... 10, 11), then alphabetically.
- Every [placeholder] in the template becomes a box. Fixed rule text is kept
  word-for-word. Character names are typed once and inserted everywhere.
- Character limits, image-marker count, tag rules, greeting formatting,
  V-neckline/outfit rules and banned words are read from the template and
  checked live. "Copy full bot" copies the finished text in template order.
- "Fill from scenario" starts a draft from a Weekly Blueprint scenario.
- "Edit final text directly" lets you trim a section by hand when the
  template's own fixed rules are longer than its character limit.

BONUS IDEAS (v0.20)
-------------------
Bonus Ideas tab (under Weekly Blueprint in the sidebar). Type a one or two sentence bot idea (optional:
name, series, archetype, relationship, setting, opening moment, tags).
- "Check success estimate" scores the idea without saving it.
- "Add to Bonus" builds a full scenario card with the same fields as the
  weekly scenarios and saves it under Bonus with its estimate.
The estimate compares your idea with the collected Recent + Trending bots and
the measured engines: engine fit, how similar bots perform, Trending presence,
crowding, and whether the idea has a clear opening and relationship stakes.
It is re-checked automatically after each new analysis. Bonus ideas carry over
when a new week is generated. "Build bot" sends a bonus card to the Bot Builder.

LEARNING, PASTED SCENARIOS, MULTIPLE CHARACTERS (v0.27)
-------------------------------------------------------
- Scrape history: every collected bot is kept in juicy-bot-history.json in the
  app's data folder (it no longer disappears on the next scrape). Each scrape
  adds a sighting (rank, engagement). Engines are measured on the whole history,
  weighted toward recent scrapes (half-life 3 weeks), with extra credit for bots
  that stay on Trending. Engines are marked Rising / Fading once there are a few
  scrapes on different days. Analysis page > "Learning from N bots" panel.
  "Clear history" is in that panel.
- Pasting a full scenario into Bonus Ideas: labels are read in both the HTML
  Copy layout (label line, value below) and "Label: value" lines. Scene Name,
  characters, tags and every field are kept word for word; fields the app had to
  add are marked "added by app" on the card.
- Casts: every card has 1-3 characters (shown under the title). ANTI-NTR cards
  include the antagonist and an Antagonist field. Bonus Ideas > More details has
  two extra character rows. The Bot Builder fills Name 2 / Name 3 from the cast.

AUTOMATIC DAILY RUN, PERFORMANCE PULL, REGENERATE TAB (v0.29)
-------------------------------------------------------------
- Every day at 8:00 PM Eastern (America/New_York, so EST and EDT are both
  handled) the app collects 100 Recent + 100 Trending, updates the analysis,
  then pulls your own bots' stats. If the app was closed at 8 PM, the missed run
  happens the next time it is opened; a failed run retries every 45 minutes.
  The app has to be open (it can be minimized). Settings > "Start with Windows"
  opens it minimized at login so the 8 PM run happens on its own.
  The manual Collect buttons and "Pull from JuicyChat now" still work any time.
- Performance: reads your bots from your JuicyChat profile (found from your
  signed-in account, or from Settings > My JuicyChat profile URL), matches
  them to scenario cards by name, and shows chats, likes, views, days live and
  the change since the last pull. Pick a bot by hand in a card's "JuicyChat bot"
  box for any that did not match, or mark a card "Not published yet".
- Weekly Blueprint > "Regenerate Tab" rebuilds every card in the tab you are
  on (a day, NTR, or Bonus). Cards marked Built are kept. Bonus cards are
  rebuilt from their original idea or pasted card.

TWO ACCOUNTS IN PERFORMANCE (v0.30)
-----------------------------------
- Daily automatic run is at 8:00 PM Eastern.
- Performance has a Main Account tab and an NTR Account tab. Each reads the
  bots listed on that account's public lounge link (paste it in the tab or in
  Settings), so the tool never signs in as those accounts. Main bots match to
  weekly + Bonus cards, NTR bots to NTR cards.
- Each tab shows: bots, total chats/likes/views with the change since the last
  pull and chats per day, a chats-over-time chart, what's working by series,
  predicted vs actual (rank agreement), and a sortable table of every bot
  (most chats, fastest growing, chats per day, most likes, newest) where any
  bot can be linked to a scenario card.

PREDICTION ACCURACY (v0.31)
---------------------------
- A card's score is frozen as its "initial score" when you mark it Built (or,
  if it was never marked Built, when a bot is first linked to it).
- Once a bot has been live 3 days, and its account has at least 4 bots that
  old, it gets an actual score on the same 0-100 scale: chats per day (60%),
  total chats (25%) and like rate (15%), ranked against that account's bots.
- Performance > Prediction accuracy shows, per account: bots judged, average
  miss, share within 12 points, whether scores run high or low, and how well
  the order of scores matched the order of results; every bot's initial vs
  actual score with a verdict; and what the app learned.
- The app learns an overall correction plus per-series and per-engine
  corrections and applies them to every new and current score ("Learned
  adjustment" on each card). Corrections are kept small until enough bots
  back them up. Regenerating a card clears its frozen score.

PERFORMANCE FIXES (v0.32)
-------------------------
- Numbers shown next to icons (chat bubble, heart, star) are now read, as
  well as numbers written with words. Favourites are tracked separately from
  likes. "Pull details" shows how the numbers were read, and warns clearly if
  bots were found but their numbers could not be read.
- Generating a new week now keeps the previous week's cards (and their scores)
  in an archive, so bots built from earlier weeks can still be matched and
  compared with the score they were given. Built cards win name ties.
- The All bots table has an App score column: the card's frozen score (from
  when it was built) or, if not frozen yet, its current score marked LIVE.

PERFORMANCE: READING NUMBERS FROM JUICYCHAT (v0.33)
---------------------------------------------------
JuicyChat builds its lounge in the browser and the lounge cards don't show
counts. A pull now reads each bot's chats, likes, favourites and creation date
from the data JuicyChat loads for the lounge; any bot still missing numbers is
opened on its own page and read there. This takes a little longer (a few
seconds per bot that needs its page opened). Pull details shows which route
was used.

JUICYCHAT DATA + BOT FORENSICS (v0.34)
--------------------------------------
- Lounge pulls now ask JuicyChat's own data service for the lounge (the same
  way JuicyChat's page does, including its built-in scrambling of requests and
  replies). For lounge links of the form .../userdetailspace/<number> this gives
  exact chats, likes, favourites, first-published time, tags and description for
  every bot, and each bot's public comments. If that fails, the older
  page-reading method is used automatically.
- Performance > click any bot in the All bots table for its forensics:
  Why it performed (change vs previous pull, each tag's chats/day vs the
  account median), When it performed (first published, first-week chats,
  biggest jump, best hour/weekday from comment times in Toronto time, chats
  over time), Archived commenters (kept even after JuicyChat stops listing
  them) and Prediction accuracy (initial vs actual score).
- "Who liked / starred" needs that account's own notifications (signing in as
  that creator), so it is not available from a lounge link.

BACKGROUND PULLS + ACCOUNT SIGN-IN (v0.35)
------------------------------------------
- Reading your bots (lounges, bot pages, account data) now runs in a hidden
  browser window parked off-screen. Only Recent/Trending collection shows its
  window.
- The progress counter shows the real number of bots: "N found" while the
  lounge is still being read, then "N / total".
- Each Performance tab (Main / NTR) can be signed in with that account's own
  magic link. A signed-in account is read directly: its own bots with exact
  numbers (no lounge link needed), comments, and its notifications, which fill
  in "Who liked / starred" in each bot's forensics. Each account's sign-in is
  kept in its own browser profile, separate from the tool account.

18+ BOTS (v0.36)
----------------
JuicyChat only shows 18+ bots to accounts allowed to see 18+ content, so an
account without that access never receives them. The tool does not try to get
around that. Instead:
- Performance: sign an account in with its magic link (Performance tab). A
  signed-in account's pull uses JuicyChat's owner-only "my bots" list, which
  includes every bot the account owns: SFW, NSFW and 18+. Each tab shows the
  SFW / NSFW / 18+ split, and each bot's rating appears in its forensics.
- Analysis: JuicyChat Analysis > "Collect with" chooses which account collects
  Recent/Trending. Pick a signed-in account that is allowed to see 18+ and the
  18+ bots are included in the market data and engine analysis.

RATING CHECK (v0.37)
--------------------
When a lounge is read by an account without 18+ access, JuicyChat can report
18+ bots as NSFW. Each pull now records every small field JuicyChat sends per
bot. Performance > "Rating check" lists the fields that split your bots into a
few groups, with counts per value; "mark 18+" on the value that matches your
18+ count makes the split use it. Signing the account in with its magic link
remains the most reliable fix: the owner's own list carries the true rating.

STORY BRIEF (v0.39)
-------------------
Bot Builder > "Write the story with the chatbot you already use":
1. Pick a scenario under "Draft from", then click "Copy story brief". The
   brief is about one screen long: the story facts, what the data says is
   working, craft notes for a real scene and a hook, and only light format
   rules. The long template never goes to the chatbot.
2. Paste the brief into ChatGPT (or any chatbot you already have).
3. Paste its whole reply into "Paste the chatbot's reply" and click "Use this
   story" (or "Use it and fill the rest" to also auto-complete the other boxes).
   The tool places the Introduction and each Greeting paragraph, keeps the
   series prefix, fixes banned punctuation and {{user}}, drops chatty
   sign-offs, and runs every template check. Nothing extra is paid for.
The Bot Builder form and full-bot panel are now split 50/50.

v0.40
-----
- Fixed: Engine Library and Settings showed their content below the sidebar
  (an extra closing tag in the Performance screen).
- Weekly Blueprint tabs show built progress ("Monday 1/3") and turn green
  when a day is complete. Each card has a single "Built" checkbox instead of
  the Idea/Built dropdown, and the score shows as "85/100" with its confidence.
- Bot Builder > "Replace template...": pick a template, click Replace, choose
  your updated .txt. Your file takes over under the same name (drafts kept);
  "use the original" next to the template list switches back.

v0.42
-----
- Likeable NTR stories are real affairs involving sex between consenting
  adults (described without explicit detail), not kisses or text threads. The
  "survival" pattern never turns sex into payment or pressure: the PigeonGuy
  template forbids inventing sexual violence. NTR cards carry Content
  Intensity "Adult Infidelity / Sexual Betrayal".
- Generate Week and Regenerate Whole Week leave the Bonus tab exactly as it
  was: cards, scores, estimates and Built ticks. Bonus cards only change when
  you use Re-check or Regenerate Tab on the Bonus tab.

v0.43
-----
- Copy buttons work on the first click. They now copy through the desktop
  app's own clipboard instead of the web page clipboard, which Electron only
  allows while the window has focus.

v0.44
-----
- Performance shows where each bot sits in JuicyChat's feeds: Popular,
  Trending, Recent, New and Editor's Choice. Each pull reads the top 500 of
  each feed. All bots has a Placement column (and a "Best placed" sort), the
  KPIs count bots in a feed now, and each bot's forensics shows its position
  now, its best position and when it first appeared in each feed.
- Positions are as seen by the account that pulls. An account without 18+
  access sees feeds without 18+ bots, so positions can differ from what an
  18+ viewer sees; a signed-in account with 18+ access gives the truest ones.

v0.45
-----
- Performance > All bots has a search box under the heading. It filters the
  table instantly as you type, by bot name or tag (several words narrow it
  down), shows "N of M bots", keeps the search when you change the sort, and
  Escape clears it.

v0.46
-----
- Fixed: bot search matched tags as well as names, so typing "her" showed
  bots tagged "Hero". Search now matches bot names only; start a word with #
  to search tags (#hero, #wholesome), and both can be combined ("her #drama").

v0.47
-----
- Performance charts rebuilt (account chart and each bot's forensics chart):
  a labelled value axis with enough precision to tell points apart, a real
  time axis (points spaced by when each pull happened, with times shown for
  same-day pulls), a summary line ("+3,700 chats across 6 pulls since ..."),
  and hover anywhere across the chart to see the nearest pull's value, time
  and change since the previous pull. The account chart switches between
  Chats, Likes, Favourites and Bots. Early pulls taken before numbers could be
  read are hidden (with a note) instead of drawing a false line at zero.

v0.48
-----
- "What's working on this account" now uses every bot, not only bots linked
  to a scenario card. Series come from a linked card when there is one,
  otherwise from the series prefix in the bot's description ("[Bully Series
  28]", "["NTR?" Series 03]"), otherwise from the title ("Your Bully ...");
  the rest are grouped as "no series". Switch between By series and By tag.
  Ranked by median chats per day, with how that compares with the account's
  median (1.0x = typical), plus average chats, average likes and best bot.

v0.49
-----
- Two editions from one app, chosen by edition.json ("personal" or "share").
  The shareable edition has no NTR anywhere, no series (two standalone
  scenarios and one high-reaction scenario a day), no bundled templates or
  rulebook, one account read from a lounge link, and sign-in only on the
  JuicyChat Analysis tab. It keeps its data in its own folder, separate from
  the personal edition. Series and NTR stories now live in
  lib/incidents-personal.js, which the shareable package does not include.
- Performance sorting order: Best placed (default), Most chats, Most likes,
  Fastest growing, Chats per day, Newest. Bots in no feed follow in chat order.
- 12 new standalone stories.

v0.50
-----
- JuicyChat's daily "Claim Coins" pop-up is handled automatically. Whenever
  the scanner opens JuicyChat (Recent/Trending collection and bot pulls) it
  checks for a Claim pop-up covering the page, clicks Claim, dismisses any
  follow-up pop-up ("OK", "Got it", close), and then carries on. If a tab
  click is ever blocked by a pop-up anyway, it clears it and retries once.
  Only Claim buttons inside a pop-up are clicked; the live log records it.

v0.51
-----
- Installer fix: START_JUICY_BLUEPRINT_STUDIO.bat now checks the Node.js
  already on the computer. If it is older than version 18 (which can't
  install the desktop shell), the app downloads and uses its own private
  Node.js instead; the computer's Node is not changed. A half-finished
  install from an old Node is cleaned up automatically. The start script
  now uses Windows line endings.

v0.52
-----
- Installer fix: the private Node.js is now used where it is unzipped
  (.runtime\node-dl) instead of being moved, which antivirus scanning could
  block ("Access to the path ... is denied"). Every download/unzip step now
  stops with a clear message if it fails, the private Node is checked before
  use, and npm always runs from the private Node, so an old Node on the
  computer can no longer be picked up by mistake. A copy unzipped by an
  earlier failed attempt (.runtime\node-temp) is found and reused.

v0.53
-----
- Installer fix: when the computer's own Node.js is new enough, npm is now
  run by its full path. Calling it by name made npm look for its own files in
  the app folder ("Cannot find module ...\node_modules\npm\bin\npm-cli.js").
  If npm can't be found, the app uses its own private Node.js instead.

v0.54
-----
- Bonus Ideas page lists "Your bonus ideas", each with an Edit button that
  opens that card's editor (scene name, characters, tags and every field).
- Shareable edition: Performance reads the signed-in account's own bots
  (every rating, 18+ included) with no lounge link.
- Settings > Weekly Blueprint: choose the rulebook (.txt) and card template
  (.html), click Update Blueprint. Cards follow the template's fields and
  order, show each field's instruction (hover the i), fill new fields from
  what they already know and mark the rest "Needs writing"; the Approved Tag
  List and rule text update. Every version is kept: Revert to Previous
  Version switches back. Content is never deleted. Rules about how scenarios
  are chosen (series rotation, quotas, new series) still need an app change.
  The files that shipped with the app count as the built-in version, so
  nothing changes until you upload your first update.
- The app runs on 3 bots a day: the rulebook and card template that come
  with it (resources/rules/weekly_blueprint_rules.txt +
  weekly_blueprint_template.html) are the 3 bots/day schedule. The 2 / 3
  bots/day switch and the Kill Switch upload are no longer in Settings.
- The Setup is now a detailed brief (about 1,000-1,500 characters): history,
  what happened, where and when, her side, what {{user}} knows and what's at
  stake, and the exact moment the Greeting opens on. Typed Bonus ideas get
  the same; pasted cards keep their own Setup.
- scripts/build_share.py builds the shareable edition the same way every time.

v0.55
-----
- Field writer (lib/fieldWriter.js): every field your uploaded blueprint asks
  for is filled automatically when cards are built, regenerated, added as a
  Bonus idea, or when you update the blueprint. It draws on everything the
  card already holds (under whatever name), writes engine fields, appearance,
  NTR planning fields (Partner / User Role, Betrayal Motivation, What Has NOT
  Happened, the antagonist's fields...), a detailed Setup and long-engagement
  beats, replaces {{Name1}}/{{Name2}} with the real characters, and takes the
  default an instruction offers ("KEEPER or SLOP" -> KEEPER, "Use NTR unless
  NETORI" -> NTR). With the new NTR layout, a full week has no "Needs
  writing" boxes left.
- Fixed: fields about the antagonist could borrow the main character's
  answer (e.g. "Antagonist Type / Relationship to {{user}}").
- Every card (day scenarios, NTR and Bonus) has an Edit button. The editor
  lists the blueprint's fields, including any still marked "Needs writing",
  so anything can be written or corrected by hand.

v0.56
-----
- Fixed: a value left in the Bonus form's More details (Title, character
  name, archetype, relationship, hook, characters) overrode the pasted
  card's own values, renaming pasted scenes. The pasted card now always
  wins; More details only fills what the card leaves out. A rename made later
  in the card editor is remembered and survives Regenerate.
- Performance: every bot is scored automatically from its own title,
  description and tags the first time it is pulled, then frozen, and judged
  against how it actually performs. No linking to scenario cards; the
  "Scenario card" column is gone. (A card's own frozen score is used if the
  bot was built from one of the app's cards.)
- Weekly Blueprint > Import ChatGPT week: choose the Weekly Blueprint HTML
  ChatGPT wrote. Every card is read, filled to your blueprint and scored
  against your data. For cards under 80 the app offers only safe tidy-ups you
  approve one by one (never scene names or story text), plus a ready-made
  fix request to paste into ChatGPT; paste its revised card back to re-score
  it. Import archives the current week (with scores) and keeps Bonus cards.

v0.57
-----
- Improve to 80+ for Bonus cards (Bonus Ideas > Your bonus ideas, or the
  Improve button on a Bonus card in the Weekly Blueprint): what moved the
  score; tidy-ups you approve one by one with before/after; Copy fix request
  for ChatGPT; paste the revised card back and Score revised card to see its
  new score before you Keep it. The revised text becomes the card's idea, so
  the new score sticks and Regenerate builds from it. Your Scene Name and
  characters always stay, whatever the revised card says.
- Fixed: the "remove unapproved tags" tidy-up also dropped allowed tags such
  as Event; it now removes exactly the tags it lists (Bonus and ChatGPT
  week import).

v0.58
-----
- Import ChatGPT week now reads ChatGPT's batch layout as well as the
  template's: cards as <article class="scenario">, the scene name in the card
  title, "Primary: Name" under it, the series and slot in the line above,
  field labels without colons, and day tabs as <section> elements. The slot
  comes from each card's own label (so Futa Friday as Scenario 2 is kept).
- Fixed: apostrophes and other characters written as hex codes (&#x27;)
  were left garbled in field names and text (e.g. "Character's Relationship
  to You"); this also affected the blueprint reader.
- Ages are read from "Name, 22" and "Name, age 30"; field names are no longer
  mistaken for characters ("Antagonist Type"); duplicate characters removed.

v0.59
-----
- Updates: both editions check a Google Drive folder at start-up. If a newer
  zip for their edition is there, a pop-up shows exactly what changed (from
  CHANGELOG.txt inside the zip). Update now downloads it, unpacks it into the
  folder the app is installed in (keeping node_modules and the private
  runtime), deletes the download and offers Restart. Not now keeps the
  current version and doesn't ask again for that version; "Update available"
  stays in the sidebar. Settings > Updates has Check for updates.
  The shareable edition uses the shared folder; the personal edition uses a
  folder you set in Settings (keep it separate from the shared one).
  Zip names must stay JuicyBlueprintStudio_vX.YY_Shareable.zip / _Personal.zip.
- Release notes now live in CHANGELOG.txt (personal) and
  scripts/SHARE_CHANGELOG.txt (shareable, no personal content).

v0.60
-----
- Dashboard shows the app's version with a Check for updates button.

v0.61
-----
- The personal edition has the same Google Drive update folder built in as
  the shareable edition (edition.json). Each edition only installs zips with
  its own name (_Personal / _Shareable). Anyone with the folder link can see
  and download every zip in it.

v0.62
-----
- Start with Windows fixed (Electron is started with the app folder), tray
  icon, hide-to-tray, daily update check while open, update notification
  when hidden. Open the app once so the start-up entry is rewritten.
- Adapt to Event / Adapt all to Event (lib/eventAdapt.js): event tag,
  opportunity tags and the Event Tag / Opportunity Tag / Event Integration
  fields only. Stories are never rebuilt. A tag only counts as featured when
  the story fields clearly show it (not tags, personality types or negated
  mentions); otherwise the card is flagged and its fix request asks ChatGPT
  for a small detail. Running it again changes nothing.
- Import: Tick all tidy-ups; "Import all N cards".

v0.63
-----
- Import: cards are any element whose classes include "scenario" (e.g.
  "scenario ntrcard"); ntrcard / hrpcard / anticard set the card type; the
  scene name comes from the Scene Name field or the scene-title subtitle.
- Main character: card header "Primary:", then Character / Primary Character
  / Name fields, then the first word of Character's Personality plus the
  surname found in the card. Antagonist from its own field. Series lines that
  aren't a named series are filed as Standalone.
- Preview warns when the file has more Built boxes / Copy buttons than cards
  read.

v0.64
-----
- Improve (bonus:improvePlan / applyTidy / revisePreview / reviseApply) works
  on any card in the week. The panel uses the data-based estimate; keeping a
  revised day/NTR card marks it imported so its score stays on that estimate.

v0.65
-----
- weekImport.fixRequest: plain-language request built from the card's
  closest engine and the strongest engines (bonus.js now returns engineFit
  and topEngines), with plain names for every relationship, opening and
  setting, missing parts to work in, and approved-tag suggestions.
- eventAdapt: "guild" alone no longer counts as RPG.
- fieldWriter.matchField / renderer bpMatch: {{Name1}}/{{Name2}} in a label
  match the character's name in the card's field label.

v0.66
-----
- cardParser: labels glued to their value at the start of an indented line;
  numbered multi-character labels; the title block (scene name + "Primaries:"
  names and ages); Scene Name from the title block counts as the user's own.
- bonus.buildBonusFromIdea refuses (with a message) a paste that mentions 4+
  field names but can't be read, instead of inventing a card.

v0.67
-----
- Ratings from lounge badges (worker.apply_badges): reads the badge on the
  first cards of the lounge, finds the data field whose values match them
  exactly and labels every bot from it; otherwise scrolls the whole lounge
  and reads each badge. Stored as ratingLabel, which Performance prefers.
- Pull details merge every details message from a pull.

v0.68
-----
- BADGE_JS reads each small pill's whole text (so "18"+"+" reads "18+"),
  class names, alt/title/aria labels and image file names; apply_badges only
  learns a field when the sample contains 18+ badges, otherwise reads every
  badge.
- Bot pulls: step list (Reading your bots, Feed positions, Ratings) and an
  overall bar across accounts; batch-start carries account/accountIndex/
  accountCount.

v0.69
-----
- AI writer through the Cloudflare relay (ai.json holds the relay address and
  app code; personal edition only, removed from the shareable build).
  lib/aiRelay.js: streaming, retries with backoff, continue-where-it-stopped,
  plain error messages. lib/aiBotWriter.js: whole bot in 5 steps, saved per
  step in userData/ai-jobs, resumable; marks AI-written parts as touched so
  the auto-fill never overwrites them. The old key-in-Settings OpenRouter
  writer (lib/aiWriter.js) was removed.

v0.69 (continued)
-----------------
- Release day for Bonus ideas (main.js placeBonus / reattachBonus / isAdded,
  IPC bonus:add(idea, day) and bonus:move). Cards on a day carry addedBonus
  and keep it through regenerate; they are kept and renumbered after a new
  week or an import, and scored with the data-based estimate.

v0.70
-----
- renderer/pov.js loaded in the window; Bot Builder reader toggle (v.pov),
  applied after Fill, Auto-complete, a pasted story and the AI writer (which
  is also told the style). Narration only; 99% exact round trips on 3,045
  generated passages, dialogue never changed.
- Saved bots: state.savedBots keyed by card and template (builder:saveBot /
  savedBots / loadSavedBot / deleteSavedBot); Saved bot button on cards.
- ai:writeWeek: generateWeekLocal plan -> AiBotWriter.writeWeek (9 steps,
  per-day JSON cards with the blueprint's fields) -> import review.

v0.71
-----
- Startup: duplicate ipcMain registrations are ignored with a log line (a
  second 'builder:savedBots' from a parallel saved-bots system had stopped
  every later registration, including builder:export). That system was
  removed; saved bots use state.savedBots keyed card::template.
- renderer/eventrules.js (shared): fromParsed (tags, figure, bracketed
  example lists as signs, reminders), check, safeFix. ai:eventRules adds AI
  rules for personality/scenario/greeting/image. Bot Builder event panel,
  gate on copy/save, Fix for event. Writer: event rules in prompts + event
  step (AI fix, then safeFix).
- Writer archetype: from the card's Primary Archetypal Personality field,
  must be on the template list, else stop. improveCard (2 gentle rounds,
  word-overlap < 0.45 flagged as a rewrite); (writeWeek no longer runs an 80+ pass).
- botTemplates: archetype lists in the new wordings, "Mandatory archetype
  tag" lines, [bracketed] lines skipped as tags, "[... FIELD]:" lines are
  fill-in boxes, greeting.locks carried into the story brief.

v0.67 (AI replies)
------------------
- aiBotWriter: replies in "@@key" blocks (parseBlocks), JSON still accepted
  with repairJSON (raw line breaks, trailing commas, smart quotes); _ask runs
  a step, validates the parsed reply and retries once with a clear note; an
  unreadable reply is shown in the progress window. Week cards use
  "=== CARD n ===" + @@ blocks. applyChanges shared by template and event fixes.


STORY ENGINE (Bot Builder)
--------------------------
The Story engine decides how a bot paces, feels and behaves, from the character, her archetype, her personality text and the scenario. It picks one topic each for Pacing, Tone and Character from a library built from the "I Dream of Nemo" prompt PDF (STORY_ENGINE_TOPICS.txt lists every entry of the PDF and why it was used or left out).
- Click Write with AI. Step 1 is Choose the story, step 2 is Plan the Greeting, then Write bot with this plan.
- Auto shows the three best matches for each group and why they fit; the best is selected for you and you click another to use it. Pick shows a list of every topic, with your Auto selections already chosen. Off writes the bot without it.
- The Details box re-picks the matches (for example "make it angsty and fast-paced").
- Every bot also gets a character drive: she wants and fears something, has a visible tell, starts something herself and pushes back. Quiet archetypes also get a stoic guard.
- The topics used are kept on the bot, so Rewrite uses the same ones. Write with AI shows them again and you can change them. The bots of one week rotate to different topics.
- After writing, the app tells you if she still only agrees, never asks or refuses, or speaks in very short clipped lines.


V1.2.0 INTRODUCTION DESIGNER
In Bot Builder choose Build Introduction to open the dedicated visual Introduction Designer.
Design static HTML visually, save local templates, copy JuicyChat-ready code (15,000 character maximum),
or click Save and Return to place the finished HTML in the active bot's Introduction.
The separate Introduction Designer does not change the WebP Maker or other Studio features.
