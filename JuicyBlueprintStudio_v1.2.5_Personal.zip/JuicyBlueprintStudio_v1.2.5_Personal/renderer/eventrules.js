/* Event rules: turn any event announcement into a rulebook, then check a bot against it.
   Every event is different, so nothing here is tied to one event. Each rule says which part
   of the bot it applies to (personality, scenario, greeting, image, tags, publishing) and how to
   recognise it (signs: words or phrases, any one of which shows the rule is met).
   - fromParsed(): what the app can read without AI (tags, counts, bracketed example lists, reminders)
   - check(): runs the rulebook over a built bot (works in the window and in the AI writer)        */
(function () {
  const PARTS = ['personality', 'scenario', 'greeting', 'image', 'tags', 'publishing'];
  const esc = s => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const clean = s => String(s || '').replace(/^\s*(or|and)\s+/i, '').replace(/\s*(or other|and other|etc\.?|or similar|or more).*$/i, '').replace(/[.;:]+$/, '').trim();

  // a word/phrase counts when it appears, but not when negated just before it ("no horns", "without fangs")
  // singular/plural and accents don't matter: "horns" matches "a horn", "cafés" matches "the cafe"
  const plain = x => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const forms = w => [...new Set([w, w.replace(/s$/i, ''), w.replace(/es$/i, ''), w.replace(/ies$/i, 'y'), w + 's', w + 'es', w.replace(/y$/i, 'ies')])].filter(x => x.length >= 2);
  function has(text, sign) {
    const t0 = plain(text), w0 = plain(String(sign || '').trim()); if (!w0) return false;
    return forms(w0).some(w => hasOne(t0, w) || (w.includes(' ') && hasOne(t0, w.split(' ').slice(-1)[0]) && hasOne(t0, w.split(' ')[0])));
  }
  function hasOne(text, sign) {
    const t = String(text || ''), w = String(sign || '').trim(); if (!w) return false;
    const re = new RegExp(`(^|[^A-Za-z])${esc(w).replace(/\s+/g, '\\s+')}(?=$|[^A-Za-z])`, 'gi'); let m;
    while ((m = re.exec(t))) { const before = t.slice(Math.max(0, m.index - 28), m.index).toLowerCase(); if (!/\b(no|not|never|without|n't|neither|nor)\b[^.,;]*$/.test(before)) return true; }
    return false;
  }

  // which part a requirement line is about
  function partOf(line) {
    const l = line.toLowerCase();
    if (/\b(pfp|profile picture|figure|image|appearance|visible|traits?|clothing|wear|outfit|uniform|accessor|background|environment|art|picture)\b/.test(l)) return 'image';
    if (/\b(tag|tags)\b/.test(l)) return 'tags';
    if (/\b(public|publish|created after|create .* after|event begins|one event|multiple event|tos|terms)\b/.test(l)) return 'publishing';
    if (/\b(personality|behaviou?r|character must|archetype)\b/.test(l)) return 'personality';
    if (/\b(setting|world|location|theme|story|scenario)\b/.test(l)) return 'scenario';
    return 'publishing';
  }

  // what a theme looks like on a character: the visible traits that show "monsters", "ghosts", "witches"... in the Image Generation
  // appearance keywords (a theme word like "ghosts" is rarely written in a keyword list, but "translucent" or "spectral" is)
  const VISUAL = [
    [/monster|creature|beast|abomination/, ['horns', 'fangs', 'claws', 'scales', 'pointed ears', 'glowing eyes', 'slit pupils', 'tail', 'wings', 'fur', 'tentacles']],
    [/demon|devil|\bimps?\b|succub|incub|infernal/, ['horns', 'tail', 'wings', 'red eyes', 'glowing eyes', 'fangs', 'pointed ears', 'slit pupils', 'red skin', 'black claws']],
    [/ghost|spirit|specter|spectre|phantom|haunt|wraith|poltergeist/, ['translucent', 'spectral', 'ethereal', 'ghostly', 'semi-transparent', 'faint glow', 'wispy', 'pale blue', 'floating']],
    [/vampire|nosferatu|undead|zombie|ghoul|corpse|\blich\b|revenant/, ['fangs', 'pale skin', 'red eyes', 'sunken eyes', 'stitched scars', 'grey skin', 'pallor', 'bloodstained', 'cracked skin']],
    [/slasher|killer|murder|psycho|serial/, ['scar', 'scars', 'stitches', 'blood spatter', 'bloodstained', 'mask', 'hockey mask', 'bandages', 'cracked mask']],
    [/werewolf|wolf|lycan|beastkin/, ['fur', 'wolf ears', 'fangs', 'claws', 'amber eyes', 'yellow eyes', 'tail']],
    [/witch|warlock|sorcer|\bmage\b|wizard|\bhex/, ['witch hat', 'pointed hat', 'glowing runes', 'sigils', 'amulet', 'star charm', 'violet eyes']],
    [/\bfae\b|fairy|fairies|\belf\b|elves|pixie|sprite/, ['pointed ears', 'wings', 'glitter', 'iridescent', 'floral crown']],
    [/mummy|skeleton|\bbones?\b/, ['bandages', 'bone markings', 'hollow eyes', 'skull face paint']],
    [/dragon|drake/, ['scales', 'horns', 'tail', 'wings', 'slit pupils', 'gold eyes']],
    [/slime|\booze\b/, ['translucent skin', 'gel hair', 'dripping', 'glossy skin']],
    [/mermaid|siren/, ['fins', 'scales', 'gills', 'seashell', 'iridescent skin']],
    [/kitsune|nekomimi|\bcat\b|\bfox\b|bunny/, ['animal ears', 'tail', 'whiskers', 'slit pupils', 'fur']],
  ];
  // A picture rule about monsters, ghosts, vampires and other creatures is not met by one soft detail. "pointed ears" alone is an elf and "pale skin" alone is a person,
  // so the picture needs at least two visible traits and at least one of them a real creature trait. (Before, any ONE word from the announcement's list was enough,
  // and the app's own quick fix added the first word of that list, "horns", to every picture.)
  const CREATURE_WORDS = /\b(monsters?|creatures?|ghosts?|vampires?|demons?|slashers?|werewol(?:f|ves)|undead|zombies?|supernatural|spooky|haunted)\b/i;
  const creatureImage = r => !!r && r.part === 'image' && r.mode !== 'figure' && r.mode !== 'reminder' && CREATURE_WORDS.test(`${r.requirement || ''}`);
  const WEAK = new Set(['pointed ears', 'elf ears', 'pale skin', 'pallor', 'unusual eyes', 'slit pupils', 'red eyes', 'amber eyes', 'yellow eyes', 'gold eyes', 'violet eyes', 'glitter', 'star charm', 'amulet', 'iridescent', 'pale blue', 'floral crown']);
  const STRONG = ['horns', 'fangs', 'claws', 'scales', 'tail', 'wings', 'fur', 'tentacles', 'translucent', 'spectral', 'ghostly', 'ethereal', 'stitches', 'stitched scars', 'scars', 'scar', 'mask', 'bandages', 'gills', 'fins', 'antlers', 'hooves', 'talons', 'feathers', 'extra eyes', 'many eyes', 'third eye', 'hollow eyes', 'sunken eyes', 'glowing eyes', 'rotting', 'decayed', 'cracked skin', 'bone markings', 'skull', 'black eyes', 'red skin', 'blue skin', 'green skin', 'grey skin', 'gray skin', 'forked tongue', 'snake hair', 'stone skin', 'floating', 'wispy', 'blood spatter', 'bloodstained', 'wolf ears', 'animal ears'];
  const visualCues = text => { const t = String(text || '').toLowerCase(), out = []; for (const [re, cues] of VISUAL) if (re.test(t)) out.push(...cues); return [...new Set(out)]; };

  // what the app can read from the announcement without AI
  // the things a Theme or Setting sentence names: the last word or two of each item in its lists
  const KW_STOP = new Set(('the a an and or of to in on at for with from by as is are be that this these those it its their your you they them we our ' +
    'create bots bot characters character stories story relationships worlds world explore show us whether maybe simply just normal part daily routine ' +
    'side live lives living go beyond ordinary things all other kind sort way ways any every each some more most where when what who how which ' +
    'comedy romance horror drama chaos action mystery humor humour fun dark genuinely terrifying wholesome eerie encounters friendships comes come brings bring invites invite spooky simply blend mundane collide').split(/\s+/));
  function keywords(text) {
    const out = [];
    // what a sentence says is NOT so ("the monsters aren't waiting in haunted castles") never becomes a sign
    const t0 = String(text || '').toLowerCase().replace(/[“”"()]/g, ' ').replace(/\b(aren't|isn't|not|never|no longer|instead of|rather than|unlike)\b[^.;,]*(,[^.;]*?\bor\b[^.;,]*)?/g, ' ');
    for (let part of t0.split(/[,;.:!?]|\band\b|\bor\b|\bwith\b|\bfrom\b|\bto\b|\bwhere\b|\bwhen\b|\bthat\b|\binto\b|\bin\b/)) {
      const w = part.trim().split(/\s+/).filter(x => x && !KW_STOP.has(x) && x.length >= 4 && /^[a-zà-ÿ'-]+$/.test(x));
      if (!w.length) continue;
      const k = w.slice(-2).join(' ');                               // "spooky creatures", "modern life", "neighborhoods"
      if (!out.includes(k)) out.push(k);
    }
    return out.slice(0, 14);
  }
  function fromParsed(P0) {
    // tags that describe men are never turned into a rule (every card is a woman), unless one is the only tag the event lists
    const P = (() => { const t = P0.opportunityTags || [], M = ['himbo', 'bbm', 'husband', 'gay', 'monster boy', 'petalboy', 'femboy', 'dilf'], f = t.filter(x => !M.includes(String(x).toLowerCase().replace(/[^a-z]+/g, ' ').trim())); return f.length && f.length !== t.length ? {...P0, opportunityTags: f} : P0; })();
    const rules = [], raw = String(P.rawOriginal || '');
    const intro = raw.split(/\n\s*\n/).slice(0, 3).find(par => par.length > 120 && !/^(theme|setting|event)/i.test(par.trim())) || '';
    const add = r => rules.push({id: 'r' + rules.length, source: 'text', ...r});
    if (P.eventTag) add({part: 'tags', requirement: `Use the event tag "${P.eventTag}" (your template's "Event" tag is that slot)`, signs: [P.eventTag, 'Event'], mode: 'any'});
    if ((P.opportunityTags || []).length) add({part: 'tags', requirement: `Use at least ${P.minOpportunityTags || 1} opportunity tag${(P.minOpportunityTags || 1) > 1 ? 's' : ''} (any of: ${P.opportunityTags.join(', ')}); every one the bot carries must be built into its story`, signs: P.opportunityTags, mode: 'count', n: P.minOpportunityTags || 1});
    if (P.requiresFigure) add({part: 'image', requirement: 'The bot must have a figure (an image)', signs: [], mode: 'figure'});
    // bracketed example lists: "(horns, fangs, claws, ...)" become signs for the line they sit in
    for (const line of raw.split(/\n/)) {
      const m = line.match(/^(.*?)\(([^()]{8,})\)\s*$/) || line.match(/^(.*?)\(([^()]*,[^()]*)\)/);
      if (!m) continue;
      const items = m[2].split(/,\s*|\bor\b/).map(clean).filter(x => x && x.length <= 40 && !/^(e\.g|such as|like)$/i.test(x));
      if (items.length < 2) continue;
      const head = m[1].replace(/^[\s\-*•]+/, '').trim();
      add({part: partOf(head + ' ' + m[2]), requirement: head || `Include one of: ${items.slice(0, 6).join(', ')}`, signs: items, mode: 'any'});
    }
    // theme and setting become real checks from the words they name (no AI): the theme's subjects shape the personality,
    // the setting's places and world shape the scenario. Too little to go on, and they stay reminders to tick.
    // who the character is (the theme's subjects) vs where the story happens (place and world words)
    const PLACE = /modern|everyday|\blife\b|neighbo|caf|workplace|office|city|street|world|society|routine|home|apartment|town|school|university|campus|shop|\bbar\b|club|park|\bbus\b|train|kingdom|realm|castle|forest|village|daily|humans/;
    // the event's own name and the season it runs in ("Monsters Next Door", "This Halloween") say nothing about who the character is
    const nameWords = new Set(`${P.name || ''} ${P.eventTag || ''}`.toLowerCase().split(/[^\p{L}]+/u).filter(w => w.length > 2));
    const SEASON = /^(halloween|christmas|xmas|valentine'?s?|easter|thanksgiving|new year|summer|winter|spring|autumn|fall|holiday|holidays|season|seasonal|spooky season|next door)$/i;
    const themeKw = [...new Set([...keywords(`${intro}. ${P.theme || ''}`)])].filter(k => !PLACE.test(k) && !SEASON.test(k) && !/^(about|into|from|with|over|under|around|after|before)\b/i.test(k) && !/^(noise|things?|stuff|days?|nights?|times?|ways?)$/i.test(k) && !(k.split(/\s+/).every(w => nameWords.has(w)) && !/^monsters?$/.test(k))).slice(0, 12);
    // the setting's own place words, places named elsewhere in the announcement, and (for a modern, everyday setting)
    // the ordinary places of modern life
    const MODERN = ['apartment', 'flat', 'office', 'cafe', 'café', 'coffee shop', 'university', 'college', 'campus', 'dorm', 'school', 'street', 'bus', 'train', 'subway',
      'shop', 'store', 'supermarket', 'bar', 'club', 'gym', 'hospital', 'library', 'neighborhood', 'neighbourhood', 'workplace', 'city', 'suburb', 'restaurant', 'diner', 'motel', 'hotel', 'laundromat', 'parking lot', 'convenience store', 'phone', 'commute', 'rent', 'shift', 'coworker', 'roommate', 'landlord'];
    const placeWords = t => keywords(t).filter(k => PLACE.test(k) && !/^(humans|creatures)/.test(k));
    const named = (`${raw}`.toLowerCase().match(/\b(universit\w*|college|office|caf[eé]\w*|bus(?: stop)?|apartment\w*|shop\w*|workplace\w*|neighbou?rhood\w*|street\w*|school|librar\w*|hospital|bar|gym|train|subway|diner)\b/g) || []);
    const modern = /modern|everyday|contemporary|present[- ]day|slice[- ]of[- ]life/i.test(`${P.setting || ''} ${P.theme || ''}`);
    const setKw = [...new Set([...placeWords(P.setting), ...named, ...(modern ? ['modern', 'everyday', ...MODERN] : [])])].filter(k => !themeKw.includes(k));
    const short = t => String(t || '').replace(/\s+/g, ' ').trim().slice(0, 140);
    if (P.theme) add(themeKw.length >= 3 ? {part: 'personality', requirement: `On theme: the character is part of it (${themeKw.slice(0, 6).join(', ')})`, signs: themeKw, mode: 'any', fixHint: `Make the character one of these: ${themeKw.slice(0, 8).join(', ')}.`} : {part: 'scenario', requirement: `On theme: ${short(P.theme)}`, signs: [], mode: 'reminder'});
    if (P.setting) add(setKw.length >= 3 ? {part: 'scenario', requirement: `In the event's setting (${setKw.slice(0, 6).join(', ')})`, signs: setKw, mode: 'any', fixHint: `Place the story in this setting: ${short(P.setting)}`} : {part: 'scenario', requirement: `In the event's setting: ${short(P.setting)}`, signs: [], mode: 'reminder'});
    if (P.mustRemainPublic) add({part: 'publishing', requirement: 'Keep the bot public', signs: [], mode: 'reminder'});
    if (P.noOtherEventTags) add({part: 'publishing', requirement: 'Do not add any other event\'s tag', signs: [], mode: 'reminder'});
    if (/create[^.]*after the event begins|must create event bot after/i.test(raw) || P.createdAfterStart) add({part: 'publishing', requirement: `Create the bot after the event begins${P.startDate ? ` (${P.startDate})` : ''}`, signs: [], mode: 'reminder'});
    // the theme shapes how the character LOOKS as well as who she is: the appearance keywords must show it. Only an AI can write that well, so the rule is marked aiOnly.
    // the creator's choices ("a mysterious vampire, a wild werewolf" next to the Opportunity Tags list) are a menu, never what every bot must look like
    const menuOut = t => { let o = String(t || ''); if ((P.opportunityTags || []).length >= 2) for (const tag of P.opportunityTags) for (const h of String(tag).split('/')) { const w = h.trim(); if (w.length > 2) o = o.replace(new RegExp('\\b' + w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'gi'), ' '); } return o; };
    const visual = visualCues(menuOut(`${P.theme || ''} ${intro}`));
    const menuEvent = (P.opportunityTags || []).length >= 2;
    if (P.theme && (menuEvent ? visual.length > 0 : (themeKw.length >= 3 || visual.length))) add({part: 'image', requirement: menuEvent ? 'The appearance shows the theme' : `The appearance shows the theme (${(themeKw.slice(0, 4).join(', ')) || short(P.theme)})`, signs: [...visual, ...themeKw], mode: 'any', aiOnly: true,
      fixHint: `Add one or two visible traits from the theme to the appearance keywords (for example ${visual.slice(0, 6).join(', ') || 'a visible supernatural trait'}), keeping the existing keywords. Write short comma-separated keywords, never sentences.`});
    return {source: 'text', builtAt: new Date().toISOString(), event: P.name || P.eventTag || '', rules};
  }

  // what each part of a built bot says
  function texts(spec, v, c) {
    const sec = (c && c.sec) || {};
    const tags = [...new Set([...(v.tags || []), v.archetype || '', ...String((sec.tags && sec.tags.body) || '').split(/[\n,]/)].map(x => String(x).trim()).filter(Boolean))];
    return {
      personality: (sec.personality && sec.personality.body) || '',
      scenario: [(sec.scenario && sec.scenario.body) || '', (sec.greeting && (sec.greeting.prose || sec.greeting.body)) || ''].join('\n'),
      greeting: (sec.greeting && (sec.greeting.prose || sec.greeting.body)) || '',
      image: [(sec.image && sec.image.body) || '', (sec.scene && sec.scene.body) || ''].join('\n'),
      tags, figure: !!(spec && spec.image && spec.image.present),
    };
  }

  // run the rulebook: [{rule, ok, missing}] ; reminders are ok once ticked
  function check(rulebook, spec, v, c) {
    if (!rulebook || !(rulebook.rules || []).length) return [];
    const T = texts(spec, v, c), ticks = (v && v.eventTicks) || {};
    // the personality must show the opportunity tag the bot uses (or, if it uses none yet, the one that fits it best)
    const extra = [];
    for (const r of rulebook.rules.filter(x => x.part === 'tags' && x.mode === 'count' && (x.signs || []).length)) {
      const used = r.signs.filter(s => T.tags.some(t => sameTag(s, t)));
      for (const tag of (used.length ? used : [bestOpp(r.signs, T)]))
        extra.push({id: `opp:${tag}`, source: 'tag', part: 'personality', requirement: `The personality reflects the opportunity tag "${tag}"`, signs: oppSigns(tag), mode: 'any', oppTag: tag,
          fixHint: `Make "${tag}" part of who she is: her traits, habits, behaviour and how she speaks, not just a mention.`});
    }
    return [...rulebook.rules, ...extra].map(r => {
      if (r.mode === 'reminder') return {rule: r, ok: !!ticks[r.id], reminder: true};
      // a template without an image section can't be checked for picture rules: they become reminders to tick
      if ((r.part === 'image' || r.mode === 'figure') && !T.figure) return {rule: r, ok: !!ticks[r.id], reminder: true, noImageSection: true};
      if (r.mode === 'figure') return {rule: r, ok: T.figure};
      if (r.part === 'tags') {
        const n = (r.signs || []).filter(s => T.tags.some(t => sameTag(s, t))).length;
        if (r.mode === 'count') return {rule: r, T, ok: n >= (r.n || 1), found: n, missing: (r.signs || []).slice(0, 4)};   // at least the number the event names
        return {rule: r, ok: n >= 1, found: n};
      }
      const text = T[r.part] || '';
      if ((r.all || []).length) { const miss = r.all.filter(group => !group.some(s => has(text, s))); return {rule: r, ok: !miss.length, missing: miss.map(g => g[0])}; }
      if (creatureImage(r)) {
        // an exact phrase, not the loose word match used elsewhere ("green skin" must not be found in "gray-green eyes ... fair skin")
        const flat = ' ' + String(text).toLowerCase().replace(/[-_/]+/g, ' ').replace(/[^a-z0-9' ]+/g, ' ').replace(/\s+/g, ' ') + ' ';
        const phrase = w => { const p = String(w).toLowerCase().replace(/[-_/]+/g, ' ').replace(/[^a-z0-9' ]+/g, ' ').replace(/\s+/g, ' ').trim(); return !!p && (flat.includes(' ' + p + ' ') || flat.includes(' ' + p + 's ') || flat.includes(' ' + p + 'es ')); };
        const hit = [...new Set([...(r.signs || []), ...STRONG].filter(phrase).map(w => String(w).toLowerCase()))], strong = hit.filter(w => !WEAK.has(w));
        const okC = strong.length >= 2 || (strong.length >= 1 && hit.length >= 2);
        return {rule: r, ok: okC, found: hit.length, missing: okC ? [] : ['two or more clear traits of one creature kind (fangs, claws, scales, stitched scars, translucent skin, a mask, tentacles...), not only pointed ears or pale skin']};
      }
      const ok = (r.signs || []).some(s => has(text, s));
      return {rule: r, ok, missing: ok ? [] : (r.signs || []).slice(0, 4)};
    });
  }

  // fixes that never touch the story: add a missing event/opportunity tag, or one item from the
  // announcement's own list to the right part of the Image Generation section
  function safeFix(results, v) {
    const done = [], left = [];
    for (const x of results) {
      if (x.ok || x.reminder) continue; const r = x.rule;
      if (r.part === 'tags' && r.mode === 'count') {
        // at least N opportunity tags: add the best fitting if there are too few
        const need = r.n || 1, T = x.T || {personality: '', scenario: '', greeting: ''}; v.tags = v.tags || [];
        const isOpp = t => (r.signs || []).some(s => sameTag(s, t));
        let used = v.tags.filter(isOpp);
        // more than the event's minimum is fine: every tag the bot carries is checked against its story instead of being cut
        while (v.tags.filter(isOpp).length < need) { const pool = (r.signs || []).filter(t => !v.tags.some(x => sameTag(t, x))); if (!pool.length) break; v.tags.push(bestOpp(pool, T)); }
        done.push(r.requirement);
      }
      else if (r.part === 'tags') { const add = (r.signs || []).filter(t => t !== 'Event').slice(0, 1); v.tags = v.tags || []; for (const t of add) if (!v.tags.includes(t)) v.tags.push(t); done.push(r.requirement); }
      else if (r.aiOnly || creatureImage(r)) left.push(r.requirement);              // a theme on the character's looks (or a creature's body): only the AI writes that well, the app never adds a word from the list by itself
      else if (r.part === 'image' && (r.signs || []).length) {
        const low = r.requirement.toLowerCase(), k = /cloth|wear|outfit|uniform|accessor/.test(low) ? 'clothing' : /background|environment|setting/.test(low) ? 'action' : 'appearance';
        v.img = v.img || {}; v.img[k] = `${String(v.img[k] || '').replace(/[.,\s]+$/, '')}${v.img[k] ? ', ' : ''}${r.signs[0]}`; done.push(r.requirement);
      } else left.push(r.requirement);
    }
    return {done, left};
  }

  // how a character's personality shows each opportunity tag (any tag not listed falls back to its own words)
  const OPP_SIGNS = {
    'magic': ['magic', 'magical', 'spell', 'witch', 'mage', 'wizard', 'sorcer', 'sorceress', 'enchant', 'enchanted', 'arcane', 'rune', 'ritual', 'hex', 'curse', 'potion', 'conjure', 'mana', 'familiar', 'warding', 'alchemy'],
    'rpg': ['quest', 'guild', 'adventurer', 'party', 'dungeon', 'level', 'class', 'skill', 'loot', 'raid', 'mission', 'rank', 'stats', 'healer', 'tank', 'ranger', 'paladin', 'rogue'],
    'kemonomimi': ['ears', 'tail', 'fox', 'cat', 'wolf', 'bunny', 'rabbit', 'fur', 'paws', 'purr', 'kemonomimi', 'nekomimi', 'whiskers', 'scent', 'instinct'],
    'monster girl': ['monster', 'lamia', 'slime', 'harpy', 'centaur', 'arachne', 'succubus', 'demon', 'scales', 'horns', 'fangs', 'claws', 'wings', 'tentacle', 'mermaid', 'dragon', 'beast'],
    'hero': ['hero', 'heroic', 'protect', 'protector', 'champion', 'chosen', 'savior', 'saviour', 'duty', 'oath', 'sworn', 'justice', 'rescue', 'brave', 'courage', 'sword', 'knight'],
    'isekai': ['another world', 'other world', 'otherworld', 'isekai', 'transported', 'summoned', 'reincarnated', 'portal', 'homesick', 'unfamiliar world', 'from earth', 'old world'],
    'vampire': ['vampire', 'blood', 'fangs', 'immortal', 'undead', 'sunlight', 'centuries'],
    'demon': ['demon', 'hell', 'infernal', 'horns', 'contract', 'soul', 'sin'],
    'elf': ['elf', 'elven', 'pointed ears', 'forest', 'centuries', 'grace'],
    'fantasy': ['magic', 'kingdom', 'realm', 'quest', 'sword', 'spell', 'dragon', 'castle'],
    'supernatural': ['ghost', 'spirit', 'haunted', 'curse', 'supernatural', 'possessed', 'psychic', 'demon'],
  };
  const oppSigns = t => OPP_SIGNS[String(t).toLowerCase()] || (() => { const n = String(t).toLowerCase(), k = Object.keys(OPP_SIGNS).find(x => x.includes('/') && x.split('/').map(y => y.trim()).includes(n)); return k ? OPP_SIGNS[k] : null; })() || String(t).toLowerCase().split(/[\s/-]+/).filter(w => w.length > 2);
  // the opportunity tag that fits a bot best: the one whose signs show up most in its personality, scenario and greeting
  // the event's tags are exactly as JuicyChat's announcement writes them ("Mafia/Gang" is not "Mafia")
  const sameTag = (sign, tag) => String(sign).toLowerCase() === String(tag).toLowerCase();
  function bestOpp(list, T) { const txt = `${T.personality}\n${T.scenario}\n${T.greeting}`; let best = list[0], top = -1; for (const t of list) { const n = oppSigns(t).filter(w => has(txt, w)).length; if (n > top) { top = n; best = t; } } return best; }

  const api = {sameTag, PARTS, has, fromParsed, check, texts, safeFix, oppSigns, OPP_SIGNS, visualCues};
  if (typeof window !== 'undefined') window.EventRules = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
