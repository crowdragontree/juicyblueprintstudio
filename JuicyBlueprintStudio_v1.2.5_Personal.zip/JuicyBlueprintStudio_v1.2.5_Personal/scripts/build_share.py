"""Build the shareable edition from the personal edition, the same way every time.
Usage: python3 scripts/build_share.py <personal app folder> <output folder>"""
import json, os, re, shutil, sys
src, out = sys.argv[1], sys.argv[2]
if os.path.exists(out): shutil.rmtree(out)
shutil.copytree(src, out, ignore=shutil.ignore_patterns('__pycache__', 'node_modules', '.scanner-venv', '.runtime', '_*.js', '_*.py'))
j = lambda *p: os.path.join(out, *p)
# where friends' copies look for updates: set JBS_UPDATE_SOURCE=https://github.com/OWNER/REPO (a public repo with the zips attached to its Releases) to use GitHub; without it the Google Drive folder below is used
UPDATE_FOLDER = os.environ.get('JBS_UPDATE_SOURCE') or 'https://drive.google.com/drive/folders/1wbTaY2L1LDnWgnQ0PeOpWhuAp9zZAM78'
open(j('edition.json'), 'w').write(json.dumps({'edition': 'share', 'updateFolder': UPDATE_FOLDER}) + '\n')
# the shareable edition's own release notes (never the personal ones)
shutil.copy(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'SHARE_CHANGELOG.txt'), j('CHANGELOG.txt'))
for f in ['lib/incidents-personal.js', 'lib/preventableGen.js', 'lib/preventableSeeds.js', 'lib/preventableModes.js', 'lib/preventableMode3.js', 'lib/preventableV2.js', 'lib/postNtrGen.js', 'lib/postNtrSeeds.js', 'lib/thirdGender.js']: os.path.exists(j(f)) and os.remove(j(f))
# the NTR-tab helpers belong to the personal edition (this edition has no NTR cards): inert stand-ins keep the same calls working
open(j('lib/ntrSetup.js'), 'w').write("module.exports = {ensure: () => false, removeBuiltPreventableSetup: () => false};\n")
open(j('lib/thirdParty.js'), 'w').write("module.exports = {rename: () => false, fillRows: () => false, isThirdPartyCard: () => false};\n")
# the sandbox (a test copy of the app on its own data) is for testing only: the shareable edition that goes to friends has no launchers and the code is switched off.
# Pass --test as a third argument to keep it (for a copy you test yourself, never one you send).
if '--test' not in sys.argv:
    for f in ['START_SANDBOX.bat', 'START_SANDBOX_EMPTY.bat', 'RESET_SANDBOX.bat']: os.path.exists(j(f)) and os.remove(j(f))
    open(j('lib/sandbox.js'), 'w').write("module.exports = {on: () => false, wantsCopy: () => false, folderName: () => '', seed: () => 0, skipped: () => false, hasData: () => false};\n")
# your friends use the relay, but never get its admin password (the relay controls are yours only)
if os.path.exists(j('ai.json')):
    a = json.load(open(j('ai.json'))); a.pop('admin', None); open(j('ai.json'), 'w').write(json.dumps(a, indent=2) + '\n')   # ai.json stays: friends use your relay, within its per-computer and total caps
shutil.rmtree(j('resources', 'rules'), ignore_errors=True)
for f in os.listdir(j('resources', 'bot-templates')): os.remove(j('resources', 'bot-templates', f))
open(j('resources', 'bot-templates', 'README.md'), 'w').write('This folder is intentionally empty. Add your own bot templates inside the app:\nBot Builder > "+ Add template..." (they are stored in the app\'s data folder).\n')
# the NTR lane's own self-test (it needs the NTR cards, which this edition does not have) stays with the personal edition
os.path.exists(j('scripts', 'ntrlane-selftest.js')) and os.remove(j('scripts', 'ntrlane-selftest.js'))
_pk = open(j('package.json'), encoding='utf8').read(); _pk2 = _pk.replace(' && node scripts/ntrlane-selftest.js', ''); assert _pk2 != _pk; open(j('package.json'), 'w', encoding='utf8').write(_pk2)
d = json.load(open(j('package.json'))); d['name'] = 'juicy-blueprint-studio-shared'; d['productName'] = 'Juicy Blueprint Studio'; d['description'] = 'Plan, build and track JuicyChat character bots.'
json.dump(d, open(j('package.json'), 'w'), indent=2)
t = open(j('scripts', 'selftest.js')).read()
t = t.replace("assert.equal(core.length,21);assert.equal(week.ntr.length,7);", "assert.equal(core.length,21);assert.equal(week.ntr.length,0);")
t = '\n'.join(l for l in t.split('\n') if not re.search(r"ANTI-NTR Series'\)\.length|Futa Friday Series'\)\.length|Primary Character Futanari'\]==='Yes'\)\.length|weekly_blueprint_rules\.txt'\)|weekly_blueprint_template\.html'\)", l))
open(j('scripts', 'selftest.js'), 'w').write(t)
a = open(j('renderer', 'autofill.js')).read().replace('    // PigeonGuy-style guided fields', '    // guided-field templates'); open(j('renderer', 'autofill.js'), 'w').write(a)
os.path.exists(j('scripts', 'build_share.py')) and os.remove(j('scripts', 'build_share.py'))
shutil.copy(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'SHARE_README.txt'), j('README.txt'))
os.path.exists(j('scripts', 'SHARE_README.txt')) and os.remove(j('scripts', 'SHARE_README.txt'))
os.path.exists(j('scripts', 'SHARE_CHANGELOG.txt')) and os.remove(j('scripts', 'SHARE_CHANGELOG.txt'))
# the personal edition keeps men's tags (Himbo, Husband, Gay...) off its women; friends make characters of every kind, so the shareable edition keeps every tag
e = open(j('lib', 'eventAdapt.js')).read()
e2 = re.sub(r"const MALE_TAGS = \[[^\]]*\];", "const MALE_TAGS = [];", e); assert e2 != e; open(j('lib', 'eventAdapt.js'), 'w').write(e2)
r = open(j('renderer', 'eventrules.js')).read()
r2 = re.sub(r"M = \['himbo'[^\]]*\],", "M = [],", r); assert r2 != r; open(j('renderer', 'eventrules.js'), 'w').write(r2)
# automatic backup stays in the shareable edition: each person makes their own Google script and pastes their own URL (never the owner's)
os.path.exists(j('backup.json')) and os.remove(j('backup.json'))
g = open(j('GOOGLE_BACKUP_SETUP.txt'), encoding='utf8').read()
g2 = re.sub(r"Giving the same URL to someone else.*?treat it like a password\.\n", "Keep the URL private: anyone who has it can store and read backups in your Drive.\nEvery person makes their own script and URL in their own Google account.\n", g, flags=re.S); assert g2 != g
open(j('GOOGLE_BACKUP_SETUP.txt'), 'w', encoding='utf8').write(g2)
# your own Greeting format (no blank lines, *ㅤ* between narration blocks) is a personal-edition option
b = open(j('renderer', 'builder.js'), encoding='utf8').read(); b2 = b.replace('const GREET_FMT = true;', 'const GREET_FMT = false;', 1); assert b2 != b; open(j('renderer', 'builder.js'), 'w', encoding='utf8').write(b2)
# the tool's own Image Generation rules (limits, checks, defaults, the instructions it gives the AI) are the Personal edition's; the shareable edition's people use their own template's rules
im = open(j('renderer', 'imagestyle.js'), encoding='utf8').read(); im2 = im.replace('const IMAGE_RULES = true;', 'const IMAGE_RULES = false;', 1); assert im2 != im; open(j('renderer', 'imagestyle.js'), 'w', encoding='utf8').write(im2)
# the NTR Account / Main Account folders are the Personal edition's; each friend files bots into one folder of their own choosing
ih = open(j('lib', 'imageHost.js'), encoding='utf8').read(); ih2 = ih.replace('const NTR_ACCOUNTS = true;', 'const NTR_ACCOUNTS = false;', 1); assert ih2 != ih; open(j('lib', 'imageHost.js'), 'w', encoding='utf8').write(ih2)
print('shareable edition built at', out)
