// The NTR type keeps to its lane: 3 to 7 years together (1 to 4 married), a weeks-to-3-months affair, and the affair is ACTIVE and ONGOING (never "she ended it").
// Other types and ANTI-NTR / Post-NTR keep their own rules. Rule based, no AI.
'use strict';
const assert = require('assert'), fs = require('fs'), path = require('path');
if (!fs.existsSync(path.join(__dirname, '..', 'lib', 'incidents-personal.js'))) { console.log('NTR lane self-test skipped (this edition has no NTR cards)'); process.exit(0); }
const {generateWeekLocal} = require('../lib/procedural');
const NtrClear = require('../lib/ntrClear');
const NtrCanon = require('../renderer/ntrcanon.js');
const W = {a: 1, one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12};
const ENDED = /\b(?:ended it|ended the affair|broke it off|broke things off|called it off|stopped seeing him|it(?:'s| is| was) over|it ended|it has ended|no longer seeing|since it ended|an ex\b|ex-(?:wife|girlfriend))\b/i;
let seen = 0, other = 0;
for (let i = 0; i < 60; i++) {
  const week = generateWeekLocal({});
  for (const c of week.ntr || []) {
    const f = c.fields, ty = f['NTR Type'];
    if (ty !== 'NTR') { other++; continue; }
    seen++;
    const bg = f['Relationship background'];
    const mar = bg.match(/your wife for (\w+) years?\b/), all = bg.match(/(?:together for (\w+) years? in all|(?:girlfriend|fiancée) for (\w+) years?)/);
    const total = all && W[all[1] || all[2]];
    assert.ok(total >= 3 && total <= 7, 'NTR type: the relationship is 3 to 7 years in all: ' + bg);
    if (/your wife/.test(bg)) assert.ok(mar && W[mar[1]] >= 1 && W[mar[1]] <= 4 && W[mar[1]] <= total, 'NTR type: a wife has been married 1 to 4 years: ' + bg);
    { const w = f['What happened'], m = w.match(/\b(?:for|about|past)\s+(?:about\s+|the past\s+)?(\w+)\s+(weeks|months)\b/i), n = m && W[m[1].toLowerCase()];
      const months = m && (m[2].toLowerCase() === 'weeks' ? n / 4.345 : n);
      assert.ok(m && months <= 4, 'NTR type: the affair is stated and is 4 months or less: ' + w);
      assert.ok(months / (total * 12) <= 0.15, 'NTR type: the affair is under 15% of the relationship: ' + w + ' / ' + bg); }
    for (const k of ['What happened', 'Fixed Facts', 'The Hidden Truth', 'User Interaction Hook', 'Greeting Direction']) assert.ok(!ENDED.test(String(f[k] || '')), `NTR type: the affair has not ended (${k}): ${f[k]}`);
    assert.ok(/\b(?:has been|have been|is sleeping|is having)\b|\bsince\b|\bevery (?:Thursday|week)\b/i.test(f['What happened']), 'NTR type: written as ongoing: ' + f['What happened']);
    { const w = f['What happened']; assert.ok(!/\b(?:year|spring|summer|winter)\b|\b(?:four|five|six|seven|eight|nine|ten|eleven|twelve)\s+months\b|\bhalf a year\b/i.test(w), 'NTR type: the affair is weeks to about 3 months old: ' + w); }
    assert.ok(/ACTIVE|ongoing|still going on/i.test(NtrClear.brief(c)), 'NTR brief says the affair is active');
  }
}
assert.ok(seen >= 20, 'the NTR type was generated (' + seen + ' cards)');
assert.ok(other >= 60, 'the other NTR-lane types are still generated');
const canon = NtrCanon.RULE ? NtrCanon.RULE.full : '';
assert.ok(/ACTIVE and ONGOING/.test(canon) && /3 months/.test(canon) && /3 to 7 years/.test(canon) && !/whether it has ended/.test(canon), 'CANON LOCK for NTR: active, 3 to 7 years');
assert.ok(/over/.test(NtrCanon.RULE.light) && /already in the open/.test(NtrCanon.RULE.emotionalpost), 'Light and Post-NTR canon unchanged (they are the ended ones)');
for (const f of ['weekly_blueprint_rules.txt', 'weekly_blueprint_template.html']) {
  const t = fs.readFileSync(path.join(__dirname, '..', 'resources', 'rules', f), 'utf8');
  assert.ok(!/whether it has ended/.test(t), f + ': no "whether it has ended" left in the NTR lane');
}
const tpl = fs.readFileSync(path.join(__dirname, '..', 'resources', 'bot-templates', '6._PigeonGuy_Template_NTR_October_2026_v3.txt'), 'utf8');
assert.ok(/ACTIVE and ONGOING/.test(tpl) && /3 months/.test(tpl) && /3 to 7 years/.test(tpl) && !/whether it has ended/.test(tpl), 'NTR template: active, 3 to 7 years');
console.log('NTR lane self-test passed:', seen, 'NTR-type cards, 3-7 year relationship, short ongoing affair; other types untouched');
