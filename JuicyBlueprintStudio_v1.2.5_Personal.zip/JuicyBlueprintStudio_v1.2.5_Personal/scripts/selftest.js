const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {parseEventAnnouncement} = require('../lib/eventParser');
const {analyzeEnginesLocal} = require('../lib/engineAnalyzer');
const {generateWeekLocal, regenerateScenarioLocal} = require('../lib/procedural');
const {validateWeekLocal} = require('../lib/validator');
const {scoreScenario} = require('../lib/scoring');

const event = `Beyond the Ordinary
Theme: Explore other worlds.
Setting: No fixed setting.
Event Period:
September 10, 2026 – October 9, 2026 UTC
Event Tag:
Beyond the Ordinary
Opportunity Tags:
RPG, Kemonomimi, Monster Girl, Magic, Hero, Isekai
Other Requirements:
Each Bot must select at least 1 Opportunity Tag.
Each Bot must include at least one Regular Tag.
Bots must have a Figure.
Bots must remain public.
Bots may not use Event Tags from other concurrent Bot events.
Reward Rules:
Bots that reach 1,000 conversations receive rewards.`;
const p=parseEventAnnouncement(event);
assert.equal(p.name,'Beyond the Ordinary');
assert.equal(p.eventTag,'Beyond the Ordinary');
assert(p.opportunityTags.includes('Magic'));
assert.equal(p.requiresFigure,true);
assert.equal(p.conversationRewardThreshold,1000);
assert(fs.existsSync(path.join(__dirname,'..','scanner','scraper.py')));
assert(fs.existsSync(path.join(__dirname,'..','scanner','worker.py')));
assert(fs.existsSync(path.join(__dirname,'..','lib','pythonCollector.js')));

const recent = Array.from({length:100},(_,i)=>({source:'Recent',rank:i+1,url:`https://x/recent/${i}`,title:i%3===0?'Roommate Secret':'Best Friend Return',rawText:i%3===0?'@a 12k OC Drama roommate secret shared apartment discover hidden message':'@b 8k Romance ex girlfriend returns years later at your door secret',engagementEstimate:12000-i*20}));
const trending = Array.from({length:100},(_,i)=>({source:'Trending',rank:i+1,url:`https://x/trending/${i}`,title:i%2===0?'Ex Returns':'Roommate Discovery',rawText:i%2===0?'@c 50k Drama Romance ex girlfriend returns at your door after years secret':'@d 40k OC roommate trapped apartment discover secret messages',engagementEstimate:50000-i*40}));
const analysis=analyzeEnginesLocal({recent,trending});
assert.equal(analysis.sample.unique,200);
assert(analysis.engines.length>0);
assert(analysis.summary.includes('strongest measured engine'));
assert(analysis.sourceSummaries.Recent.count===100);
assert(analysis.sourceSummaries.Trending.count===100);
assert(analysis.engines[0].whyItWorks);
const activeEvent={active:true,parsed:p,applyMode:'whole-week'};
let week,validation;
for(let i=0;i<5;i++){week=generateWeekLocal({engineAnalysis:analysis,activeEvent,weekStart:'2026-09-28'});validation=validateWeekLocal(week,activeEvent);if(validation.ok)break;}
assert(validation.ok, validation.errors.join('\n'));
const core=week.days.flatMap(d=>d.scenarios);
assert.equal(core.length,21);assert.equal(week.ntr.length,7);
assert.equal(core.filter(s=>s.series==='ANTI-NTR Series').length,2);
assert.equal(core.filter(s=>s.series==='Futa Friday Series').length,1);
assert.equal(core.filter(s=>s.fields['Primary Character Futanari']==='Yes').length,2);
const regen=regenerateScenarioLocal({engineAnalysis:analysis,activeEvent,scenario:core[0],weekPeers:core.slice(1)});
assert.equal(regen.day,core[0].day);assert.equal(regen.slot,core[0].slot);
const scored=scoreScenario(core[0],analysis,activeEvent,core);
assert(scored.score>40);
assert(fs.existsSync(path.join(__dirname,'..','resources','rules','weekly_blueprint_rules.txt')));
assert(fs.existsSync(path.join(__dirname,'..','resources','rules','weekly_blueprint_template.html')));
{ // SCP Series: a house is never the setting, and two SCP cards never share a kind of place
  const S = require('../lib/settings.js'), assert = require('assert');
  const mk = (id, name, setup) => ({id, sceneName: name, series: 'SCP Series', slot: 'Scenario 3 (SCP Series - Anomaly Encounter)', fields: {'The Setup': setup}});
  const house = mk('a', 'Hollow Hearth', 'She waits in the abandoned farmhouse kitchen while the cellar door stands open.'), sub = mk('b', 'Platform Nine', 'A flooded subway platform where a tall figure waits in the tunnel.');
  assert(S.isScp(house) && !S.isScp({id: 'x', series: 'Bully Series'}), 'SCP cards are recognised');
  assert(S.problems(house, [sub], []).some(x => x.kind === 'home'), 'a house is flagged');
  assert(S.problems(mk('c', 'Static', 'The train station platform hums.'), [sub], []).length === 1, 'the same kind of place is flagged');
  for (let i = 0; i < 200; i++) { const [k] = S.pick(house, [sub], []); assert(k !== 'home' && k !== 'transit', 'the pool never hands out a home or a place already used'); }
}
console.log('Self-test passed: local event parsing, transplanted Python Market Scan files, engine analysis, procedural week generation, validation, regeneration, scoring, and rule files are available.');

// the desktop app (Electron) has no prompt(): a screen that relies on it silently does nothing, so none may use it
{ const fs = require('fs'), path = require('path'), dir = path.join(__dirname, '..', 'renderer');
  for (const f of fs.readdirSync(dir).filter(f => f.endsWith('.js'))) {
    const src = fs.readFileSync(path.join(dir, f), 'utf8').replace(/\/\/[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');   // comments don't count
    if (/(^|[^.\w])(window\.)?prompt\s*\(/m.test(src)) throw new Error(`${f} uses prompt(), which the desktop app doesn't support: use askText() instead.`);
  } }


// ANTI-NTR: the AI card writer is told the woman hides nothing from {{user}}; other series get no such rule
{ const A = require('../lib/antagonist.js');
  assert.ok(/hides nothing from \{\{user\}\}/.test(A.brief({series: 'ANTI-NTR Series'})));
  assert.equal(A.brief({series: 'Likeable NTR'}), '');
  assert.equal(A.brief({series: 'SCP Series'}), '');
  const f = A.fieldsFor({name: 'Ingrid Spencer', antName: 'Brock Kurowski', age: 41, wife: true, incidentId: 'ANTI-NTR Series:anti-envelope', seed: 'x'}).fields;
  assert.ok(!/instead of telling|quietly/.test(f['The Reveal'] + f['Fresh Angle']), 'local ANTI-NTR cards must not make her hide it'); }

// ANTI-NTR: hiding is detected in the writer's text (her own sentences, not the antagonist's quoted claims), and the rulebook's "secrecy" examples are removed from what the AI is sent
{ const A = require('../lib/antagonist.js');
  const card = {series: 'ANTI-NTR Series', cast: [{name: 'Madeline Grant', role: 'Primary'}, {name: 'Brock Halloway', role: 'Antagonist'}], fields: {
    'The Setup': 'She has spent the last month secretly restoring a record player. She has kept it from {{user}} for nine years. Brock tells {{user}} "some things a woman just doesn\'t tell her husband."',
    "Character's Personality": 'She thought handling it herself was kinder than dragging him in, so she carried it alone.'}};
  const h = A.hiding(card);
  assert.equal(h.length, 3, 'three hiding sentences found, the quoted claim is not one');
  assert.equal(A.hiding({series: 'ANTI-NTR Series', cast: [], fields: {'The Setup': 'She tells {{user}} about every word that same night and hands him the folded list.'}}).length, 0);
  assert.equal(A.hiding({series: 'Likeable NTR', fields: {'The Setup': 'She hid it.'}}).length, 0);
  assert.ok(!/secrecy/i.test(A.cleanInstruction("timing/optics, secrecy, rumors; such as protective secrecy, pride; such as secrecy or overprotection; timing, secrecy, manipulation")), 'secrecy removed from instructions'); }

// ANTI-NTR card written by the AI with the antagonist only in his own field (not in the cast): the local fill reads him from there
{ const FW = require('../lib/fieldWriter.js');
  const card = {series: 'ANTI-NTR Series', sceneName: 'Her Proof in the Rain', primaryCharacter: 'Madeline Grant', cast: [{name: 'Madeline Grant', role: 'Primary', age: 34}], tags: ['Wife'], fields: {'The Setup': 'Madeline Grant and {{user}} have been married six years.', 'Antagonist': 'Brock Halloway, a pushy repair-table regular at the flea market. His pursuit method is to crowd her errands. He is unredeemable.'}};
  const fa = FW.writeField('Fresh Angle', '', card), rv = FW.writeField('The Reveal', '', card);
  assert.ok(/pushy repair-table regular/.test(fa) && !/tells its story through/.test(fa), 'Fresh Angle uses his own role, not the generic line');
  assert.ok(rv.length > 80 && !/instead of telling|quietly/.test(rv), 'The Reveal is written and has her hiding nothing'); }

// SCP Series: numbered by the creator's own counter, named by designation
{ const SN = require('../lib/scpNumber.js');
  const mk = id => ({id, series: 'SCP Series', slot: 'Scenario 3 (SCP Series - Anomaly Encounter)', primaryCharacter: 'Paige Mercer', cast: [{name: 'Paige Mercer', role: 'Primary', gender: 'Female', age: '28'}], sceneName: 'SCP-000: The Salt Beacon'});
  const groups = [{cards: [mk('a')]}, {cards: [mk('b')]}];
  SN.apply(groups, {accounts: {main: {bots: [{title: 'SCP-021: Memory Bloom'}, {title: 'Her Harvest'}]}}, week: {}, cardArchive: []}, []);
  assert.equal(groups[0].cards[0].primaryCharacter, 'SCP-022'); assert.equal(groups[1].cards[0].primaryCharacter, 'SCP-023', 'consecutive numbers');
  assert.equal(groups[0].cards[0].cast[0].name, 'SCP-022');
  assert.ok(/main character is the anomaly SCP-022/.test(SN.brief(groups[0].cards[0])));
  const kept = [{cards: [{...mk('c'), primaryCharacter: 'SCP-040', cast: [{name: 'SCP-040', role: 'Primary'}]}]}]; SN.apply(kept, {}, []); assert.equal(kept[0].cards[0].primaryCharacter, 'SCP-040', 'a card keeps its own designation');
  const c = {...groups[0].cards[0], sceneName: 'The Drowned Choir With A Very Long Name Indeed [SCP Series]'}; SN.normalize(c);
  assert.ok(/^SCP-022: /.test(c.sceneName) && c.sceneName.length <= 30, c.sceneName);
  assert.equal(SN.brief({series: 'Likeable NTR', primaryCharacter: 'SCP-022'}), ''); }

{ // SCP number typed by the creator + renumbering without the AI
  const SN = require('../lib/scpNumber');
  const mk = (id, name) => ({id, series: 'SCP Series', slot: 'SCP', primaryCharacter: name, sceneName: 'SCP-000: The Salt Beacon', cast: [{name, role: 'Primary', about: name + ' is calm.'}], fields: {Setup: name + ' keeps salt. ' + name.split(' ')[0] + ' smiles.', 'Scene Name': 'SCP-000: The Salt Beacon'}});
  const g = [{cards: [mk('a', 'Paige Mercer')]}, {cards: [mk('b', 'Nina Cole')]}];
  SN.apply(g, {scpStart: 41, accounts: {main: {bots: [{title: 'SCP-099: Old'}]}}}, []);
  assert.equal(g[0].cards[0].primaryCharacter, 'SCP-041'); assert.equal(g[1].cards[0].primaryCharacter, 'SCP-042', 'typed number wins, then consecutive');
  const c = mk('c', 'Paige Mercer'); const r = SN.rename(c, 22);
  assert.equal(r.designation, 'SCP-022'); assert.equal(c.primaryCharacter, 'SCP-022'); assert.equal(c.cast[0].name, 'SCP-022');
  assert.equal(c.sceneName, 'SCP-022: The Salt Beacon'); assert.equal(c.fields['Scene Name'], c.sceneName);
  assert.ok(!/Paige|Mercer|SCP-000/.test(JSON.stringify(c)), 'old name and old number gone'); assert.ok(/SCP-022 keeps salt\. SCP-022 smiles\./.test(c.fields.Setup));
  SN.rename(c, 31); assert.equal(c.sceneName, 'SCP-031: The Salt Beacon'); assert.equal(c.primaryCharacter, 'SCP-031');
  assert.throws(() => SN.rename(c, 'abc')); assert.throws(() => SN.rename({series: 'Likeable NTR'}, 5));
}

{ // a Personality whose template wording alone is over its limit is written whole, as finished text (mocked AI)
  { const fsx = require('fs'), rp = require('path').join(__dirname, '..', 'resources', 'rules', 'weekly_blueprint_rules.txt'); if (fsx.existsSync(rp)) { const {BlueprintStore} = require('../lib/blueprint.js'), sr = new BlueprintStore(fsx.mkdtempSync(require('path').join(require('os').tmpdir(), 'scpbp-')), {rules: rp, template: ''}).scpRules(); assert.ok(/Last Human/.test(sr) && /APPEARANCE/.test(sr) && !/SCENARIO 3 TEMPLATE/.test(sr), 'scpRules() returns the SCP hard lock only'); } } // SCP cards: the rulebook's SCP hard lock reaches the AI (weekly_blueprint_rules.txt')
  const fs2 = require('fs'), tp = require('path').join(__dirname, '..', 'resources', 'bot-templates', '2._Gemini_Template_ANTI-NTR_September_2026_6_Paragraph_Test.txt');
  if (fs2.existsSync(tp)) {
    const BT = require('../lib/botTemplates'), {AiBotWriter, loadCore} = require('../lib/aiBotWriter.js');
    const spec = BT.parseTemplate(fs2.readFileSync(tp, 'utf8'), 'anti.txt'), {C} = loadCore(require('path').join(__dirname, '..', 'renderer'));
    const w = new AiBotWriter({relay: {}, rendererDir: require('path').join(__dirname, '..', 'renderer'), jobsDir: require('os').tmpdir(), store: {get: () => ({})}, templates: () => [spec], engineNotes: () => '', send: () => {}, storyFor: null});
    const base = C.compose(spec, {...C.blank(spec), fit: {personality: false}}).sec.personality.body, lim = spec.personality.limit;
    assert.ok(base.length > lim.max * 1.1, 'the template wording alone is over the limit');
    const fits = base.split('\n').filter(l => /^[A-Z\[{]|^[A-Za-z &]+:/.test(l.trim())).map(l => l.length > 120 ? l.slice(0, 60) : l).join('\n').slice(0, 3300);
    let asks = 0; w._ask = async (job, step, m, o, parse) => { asks++; step.output = '@@personality\n' + fits.padEnd(3300, ' .'); step.state = 'done'; return parse(step.output); };
    w._emit = () => {};
    w._writeFinishedSection({}, 'fields', 'CARD', 'personality', base, lim, 3350).then(t => { assert.ok(t && t.length <= Math.ceil(lim.max * 1.1) && asks >= 1, 'finished section returned'); }).catch(e => { console.error(e); process.exit(1); });
  }
}

{ // a box whose instruction asks for sentences keeps every sentence the AI wrote; only one-value boxes (Race, Gender, Age...) are cut to their value
  const {shortBox} = require('../lib/aiBotWriter.js');
  const three = 'raises her voice to win an argument, then goes quiet for hours until {{user}} gives in. She never apologizes first. She leaves his favorite snack out the next morning instead.';
  assert.equal(shortBox({label: 'Two to three sentences', hint: 'Two to three sentences', sentence: '{{Name1}}: ___'}, three), three, 'a "Two to three sentences" box is never cut to one clause');
  assert.equal(shortBox({label: 'When She Fights', hint: 'Two to three sentences', sentence: 'When She Fights: ___'}, three), three);
  assert.equal(shortBox({label: 'Habit', hint: 'Her habit', sentence: 'Habit: ___'}, 'bites her pen when she lies, then denies it.'), 'bites her pen when she lies, then denies it.', 'a box that is not a one-value field is not cut');
  assert.equal(shortBox({label: 'Race', hint: 'Human, Demon, Elf, etc.', sentence: 'Race: ___'}, 'Werewolf. Runs hot, pointed ears.'), 'Werewolf', 'a one-value box still gets just its value');
  assert.equal(shortBox({label: 'Gender', hint: 'Gender Identity', sentence: 'Gender: ___'}, 'Woman, a vet tech on swing shifts'), 'Female');
  // a template that writes its own PolicyWeights section keeps its whole Scenario limit (the app's block never goes into it, so its length is not taken off)
  const {templateOwnsPolicy} = require('../lib/aiBotWriter.js');
  assert.equal(templateOwnsPolicy({scenario: {lines: [{segs: [{t: 'lit', v: 'Mara PolicyWeights { Tease: '}, {t: 'ph', key: 'scenario.1'}]}]}}), true);
  assert.equal(templateOwnsPolicy({scenario: {lines: [{segs: [{t: 'lit', v: 'Mara will always '}, {t: 'ph', key: 'scenario.1'}]}]}}), false);
}

{ // Introduction and Greeting narration tense are separate (local converter, template contract, AI settings)
  const T = require('../renderer/tense.js');
  const mk = () => ({intro: 'She walks into the room and looks at you.', greet: ['He opens the door and smiles.', 'You wait by the window.'], over: {}, touched: {}, names: {}});
  const v = mk(), i0 = v.intro, g0 = JSON.stringify(v.greet);
  assert.ok(T.apply(v, 'past', 'intro').changed); assert.equal(JSON.stringify(v.greet), g0, 'the Greeting is untouched by an Introduction conversion');
  assert.equal(T.status(v, 'intro').mode, 'past'); assert.equal(T.status(v, 'greet').mode, 'present');
  const ip = v.intro; T.apply(v, 'past', 'greet'); assert.equal(v.intro, ip, 'the Introduction is untouched by a Greeting conversion');
  assert.ok(T.status(v, 'intro').canUndo && T.undo(v, 'greet') && JSON.stringify(v.greet) === g0 && v.intro === ip, 'undo is per part');
  T.apply(v, 'present', 'intro'); assert.equal(v.intro, i0, 'an unedited past/present round trip restores the exact text');
  assert.deepEqual(T.chosen({tenseIntro: {mode: 'past'}, tenseGreet: {mode: 'present'}}), {intro: 'past', greeting: 'present'});
  assert.deepEqual(T.chosen({narrativeTense: {mode: 'past'}}), {intro: 'past', greeting: 'past'}, 'a bot saved with one tense keeps it for both parts');
  global.window = global; delete require.cache[require.resolve('../renderer/templatecontract.js')]; const TCx = require('../renderer/templatecontract.js');
  const res = (global.TemplateContract || TCx).resolved({}, {narrativeTense: {intro: 'past', greeting: 'present'}});
  assert.ok(/Introduction: past/.test(res) && /Greeting: present/.test(res), 'the contract names each part\'s tense');
  assert.ok(/past, for Introduction and Greeting/.test((global.TemplateContract || TCx).resolved({}, {narrativeTense: {mode: 'past'}})));
}

{ // PolicyWeights: the author's lists and flags, the checks, the lane locks, the tracker, the reply reader and the Scenario insert
  const P = require('../renderer/policyweights.js');
  assert.ok(P.enabled && P.CATS.length === 10);
  assert.equal(P.info('RemorseResistance').value, 0.8); assert.ok(P.info('RetaliationSeverity').guard && P.info('RetaliationSeverity').cap); assert.ok(P.info('Hopelessness').cap); assert.ok(P.info('GaslightingTendency').guard);
  assert.ok(P.info('Stonewalling').guard, 'every Toxic Relationships weight needs guardrails');
  const bully = {series: 'Bully Series', cast: [{name: 'Mara Voss'}]};
  assert.ok(P.check({weights: 'RetaliationSeverity: 0.9'}, bully).errors.some(e => /never above/.test(e)), 'the author\'s .8 cap');
  assert.ok(P.check({weights: 'RomanticTension: 0.5'}, bully).errors.length >= 1, 'a Bully card takes no romance weights');
  assert.ok(P.check({weights: 'MadeUpDial: 0.9'}, {series: 'Standalone'}).errors.some(e => /\.8/.test(e)), 'a new weight stays at .8 or less');
  assert.ok(!P.check({weights: 'DismissiveSnark: 0.8; SarcasmLoad: 0.7'}, bully).errors.length);
  assert.ok(P.suggestCats(bully).join() === 'Bully' && !P.suggestCats({series: 'ANTI-NTR Series'}).includes('Toxic Relationships'));
  const rp = P.parseReply({weights: 'DismissiveSnark: .8\nRetaliationSeverity: .9\nRomanticTension: .7\nNewDial: .95\nDismissiveSnark: .2', tracker: 'TRACKER: Trust | start 0 | step 0.05\nUP: is patient\nDOWN: mocks her\nAT 0.5: stops mid-insult\nAT 0.8: romance becomes possible, slowly, only if {{user}} leads\nAT -0.5: gets meaner', extra: 'None needed.', note: 'x'}, bully);
  assert.equal(rp.weights, 'DismissiveSnark: 0.8; RetaliationSeverity: 0.6; NewDial: 0.8', 'repaired to the author\'s values, caps and lane lock'); assert.deepEqual(rp.fresh, ['NewDial']); assert.ok(/^\[Tracker: Trust\]/.test(rp.tracker));
  assert.equal(P.parseReply({weights: 'SarcasmLoad: .7', tracker: 'TRACKER: Trust | start 0 | step 0.05\nUP: kisses her\nDOWN: mocks\nAT 0.5: falls in love\nAT -0.5: cold'}, bully).tracker, '', 'a Bully tracker that mentions romance is thrown out');
  assert.equal(P.parseReply({weights: 'SarcasmLoad: .7', tracker: 'TRACKER: Trust | start 0 | step 0.05\nUP: is patient\nDOWN: mocks\nAT 0.5: reluctant\nAT -0.5: cold'}, bully).tracker, '', 'a Bully Trust tracker needs its AT 0.8 romance-unlock stage');
  assert.equal(P.parseReply({weights: 'SarcasmLoad: .7', tracker: 'TRACKER: Trust | start 0 | step 0.05\nUP: is patient\nDOWN: mocks\nAT 0.5: starts a crush on {{user}}\nAT 0.8: romance becomes possible\nAT -0.5: cold'}, bully).tracker, '', 'romance before 0.8 is thrown out');
  assert.ok(P.parseTrackerReply('TRACKER: T | step 0.5\nUP: a\nDOWN: b\nAT 0.5: c\nAT -0.5: d').errors.length, 'a step of 0.5 is rejected');
  const pol = {on: true, weights: rp.weights, tracker: rp.tracker, extra: '', rules: ['noRomance']};
  { // making the block fit: shorter wording first (nothing lost), then the least important parts, never the lane guardrail
    const full = P.blockLength(pol, 'Mara'), small = P.trim(pol, 'Mara', full - 150);
    assert.ok(small.changed && small.policy.compact && !small.cuts.length && P.blockLength(small.policy, 'Mara') <= full - 150, 'compact wording alone makes room first');
    assert.ok(/Hidden; -?[\d.]+\.\.[\d.]+, starts/.test(P.blockText(small.policy, 'Mara')) && /Trust 0\.8/.test(P.blockText(small.policy, 'Mara')), 'compact wording keeps the numbers and the Trust 0.8 romance rule');
    const tiny = P.trim({...pol, extra: 'Keep it slow. '.repeat(20)}, 'Mara', 500);
    assert.ok(tiny.short && !tiny.cuts.some(x => /extra|weight/i.test(x)) && tiny.policy.extra === 'Keep it slow. '.repeat(20) && P.parseWeights(tiny.policy.weights).items.length === P.parseWeights(pol.weights).items.length && /Trust 0\.8/.test(P.blockText(tiny.policy, 'Mara')), 'the extra guardrail text, the weights and the romance guardrail are never cut: if nothing more can go, the block is reported as too long');
  }
  const body = 'System Rules {\n[USER AGENCY HARD LOCK]\nx\n[END USER AGENCY HARD LOCK]\n\nWrite.\n}', out = P.insert(body, pol, 'Mara');
  assert.ok(out.indexOf('Mara PolicyWeights {') < out.indexOf('[Tracker') && out.indexOf('[Tracker') < out.indexOf('System Rules {') && out.indexOf('[END USER AGENCY HARD LOCK]') < out.indexOf('[POLICYWEIGHT GUARDRAILS]'), 'the author\'s order, guardrails after the lock');
  assert.ok(/RetaliationSeverity, NewDial are tone and pacing dials only/.test(out) && /no romantic or sexual interest in \{\{user\}\}/.test(out) && /Trust is below 0\.8/.test(out), 'a new weight and a Bully card get their guardrail lines');
  assert.equal(P.insert(out, pol, 'Mara'), out, 'never inserted twice'); assert.equal(P.insert(body, {...pol, on: false}, 'Mara'), body, 'off changes nothing');
  assert.equal(P.insert('System Rules {\nWrite.\n}', pol, 'Mara').split('POLICYWEIGHT GUARDRAILS').length, 2, 'a template without the lock still gets one guardrail line');
  assert.equal(P.isOn({series: 'Bully Series'}, {policyDefaults: {'Bully Series': true}}), true); assert.equal(P.isOn({series: 'Bully Series', policy: {on: false}}, {policyDefaults: {'Bully Series': true}}), false); assert.equal(P.isOn({series: 'X'}, {}), false, 'off unless switched on');
  // inside the Bot Builder: the block is counted by compose (so the length fit sees it) and a card with it off is composed exactly as before
  const BT = require('../lib/botTemplates'), {loadCore} = require('../lib/aiBotWriter.js'), tp2 = require('path').join(__dirname, '..', 'resources', 'bot-templates', '1._Gemini_Template_8K_September_2026_6_Paragraph_Test.txt');
  if (require('fs').existsSync(tp2)) {
    const spec = BT.parseTemplate(require('fs').readFileSync(tp2, 'utf8'), 'p.txt'), {C} = loadCore(require('path').join(__dirname, '..', 'renderer')), v = C.blank(spec); v.names[1] = 'Mara';
    const plain = C.compose(spec, v).sec.scenario.body; v.policy = pol; const withP = C.compose(spec, v).sec.scenario.body;
    assert.ok(withP.length > plain.length && withP.includes('Mara PolicyWeights {') && withP.split('PolicyWeights {').length === 2);
    v.over = {scenario: plain}; assert.ok(C.compose(spec, v).sec.scenario.body.includes('Mara PolicyWeights {'), 'a whole-written Scenario gets the block too');
    delete v.policy; delete v.over; assert.equal(C.compose(spec, v).sec.scenario.body, plain);
  }
}

// Weekly schedule (2 or 3 bots per day) and the Crush Series. The bundled rulebook + card template pairs are read by the app's own reader, a week is
// generated and validated for each, and the Crush guardrail turns a Netorare / Preventable-NTR drift back. (Personal edition only: the shareable edition has no rulebook.)
{
  const fsx = require('fs'), pth = require('path'), rd = pth.join(__dirname, '..', 'resources', 'rules');
  const mainRules = 'weekly_blueprint_rules' + '.txt';      // written this way so the shareable build keeps this block
  if (fsx.existsSync(pth.join(rd, mainRules))) {
    const BP = require('../lib/blueprint.js'), WP = require('../lib/weekPlan.js'), PR = require('../lib/procedural.js'), VA = require('../lib/validator.js'), CG = require('../lib/crushGuard.js');
    for (const [n, rf, tf] of [[3, mainRules, 'weekly_blueprint_template' + '.html']]) {      // the app's one schedule: 3 bots a day
      const sc = BP.buildSchema(fsx.readFileSync(pth.join(rd, rf), 'utf8'), fsx.readFileSync(pth.join(rd, tf), 'utf8')), plan = WP.planOf(sc, null);
      assert.deepEqual(WP.missingParts(plan), [], `${n}/day: nothing in the plan is missing`);
      assert.ok(plan.days.length === 7 && plan.days.every(d => d.cards === n), `${n}/day: ${n} cards on each of the 7 days`);
      assert.ok(sc.types.crush && sc.types.scp, `${n}/day: the Crush Series and SCP Series card types are read`);
      const crush = [...plan.established, ...plan.slot3].filter(x => /crush/i.test(x.series)).reduce((a, x) => a + x.count, 0);
      assert.equal(crush, 2, `${n}/day: 2 Crush Series a week`);
      assert.deepEqual((plan.keepOff['Crush Series'] || []), ['Sunday'], `${n}/day: Crush Series is kept off Sunday`);
      if (n === 2) { assert.equal(plan.read.slot3, 'none', '2/day has no third slot'); assert.equal(plan.slot3.length, 0); assert.ok(!plan.mix2.some(x => /standalone/i.test(x.series)), '2/day has no Standalone'); }
      else assert.ok(plan.slot3.some(x => /high-reaction/i.test(x.series)) && plan.mix2.some(x => /standalone/i.test(x.series)), '3/day keeps the High-Reaction Pilots and Standalone');
      for (let i = 0; i < 25; i++) {
        const w = PR.generateWeekLocal({plan, weekStart: '2026-10-19'}), v = VA.validateWeekLocal(w, null, plan);
        assert.ok(v.ok, `${n}/day week is valid: ${v.errors.join(' | ')}`);
        const cd = w.days.filter(d => d.scenarios.some(c => c.series === 'Crush Series')).map(d => d.day), idx = cd.map(d => WP.WEEKDAYS.indexOf(d));
        assert.ok(cd.length === 2 && !cd.includes('Sunday') && idx[1] - idx[0] > 1, `${n}/day Crush Series: two days, never Sunday, never back to back (${cd})`);
        assert.ok(w.days.every(d => d.scenarios.length === n));
      }
    }
    const crushCard = {series: 'Crush Series', fields: {}};
    assert.deepEqual(CG.check(crushCard, {'The Setup': 'She is single, with no boyfriend, and nothing has happened. Dan hands her a drink and {{user}} arrives with a gift.'}), []);
    assert.ok(CG.check(crushCard, {'The Setup': 'Her boyfriend is away and Dan kisses her.'}).length >= 2, 'a partner and a kiss are sent back');
    assert.ok(CG.check(crushCard, {Tags: 'Event, Netorare, Multiple'}).length === 1 && CG.check(crushCard, {'User Interaction Hook': 'Dan grins. "Her choice: him or me?"'}).length === 1);
    assert.ok(CG.check(crushCard, {'Primary Archetypal Personality': 'Yandere'}).length === 1 && CG.check({series: 'Bully Series'}, {'The Setup': 'cheating boyfriend'}).length === 0, 'other series are not touched');
  }
}

// The Crush Series bot template (personal edition): read by the Bot Builder's own reader like the ANTI-NTR template, with its own prefix, tags and archetypes.
{
  const fsx = require('fs'), pth = require('path'), cf = pth.join(__dirname, '..', 'resources', 'bot-templates', '10._Gemini_Template_Crush_Series_September_2026_6_Paragraph_Test.txt');
  if (fsx.existsSync(cf)) {
    const BT = require('../lib/botTemplates.js'), t = BT.parseTemplate(fsx.readFileSync(cf, 'utf8'), '6__Crush.txt');
    assert.equal(t.introduction.prefix, '[Crush Series 00]'); assert.equal(t.greeting.count, 6); assert.ok(t.scene.present && t.image.present && t.image.negative);
    assert.deepEqual(t.tags.mandatory, ['Event', 'Multiple', 'Juiciest']); assert.equal(t.tags.total, 8); assert.equal(t.tags.wifeRule, false); assert.equal(t.rules.relationshipSpecific, false, 'she is single: no wife/girlfriend rule');
    assert.ok(t.tags.archetypes.length === 21 && !t.tags.archetypes.includes('Bully') && !t.tags.archetypes.includes('Yandere'), 'no menacing archetypes');
    assert.ok(t.tags.approved.length > 100 && t.rules.hasName2 && t.rules.total.min === 11000);
    const raw = t.raw; for (const w of ['SINGLE STATUS HARD LOCK', 'CRUSH SERIES IS NOT NTR HARD LOCK', 'CRUSH SERIES HARD ENDPOINT', 'R4 COURTSHIP, NOT NTR']) assert.ok(raw.includes(w), w);
  }
}

{
  // an event tag written with a slash ("Mafia/Gang") is never followed by its own half ("Mafia") as a second tag
  const C = require('../lib/cardRules');
  const R = {fields: [{label: 'Tags'}], approved: ['Mafia', 'Drama', 'Slow Burn', 'OC', 'Dandere', 'Juicy Royalty', 'Romance'], namedTags: ['Event', 'Juicy Royalty'], tagCount: 8, archetypes: ['Dandere']};
  const card = {opportunityTags: ['Mafia/Gang'], fields: {Tags: 'Event, Juicy Royalty, Dandere, Mafia/Gang, Drama, Slow Burn, OC, Romance'}};
  const bad = C.check(R, card, {Tags: 'Event, Juicy Royalty, Dandere, Mafia/Gang, Drama, Slow Burn, Mafia, OC'}).map(x => x.problem).join(' | ');
  assert.ok(/Mafia repeats the event tag Mafia\/Gang/.test(bad), 'half of an event tag is flagged: ' + bad);
  const good = C.check(R, card, {Tags: 'Event, Juicy Royalty, Dandere, Mafia/Gang, Drama, Slow Burn, OC, Romance'}).map(x => x.problem).join(' | ');
  assert.ok(!/repeats the event tag/.test(good), 'a clean tag set is not flagged: ' + good);
}

{
  // the approved tag list names Mafia/Gang (JuicyChat's tag), never a plain Mafia tag
  const BR = require('../lib/blueprintRules');
  assert.ok(BR.APPROVED_TAGS.includes('Mafia/Gang') && !BR.APPROVED_TAGS.includes('Mafia'), 'built-in approved tags: Mafia/Gang, no plain Mafia');
  const fs = require('fs'), path = require('path'), rd = path.join(__dirname, '..', 'resources');
  for (const d of ['rules', 'bot-templates']) {
    const dir = path.join(rd, d); if (!fs.existsSync(dir)) continue;
    for (const f of fs.readdirSync(dir).filter(x => /\.(txt|html)$/.test(x))) { const t = fs.readFileSync(path.join(dir, f), 'utf8'); assert.ok(!/Mafia \(Characters in organized crimes\)/.test(t), f + ' still lists plain Mafia as a tag'); }
  }
}
