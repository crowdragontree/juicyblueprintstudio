# Introduction Designer: Image Frame Update

Select an image, then open **Element > Style > Image frame & spacing**.
You can change Inner spacing, border color/width/style, frame corners, image corners, background color, and glow.
The image is padded **inside its own frame**, so the outer box position and dimensions are unchanged.
Cropping, zooming and dragging the artwork within its frame remain available.
Existing images use zero new frame spacing until edited.

Version numbers are unchanged; this is a source-level repair. Use the existing build process to create Windows/Linux executables.
