JUICY BLUEPRINT STUDIO v1.1.1
============================

UPDATING FROM AN EXISTING INSTALLATION
-------------------------------------
Close the app. Extract this edition into a new permanent folder, then run
START_JUICY_BLUEPRINT_STUDIO.bat. Keep the existing application data. Use the
same edition as before; Personal and Shareable retain their own application names.

Write with AI (Bot Builder) opens the Greeting planner before sending a request.
The planner's Dialogue share box sets what % of the Greeting is dialogue; it is sent
with every Greeting instruction and checked after writing.
Rewrite [section] with AI affects only that section after you review and apply it.
Save to card stores a local bot; it does not publish to JuicyChat or check off
publishing tasks. Separate cards can hold separate saved bots.


WEBP MAKER: VIDEO CROPPING (v1.1.1)
---------------------------------
Open WebP Maker inside Juicy Blueprint Studio and add two or more MP4 or WebM video clips (including AI-generated VP9 streams stored with .mp4 filenames).
Choose a crop preset: 16:9, 9:16, 3:4, 4:3 or 1:1. Center/Top/Bottom/Left/Right positions are supported; the crop preview shows the framing before conversion.
For different crops per file, select Freeform, choose a clip in the crop preview, then drag the crop box or its corner handles. Reset this clip's crop restores only that clip. Each clip keeps its own framing when reordered.
Choose Custom dimensions to set width and height independently, for example 480 x 640. Freeform selections preserve the output proportions to avoid stretching.
The file must remain under 9.99 MB. Video processing stays local; automatic quality/FPS adjustments retain their existing safeguards.

ORIGINAL INSTALLATION / OPERATION NOTES
--------------------------------------
A desktop app for planning, building and tracking JuicyChat character bots.
Analysis is statistical and scenarios are procedural, so everything works without AI. The AI writer (Write whole bot with AI, Suggestions, Fix for event, and the AI event checklist) is optional: it uses a shared AI service with a monthly allowance per computer, and follows your own templates and limits.

FIRST RUN
1. Unzip the folder somewhere permanent (for example Documents), not inside
   the zip preview.
2. Double-click START_JUICY_BLUEPRINT_STUDIO.bat. The first run installs
   everything it needs (a few minutes; it may download a private copy of
   Node.js and Python). Later runs start straight away.
   - If Windows asks, allow it to run.
   - If the window says Python was installed, close it and double-click
     START_JUICY_BLUEPRINT_STUDIO.bat again.
3. JuicyChat Analysis: paste a JuicyChat magic link, click Open Sign-in, finish
   signing in in the window that opens, then click Finish Sign-in.
Always start the app with START_JUICY_BLUEPRINT_STUDIO.bat.

IF THE INSTALL FAILED BEFORE
Delete the "node_modules" folder inside the app folder (if there is one), then
double-click START_JUICY_BLUEPRINT_STUDIO.bat again. An old Node.js on the
computer is fine: the app now uses its own private copy when it needs to.

WHAT'S IN IT
- JuicyChat Analysis: collect 100 Recent + 100 Trending bots (by hand, or
  automatically every day at 8:00 PM Eastern) and find the success engines.
  Every collected bot is kept, so the analysis learns across collections.
- Weekly Blueprint: 21 scenarios a week (three a day), built from the success
  engines. Tick Built on each card; tabs show progress. Regenerate a card, a
  tab or the whole week.
- Bonus Ideas: turn a one-line idea (or a pasted scenario card) into a full
  scenario card with a success estimate.
- Bot Builder: fills YOUR bot templates. Add them with "+ Add template...";
  every box, character limit and rule comes from your template. "Copy story
  brief" lets you write the Introduction and Greeting with a chatbot you
  already use, then paste its reply back in.
- Performance: reads every bot you own (SFW, NSFW and 18+) from the account
  you signed in with on the JuicyChat Analysis tab. No lounge link needed.
  Pulls read chats, likes, favourites, stars, comments and each bot's
  position in Popular, Trending, Recent, New and Editor's Choice, and compare
  its real results with the score the app gave it when you built it.
- Settings > Weekly Blueprint: upload your own rulebook (.txt) and card
  template (.html) and click Update Blueprint; cards follow your fields and
  show each field's instruction. Revert to Previous Version undoes it.

18+ BOTS
Your own bots are always included, whatever their rating. For Recent and
Trending collection, JuicyChat only shows 18+ bots to accounts allowed to
see 18+ content, so the app sees what your signed-in account can see.

YOUR DATA
Everything is stored on your own computer in the app's data folder. Nothing
is sent anywhere except the requests to JuicyChat itself.


STORY ENGINE (Bot Builder)
--------------------------
The Story engine decides how a bot paces, feels and behaves, from the character, her archetype, her personality text and the scenario. It picks one topic each for Pacing, Tone and Character from a library built from the "I Dream of Nemo" prompt PDF (STORY_ENGINE_TOPICS.txt lists every entry of the PDF and why it was used or left out).
- Click Write with AI. Step 1 is Choose the story, step 2 is Plan the Greeting, then Write bot with this plan.
- Auto shows the three best matches for each group and why they fit; the best is selected for you and you click another to use it. Pick shows a list of every topic, with your Auto selections already chosen. Off writes the bot without it.
- The Details box re-picks the matches (for example "make it angsty and fast-paced").
- Every bot also gets a character drive: she wants and fears something, has a visible tell, starts something herself and pushes back. Quiet archetypes also get a stoic guard.
- The topics used are kept on the bot, so Rewrite uses the same ones. Write with AI shows them again and you can change them. The bots of one week rotate to different topics.
- After writing, the app tells you if she still only agrees, never asks or refuses, or speaks in very short clipped lines.


Introduction Designer improvement: Smart snapping, collision-free layouts that move elements aside, instant HTTPS image previews, and visible loading/error statuses.
