@echo off
setlocal
cd /d "%~dp0"
rem use the app's private Node.js if it has one (wherever it was unzipped)
set "RT=%CD%\.runtime"
if exist "%RT%\node\node.exe" set "PATH=%RT%\node;%PATH%"
for /d %%d in ("%RT%\node-dl\node-v*" "%RT%\node-temp\node-v*") do if exist "%%~d\node.exe" set "PATH=%%~d;%PATH%"
if not exist "node_modules\electron\dist\electron.exe" (
  echo The first-run setup has not completed yet.
  echo Run START_JUICY_BLUEPRINT_STUDIO.bat instead.
  pause
  exit /b 1
)
rem --log-level=3: Chromium writes only fatal errors to this window (no display notices such as "PlacementList must be sorted")
call "node_modules\.bin\electron.cmd" "%CD%" --log-level=3
