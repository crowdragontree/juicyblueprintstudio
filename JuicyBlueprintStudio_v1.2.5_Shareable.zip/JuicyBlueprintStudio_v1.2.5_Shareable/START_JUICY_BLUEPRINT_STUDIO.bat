@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Juicy Blueprint Studio

echo.
echo  Juicy Blueprint Studio
echo  ----------------------
echo.

rem ------------------------------------------------------------ Node/Electron
rem The desktop shell needs Node.js 18 or newer. If the computer has an older
rem Node (for example 12), the app downloads its own private copy into .runtime
rem and uses it where it was unzipped (nothing is moved, so antivirus scanning
rem can't block it). The computer's own Node.js is never changed.
set "RT=%CD%\.runtime"
set "NODE_URL=https://nodejs.org/dist/v22.16.0/node-v22.16.0-win-x64.zip"
set "NODE_DIR="
call :FIND_PRIVATE_NODE
if defined NODE_DIR goto USE_PRIVATE_NODE

where node >nul 2>nul
if errorlevel 1 goto GET_PRIVATE_NODE
node -e "process.exit(Number(process.versions.node.split('.')[0])>=18?0:1)" >nul 2>nul
if not errorlevel 1 goto USE_SYSTEM_NODE
set "OLD_NODE=an old version"
for /f "delims=" %%v in ('node -v 2^>nul') do set "OLD_NODE=%%v"
echo The Node.js on this computer (%OLD_NODE%) is too old for the app.
echo The app will download its own private copy (about 30 MB, one time only).
echo Your installed Node.js is not changed.
echo.

:GET_PRIVATE_NODE
echo Downloading a private Node.js for the app...
if not exist "%RT%" mkdir "%RT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri '%NODE_URL%' -OutFile '%RT%\node.zip'; Expand-Archive -LiteralPath '%RT%\node.zip' -DestinationPath '%RT%\node-dl' -Force; Remove-Item '%RT%\node.zip' -Force -ErrorAction SilentlyContinue; exit 0 } catch { Write-Host ('  ' + $_.Exception.Message); exit 1 }"
if errorlevel 1 goto DOWNLOAD_FAIL
call :FIND_PRIVATE_NODE
if not defined NODE_DIR goto DOWNLOAD_FAIL

:USE_PRIVATE_NODE
rem the private Node must actually run and be new enough, or stop here
"%NODE_DIR%\node.exe" -e "process.exit(Number(process.versions.node.split('.')[0])>=18?0:1)" >nul 2>nul
if errorlevel 1 goto PRIVATE_NODE_FAIL
set "PATH=%NODE_DIR%;%PATH%"
set "NPM=%NODE_DIR%\npm.cmd"
goto NODE_READY

:USE_SYSTEM_NODE
rem Run npm by its full path. Calling a quoted "npm" that Windows has to search
rem for makes npm look for its own files in the app folder instead of its own.
set "NPM="
for /f "delims=" %%p in ('where npm.cmd 2^>nul') do if not defined NPM set "NPM=%%p"
if not defined NPM goto GET_PRIVATE_NODE
if not exist "%NPM%" goto GET_PRIVATE_NODE

:NODE_READY
set "USING_NODE="
for /f "delims=" %%v in ('node -v 2^>nul') do set "USING_NODE=%%v"
echo Using Node.js %USING_NODE%
rem a half-finished install from an old Node leaves a broken electron folder: start clean
if exist "%CD%\node_modules\electron" if not exist "%CD%\node_modules\electron\dist\electron.exe" rmdir /s /q "%CD%\node_modules\electron"
if not exist "%CD%\node_modules\electron\dist\electron.exe" (
  echo Installing the desktop shell...
  call "%NPM%" install --no-audit --no-fund
  if errorlevel 1 goto INSTALL_FAIL
)

rem ------------------------------------------------------ EXACT MARKET SCANNER
rem This intentionally mirrors the Install.bat from the working Blueprint Studio
rem supplied by the user: Python venv + full Playwright + Playwright Chromium.
set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>&1 && set "PY=py -3"
if not defined PY (python -c "import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)" >nul 2>&1 && set "PY=python")
if defined PY goto HAVE_PYTHON

echo Python is required by the transplanted working Market Scan. Installing Python 3.12...
winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto PYTHON_FAIL
echo.
echo Python was installed. Close this window and run START_JUICY_BLUEPRINT_STUDIO.bat again.
pause
exit /b 0

:HAVE_PYTHON
if not exist "%CD%\.scanner-venv\Scripts\python.exe" (
  echo Creating the private Market Scan Python environment...
  %PY% -m venv .scanner-venv
  if errorlevel 1 goto SCANNER_FAIL
)

if not exist "%CD%\.runtime\python-market-scan-installed.flag" (
  echo Installing the EXACT Python Playwright components used by the supplied working Market Scan...
  "%CD%\.scanner-venv\Scripts\python.exe" -m pip install --upgrade pip --quiet
  if errorlevel 1 goto SCANNER_FAIL
  "%CD%\.scanner-venv\Scripts\python.exe" -m pip install -r "%CD%\scanner\requirements.txt" --quiet
  if errorlevel 1 goto SCANNER_FAIL
  echo Installing Chromium for the transplanted Market Scan...
  "%CD%\.scanner-venv\Scripts\python.exe" -m playwright install chromium
  if errorlevel 1 goto SCANNER_FAIL
  if not exist "%CD%\.runtime" mkdir "%CD%\.runtime"
  >"%CD%\.runtime\python-market-scan-installed.flag" echo installed
)

:RUN_APP
echo Starting Juicy Blueprint Studio...
rem --log-level=3: Chromium writes only fatal errors to this window (no display notices such as "PlacementList must be sorted")
call "%CD%\node_modules\.bin\electron.cmd" "%CD%" --log-level=3
exit /b 0

:DOWNLOAD_FAIL
echo.
echo Could not download or unzip the app's private Node.js (see the message above).
echo Check your internet connection, then run this file again. If antivirus blocked it,
echo wait a minute, delete the ".runtime" folder inside the app folder, and try again.
pause
exit /b 1

:INSTALL_FAIL
echo.
echo The desktop shell could not be installed. Check your internet connection and run this file again.
pause
exit /b 1

:PYTHON_FAIL
echo.
echo Python could not be installed automatically. Install Python 3.12 or newer, then run this file again.
pause
exit /b 1

:SCANNER_FAIL
echo.
echo The transplanted Python Market Scan could not be installed.
echo Check your internet connection and run this file again.
pause
exit /b 1

:PRIVATE_NODE_FAIL
echo.
echo The app's private Node.js was downloaded but could not be started:
echo   %NODE_DIR%
echo This is usually antivirus still scanning the new files. Wait a minute and
echo run this file again. If it keeps happening, delete the ".runtime" folder
echo inside the app folder and run this file again.
pause
exit /b 1

rem ---------------------------------------------------------------- helpers
:FIND_PRIVATE_NODE
rem the private Node, wherever it was unzipped (older versions of this script used .runtime\node)
set "NODE_DIR="
if exist "%RT%\node\node.exe" set "NODE_DIR=%RT%\node"
if defined NODE_DIR goto :eof
for /d %%d in ("%RT%\node-dl\node-v*" "%RT%\node-temp\node-v*") do if exist "%%~d\node.exe" set "NODE_DIR=%%~d"
goto :eof
