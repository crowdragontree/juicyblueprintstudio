'use strict';
/* Host adapter for the stand-alone web page (GitHub Pages / a downloaded .html file).
 * NOT loaded inside Blueprint Studio or the Creator Tool: they have their own host (preload.js / creator-bridge.js).
 * scripts/sync-designer.js inlines this file into the single-file page. */
(() => {
  const CORE=window.IntroCore;
  const KEYS={templates:'introductionDesigner.portable.templates.v1',draft:'introductionDesigner.portable.draft.v1'};
  let volatileTemplates=[],volatileDraft=null;
  const get=(key,fallback)=>{try{const value=localStorage.getItem(key);return value==null?fallback:JSON.parse(value);}catch{return fallback;}};
  const put=(key,value)=>{try{localStorage.setItem(key,JSON.stringify(value));return true;}catch{return false;}};
  const makeId=()=>typeof crypto!=='undefined'&&crypto.randomUUID?crypto.randomUUID():`id-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  function download(name,content){
    const blob=new Blob([content],{type:'application/json;charset=utf-8'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;
    document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),3000);
  }
  const load=()=>get(KEYS.templates,volatileTemplates).filter(x=>x&&x.id&&x.name&&x.design).slice(0,100);
  function store(templates){volatileTemplates=templates;if(!put(KEYS.templates,templates)){
    const status=document.querySelector('#id-message');if(status)status.textContent='Browser storage blocked. Export your templates as JSON to keep them.';
  }}
  function checkDoc(doc){if(!doc||typeof doc!=='object'||JSON.stringify(doc).length>350000)throw Error('Design is too large.');}
  async function copy(text){
    const checked=CORE.verifyOutput(text);if(!checked.valid)throw Error(checked.issues.join(' '));
    // Clipboard API requires secure context / permission. Legacy copy supports file:// on desktop.
    try{if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return text.length;}}catch{}
    const area=document.createElement('textarea');area.value=text;area.style.cssText='position:fixed;left:-10000px;top:0';document.body.appendChild(area);area.select();
    const okay=document.execCommand('copy');area.remove();if(!okay)throw Error('Browser blocked clipboard access. Use Show code and copy the output manually.');return text.length;
  }
  window.introHost={
    bootstrap:async()=>({embedded:false,seed:null,draft:get(KEYS.draft,volatileDraft),templates:load(),appVersion:'portable'}),
    saveDraft:async doc=>{checkDoc(doc);volatileDraft=doc;put(KEYS.draft,doc);return true;},
    templates:async()=>load(),
    saveTemplate:async(name,doc,id)=>{checkDoc(doc);const all=load(),key=id||makeId();const t={id:key,name:String(name||'My template').slice(0,90),design:CORE.forTemplate(doc),savedAt:new Date().toISOString()};const i=all.findIndex(x=>x.id===key);if(i>=0)all[i]=t;else all.push(t);if(all.length>100)throw Error('Template library holds up to 100 templates.');store(all);return t;},
    deleteTemplate:async id=>{const l=load().filter(x=>x.id!==id);store(l);return l;},
    exportTemplate:async id=>{const t=load().find(x=>x.id===id);if(!t)throw Error('Select a saved template.');download(t.name.replace(/[^a-z0-9._-]/gi,'_')+'.json',JSON.stringify({type:'juicychat-introduction-template',version:1,...t},null,2));return true;},
    importTemplate:()=>new Promise((resolve,reject)=>{
      const input=document.createElement('input');input.type='file';input.accept='.json,application/json';input.hidden=true;document.body.appendChild(input);
      input.onchange=async()=>{try{
        const file=input.files?.[0];if(!file||file.size>350000){input.remove();return resolve(null);}
        const json=JSON.parse(await file.text());if(json.type!=='juicychat-introduction-template'||!json.design)throw Error('Invalid Introduction Designer template.');
        checkDoc(json.design);const all=load();if(all.length>=100)throw Error('Template library is full.');
        const t={id:makeId(),name:String(json.name||'Imported template').slice(0,90),design:CORE.forTemplate(json.design),savedAt:new Date().toISOString()};all.push(t);store(all);input.remove();resolve(t);
      }catch(e){input.remove();reject(e);}};
      input.oncancel=()=>{input.remove();resolve(null);};input.click();
    }),
    copy,
    saveAndReturn:async()=>{throw Error('Save and Return is available only inside Juicy Blueprint Studio.');},
    close:async()=>{window.close();return true;},
    onContext:()=>{}
  };
})();
