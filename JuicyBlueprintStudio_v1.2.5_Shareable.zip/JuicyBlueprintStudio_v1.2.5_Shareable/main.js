const path = require('path');
const { app, BrowserWindow, ipcMain, dialog, shell, clipboard, Tray, Menu, nativeImage, Notification , safeStorage, powerSaveBlocker } = require('electron');
// Chromium's own notices ("PlacementList must be sorted by first 8 bits of display_id" whenever Windows reports a display change) never reach the launcher window: only fatal errors do. The launchers pass the same switch, since Chromium reads it before this file runs.
app.commandLine.appendSwitch('log-level', '3');
const { EDITION, isShare, UPDATE_FOLDER } = require('./lib/edition');
const { Updater } = require('./lib/updater');
const closeChoice = require('./lib/closeChoice');
const { Relay } = require('./lib/aiRelay');
const { AiBotWriter } = require('./lib/aiBotWriter');
// the shareable edition keeps its data in its own folder, so it can never touch the personal edition's data
if (isShare) { app.setName('Juicy Blueprint Studio Shared'); app.setPath('userData', path.join(app.getPath('appData'), 'Juicy Blueprint Studio Shared')); }
// sandbox: a test copy of the app on its own data folder, so a new version can be tried without touching the real data
const Sandbox = require('./lib/sandbox'), SANDBOX = Sandbox.on();
if (SANDBOX) {
  const realDir = app.getPath('userData');
  app.setName('Juicy Blueprint Studio Sandbox');
  app.setPath('userData', path.join(app.getPath('appData'), Sandbox.folderName(isShare)));
  if (Sandbox.wantsCopy()) Sandbox.seed(realDir, app.getPath('userData'));
}
// Keep a unique Windows taskbar identity for each edition, rather than
// grouping the window with Electron's generic development executable.
const WINDOWS_APP_ID = `com.juicyblueprintstudio.${isShare ? 'shareable' : 'personal'}${SANDBOX ? '.sandbox' : ''}`;
if (process.platform === 'win32') app.setAppUserModelId(WINDOWS_APP_ID);
const fs = require('fs');
const { WebpMaker } = require('./lib/webpMaker');
// startup.log (in the app's data folder): a few lines about how the app started and whether the window or tray went wrong, so "it sat in the tray and did nothing" can be diagnosed. Kept small.
const dbg = msg => { try { const f = path.join(app.getPath('userData'), 'startup.log'); fs.mkdirSync(path.dirname(f), {recursive: true}); try { if (fs.statSync(f).size > 60000) fs.writeFileSync(f, ''); } catch {} fs.appendFileSync(f, `${new Date().toISOString()} ${msg}\n`); } catch {} };
dbg(`start v${app.getVersion()} pid ${process.pid} args ${JSON.stringify(process.argv.slice(1))}`);
process.on('uncaughtException', e => { dbg(`uncaughtException: ${e && e.stack || e}`); try { console.error(e); } catch {} });
process.on('unhandledRejection', e => { dbg(`unhandledRejection: ${e && e.stack || e}`); });
// one copy at a time: starting the app again (or Windows starting it at login while it is already open) brings the open window forward instead of running a second copy on the same data
const GOT_LOCK = SANDBOX || app.requestSingleInstanceLock();
if (!GOT_LOCK) { dbg('another copy is already running: handing over and quitting'); app.quit(); }
else app.on('second-instance', () => { dbg('second launch: showing the window'); try { showMainWindow(); } catch (e) { dbg('second-instance show failed: ' + e.message); } });
try { if (!SANDBOX && GOT_LOCK) require('./lib/backup').applyPending(app.getPath('userData')); } catch (e) { console.error('restore:', e.message); }   // a restore asked for in Settings is applied here, before any data is opened
const crypto = require('crypto');
const { JsonStore } = require('./lib/store');
const { parseEventAnnouncement } = require('./lib/eventParser');
const { scoreScenario } = require('./lib/scoring');
const { PythonCollector } = require('./lib/pythonCollector');
const { analyzeEnginesLocal } = require('./lib/engineAnalyzer');
const { analyzeAsync } = require('./lib/analysisWorker');
const { HistoryStore } = require('./lib/history');
const TagBlock = require('./lib/tagBlock');
const { parseCard, repairPastedTitle } = require('./lib/cardParser');
const CardIdentity = require('./renderer/cardidentity');
const Archetype = require('./lib/archetype');
const { removeScenarioCard } = require('./lib/cardLifecycle');
const { BlueprintStore, typeForCard, fieldApplies, norm: bpNorm, tabsOf, isNtrTab, rotationLaneTabs, ntrTabDays } = require('./lib/blueprint');
const WL = require('./lib/weekLists');
const {resetWeek} = require('./lib/weekReset');
const { laneTabs, buildLaneCards, buildLaneLists, hasLocalWriter, writeLaneLocally } = require('./lib/laneCards');
const { writeField, matchField } = require('./lib/fieldWriter');
const { repairSetup } = require('./lib/setupWriter');
const NtrSetup = require('./lib/ntrSetup');
let PW = null; try { PW = require('./renderer/policyweights.js'); } catch { PW = null; }   // PolicyWeights (both editions)
// PolicyWeights: a rebuilt card keeps the on/off choice; a Bonus Idea keeps its weights too (it is rebuilt from the idea you edited).
const keepPolicy = (from, to) => {
  if (!PW || !from || !from.policy || !to) return;
  const keepAll = from.bonusIdea || from.addedBonus || from.slot === 'Bonus';
  if (keepAll) to.policy = JSON.parse(JSON.stringify(from.policy)); else if (typeof from.policy.on === 'boolean') to.policy = {on: from.policy.on};
};
const ThirdParty = require('./lib/thirdParty');
const WI = require('./lib/weekImport');
const CU = require('./lib/cardUpload');
const CR = require('./lib/cardRules');
// your Weekly Blueprint's rules for a card (field instructions, tag count, approved and required tags)
const cardRulesFor = c => { try { return blueprints && blueprints.current() ? CR.rulesFor(blueprints.current(), typeForCard(c), c) : null; } catch { return null; } };
// every improvement request (Improve with AI, the ChatGPT fix request, the 80+ pass) carries those rules
const fixRequestWithRules = (c, plan) => { const R = cardRulesFor(c), t = CR.rulesText(R); return WI.fixRequest(c, plan) + (t ? `\n\n${t}` : ''); };
const { adaptToEvent } = require('./lib/eventAdapt');
const EventCard = require('./lib/eventCard');
const Events = require('./lib/events');
const Suggest = require('./lib/suggest');
const SuggestLocal = require('./lib/suggestLocal');
const EventRules = require('./renderer/eventrules.js');
const { ACCOUNTS, ensureAccounts, cardsFor, mergePull, autoLink, syncPerformance, linkableCards, archiveWeek } = require('./lib/myBots');
const { freeze, evaluate, learn, applyCalibration } = require('./lib/calibration');
const { generateWeekLocal, regenerateScenarioLocal, chooseArchetype } = require('./lib/procedural');
const SeriesLib = require('./lib/series');
const NtrScope = require('./lib/ntrScope');
const { validateWeekLocal } = require('./lib/validator');
const { parseTemplate, loadTemplates } = require('./lib/botTemplates');
const { buildBonusFromIdea, assessIdea, assessScenario, applyAssessment, ideaText } = require('./lib/bonus');

let mainWindow;
let backup = null;   // automatic backup to a user-chosen folder (lib/backup.js)
let store;
let collector;
let webpMaker;
// Visual Introduction Designer, available as a separate local window.
const {register:registerIntroductionDesigner}=require('./introduction-designer/host');
const introDesigner=registerIntroductionDesigner({app,BrowserWindow,ipcMain,clipboard,dialog,parentWindow:()=>mainWindow,standalone:false});

const resourcesDir = path.join(__dirname, 'resources');
const rulesPath = path.join(resourcesDir, 'rules', 'weekly_blueprint_rules.txt');
const templatePath = path.join(resourcesDir, 'rules', 'weekly_blueprint_template.html');
// optional reference files (not needed to run; the shareable edition doesn't include them)
const readOpt = f => { try { return fs.readFileSync(f, 'utf8'); } catch { return ''; } };
// The two schedules (personal edition). Each one uses YOUR saved files when you have them, else the ones that came with the app:
//   3 bots/day (the Kill Switch): the Kill Switch rulebook + card template you upload in Settings > Weekly Blueprint (else the bundled *_3_per_day files)
//   2 bots/day: your own 2-bots-per-day rulebook + card template, kept from your last Update Blueprint on that schedule (else the bundled files)
const bundledPair = n => ({rules: path.join(resourcesDir, 'rules', n === 3 ? 'weekly_blueprint_rules_3_per_day.txt' : 'weekly_blueprint_rules.txt'), template: path.join(resourcesDir, 'rules', n === 3 ? 'weekly_blueprint_template_3_per_day.html' : 'weekly_blueprint_template.html')});
const schedDir = n => path.join(app.getPath('userData'), 'blueprint', 'schedules', n === 3 ? 'kill-switch-3-per-day' : 'main-2-per-day');
const schedInfo = n => { try { const i = JSON.parse(fs.readFileSync(path.join(schedDir(n), 'info.json'), 'utf8')); return i && i.rulesName && i.templateName && fs.existsSync(path.join(schedDir(n), i.rulesName)) && fs.existsSync(path.join(schedDir(n), i.templateName)) ? i : null; } catch { return null; } };
const schedulePair = n => { const i = schedInfo(n); return i ? {rules: path.join(schedDir(n), i.rulesName), template: path.join(schedDir(n), i.templateName), own: true} : {...bundledPair(n), own: false}; };
const cleanFileName = (n, fallback) => String(path.basename(String(n || '')) || fallback).replace(/[\\/:*?"<>|]/g, '_') || fallback;
// keeps a copy of a rulebook + card template as your files for one schedule (under their own names, so the blueprint shows them by name)
function saveSchedFiles(n, rulesText, templateHtml, rulesName, templateName) {
  const d = schedDir(n); fs.rmSync(d, {recursive: true, force: true}); fs.mkdirSync(d, {recursive: true});
  const rn = cleanFileName(rulesName, 'rules.txt'), tn0 = cleanFileName(templateName, 'template.html'), tn = tn0 === rn ? 'template-' + tn0 : tn0;
  fs.writeFileSync(path.join(d, rn), rulesText, 'utf8'); fs.writeFileSync(path.join(d, tn), templateHtml, 'utf8');
  const info = {rulesName: rn, templateName: tn, savedAt: new Date().toISOString()}; fs.writeFileSync(path.join(d, 'info.json'), JSON.stringify(info, null, 2)); return info;
}
// how many cards a day a rulebook + card template give (2 or 3), read the same way the week plan is read
const perDayOf = (rulesText, templateHtml) => { try { const sc = require('./lib/blueprint.js').buildSchema(rulesText, templateHtml), d = require('./lib/weekPlan').planOf(sc).days || []; return d.length ? Math.max(...d.map(x => x.cards || 0)) : 0; } catch { return 0; } };
const scheduleHere = () => { try { const d = blueprints && blueprints.plan().days; return d && d.length ? Math.max(...d.map(x => x.cards || 0)) : 0; } catch { return 0; } };
const scheduleStatus = () => {
  const ok = n => { const p = schedulePair(n); return fs.existsSync(p.rules) && fs.existsSync(p.template); };
  const perDay = scheduleHere(), cur = blueprints ? blueprints.rulesText() : '', curT = blueprints ? blueprints.templateText() : '';
  // "matches": the blueprint in use is exactly the files that schedule loads (yours, or the app's when you have none)
  const same = n => { try { const p = schedulePair(n); return ok(n) && fs.readFileSync(p.rules, 'utf8') === cur && fs.readFileSync(p.template, 'utf8') === curT; } catch { return false; } };
  // the 2 / 3 bots-a-day switch and the Kill Switch upload are retired: the app runs on its one rulebook (3 bots a day), so Settings no longer shows them
  return {available: false, perDay, bundled: same(2) ? 2 : same(3) ? 3 : 0, matches: same(perDay), own: {2: schedInfo(2), 3: schedInfo(3)}};
};
// how many core day scenarios a full week has under the schedule in use
const coreWanted = () => { try { const d = blueprints && blueprints.plan().days; return d && d.length ? d.reduce((n, x) => n + (x.cards || 0), 0) : 21; } catch { return 21; } };
const rulesText = readOpt(rulesPath);
const templateText = readOpt(templatePath);
void rulesText; void templateText;

function send(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
}
// an open slot in a tab the app has no writer for (nothing written or imported into it yet)
const isOpenSlot = c => !!c && (!!c.laneTab || !!c.blankSlot) && !c.imported && !c.aiWritten && !c.localWritten;      // blankSlot: a card emptied by Clear & Reset Tab
function flattenWeek(week) { return WL.weekCards(week).filter(c => !isOpenSlot(c)); }
// imported cards sorted into the week's lists: day cards, NTR, Bonus, and one list per extra tab
function splitImported(cards) {
  const out = {scenarios: [], ntr: [], bonus: []};
  for (const c of cards) {
    if (c.laneTab) (out[WL.laneName(c.laneTab)] = out[WL.laneName(c.laneTab)] || []).push(c);
    else if (c.slot === 'NTR') out.ntr.push(c); else if (c.slot === 'Bonus') out.bonus.push(c); else out.scenarios.push(c);
  }
  return out;
}
const hasNtrTab = () => !isShare && tabsOf(blueprints && blueprints.current()).some(t => t.kind === 'ntr');      // a template without an NTR tab means no NTR cards
// the combined NTR tab: Likeable NTR, Preventable NTR and Post-NTR alternate over the 7 days on ONE tab. Each kind keeps its own list
// (week.ntr and its lane lists), its own fields and its own rulebook section; these helpers show and handle them together as the NTR tab.
const rotationLanes = () => isShare ? [] : rotationLaneTabs(blueprints && blueprints.current());
const isCombinedNtr = () => hasNtrTab() && rotationLanes().length > 0;
const ntrDaysNow = () => (isShare ? null : ntrTabDays(blueprints && blueprints.current()));
const weekPlanNow = () => blueprints ? blueprints.plan() : require('./lib/weekPlan').planOf(null);      // the week as the loaded rulebook and template describe it (plus what you typed in for parts the rulebook does not state)
// a week is only built from a plan the app has read in full: no filling gaps from old defaults
const needPlan = () => { const WP = require('./lib/weekPlan'), msg = WP.missingMessage(weekPlanNow(), isShare); if (msg) throw new Error(msg); };
const WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const cardDay = c => WEEKDAYS.includes(c && c.day) ? c.day : String(((c && c.fields) || {})['Day Assignment'] || '').trim();
const byCardDay = (a, b) => { const x = WEEKDAYS.indexOf(cardDay(a)), y = WEEKDAYS.indexOf(cardDay(b)); return (x < 0 ? 9 : x) - (y < 0 ? 9 : y); };
function combinedNtrCards(week) {
  const w = week || {}, out = [...(w.ntr || [])];
  for (const t of rotationLanes()) out.push(...(w[WL.laneName(t.key)] || []));
  return out.sort(byCardDay);
}
// The combined NTR tab holds exactly ONE card per day, each day's own card type (NTR, Preventable NTR or Post-NTR).
// A card on the wrong day moves to a free day of its own type; a card with no free day left leaves the week (archived with its
// score, never deleted); a day with no card gets a blank slot. Built cards are kept first. Returns how many cards changed.
function normalizeNtrRotation(state, schema) {
  const w = state.week; if (isShare || !w || !(w.scenarios || []).length) return 0;
  const tabs = tabsOf(schema).filter(t => t.rotation); if (!tabs.some(t => t.kind === 'ntr')) return 0;
  w.statuses = w.statuses || {}; let changed = 0;
  const rank = c => (w.statuses[c.id] === 'Built' ? 0 : isOpenSlot(c) ? 2 : 1);
  for (const t of tabs) {
    const name = t.kind === 'ntr' ? 'ntr' : WL.laneName(t.key), days = t.rotation.days, list = Array.isArray(w[name]) ? w[name] : [];
    // a lane card whose Day Assignment holds text instead of a day (an AI write that copied the field's instruction) gets the day back: the one of this tab's days named in it
    for (const c of list) { if (!c.laneTab || !c.fields || WEEKDAYS.includes(String(c.fields['Day Assignment'] || '').trim())) continue;
      const named = days.filter(d => new RegExp('\\b' + d + '\\b', 'i').test(String(c.fields['Day Assignment'] || ''))); if (named.length === 1) { c.fields['Day Assignment'] = named[0]; changed++; } }
    const placed = new Map(), added = list.filter(isAdded), rest = list.filter(c => !isAdded(c)).sort((a, b) => rank(a) - rank(b));
    const leftover = [];
    // Built cards are placed first (on their own day, or moved to a free day), then the rest, so a Built card never loses its place to an unbuilt one
    for (const group of [rest.filter(c => rank(c) === 0), rest.filter(c => rank(c) !== 0)]) {
    const extra = [];
    for (const c of group) { const d = cardDay(c); if (days.includes(d) && !placed.has(d)) placed.set(d, c); else extra.push(c); }
    for (const c of extra) {
      const free = days.find(d => !placed.has(d));
      if (!free) { leftover.push(c); continue; }
      if (WEEKDAYS.includes(c.day) || (t.kind === 'ntr' && !c.laneTab)) c.day = free;      // NTR cards carry their day (also one an earlier AI write had reset to "NTR"); tab cards carry a Day Assignment
      if (c.laneTab || (c.fields || {})['Day Assignment'] !== undefined) { c.fields = c.fields || {}; c.fields['Day Assignment'] = free; }
      placed.set(free, c); changed++;
    }
    }
    const written = leftover.filter(c => !isOpenSlot(c));
    if (written.length) { for (const c of written) freeze(state, c, 'archived'); archiveWeek(state, written, w.weekStart || ''); }
    for (const c of leftover) delete w.statuses[c.id];
    changed += leftover.length;
    for (const d of days) {
      if (placed.has(d)) continue;
      const id = `${t.kind === 'ntr' ? 'ntr' : 'lane-' + t.key}-${d.slice(0, 3).toLowerCase()}-${crypto.randomBytes(3).toString('hex')}`;
      const b = t.kind === 'ntr'
        ? {id, day: d, slot: 'NTR', series: 'Likeable NTR', lane: 'Likeable NTR', sceneName: 'Untitled', primaryCharacter: '', cast: [], tags: [], fields: {}, blankSlot: true}
        : {...buildLaneCards(t).find(x => x.fields['Day Assignment'] === d), id};
      placed.set(d, b); w.statuses[id] = 'Idea'; changed++;
    }
    w[name] = [...days.map(d => placed.get(d)), ...added];
    if (t.kind !== 'ntr') w[name].forEach((c, i) => { if (i < days.length && c.order !== i + 1) { c.order = i + 1; } });
  }
  return changed;
}
const laneLabels = () => Object.fromEntries(laneTabs(blueprints && blueprints.current(), isShare).map(t => [t.key, t.label]));
// Keep the week's extra tabs in step with the Weekly Blueprint: a tab the template now has gets its open
// slots; a tab the template no longer has leaves the week (written cards are archived, never deleted).
function reconcileLanes(state, schema) {
  const w = state.week; if (!w || !(w.scenarios || []).length) return {added: [], removed: [], modesUpdated: 0};
  const want = laneTabs(schema, isShare), keys = new Set(want.map(t => t.key)), added = [], removed = []; let modesUpdated = 0;
  w.statuses = w.statuses || {};
  for (const t of want) {
    const name = WL.laneName(t.key);
    // blank slots in a tab the app can write itself (left by an older version, or a template that just gained the tab) are written now
    if (Array.isArray(w[name]) && hasLocalWriter(t) && w[name].length && w[name].every(isOpenSlot)) {
      w[name] = ensureIds(writeLaneLocally(t, w[name].map(c => ({...c, sceneName: 'Untitled', fields: {'Day Assignment': (c.fields || {})['Day Assignment']}})), schema));
      for (const c of w[name]) w.statuses[c.id] = w.statuses[c.id] || 'Idea'; added.push(t.label); continue;
    }
    // cards the app wrote under a mode the rulebook no longer has (or has renamed) are rewritten under one it has now (Built cards are left alone)
    if (Array.isArray(w[name]) && hasLocalWriter(t) && !isShare) {
      const pg = require('./lib/preventableGen');
      w[name] = w[name].map(c => { if (w.statuses[c.id] === 'Built') return c; try { const f = pg.refreshMode(c, schema); if (f) { modesUpdated++; if (state.predictionLog) delete state.predictionLog[c.id]; } return f || c; } catch (e) { console.error('mode refresh:', e.message); return c; } });
    }
    if (Array.isArray(w[name])) continue;
    w[name] = ensureIds(writeLaneLocally(t, buildLaneCards(t), schema)); for (const c of w[name]) w.statuses[c.id] = 'Idea'; added.push(t.label);
  }
  for (const name of Object.keys(w)) {
    if (!WL.isLaneName(name) || keys.has(WL.laneKeyOf(name))) continue;
    const cards = w[name] || [], written = cards.filter(c => (c.sceneName && c.sceneName !== 'Untitled') || Object.keys(c.fields || {}).some(k => k !== 'Day Assignment'));
    if (written.length) { for (const c of written) freeze(state, c, 'archived'); archiveWeek(state, written, w.weekStart || ''); }
    for (const c of cards) delete w.statuses[c.id];
    removed.push((cards[0] || {}).slot || WL.laneKeyOf(name)); delete w[name];
  }
  if (!isShare && !hasNtrTab() && (w.ntr || []).length) {            // the template no longer has an NTR tab
    for (const c of w.ntr) freeze(state, c, 'archived'); archiveWeek(state, w.ntr, w.weekStart || '');
    for (const c of w.ntr) delete w.statuses[c.id]; removed.push('NTR'); w.ntr = [];
  }
  const rotated = normalizeNtrRotation(state, schema);
  if (added.length || removed.length || modesUpdated || rotated) scoreWeek(state);
  return {added, removed, modesUpdated, rotated};
}
// every card that belongs to the week itself (all tabs except Bonus)
function weekOwnCards(week) { return WL.weekListNames(week).filter(n => n !== 'bonus').flatMap(n => (week && week[n]) || []).filter(c => !isOpenSlot(c)); }
function ensureIds(items) {
  const seen = new Set();
  return items.map((s, i) => {
    let id = String(s.id || `${(s.day || 'x').slice(0,3)}-${(s.slot || 'slot').replace(/\W+/g,'-')}-${i}`).toLowerCase();
    while (seen.has(id)) id += '-' + crypto.randomBytes(2).toString('hex');
    seen.add(id);
    return {...s, id};
  });
}
// the estimate compares a card with every collected bot, so it is kept per card until the card, the analysis or the data changes
const assessMemo = new Map();
function applyAssessmentCached(s, L, peers) {
  const sig = JSON.stringify([s.fields, s.sceneName, s.bonusIdea || null, s.series, s.primaryArchetype, s.tags, s.cast, L.engineAnalysis && L.engineAnalysis.generatedAt, L.event && L.event.name, (L.performance || []).length, ((L.datasets || {}).recent || []).length, ((L.datasets || {}).trending || []).length]);
  let hit = assessMemo.get(s.id);
  if (!hit || hit.sig !== sig) { hit = {sig, a: assessScenario(s, L)}; assessMemo.set(s.id, hit); }
  return applyAssessment(s, L, peers, JSON.parse(JSON.stringify(hit.a)));
}
// one score on every card: a card needs scoring again when it has no saved estimate, or its ring is not the estimate
function needsRescore(st) { return !!(st.week && (flattenWeek(st.week).some(c => !c.bonusAssessment || !c.prediction || c.prediction.score !== c.bonusAssessment.score) || WL.weekCards(st.week).some(NtrScope.hasNtrOnlyFields) || WL.weekCards(st.week).some(c => Archetype.needsClean(c)))); }
function scoreWeek(state) {
  // a card that is not an event card has no Event tag, event tags or event fields (the Event card switch, and the series that are never entered)
  for (const c of WL.weekCards(state.week)) EventCard.normalize(c, state.settings);
  try { if (blueprints) fillBlueprintFields(state, blueprints.current()); } catch (e) { console.error(e); }
  const all = flattenWeek(state.week);
  for (const s of all) { CardIdentity.normalizeCard(s); Archetype.clean(s); try { require('./lib/castRule').soloFix(s); } catch (e) { /* tags stay as they are */ } }     // the archetype field is one approved name, never a paragraph
  // NTR-only engine fields (Scenario Engine, Engine Machine, ...) belong on the NTR tab only: older weeks lose them from every other card
  for (const c of WL.weekCards(state.week)) NtrScope.stripNtrOnlyFields(c);
  // open slots are left out of flattenWeek, so they carry no score
  for (const c of WL.weekCards(state.week)) if (isOpenSlot(c)) delete c.prediction;
  const live = all;
  for (const s of live) Events.annotate(s, state);        // which event each card is entered in (the screen reads eventKey / eventLabel)
  for (const s of live) s.prediction = scoreScenario(s, state.engineAnalysis, Events.forCard(state, s), all);
  const L = history ? withLearning(state) : state;
  // ONE score on every card: the ring is the card's Success estimate (the card compared with the collected Recent and Trending bots), so the ring and the estimate panel always show the same number
  for (const c of live) applyAssessmentCached(c, L, all);
  // corrections learned from your bots' real results adjust every score
  for (const s of live) s.prediction = applyCalibration(state.calibration, s, s.prediction);
  // what was learned from real results is part of the score, so it is shown inside the estimate too (the panel then shows exactly the ring's number)
  for (const s of live) { const a = s.bonusAssessment, p = s.prediction; if (!a || !p) continue;
    if (p.calibrated) a.breakdown = [...(a.breakdown || []), {label: 'Learned from your real results', delta: p.calibrated, detail: p.calNote || 'Adjusted by how your own bots with similar traits actually performed.'}];
    a.score = p.score; }
}
// Freeze scores of cards you've acted on, measure them against real results,
// learn corrections, and re-score the current week with them.
function refreshAccuracy(state, reason = 'built') {
  ensureAccounts(state);
  const all = flattenWeek(state.week), linkedIds = new Set(Object.values(state.accounts).flatMap(a => Object.keys(a.links || {}).filter(k => a.links[k])));
  for (const c of all) if (String(state.week.statuses?.[c.id] || '') === 'Built' || linkedIds.has(c.id)) freeze(state, c, reason);
  const {evals, maturing} = evaluate(state), {metrics, calibration} = learn(evals);
  state.accuracy = {...metrics, evals, maturing, updatedAt: new Date().toISOString()};
  state.calibration = calibration;
  scoreWeek(state);
}
// ---- Weekly Blueprint from your own files (Settings > Weekly Blueprint)
let blueprints = null;
const APPROVED_BASE = [...require('./lib/blueprintRules').APPROVED_TAGS];
function applyBlueprintTags(schema) {
  const A = require('./lib/blueprintRules').APPROVED_TAGS;
  const next = schema && Array.isArray(schema.approvedTags) && schema.approvedTags.length >= 10 ? schema.approvedTags : APPROVED_BASE;
  A.length = 0; A.push(...next);
}
const fieldMatch = (label, fields, labels) => matchField(label, fields, labels);
function fillBlueprintFields(state, schema) {
  // built-in blueprint (version 0): cards stay exactly as the app builds them, except cards in tabs the template defines (they have no other source)
  const own = !!(schema && schema.version);
  for (const c of WL.weekCards(state.week)) if (!own && !c.laneTab) delete c.bpNeeds;
  if (!schema) return 0;
  let added = 0;
  const cards = WL.weekCards(state.week).filter(c => own || c.laneTab);
  for (const c of cards) {
    try { ThirdParty.rename(c); } catch (e) { console.error('third party rename:', e.message); }       // the other man is the Third Party on the NTR tabs; "Antagonist" is the ANTI-NTR card's
    try { if (!c.blankSlot && NtrSetup.ensure(c, writeField)) added++; } catch (e) { console.error('setup:', e.message); }      // the Greeting is written from The Setup: NTR and Preventable NTR cards always have one
    const t = schema.types?.[typeForCard(c)]; if (!t) continue;
    c.fields = c.fields || {}; c.bpNeeds = [];
    const labelsOfType = typeForCard(c) === 'ntr' ? t.fields.map(f => f.label) : null;      // rows on the NTR tab keep to their own template row; other tabs match as they always did
    for (const f of t.fields) {
      if (fieldMatch(f.label, c.fields, labelsOfType)) continue;
      if (!fieldApplies(f.label, f.instruction, c, typeForCard(c))) continue;      // a field that belongs to other cards (for example ANTI-NTR's Antagonist) is not asked of this one
      if (c.laneTab || c.blankSlot) { c.bpNeeds.push(f.label); continue; }          // a tab the app has no writer for (or a card emptied by Clear & Reset): never invent its story, leave it to write or import
      let v = ''; try { v = writeField(f.label, f.instruction, c); } catch (e) { console.error('field writer:', f.label, e.message); }
      if (v) { c.fields[f.label] = v; c.autoFilled = [...new Set([...(c.autoFilled || []), f.label])]; added++; }
      else c.bpNeeds.push(f.label);
    }
  }
  return added;
}

// ---- every bot gets its own app score, automatically, the first time a pull sees it
// Scored from what JuicyChat shows about it (title, description, tags) with the same
// estimator Bonus Ideas uses, against the collected market bots, never its own numbers.
// Frozen at that moment. Bots already live for more than 2 days are marked "scored after launch".
function scoreNewBots(state, acct, preRead) {
  const { assessIdea } = require('./lib/bonus');
  acct.botScores = acct.botScores || {};
  const data = preRead || learningData(state), fresh = (acct.bots || []).filter(b => !acct.botScores[b.id]);
  if (!fresh.length) return 0;
  for (const b of fresh) {
    const own = String(b.url || '');
    const ds = {recent: (data.recent || []).filter(r => r.url !== own), trending: (data.trending || []).filter(r => r.url !== own)};   // never peek at itself
    let r = null;
    try { r = assessIdea({text: [b.title, b.description, (b.tags || []).join(', ')].filter(Boolean).join('. ')}, {engineAnalysis: state.engineAnalysis, datasets: ds, event: state.event, performance: state.performance}); } catch (e) { console.error('bot score:', b.title, e.message); }
    if (!r || r.score == null) continue;
    const from = Date.parse(b.created || '') || null, age = from ? (Date.now() - from) / 86400000 : null;
    const dsc = String(b.description || ''), series = (dsc.match(/^\s*\[\s*["“]?([^\]"”]*?)["”]?\s*Series\s*\d*\s*\]/i) || dsc.match(/^\s*\[\s*["“]?(Preventable NTR)["”]?\s*\d*\s*\]/i) || [, ''])[1];   // the Preventable NTR label has no Series and no number
    acct.botScores[b.id] = {score: r.score, raw: r.score, confidence: r.confidence || '', engineId: r.bestEngine?.id || '', engineName: r.bestEngine?.name || '',
      series: series ? `${series.trim()} Series` : '', at: new Date().toISOString(), retro: age == null ? true : age > 2, ageAtScoring: age == null ? null : Math.round(age * 10) / 10};
  }
  return fresh.length;
}

// Starting with Windows now opens the window like any other start (older startup entries still pass --background; it is ignored). The tray icon is still there.
const STARTED_IN_BACKGROUND = false;
let tray = null, hiddenTipShown = false;
function showMainWindow() {
  try {
    if (!mainWindow || mainWindow.isDestroyed()) { mainWindow = null; createMainWindow(); }
    else if (mainWindow.webContents.isCrashed()) { dbg('window page had crashed: reloading'); mainWindow.webContents.reload(); }
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.setSkipTaskbar(false); mainWindow.show(); mainWindow.focus(); dbg('window shown');
  } catch (e) { dbg('showMainWindow failed: ' + (e && e.stack || e)); try { mainWindow = null; createMainWindow(); mainWindow.show(); } catch (e2) { dbg('recreate failed: ' + e2.message); } }
}
// The close question is drawn by the app page itself (the tool's own look, no separate system window). If the page cannot show it within a moment, a plain system box is the fallback.
let closeAsk = null;
// A job remains active during both Electron frame extraction and ImageMagick encoding.
function webpConversionActive() { return !!(webpMaker && webpMaker.job && !webpMaker.job.cancelled); }
function askClose(trayOk) {
  return new Promise(resolve => {
    const wc = mainWindow && !mainWindow.isDestroyed() ? mainWindow.webContents : null;
    let done = false, acked = false, timer = null;
    const finish = v => { if (done) return; done = true; clearTimeout(timer); closeAsk = null; resolve(v === 'exit' || v === 'tray' ? v : 'cancel'); };
    // Fallback only if the in-app dialog cannot appear. Never quit an active
    // conversion without asking again, even when the renderer is unavailable.
    const native = () => {
      if (done) return;
      try { wc && wc.send('app:closeAskCancel'); } catch {}
      closeChoice.nativeAsk(dialog, mainWindow, trayOk).then(async choice => {
        if (choice !== 'exit' || !webpConversionActive()) return finish(choice);
        try {
          const opts = {type:'warning',title:'WebP Maker',message:'Abort WebP conversion and exit?',
            detail:'A WebP conversion is still running. Exiting will stop it and discard its unfinished output.',
            buttons:['Keep converting','Abort conversion and exit'],defaultId:0,cancelId:0,noLink:true};
          const answer = await dialog.showMessageBox(mainWindow && !mainWindow.isDestroyed() ? mainWindow : undefined, opts);
          if(answer.response !== 1) return finish('cancel');
          try { webpMaker.cancel(); } catch {}
          finish('exit');
        } catch { finish('cancel'); }
      }, () => finish('cancel'));
    };
    if (!wc || wc.isCrashed() || wc.isLoading()) return native();
    closeAsk = {finish, ack: () => { acked = true; }};
    timer = setTimeout(() => { if (!acked) native(); }, 1500);
    try { wc.send('app:closeAsk', {tray: !!trayOk}); } catch { native(); }
  });
}
function createTray(checkUpdates) {
  if (tray) return;
  try {
    tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'resources', 'icons', 'tray.png')));
    tray.setToolTip(`Juicy Blueprint Studio v${app.getVersion()}`);
    tray.setContextMenu(Menu.buildFromTemplate([
      {label: 'Open Juicy Blueprint Studio', click: showMainWindow},
      {label: 'Check for updates', click: () => { showMainWindow(); checkUpdates(true); }},
      {type: 'separator'},
      {label: 'Quit', click: () => { if(webpConversionActive() && mainWindow && !mainWindow.isDestroyed()){showMainWindow();mainWindow.close();}else{app.isQuitting=true;app.quit();} }},
    ]));
    tray.on('double-click', () => { dbg('tray double-click'); showMainWindow(); }); tray.on('click', () => { dbg('tray click'); showMainWindow(); });
  } catch (e) { console.error('tray:', e.message); }
}
// ---- Bonus ideas can go on a release day (Monday-Sunday, or NTR in the personal edition) as Scenario n+1
const isAdded = c => !!c && (c.addedBonus || (c.bonusIdea && c.day && c.day !== 'Bonus' && c.slot !== 'Bonus'));
const RELEASE_DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
function placeBonus(week, card, day) {
  const where = RELEASE_DAYS.includes(day) ? 'scenarios' : day === 'NTR' && !isShare ? 'ntr' : 'bonus';
  week.scenarios = week.scenarios || []; week.ntr = week.ntr || []; week.bonus = week.bonus || [];
  if (where === 'bonus') { card.day = 'Bonus'; card.slot = 'Bonus'; delete card.addedBonus; week.bonus.unshift(card); return 'the Bonus tab'; }
  const sameDay = where === 'ntr' ? week.ntr : week.scenarios.filter(c => c.day === day);
  card.day = day; card.slot = `Scenario ${sameDay.length + 1}`; card.addedBonus = true;
  week[where].push(card);
  return `${day} as ${card.slot}`;
}
// renumber the added cards on each day after that day's other cards (after a new week or an import)
function reattachBonus(week, kept) {
  for (const c of kept) { const day = c.day; delete c.addedBonus; placeBonus(week, c, day); }
}

// ---- character limits a template doesn't set: asked from the user once, saved per template, never invented
const LIMIT_SECTIONS = ['introduction', 'personality', 'scenario', 'greeting'];
const userLimitsFile = () => path.join(app.getPath('userData'), 'template-limits.json');
function readUserLimits() { try { return JSON.parse(fs.readFileSync(userLimitsFile(), 'utf8')) || {}; } catch { return {}; } }
function writeUserLimits(all) { fs.writeFileSync(userLimitsFile(), JSON.stringify(all, null, 2)); }
let templateDirsFn = null;                                       // set at start-up, where the template folders are known
const hiddenFile = () => path.join(app.getPath('userData'), 'templates-hidden.json');
function readHidden() { try { return JSON.parse(fs.readFileSync(hiddenFile(), 'utf8')) || []; } catch { return []; } }
function writeHidden(list) { fs.writeFileSync(hiddenFile(), JSON.stringify([...new Set(list)], null, 2)); }
function templatesWithLimits({includeHidden = false} = {}) {
  const all = readUserLimits(), dirs = templateDirsFn ? templateDirsFn() : [], hidden = new Set(readHidden());
  const list = loadTemplates(dirs).filter(t => includeHidden || !hidden.has(t.id)).sort(require('./lib/templateNames').compare);      // by number (1, 2 ... 10, 11), then alphabetically
  for (const t of list) {                                          // yours (added or replaced) or built-in
    const mine = dirs[0] && path.join(dirs[0], t.id), built = dirs[1] && path.join(dirs[1], t.id);
    t.source = mine && fs.existsSync(mine) ? 'yours' : 'built-in';
    t.replacesBuiltIn = t.source === 'yours' && !!built && fs.existsSync(built);
    t.updatedAt = t.source === 'yours' ? fs.statSync(mine).mtime.toISOString() : null;
    t.hidden = hidden.has(t.id);
  }
  // only your own templates are listed (Bot Builder, Build Bot, every picker) once you have any: the built-in ones stay out of every list,
  // and are only kept so a saved bot or draft made on one still opens
  const anyMine = list.some(t => t.source === 'yours');
  for (const t of list) t.unlisted = anyMine && t.source === 'built-in';
  return list.map(t => {
    const mine = all[t.id] || {}; const missing = [];
    for (const sec of LIMIT_SECTIONS) {
      if (!t[sec] || t[sec].absent) continue;                                  // a section the template doesn't have needs no limit
      if (t[sec].limit) continue;                                              // the template's own limit always wins
      if (mine[sec] && mine[sec].min > 0 && mine[sec].max >= mine[sec].min) t[sec].limit = {min: mine[sec].min, max: mine[sec].max, fromUser: true};
      else missing.push(sec);
    }
    t.missingLimits = missing;
    // the locked Appearance quality prompt and Negative Prompt: the ones set in Settings win over the template's own (so each person can set theirs)
    if (t.image) {
      const il = (store && store.state && store.state.settings && store.state.settings.imageLocks) || {};
      if (t.image.templateQuality === undefined) t.image.templateQuality = t.image.quality || '';
      if (t.image.templateNegative === undefined) t.image.templateNegative = t.image.negative || '';
      t.image.quality = il.quality || t.image.templateQuality; t.image.negative = il.negative || t.image.templateNegative;
      t.image.qualityFromSettings = !!il.quality; t.image.negativeFromSettings = !!il.negative;
    }
    // a combined total that the sections' own limits can never reach (or always exceed) is a contradiction in the template
    { const R = t.rules && t.rules.total, have = ['personality', 'scenario', 'greeting'].filter(k => t[k] && !t[k].absent && t[k].limit);
      if (R && have.length >= 2) { const lo = have.reduce((a, k) => a + t[k].limit.min, 0), hi = have.reduce((a, k) => a + t[k].limit.max, 0);
        t.limitConflict = !R.softMin && R.min > hi ? `Your template's combined total needs at least ${R.min.toLocaleString()} characters, but its ${have.join(', ')} limits allow at most ${hi.toLocaleString()} together.`
          : !R.softMax && R.max < lo ? `Your template's combined total allows at most ${R.max.toLocaleString()} characters, but its ${have.join(', ')} limits need at least ${lo.toLocaleString()} together.` : ''; } }
    return t;
  });
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    icon: path.join(__dirname, 'resources', 'icons', process.platform === 'win32' ? 'app.ico' : 'app.png'),
    show: !STARTED_IN_BACKGROUND,
    width: 1480, height: 940, minWidth: 1120, minHeight: 720,
    title: SANDBOX ? 'Juicy Blueprint Studio \u2014 SANDBOX (test copy)' : 'Juicy Blueprint Studio', backgroundColor: '#0e0b12',
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
  });
  // Windows sometimes shows the Electron executable's taskbar icon when
  // launching an unpackaged app. Explicitly set this window's JB icon too.
  if (process.platform === 'win32') {
    try {
      const jbIcon = nativeImage.createFromPath(path.join(__dirname, 'resources', 'icons', 'app.ico'));
      if (!jbIcon.isEmpty()) mainWindow.setIcon(jbIcon);
      mainWindow.setAppDetails({
        appId: WINDOWS_APP_ID,
        appIconPath: path.join(__dirname, 'resources', 'icons', 'app.ico'),
        appIconIndex: 0
      });
    } catch (error) { console.warn('Window icon:', error.message); }
  }
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  mainWindow.once('ready-to-show', () => dbg('window ready'));
  mainWindow.webContents.on('did-fail-load', (_e, code, desc) => dbg(`page failed to load: ${code} ${desc}`));
  mainWindow.webContents.on('render-process-gone', (_e, d) => dbg(`page process gone: ${d && d.reason}`));
  mainWindow.on('unresponsive', () => dbg('window not responding'));
  if (SANDBOX) mainWindow.webContents.on('dom-ready', () => { try { mainWindow.webContents.executeJavaScript(`(()=>{if(document.getElementById('sandbox-bar'))return;const d=document.createElement('div');d.id='sandbox-bar';d.textContent='SANDBOX: a test copy with its own data. Nothing here changes your real app, and nothing runs automatically.';d.style.cssText='position:fixed;left:0;right:0;top:0;z-index:99999;background:#b3261e;color:#fff;font:600 12px system-ui;text-align:center;padding:3px 8px;pointer-events:none';document.body.appendChild(d);document.body.style.paddingTop='22px';})()`); } catch (e) { console.error(e); } });
  // started with Windows: run quietly in the system tray (double-click the tray icon to open)
  if (STARTED_IN_BACKGROUND) mainWindow.once('ready-to-show', () => mainWindow.hide());
  mainWindow.on('session-end', () => { app.isQuitting = true; });          // Windows is shutting down or logging off: never hold that up with a question
  mainWindow.on('close', closeChoice.make({
    ask: askClose, isQuitting: () => !!app.isQuitting, hasTray: () => !!tray, log: dbg,
    onExit: () => { app.isQuitting = true; app.quit(); },
    onTray: () => {
      if (mainWindow && !mainWindow.isDestroyed()) mainWindow.hide();           // keep running for the 8 PM pulls and the backups
      if (tray && !hiddenTipShown) { hiddenTipShown = true; try { tray.displayBalloon({title: 'Juicy Blueprint Studio is still running', content: 'It keeps running in the tray. Double-click the tray icon to open it, or right-click it and choose Quit to close it.'}); } catch {} }
    },
  }));
  mainWindow.webContents.setWindowOpenHandler(({url}) => { if (/^https?:/i.test(url)) shell.openExternal(url); return {action:'deny'}; });
}
function cleanSettings(input) {
  const s = {...store.state.settings};
  for (const k of ['gender','juicyHomeUrl']) if (input[k] !== undefined) s[k] = String(input[k]).trim();
  for (const k of ['targetRecent','targetTrending']) if (input[k] !== undefined) s[k] = Math.max(1, Math.min(500, Number(input[k]) || 100));
  for (const k of ['autoCollect','autoPerformance','openAtLogin']) if (input[k] !== undefined) s[k] = !!input[k];
  if (Array.isArray(input.blockedTags)) s.blockedTags = TagBlock.clean(input.blockedTags);
  if (Array.isArray(input.eventSkipSeries)) s.eventSkipSeries = [...new Set(input.eventSkipSeries.map(x => String(x).trim().slice(0, 60)).filter(Boolean))].slice(0, 60);
  if (input.ratingRules !== undefined && typeof input.ratingRules === 'object') { const r = {}; for (const k of ['main','ntr']) { const x = input.ratingRules[k]; if (x && typeof x.field === 'string' && x.field.length < 60) r[k] = {field: x.field, value: String(x.value).slice(0, 40)}; } s.ratingRules = r; }
  if (input.updateFolder !== undefined) s.updateFolder = /^https:\/\/(?:drive\.google\.com|github\.com)\//i.test(String(input.updateFolder).trim()) ? String(input.updateFolder).trim().slice(0, 300) : '';
  if (input.imageLocks !== undefined && input.imageLocks && typeof input.imageLocks === 'object') {   // the locked Appearance quality prompt and Negative Prompt, for every template (empty = the template's own)
    const f = x => String(x || '').replace(/[\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 4000);
    s.imageLocks = {quality: f(input.imageLocks.quality), negative: f(input.imageLocks.negative)};
  }
  if (input.autoUpdateCheck !== undefined) s.autoUpdateCheck = !!input.autoUpdateCheck;
  if (input.skippedVersion !== undefined) s.skippedVersion = String(input.skippedVersion || '').slice(0, 20);
  if (input.collectAs !== undefined) s.collectAs = ['tool','main','ntr'].includes(input.collectAs) ? input.collectAs : 'tool';
  const jcUrl = u => { u = String(u || '').trim(); return /^https:\/\/([a-z0-9-]+\.)*juicychat\.ai\//i.test(u) ? u : ''; };
  if (input.myProfileUrl !== undefined) s.myProfileUrl = jcUrl(input.myProfileUrl);
  for (const k of ['loungeMain', 'loungeNtr']) if (input[k] !== undefined) s[k] = jcUrl(input[k]);
  // the daily pull times and their timezone (this block used to sit after the return, so these never saved)
  const hm = v => { const m = String(v || '').match(/^(\d{1,2}):(\d{2})$/); if (!m) return null; const h = Math.min(23, Math.max(0, +m[1])), min = Math.min(59, Math.max(0, +m[2])); return `${String(h).padStart(2,'0')}:${String(min).padStart(2,'0')}`; };
  if (input.collectTime !== undefined) s.collectTime = hm(input.collectTime) || s.collectTime || '20:00';
  if (input.perfTime !== undefined) s.perfTime = hm(input.perfTime) || s.perfTime || '20:00';
  if (input.morningTime !== undefined) s.morningTime = hm(input.morningTime) || s.morningTime || '08:00';
  if (input.autoMorning !== undefined) s.autoMorning = !!input.autoMorning;
  if (input.pullTimeZone !== undefined) s.pullTimeZone = input.pullTimeZone === 'computer' ? 'computer' : 'est';
  return s;
}
function htmlEscape(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function weekToHtml(state) {
  const week = state.week, statuses = week.statuses || {};
  const renderScenario = s => {
    const fields = Object.entries(s.fields || {}).map(([k,v]) => `<div class="field"><strong>${htmlEscape(k)}</strong><div>${htmlEscape(Array.isArray(v)?v.join(', '):v)}</div></div>`).join('');
    const p = s.prediction || {};
    return `<article class="card"><header><div><div class="lane">${htmlEscape(s.lane || s.series || '')}</div><h3>${htmlEscape(s.sceneName || 'Untitled')}</h3></div><div class="score">${p.score || '–'}</div></header><div class="meta">${htmlEscape(s.day || '')} · ${htmlEscape(s.slot || '')} · ${htmlEscape(statuses[s.id] || 'Idea')}</div>${fields}</article>`;
  };
  const days=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const daySections=days.map(day=>`<section><h2>${day}</h2>${(week.scenarios||[]).filter(s=>s.day===day).map(renderScenario).join('')}</section>`).join('');
  return `<!doctype html><html><head><meta charset="utf-8"><title>Weekly Blueprint Batch</title><style>body{font-family:Segoe UI,Arial,sans-serif;background:#0e0b12;color:#eee4f5;margin:0;padding:32px}.wrap{max-width:1100px;margin:auto}.hero{background:linear-gradient(135deg,#17111e,#4e1f62,#7c235e);color:#fff;padding:30px;border-radius:22px;margin-bottom:24px}.hero h1{margin:0 0 6px}.card{background:#17111e;border:1px solid #35263f;border-radius:16px;padding:20px;margin:14px 0}.card header{display:flex;justify-content:space-between;gap:16px}.lane{font-size:12px;font-weight:800;color:#c48add;text-transform:uppercase}.card h3{margin:4px 0 0}.score{width:54px;height:54px;border-radius:50%;display:grid;place-items:center;background:#2b1739;color:white;font-size:19px;font-weight:900}.meta{color:#aa9ab4;font-size:13px;margin:8px 0 16px}.field{display:grid;grid-template-columns:260px 1fr;gap:16px;padding:9px 0;border-top:1px solid #2a2030;white-space:pre-wrap}.field strong{color:#cfbfd8}h2{margin-top:34px}@media print{body{background:#fff;color:#111}.card{background:#fff;color:#111;border-color:#bbb}.field{border-color:#ddd}.field strong{color:#333}}</style></head><body><div class="wrap"><div class="hero"><h1>Weekly Blueprint Batch</h1><div>Week of ${htmlEscape(week.weekStart || '')}</div><div>Generated locally from collected JuicyChat success engines. No AI model used.</div></div>${daySections}<section><h2>NTR</h2>${(week.ntr||[]).map(renderScenario).join('')}</section></div></body></html>`;
}

let history = null;
let applyLoginItemNow = null;
let collectNow = null, pullMyBotsNow = null, accountCollectors = {};
// Everything that learns (engines, Bonus estimates) reads the full scrape history,
// weighted toward recent scrapes, instead of only the newest 200 bots.
function learningData(st) {
  const blocked = (st.settings && st.settings.blockedTags) || [], keep = rows => TagBlock.filterRows(rows, blocked).rows;
  const h = history ? history.analysisRows() : {recent: [], trending: []};
  if (!h.recent.length && !h.trending.length) return {recent: keep(st.datasets.recent || []), trending: keep(st.datasets.trending || [])};
  return {...h, recent: keep(h.recent), trending: keep(h.trending)};      // bots with a blocked tag never reach the analysis
}
function runAnalysis(st) {
  const d = learningData(st);
  return analyzeEnginesLocal({recent: d.recent, trending: d.trending, performance: st.performance || [], historyStats: history ? history.stats() : null});
}
// The same analysis, but worked out on a separate thread so the window keeps responding while it runs.
async function runAnalysisAsync(st) {
  const d = learningData(st);
  return analyzeAsync({recent: d.recent, trending: d.trending, performance: st.performance || [], historyStats: history ? history.stats() : null});
}
const tick = () => new Promise(r => setImmediate(r));       // lets the window draw and answer clicks between two heavy steps
// What an automatic run is doing right now, shown in the progress box at the bottom right of the window.
let bgRun = null;
const bgStep = (message, extra = {}) => { if (bgRun) send('bg:step', {kind: bgRun.kind, title: bgRun.title, message, ...extra}); };
const withLearning = st => ({...st, datasets: learningData(st)});
// Registering the same action twice makes Electron throw, which would stop every action registered after it
// (that is how Save as .txt went missing). Keep the first registration, log the duplicate, carry on.
{ const seen = new Set(), handle = ipcMain.handle.bind(ipcMain);
  ipcMain.handle = (channel, fn) => { if (seen.has(channel)) { console.error(`Duplicate action ignored: ${channel}`); return; } seen.add(channel); return handle(channel, fn); }; }

// JuicyChat's own tag list (read from the site, plus every tag seen on collected bots, plus the rulebook's approved tags) is the list of real tags:
// an event that spells one differently ("Mafia/Gang" for "Mafia") has its opportunity tags renamed to the approved spelling
const TagCanon = require('./lib/tagCanon');
function tagVocab(st) {
  const h = (() => { try { return history ? history.analysisRows({maxAgeDays: 3650}) : {recent: [], trending: []}; } catch { return {recent: [], trending: []}; } })();
  const rows = [...(st.datasets && st.datasets.recent || []), ...(st.datasets && st.datasets.trending || []), ...(h.recent || []), ...(h.trending || [])];
  const seen = TagBlock.seen([rows]).map(x => x.name);
  return [...new Set([...(st.juicyTags || []), ...seen, ...require('./lib/blueprintRules').APPROVED_TAGS])];
}
function refreshOppRule(e) {
  if (e.parsed && Array.isArray(e.parsed.hardRequirements)) e.parsed.hardRequirements = e.parsed.hardRequirements.map(x => /^Use at least \d+ Opportunity Tag/.test(x) ? `Use at least ${e.parsed.minOpportunityTags || 1} Opportunity Tag(s): ${e.parsed.opportunityTags.join(', ')}` : x);
  if (!e.rulebook || !Array.isArray(e.rulebook.rules)) return;
  const isOpp = r => r && r.part === 'tags' && r.source === 'text' && /opportunity tag/i.test(r.requirement || ''), fresh = EventRules.fromParsed(e.parsed).rules.find(isOpp);
  const at = e.rulebook.rules.findIndex(isOpp); e.rulebook.rules = e.rulebook.rules.filter(r => !isOpp(r));
  if (fresh) e.rulebook.rules.splice(at < 0 ? e.rulebook.rules.length : at, 0, {...fresh, id: 'r' + Date.now().toString(36)});
}
function canonEventTags(st) { return TagCanon.apply({events: st.events, __cards: () => flattenWeek(st.week)}, tagVocab(st), {rebuildRule: refreshOppRule}); }

app.whenReady().then(() => {
  if (!GOT_LOCK) return;
  store = new JsonStore(app.getPath('userData'));
  store.holdWrites();                                // the start-up fixes below change the state in memory and write the file once (store.releaseWrites)
  // the built-in bot templates now follow your file naming ("1._...", Crush Series is 10): saved bots, drafts and settings follow them
  try { const moved = require('./lib/templateNames').migrate({userData: app.getPath('userData'), store}); if (moved.length) console.log('template names updated:', moved.join(', ')); } catch (e) { console.error('template names:', e.message); }
  // a built-in bot template that changed with an app update is listed in the Bot Builder's closeable "what changed" box
  try { const TL = require('./lib/templateLog'), ud = app.getPath('userData'), logs = TL.checkBuiltIns({userData: ud, builtInDir: path.join(resourcesDir, 'bot-templates'), userDir: path.join(ud, 'bot-templates')});
    if (logs.length) store.update(s => { s.builder = s.builder || {}; s.builder.templateLogs = [...logs, ...(s.builder.templateLogs || [])].slice(0, 12); }); } catch (e) { console.error('template change log:', e.message); }
  history = new HistoryStore(app.getPath('userData'));
  try { backup = require('./lib/backup').create({userData: app.getPath('userData'), edition: EDITION, gs: require('./lib/gscript').create(), appDir: __dirname, flush: () => { try { store.flush(); } catch {} }, onProgress: ev => { try { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('backup:progress', ev); } catch {} }}); } catch (e) { console.error('backup init:', e.message); }
  try { if (history.seed(store.state.datasets)) store.update(s => { s.historyStats = history.stats(); }); else store.update(s => { s.historyStats = history.stats(); }); } catch (e) { console.error('history seed failed', e); }
  store.update(s => { ensureAccounts(s); for (const [k, a] of Object.entries(s.accounts)) { const u = s.settings[k === 'main' ? 'loungeMain' : 'loungeNtr']; if (u) a.url = u; } });
  store.update(s => {      // once: refreshAccuracy stamps accuracy.updatedAt, so a state with no frozen card yet is not re-scored at every launch (a Built or linked card with nothing frozen still is)
  if (s.predictionLog) return;
  let todo = !(s.accuracy && s.accuracy.updatedAt);
  if (!todo) { ensureAccounts(s); const linked = new Set(Object.values(s.accounts).flatMap(a => Object.keys(a.links || {}).filter(k => a.links[k]))); todo = flattenWeek(s.week).some(c => String(s.week.statuses?.[c.id] || '') === 'Built' || linked.has(c.id)); }
  if (todo) refreshAccuracy(s, 'backfill');
});
  // Each account can have its own JuicyChat sign-in, kept in its own browser profile,
  // separate from the tool account used for Recent/Trending collection.
  accountCollectors = Object.fromEntries(Object.keys(ACCOUNTS).map(k => [k, new PythonCollector(__dirname, path.join(app.getPath('userData'), `juicy-profile-${k}`), p => send('collector:progress', p), a => send('account:auth', {account: k, ...a}))]));
  blueprints = new BlueprintStore(path.join(app.getPath('userData'), 'blueprint'), isShare ? null : {rules: rulesPath, template: templatePath});
  applyBlueprintTags(blueprints.current());
  try { store.update(st => { reconcileLanes(st, blueprints.current()); }); } catch (e) { console.error('tabs:', e.message); }     // a week made before the template gained a tab gets that tab's slots
  // a week saved by an earlier version still carries that version's scores: score it once now so every card's ring matches its Success estimate
  try { store.update(st => { if (needsRescore(st)) scoreWeek(st); }); } catch (e) { console.error('rescore on start:', e.message); }
  // an event saved by an earlier version read its opportunity tags from a fixed list of tags (it dropped Villain, Mafia/Gang, Omegaverse and Himbo): read again, they come from the announcement's own list
  try { store.update(st => { let changed = false;
    for (const e of st.events || []) { const raw = e.raw || (e.parsed && e.parsed.rawOriginal); if (!raw || !e.parsed) continue;
      const P = parseEventAnnouncement(raw); if (!P.opportunityTags.length) continue; if (JSON.stringify(P.opportunityTags) === JSON.stringify(e.parsed.opportunityTagsPosted || e.parsed.opportunityTags || []) && P.minOpportunityTags === e.parsed.minOpportunityTags) continue;
      delete e.parsed.opportunityTagsPosted; e.parsed.opportunityTags = P.opportunityTags; e.parsed.minOpportunityTags = P.minOpportunityTags; e.parsed.hardRequirements = P.hardRequirements;
      refreshOppRule(e);
      changed = true; }
    if (canonEventTags(st)) changed = true;
    if (changed) scoreWeek(st); }); } catch (e) { console.error('event tags re-read:', e.message); }
  // an event's checklist saved by an earlier version may ask every bot to be a vampire or a werewolf because the announcement LISTS them as tags to choose from: take that out
  try { store.update(st => { let changed = false; for (const e of st.events || []) if (require('./lib/eventMenu').clean(e)) changed = true; if (changed) scoreWeek(st); }); } catch (e) { console.error('event menu clean:', e.message); }
  try { store.update(st => { const SN = require('./lib/sceneName.js'); for (const c of flattenWeek(st.week)) { const r = SN.restoreTag(c.sceneName, c.series); if (r !== c.sceneName) { c.sceneName = r; if (c.fields && c.fields['Scene Name']) c.fields['Scene Name'] = r; } } }); } catch (e) { console.error('scene name tag repair:', e.message); }
  collector = new PythonCollector(__dirname, path.join(app.getPath('userData'),'juicy-browser-profile'), p => send('collector:progress', p), a => send('juicy:authStatus', a));
  // the visible collection browser opens on the screen the app window is on (not on whichever screen the browser last used)
  { const scanBounds = () => { try { const {screen} = require('electron'); const vis = mainWindow && !mainWindow.isDestroyed() && mainWindow.isVisible() && !mainWindow.isMinimized();
      const d = vis ? screen.getDisplayMatching(mainWindow.getBounds()) : screen.getPrimaryDisplay(), w = d.workArea; return [w.x, w.y, w.width, w.height]; } catch { return null; } };
    for (const c of [collector, ...Object.values(accountCollectors || {})]) if (c) { c.windowBounds = scanBounds; c.blockedTags = () => (store.state.settings.blockedTags || []); } }
  createMainWindow();
  // WebP Maker is independent of the bot/project data store and uses a private temporary workspace.
  webpMaker = new WebpMaker({appRoot: __dirname, userData: app.getPath('userData'),
    onProgress: info => send('webpmaker:progress', info)});
  ipcMain.handle('webpmaker:begin', (_, options) => webpMaker.begin(options));
  ipcMain.handle('webpmaker:frame', (_, png) => webpMaker.frame(png));
  ipcMain.handle('webpmaker:finish', () => webpMaker.finish());
  ipcMain.handle('webpmaker:cancel', () => webpMaker.cancel());
  ipcMain.handle('webpmaker:preview', (_, allowOver) => webpMaker.preview(!!allowOver));
  // Conversion may finish while another tab is open or the app is minimized.
  // Notify at the OS level; clicking the alert opens the completed preview.
  ipcMain.handle('webpmaker:notify', (_, status) => {
    if(status!=='complete'&&status!=='failed')return false;
    try {
      if(!Notification.isSupported())return false;
      const success=status==='complete';
      const alert=new Notification({
        title: success?'WebP Maker: conversion complete':'WebP Maker: conversion failed',
        body: success?'Your animated WebP is ready to preview and save.':'Open WebP Maker to see the error and retry.',
        silent:false
      });
      alert.on('click',()=>{showMainWindow();send('webpmaker:open');});
      alert.show();
      return true;
    } catch(e) {console.error('WebP Maker notification:',e.message);return false;}
  });
  ipcMain.handle('webpmaker:save', async (_, suggested, allowOver) => {
    const source = webpMaker.resultPath(!!allowOver);
    if (!source) throw new Error('Convert an animation before saving it.');
    const defaultName = String(suggested || 'Animation.webp').replace(/[\\/:*?"<>|]/g, '_').replace(/\.webp$/i, '') + '.webp';
    const saved = await dialog.showSaveDialog(mainWindow, {title:'Save animated WebP', defaultPath:defaultName, filters:[{name:'Animated WebP',extensions:['webp']}]});
    if (saved.canceled || !saved.filePath) return {canceled:true};
    return webpMaker.save(saved.filePath, !!allowOver);
  });


  store.update(s => { for (const c of flattenWeek(s.week)) { repairPastedTitle(c); CardIdentity.normalizeCard(c); try { require('./lib/antagonist').upgrade(c); } catch (e) { console.error('anti upgrade:', e.message); } try { ThirdParty.rename(c); ThirdParty.fillRows(c, writeField); } catch (e) { console.error('third party rename:', e.message); } try { repairSetup(c, {ntr: c.slot === 'NTR' || c.series === 'Likeable NTR' || c.series === 'Preventable NTR' || c.laneTab === 'preventable'}); } catch (e) { console.error('repairSetup:', e.message); }  try { NtrSetup.removeBuiltPreventableSetup(c); NtrSetup.ensure(c, writeField); } catch (e) { console.error('ntr setup:', e.message); }} });
  store.releaseWrites();
  // every load of the state first makes sure no card carries an older score than its Success estimate
  ipcMain.handle('state:get', () => { try { const st = store.get(); if (needsRescore(st)) return store.update(s => { scoreWeek(s); }); } catch (e) { console.error('state:get rescore:', e.message); } return store.get(); });
  ipcMain.handle('settings:save', (_, input) => {
    const blockedBefore = JSON.stringify(TagBlock.clean(store.state.settings.blockedTags || []));
    let out = store.update(s => { const before = JSON.stringify(s.settings.eventSkipSeries || null); s.settings = cleanSettings(input || {}); if (JSON.stringify(s.settings.eventSkipSeries || null) !== before) scoreWeek(s); });
    if (JSON.stringify(out.settings.blockedTags || []) !== blockedBefore) {
      // newly blocked tags: take those bots out of the collected lists and redo the analysis without them
      try {
        out = store.update(s => { for (const k of ['recent', 'trending']) s.datasets[k] = TagBlock.filterRows(s.datasets[k] || [], s.settings.blockedTags).rows; });
        const d = learningData(out);
        if ((d.recent.length + d.trending.length) >= 5) {
          const analysis = runAnalysis(out);
          out = store.update(s => { s.engineAnalysis = analysis; const all = flattenWeek(s.week), L = withLearning(s); for (const b of s.week.bonus || []) applyAssessment(b, {...L, engineAnalysis: analysis}, all); });
        }
      } catch (e) { console.error('blocked tags re-analysis:', e.message); }
    }
    if (applyLoginItemNow) applyLoginItemNow(out.settings.openAtLogin);
    return out;
  });
  // tags to choose from: every tag on the bots collected so far, plus (tags:fetch) JuicyChat's own list read with the saved sign-in
  ipcMain.handle('tags:list', () => {
    const st = store.get(), h = history ? history.analysisRows({maxAgeDays: 3650}) : {recent: [], trending: []};
    const fromSite = new Set((st.juicyTags || []).map(TagBlock.norm));
    const once = new Map();      // one count per bot, even when it is in both the current list and the saved history
    for (const r of [...(st.datasets.recent || []), ...(st.datasets.trending || []), ...(h.recent || []), ...(h.trending || [])]) { const k = String(r.url || r.id || r.title || r.name || ''); if (k && !once.has(k)) once.set(k, r); }
    const seen = TagBlock.seen([[...once.values()]]);
    const names = new Map(seen.map(x => [TagBlock.norm(x.name), {name: x.name, count: x.count, site: fromSite.has(TagBlock.norm(x.name))}]));
    for (const t of st.juicyTags || []) { const k = TagBlock.norm(t); if (k && !names.has(k)) names.set(k, {name: t, count: 0, site: true}); }
    return {tags: [...names.values()].sort((a, b) => b.count - a.count || a.name.localeCompare(b.name)), fetchedAt: st.juicyTagsAt || null};
  });
  ipcMain.handle('tags:fetch', async () => {
    const found = TagBlock.clean(await collector.collectTags());
    if (!found.length) throw new Error('JuicyChat did not show any tags to the saved sign-in. Check that you are signed in (JuicyChat Analysis tab), then try again.');
    store.update(s => { s.juicyTags = TagBlock.clean([...(s.juicyTags || []), ...found]); s.juicyTagsAt = new Date().toISOString(); canonEventTags(s); scoreWeek(s); });
    return {count: found.length};
  });

  ipcMain.handle('juicy:openLogin', async (_, magicLink) => {
    const link = String(magicLink || '').trim();
    if (link && !/^https:\/\//i.test(link)) throw new Error('Paste the full https:// magic link.');
    const auth = await collector.signIn(link || 'https://www.juicychat.ai/discover');
    return {ok: auth?.signedIn === true, auth};
  });
  ipcMain.handle('juicy:authStatus', async () => collector.checkAuth());
  ipcMain.handle('juicy:finishLogin', async () => collector.finishLogin());
  ipcMain.handle('juicy:resetLogin', async () => collector.resetLogin());
  // A logged-out account: the window shows a popup asking for the magic link (sign-in runs in the background, no browser opens).
  const askLogin = (account, message) => { try { send('auth:needLogin', {account, label: account === 'tool' ? (isShare ? 'Your JuicyChat account' : 'The tool account') : (ACCOUNTS[account] || account), message}); } catch (_) {} };
  collectNow = async (kind, quiet = false) => {
    const upd = (fn) => quiet ? (store.updateQuiet(fn), null) : store.update(fn);
    const s = store.state.settings;
    const as = !isShare && s.collectAs && s.collectAs !== 'tool' && store.state.accounts?.[s.collectAs]?.signedIn?.ok ? s.collectAs : 'tool';
    if (s.collectAs && s.collectAs !== 'tool' && as === 'tool') send('collector:progress', {stage: 'log', status: 'collecting', message: `The ${ACCOUNTS[s.collectAs] || s.collectAs} isn't signed in, so the tool account is collecting instead.`});
    const col = as === 'tool' ? collector : accountCollectors[as];
    const kinds = kind === 'both' ? ['Recent','Trending'] : [kind];
    const overallTarget = kinds.reduce((sum,k)=>sum+(k==='Recent'?s.targetRecent:s.targetTrending),0);
    let completedBefore = 0;
    let cancelled = false;
    const discarded = new Map();      // bots left out because of a blocked tag, across Recent and Trending in this run
    col.beginCollectionBatch();
    const scrapeAt = new Date().toISOString(), scrapeId = `scrape-${Date.parse(scrapeAt)}`;
    send('collector:progress',{stage:'batch-start',message:`Starting ${kinds.join(' + ')} collection...`,current:0,target:overallTarget,overallCurrent:0,overallTarget,batchIndex:1,batchCount:kinds.length,status:'starting'});
    try {
      for (let index=0; index<kinds.length; index++) {
        if (col.isCancelRequested()) { cancelled = true; break; }
        const k = kinds[index];
        const target = k === 'Recent' ? s.targetRecent : s.targetTrending;
        let result;
        try { result = await col.collect(k, target, s.juicyHomeUrl, s.gender, {batchIndex:index+1,batchCount:kinds.length,completedBefore,overallTarget}); }
        catch (e) { if (/logged out|isn.t signed in|not signed in|log back in/i.test(String(e.message || e))) askLogin(as, String(e.message || e)); throw e; }
        const gate = TagBlock.filterRows(result.rows || [], s.blockedTags, true);      // the scan already skips these; this keeps any that slipped through out of the data
        const rows = gate.rows;
        for (const x of [...(result.skipped || []), ...gate.items.map(r => TagBlock.discardRecord(r, k, s.blockedTags))]) { const key = x.url || x.id || x.name; const had = discarded.get(key); if (had) { if (!had.sections.includes(x.section)) had.sections.push(x.section); } else discarded.set(key, {id: x.id || '', name: x.name || 'A bot', url: x.url || '', sections: [x.section || k], tags: x.tags || [], blocked: x.blocked || []}); }
        if (gate.dropped) send('collector:progress', {stage: 'log', status: 'collecting', message: `${k}: left out ${gate.dropped} bots with a blocked tag (${Object.entries(gate.byTag).map(([t, n]) => `${t} ${n}`).join(', ')}).`});
        if (rows.length) {
          completedBefore += rows.length;
          bgStep(`Saving ${rows.length} ${k} bots...`, {current: completedBefore, target: overallTarget});
          await tick();
          try { history.ingest(rows, k, scrapeId, scrapeAt); } catch (e) { console.error('history ingest failed', e); }
          upd(state => { state.datasets[k.toLowerCase()] = rows; state.datasets.lastCollectedAt = new Date().toISOString(); state.historyStats = history.stats(); });
          await tick();
          send('collector:progress',{stage:'source-saved',message:`Saved ${rows.length} ${k} bots locally.`,sortName:k,source:k,current:rows.length,target,overallCurrent:completedBefore,overallTarget,batchIndex:index+1,batchCount:kinds.length,status:'saved'});
        }
        if (result.cancelled || col.isCancelRequested()) { cancelled = true; break; }
      }
      if (cancelled) send('collector:progress',{stage:'batch-cancelled',message:`Collection cancelled. ${completedBefore} bot records from this run were saved locally.`,current:completedBefore,target:overallTarget,overallCurrent:completedBefore,overallTarget,batchIndex:1,batchCount:kinds.length,status:'cancelled'});
      else send('collector:progress',{stage:'batch-done',message:`Collection finished. ${completedBefore}/${overallTarget} bot records saved locally.`,current:completedBefore,target:overallTarget,overallCurrent:completedBefore,overallTarget,batchIndex:kinds.length,batchCount:kinds.length,status:'done'});
      try { history.endScrape(scrapeId); } catch (e) { console.error(e); }
      upd(st => { st.discardedBots = {at: new Date().toISOString(), blockedTags: TagBlock.clean(s.blockedTags), items: [...discarded.values()]}; });
      if (discarded.size) send('collector:progress', {stage: 'log', status: 'collecting', message: `${discarded.size} bots were discarded because of blocked tags. See the list under the progress bar.`});
      const collected = store.state;           // only read below (no copy of the whole state)
      const sampleSize = (collected.datasets.recent?.length||0) + (collected.datasets.trending?.length||0);
      if (sampleSize >= 5) {
        send('analysis:progress', {message:`Analyzing ${sampleSize} newly collected bots together with your saved history to find the success engines...`});
        bgStep(`Analyzing ${sampleSize} bots to find the success engines...`, {indeterminate: true});
        await new Promise(r => setTimeout(r, 400));          // let the window show this step first
        const analysis = await runAnalysisAsync(collected);      // on its own thread: the window stays responsive
        bgStep('Re-scoring your Bonus ideas with the new analysis...', {indeterminate: true});
        await tick();
        upd(s => { s.engineAnalysis = analysis; s.historyStats = history.stats(); const all = flattenWeek(s.week), L = withLearning(s); for (const b of s.week.bonus || []) applyAssessment(b, {...L, engineAnalysis: analysis}, all); });
        const top = (analysis.engines || [])[0];
        send('analysis:progress', {message:`Engine summary updated from the collected bots: ${(analysis.engines || []).length} success engine${(analysis.engines || []).length === 1 ? '' : 's'} found${top ? `, strongest: ${top.name}${top.strength != null ? ` (strength ${top.strength}/100)` : ''}` : ''}.`, done:true});
      } else if (!cancelled) {
        send('analysis:progress', {message:`The success-engine analysis was not run: only ${sampleSize} bots are saved (it needs at least 5).`, done:true, skipped:true});
      }
      return quiet ? null : store.get();
    } finally {
      col.endCollectionBatch();
    }
  };
  ipcMain.handle('app:version', () => app.getVersion());
  ipcMain.handle('app:closeShown', () => { if (closeAsk) closeAsk.ack(); return true; });
  ipcMain.handle('app:closeChoice', (_e, c) => {
    if (!closeAsk) return false;
    if (c === 'exit' && webpConversionActive()) {
      // Do not resolve the close request yet. Demand a *second* explicit answer,
      // presented inside the application, before an active conversion is aborted.
      closeAsk.abortRequested=true;
      try { mainWindow.webContents.send('app:abortWebpAsk'); }
      catch (e) { dbg('WebP exit confirmation failed: '+e.message); closeAsk.finish('cancel'); return false; }
      return true;
    }
    if (c === 'abort-exit') {
      if (!closeAsk.abortRequested) return false;
      try { if (webpConversionActive()) webpMaker.cancel(); } catch(e) { dbg('WebP abort failed: '+e.message); }
      closeAsk.finish('exit');
      return true;
    }
    if (c === 'exit' || c === 'cancel' || c === 'tray') { closeAsk.finish(c); return true; }
    return false;
  });
  ipcMain.handle('app:edition', () => EDITION);
  // ---- automatic backup (both editions). Copies the app's data into a folder the person picks (best: inside Google Drive for Desktop).
  const bk = fn => async (...a) => { try { if (!backup || SANDBOX) return {ok: false, error: 'Backup is not available here.'}; return await fn(...a); } catch (e) { return {ok: false, error: String(e && e.message || e)}; } };
  ipcMain.handle('backup:get', bk(() => ({ok: true, ...backup.status(), needsPrompt: backup.needsPrompt()})));
  ipcMain.handle('backup:choose', bk(async (_e, startDir) => {
    const def = startDir || (backup.status().dir) || (backup.detect()[0]) || app.getPath('documents');
    const {canceled, filePaths} = await dialog.showOpenDialog(mainWindow, {title: 'Choose where to keep your backups (best: a folder inside Google Drive)', defaultPath: def, properties: ['openDirectory', 'createDirectory']});
    if (canceled || !filePaths || !filePaths[0]) return {ok: false, canceled: true};
    backup.setDir(filePaths[0]);
    const snaps = backup.snapshots();
    if (snaps.length) { backup.hold(); return {ok: true, existing: snaps, ...backup.status()}; }   // this folder already has backups: offer to restore before making a new one
    const r = backup.run('setup', {force: true}); return {...r, ok: r.ok};
  }));
  ipcMain.handle('backup:useDetected', bk((_e, dir) => { if (!backup.detect().includes(dir)) throw new Error('That folder is no longer there.'); backup.setDir(dir); const snaps = backup.snapshots(); if (snaps.length) { backup.hold(); return {ok: true, existing: snaps, ...backup.status()}; } return backup.run('setup', {force: true}); }));
  ipcMain.handle('backup:list', bk(async () => ({ok: true, snapshots: await backup.snapshotsAny()})));
  ipcMain.handle('backup:restore', bk(async (_e, name) => { await backup.prepareRestoreAny(name); setTimeout(() => { try { app.relaunch(); } catch {} app.exit(0); }, 600); return {ok: true, restarting: true}; }));
  ipcMain.handle('backup:now', bk(() => backup.runAny('manual', {force: true})));
  // Google Drive through one script URL: no sign-in. Checks the URL, then backs up there (or offers to restore if it already holds backups)
  ipcMain.handle('backup:gdrive', bk(async (_e, url, box) => {
    await backup.setDrive(url, box);
    const snaps = await backup.snapshotsAny();
    if (snaps.length) { backup.hold(); return {ok: true, existing: snaps, ...backup.status()}; }
    return backup.runAny('setup', {force: true});
  }));
  ipcMain.handle('backup:copyScript', bk(() => { clipboard.writeText(fs.readFileSync(path.join(__dirname, 'lib', 'backup_receiver.gs.txt'), 'utf8')); return {ok: true}; }));
  // ---- LanguageTool (v1.2.0): a free grammar checker (rules, not AI) that the app installs into its own folder and runs only on this computer
  {
    const LTM = require('./lib/languagetool').create({appDir: __dirname, userData: app.getPath('userData')}), lt = fn => async (...a) => { try { return await fn(...a); } catch (e) { return {ok: false, error: String(e && e.message || e)}; } };
    ipcMain.handle('lt:status', lt(() => ({ok: true, ...LTM.status()})));
    ipcMain.handle('lt:install', lt(async () => { await LTM.install(p => send('lt:progress', p)); return {ok: true, ...LTM.status()}; }));
    ipcMain.handle('lt:remove', lt(async () => ({ok: true, ...(await LTM.remove())})));
    ipcMain.handle('lt:enable', lt((_e, on) => ({ok: true, ...LTM.setEnabled(on)})));
    ipcMain.handle('lt:check', lt((_e, text) => LTM.check(String(text || '').slice(0, 20000))));
    app.on('before-quit', () => { try { LTM.stop(); } catch (_) { /* the program ends with the app */ } });
  }
  // ---- image site (v1.1.0): sends Greeting pictures to your own image site and returns the links (never goes through the AI relay)
  {
    const IH = require('./lib/imageHost'), ihStore = IH.createStore({userData: app.getPath('userData'), safeStorage}), ihClient = IH.createClient();
    const ih = fn => async (...a) => { try { return await fn(...a); } catch (e) { return {ok: false, error: String(e && e.message || e)}; } };
    ipcMain.handle('imagehost:get', ih(() => ({ok: true, accounts: IH.NTR_ACCOUNTS, config: ihStore.config(), hasPassword: ihStore.hasPassword(), encrypted: ihStore.encrypted(), defaultBase: IH.DEFAULT_BASE})));
    ipcMain.handle('imagehost:save', ih((_e, cfg, password, clearPassword) => {
      ihStore.saveConfig(cfg || {}); if (clearPassword) ihStore.savePassword(''); else if (typeof password === 'string' && password) ihStore.savePassword(password);
      ihClient.forget(); return {ok: true, hasPassword: ihStore.hasPassword(), config: ihStore.config()};
    }));
    ipcMain.handle('imagehost:test', ih(async (_e, cfg, password) => { const c = cfg ? {...ihStore.config(), ...cfg} : ihStore.config(); return await ihClient.test(c, password || ihStore.password()); }));
    ipcMain.handle('imagehost:upload', ih(async (_e, req) => {
      req = req || {}; const cfg = ihStore.config(), pw = ihStore.password();
      if (!cfg.username || !pw) return {ok: false, error: 'Sign in to your image site first.', needsLogin: true};
      const ntr = IH.isNtrFamily(req.hints), root = IH.rootFor(cfg, {ntr, account: req.account}), folder = IH.folderName(req.scene, req.name);
      const files = (req.files || []).map(f => ({name: String(f.name || ''), bytes: f.bytes}));
      let r; try { r = await ihClient.uploadAll(cfg, pw, {root, folder, files}); } catch (e) { const m = String(e && e.message || e); return {ok: false, error: m, needsLogin: /did not accept|signed the tool out|Enter your image site/i.test(m)}; }
      return {ok: true, ...r, account: !IH.NTR_ACCOUNTS ? '' : (req.account === 'ntr' || req.account === 'main' ? req.account : (ntr ? 'ntr' : 'main'))};
    }));
  }
  ipcMain.handle('backup:disable', bk((_e, dontAsk) => ({ok: true, ...backup.disable(dontAsk)})));
  ipcMain.handle('backup:later', bk(() => ({ok: true, ...backup.snooze()})));
  ipcMain.handle('backup:open', bk(async () => { const st = backup.status(); if (st.mode === 'gdrive') { if (!st.gd || !st.gd.folderUrl) throw new Error('No link saved.'); await shell.openExternal(st.gd.folderUrl); return {ok: true}; } if (!st.root) throw new Error('No backup folder yet.'); const r = await shell.openPath(st.root); return {ok: !r, error: r || ''}; }));
  // ---- AI writer (both editions): through your Cloudflare relay, which holds the OpenRouter key and caps spending per computer.
  // Runs here in the main process, so minimizing, hiding or reloading the window never interrupts it.
  {
    const relay = new Relay({appDir: app.getAppPath(), userData: app.getPath('userData')});
    if (!isShare && relay.canAdmin) setTimeout(() => { relay.restoreCap().catch(() => {}); }, 4000);          // a limit the owner's last writing raised and the app never put back (it was closed)
    relay.thinkingLevel = () => store.state.aiThinking || 'medium';          // Settings › AI writer › Thinking
    relay.myLimit = () => { const v = Number(store.state.aiMyLimit); return v > 0 ? v : 0; };           // your own computer's limit in dollars; 0 = no limit (the default)
    relay.myName = () => store.state.aiMyName || '';                        // the name a person gives themselves, shown in the owner's relay controls
    const allCards = st => WL.weekCards(st.week);
    const writer = new AiBotWriter({relay, rendererDir: path.join(__dirname, 'renderer'), jobsDir: path.join(app.getPath('userData'), 'ai-jobs'), store,
      templates: () => templatesWithLimits(), send,
      engineNotes: (card, used) => {
        const st = store.get();
        // a NEW card (nothing written yet) in a run of cards: each gets a different pattern, never the same top pattern as the card before it
        // the NTR tab and Preventable NTR are NOT rotated: their cards keep the pattern notes they always had, built on the NTR rulebook
        if (Array.isArray(used) && !NtrScope.isNtrLaneCard(card)) {
          const all = NtrScope.usable(st.engineAnalysis?.engines || []);
          const pool = [...all].sort((a, b) => (b.strength || 0) - (a.strength || 0)).slice(0, 10);
          if (pool.length) {
            const ids = new Set(used.map(u => u.id)), hooks = new Set(used.map(u => u.hook));
            let c = pool.filter(e => !ids.has(e.id) && !hooks.has((e.hookPatterns || [])[0]));
            if (!c.length) c = pool.filter(e => !ids.has(e.id)); if (!c.length) c = pool;
            const e = c[Math.floor(Math.random() * Math.min(4, c.length))];
            used.push({id: e.id, hook: (e.hookPatterns || [])[0]});
            return WI.patternNote(e);
          }
        }
        const c = JSON.parse(JSON.stringify(card)); applyAssessment(c, withLearning(st), allCards(st)); return WI.engineNotes(c);
      }});
    const on = () => relay.ready;                                       // both editions: friends use your relay, within its caps
    // a card is entered in the active event when it was adapted to it (or the event applies to every card)
    // while an event is on, every bot is written to its requirements (personality, tags, setting, picture)
    // the Story engine: the topics for a card's bot. storyFor remembers the choice on the card (so the week's other bots rotate to different topics); storyPreview does not.
    const StoryEngine = require('./lib/storyEngine');
    const storyPreview = (card, story) => StoryEngine.plan(card, story, StoryEngine.usedFrom(WL.weekCards(store.get().week), card && card.id));
    const storyFor = (card, story) => {
      const p = storyPreview(card, story);
      try { store.update(s => { for (const name of WL.weekListNames(s.week)) s.week[name] = (s.week[name] || []).map(x => { if (!x || x.id !== card.id) return x; const y = {...x}; if (p.mode === 'off') delete y.storyPlan; else y.storyPlan = JSON.parse(JSON.stringify(p.story.chosen)); return y; }); }); } catch (e) { console.error('story plan not saved:', e.message); }
      return p;
    };
    writer.storyFor = storyFor;
    // PolicyWeights (both editions): the card's weights are saved on the card itself, and edited or written from the card panel
    if (PW) {
      const clipP = (v, n) => String(v == null ? '' : v).replace(/\r/g, '').slice(0, n);
      const savePol = (cardId, patch, drop = []) => store.update(s => { for (const name of WL.weekListNames(s.week)) s.week[name] = (s.week[name] || []).map(x => { if (!x || x.id !== cardId) return x; const np = {...(x.policy || {}), ...patch}; for (const k of drop) delete np[k]; return {...x, policy: np}; }); });
      writer.savePolicy = (cardId, p) => savePol(cardId, {weights: p.weights, tracker: p.tracker || ((WL.findCard(store.get().week, cardId) || {card: {}}).card.policy || {}).tracker || '', extra: p.extra || '', fresh: p.fresh || [], note: p.note || '', rules: p.rules || [], rev: p.rev || 1, at: p.at});
      writer.policyOthers = card => { const out = []; for (const c of WL.weekCards(store.get().week)) { if (!c || c.id === card.id || !c.policy || !c.policy.weights) continue; const tn = [...String(c.policy.tracker || '').matchAll(/\[Tracker: ([^\]]+)\][^\n]*?Rises ([\d.]+)/g)].map(m => `${m[1]} (step ${m[2]})`); out.push(`${c.sceneName || 'a card'}: ${c.policy.weights}${tn.length ? `; trackers ${tn.join(', ')}` : ''}`); } return out; };
      ipcMain.handle('policy:set', (_, id, patch = {}) => {
        if (!WL.findCard(store.get().week, id)) throw new Error('That card no longer exists.');
        const p = {}, drop = [];
        if ('on' in patch) { if (patch.on === null) drop.push('on'); else p.on = !!patch.on; }
        if (typeof patch.weights === 'string') { p.weights = clipP(patch.weights, 700).replace(/\n+/g, '; '); p.fresh = PW.parseWeights(p.weights).items.filter(i => PW.isNew(i.name)).map(i => i.name); }
        if (typeof patch.tracker === 'string') p.tracker = clipP(patch.tracker, 1600);
        if (typeof patch.extra === 'string') p.extra = clipP(patch.extra, 600);
        if (typeof patch.trackerWant === 'string') p.trackerWant = clipP(patch.trackerWant, 600);
        if ('trackerOn' in patch) { if (patch.trackerOn === null) drop.push('trackerOn'); else p.trackerOn = !!patch.trackerOn; }
        return savePol(id, p, drop);
      });
      ipcMain.handle('policy:default', (_, series, on) => store.update(s => { s.policyDefaults = {...(s.policyDefaults || {}), [clipP(series, 60) || 'Standalone']: !!on}; }));
      ipcMain.handle('policy:write', async (_, id) => {
        needAi(); const f = WL.findCard(store.get().week, id); if (!f) throw new Error('That card no longer exists.');
        const card = JSON.parse(JSON.stringify(f.card)), r = await writer.writePolicy({card, others: writer.policyOthers(card)});
        savePol(id, {weights: r.weights, extra: r.extra || '', fresh: r.fresh || [], note: r.note || '', rules: r.rules || [], rev: r.rev, at: r.at, on: typeof (card.policy || {}).on === 'boolean' ? card.policy.on : true});
        return {kind: 'policy', left: r.left, cost: r.cost, costKnown: r.costKnown, state: store.get()};
      });
      ipcMain.handle('policy:writeTracker', async (_, id, want = '') => {
        needAi(); const f = WL.findCard(store.get().week, id); if (!f) throw new Error('That card no longer exists.');
        const card = JSON.parse(JSON.stringify(f.card)), r = await writer.writeTracker({card, others: writer.policyOthers(card), want: clipP(want, 600)});
        savePol(id, {tracker: r.tracker || (card.policy || {}).tracker || '', trackerWant: clipP(want, 600)});
        return {kind: 'policy', left: r.left, cost: r.cost, costKnown: r.costKnown, state: store.get()};
      });
    }
    ipcMain.handle('story:plan', (_, cardId, story) => {
      const st = store.get(), card = allCards(st).find(c => c.id === cardId) || (st.cardArchive || []).find(c => c.id === cardId);
      if (!card) throw new Error('That scenario card is no longer available.');
      const p = storyPreview(card, story); if (p.signals) delete p.signals.all;
      return {...p, options: StoryEngine.options()};
    });
    writer.eventRulebookFor = card => { const ev = Events.forCard(store.state, card); return ev && ev.rulebook ? {...ev.rulebook, raw: ev.raw || (ev.parsed && ev.parsed.rawOriginal) || ''} : null; };
    ipcMain.handle('ai:status', async () => on() ? {...(await relay.status()), admin: !isShare && relay.canAdmin, myName: store.state.aiMyName || '', myLimit: relay.myLimit()} : {ok: false, configured: false});
    ipcMain.handle('ai:longTest', () => { if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now."); return writer.longTest(); });
    ipcMain.handle('ai:writeBot', (_, templateId, cardId, pov, greetingPlan, options = {}) => {
      { const t = templatesWithLimits().find(x => x.id === templateId);
        if (t && t.missingLimits.length) throw Object.assign(new Error(`The "${t.name}" template has no character limit for the ${t.missingLimits.map(x => x[0].toUpperCase() + x.slice(1)).join(', ')}. Set ${t.missingLimits.length > 1 ? 'them' : 'it'} first (the Bot Builder asks), so the AI knows how long to write.`), {code: 'limits', missing: t.missingLimits}); }
      if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now.");
      const st = store.get(), card = allCards(st).find(c => c.id === cardId) || (st.cardArchive || []).find(c => c.id === cardId);
      const writerSettings = {};
      if (['futa','female'].includes(options?.botVariant)) writerSettings.botVariant = options.botVariant;
      { const nt = options?.narrativeTense || {}, ok = m => ['past','present'].includes(m) ? m : '', t = {}; if (ok(nt.mode)) t.mode = nt.mode; if (ok(nt.intro)) t.intro = nt.intro; if (ok(nt.greeting)) t.greeting = nt.greeting; if (Object.keys(t).length) writerSettings.narrativeTense = t; }
      if (options?.story && typeof options.story === 'object') writerSettings.story = StoryEngine.normalizeStory(options.story);
      if (PW && card && PW.anyOn(card, store.state)) { writerSettings.policyOn = true; writerSettings.weightsOn = PW.isOn(card, store.state); writerSettings.trackerOn = PW.trackerActive(card.policy); }     // PolicyWeights: the card's own switch, else its series default
      if (options?.counterpart && typeof options.counterpart === 'object') writerSettings.counterpart = JSON.parse(JSON.stringify({pairedOrigin:options.counterpart.pairedOrigin,femaleVersion:options.counterpart.femaleVersion}));
      return writer.writeBot({templateId, card, pov, greetingPlan, writerSettings});
    });
    // AI writing is saved one card at a time: the moment a card is finished it replaces its slot in the week (the old version is archived with its score),
    // so an error later in the run never loses the cards already written
    const saveWeekCard = (card, o = {}) => {
      const c = JSON.parse(JSON.stringify(card)); delete c._prior; delete c.blankSlot;
      if (c.day === 'NTR' && !c.laneTab) c.slot = 'NTR';
      try { if (blueprints) fillBlueprintFields({week: splitImported([c])}, blueprints.current()); } catch (e) { console.error(e); }
      store.update(s => {
        const old = WL.weekCards(s.week).filter(x => x.id === c.id && !isOpenSlot(x));
        if (o.first && old.length) { for (const x of old) freeze(s, x, 'archived'); archiveWeek(s, old, s.week.weekStart || ''); }
        for (const k of ['noEvent', 'eventId']) if (c[k] === undefined) { const o0 = old[0] || WL.weekCards(s.week).find(x => x.id === c.id); if (o0 && o0[k] !== undefined) c[k] = o0[k]; }   // a rewritten card keeps its event choice
        if (c.policy === undefined) { const o0 = old[0] || WL.weekCards(s.week).find(x => x.id === c.id); keepPolicy(o0, c); }   // and its PolicyWeights choice
        try { EventCard.normalize(c, s.settings); } catch (e) { /* leave the card as written */ }
        for (const name of WL.weekListNames(s.week)) s.week[name] = (s.week[name] || []).map(x => x.id === c.id ? c : x);
        s.week.statuses = s.week.statuses || {};
        if (o.first) { s.week.statuses[c.id] = 'Idea'; for (const a of Object.values(ensureAccounts(s))) if (a.links[c.id]) delete a.links[c.id]; if (s.predictionLog) delete s.predictionLog[c.id]; }
        syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
        scoreWeek(s);
      });
    };
    // the AI writes the cards you give it: the week, one tab or one card, each card in its own request
    const weekDeps = () => ({
      tabRules: label => { try { return blueprints.tabRules(label); } catch { return ''; } },
      scpRules: () => { try { return blueprints.scpRules(); } catch { return ''; } },
      themeRules: theme => { try { return blueprints.themeRules(theme); } catch { return ''; } },
      traitRules: name => { try { return blueprints.traitRules(name); } catch { return ''; } },
      fieldsFor: {typeOf: c => typeForCard(c), fields: type => { const t = blueprints && blueprints.current() && blueprints.current().types && blueprints.current().types[type]; return t && t.fields && t.fields.length ? t.fields : null; }},
      notesFor: (card, used) => writer.engineNotes(card, used),
      // only if the AI cannot or will not write a tab the app can write itself (Preventable NTR, Post-NTR), the app's own cards stand in for that group
      localFallback: cards => { const sc = blueprints && blueprints.current(), t = laneTabs(sc, isShare).find(x => x.key === (cards[0] || {}).laneTab); return t && hasLocalWriter(t) ? writeLaneLocally(t, cards.map(c => ({...c, sceneName: 'Untitled', fields: {'Day Assignment': (c.fields || {})['Day Assignment']}})), sc) : null; },
      onCard: (c, o) => saveWeekCard(c, o),
      // the other cards of the week (including the ones this run has already written): a card that tells the same story as one of them is written again
      peersFor: c => WL.weekCards(store.get().week).filter(x => x && x.id !== c.id && !isOpenSlot(x)),
      // the cards you built in earlier weeks (kept when a week rolls over): the same prop is not used again
      pastFor: () => (store.get().cardArchive || []).filter(x => x && x.fields).slice(-60),
      // while an event is on, every card the AI writes is also adapted to it: the event goes to the AI with the card, which makes surgical edits
      eventFor: card => { const ev = Events.forCard(store.get(), card); if (!ev) return null; const P = ev.parsed, rb = ev.rulebook || EventRules.fromParsed(P);
        return {name: P.name || P.eventTag, tag: P.eventTag || '', opportunityTags: P.opportunityTags || [], min: P.minOpportunityTags, raw: ev.raw || P.rawOriginal || '', rules: ((rb && rb.rules) || []).map(r => ({part: r.part, requirement: r.requirement, signs: r.signs, fixHint: r.fixHint, menu: !!r.menu}))}; },
      adaptLocal: c => adaptToEvent(c, Events.forCard(store.get(), c), flattenWeek(store.get().week)),
      getCard: id => { const f = WL.findCard(store.get().week, id); return f ? f.card : null; },
      validate: (c, ch) => CR.check(cardRulesFor(c), c, ch || c.fields), rulesText: c => CR.rulesText(cardRulesFor(c)),
      request: (c, peers) => { const x = JSON.parse(JSON.stringify(c)), L = withLearning(store.get()); applyAssessment(x, L, peers || []); return fixRequestWithRules(x, WI.proposeImprovements(x, L, peers || [], 80)); }});
    // the skeleton the writer needs for a set of cards (the planner's slots, series and names), whichever tabs they are in
    // a series card (for example ANTI-NTR) is always written with its own series' rules from your rulebook and card template.
    // Before, those rules only went to the AI when a series option was picked for the card, so by default the AI saw only the series name.
    const withOwnSeriesRules = c => {
      if (!c || c.seriesFocus || c.laneTab || c.slot === 'NTR' || c.day === 'NTR' || c.slot === 'Bonus' || isAdded(c)) return c;
      const name = String(c.series || '').trim(); if (!name || /^standalone$/i.test(name)) return c;
      const known = seriesNames().find(n => n.toLowerCase() === name.toLowerCase()); if (!known) return c;
      const i = seriesInfoOf(known); if (i && i.text) c.seriesFocus = {mode: 'keep', name: known, text: i.text};
      return c;
    };
    const skeletonOf = (st, cards) => {
      const sk = {weekStart: st.week.weekStart, days: [], ntr: [], lanes: {}};
      for (const c0 of cards) { const c = withOwnSeriesRules(JSON.parse(JSON.stringify(c0)));
        if (c.laneTab) (sk.lanes[WL.laneName(c.laneTab)] = sk.lanes[WL.laneName(c.laneTab)] || []).push({id: c.id, userDetails: c.userDetails, laneTab: c.laneTab, day: c.day, slot: c.slot, theme: c.theme, series: c.series, lane: c.lane, order: c.order, sceneName: 'Untitled', cast: [], tags: [], fields: {'Day Assignment': (c.fields || {})['Day Assignment']}});
        else if (c.slot === 'NTR' || c.day === 'NTR') sk.ntr.push(c);
        else { let d = sk.days.find(x => x.day === c.day); if (!d) sk.days.push(d = {day: c.day, theme: c.theme || '', scenarios: []}); d.scenarios.push(c); }
      }
      return sk;
    };
    const premise = c => `${c.sceneName}: ${String((c.fields || {})['The Setup'] || (c.fields || {})['What Has Already Happened'] || '').replace(/\s+/g, ' ').slice(0, 140)}`;
    const needEngines = st => { if (!st.engineAnalysis?.engines?.length) throw new Error('Collect Recent + Trending bots and analyze them first: the AI builds the cards on the success engines.'); };
    const needAi = () => { if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now."); };
    // runs the writer on these cards (one request each) and answers with what the renderer needs to refresh and report
    // Write with AI scraps the card and writes it from nothing: the old story, characters, name, archetype, tags and fields are not sent to the AI and are not
    // reused. Only what the planner decided stays (day, slot, series, theme, order, mode), plus what the creator typed for the card. The old version is archived
    // when the new one is saved, and the old premise is handed to the AI as one to stay away from.
    const KEEP_FIELDS = ['Day Assignment'];
    const scrap = c => {
      const out = {...c};
      for (const k of ['cast', 'primaryCharacter', 'primaryArchetype', 'tags', 'hookRef', 'incidentId', 'aiWritten', 'aiMissing', 'aiFilled', 'aiDuplicate', 'localWritten', 'eventAI', 'imported', 'blankSlot', 'notes', 'seriesLabel', 'engine', 'observed', 'score', 'scoreInfo']) delete out[k];
      out.cast = []; out.tags = []; out.primaryCharacter = ''; out.sceneName = 'Untitled';
      const f = {}; for (const k of KEEP_FIELDS) if ((c.fields || {})[k]) f[k] = c.fields[k];
      out.fields = f;
      return out;
    };
    const hasStory = c => !!(c && ((c.fields && Object.keys(c.fields).some(k => !KEEP_FIELDS.includes(k) && String(c.fields[k] || '').trim())) || (c.sceneName && c.sceneName !== 'Untitled')));
    // What the loaded rulebook decides for a day or a card (a fixed day theme such as Smutty Sunday, a weekly trait such as Kemonomimi) is stored on the card when the week is generated.
    // A week built before the rulebook said so would be written from the old plan, so Write with AI reads the rulebook again first and puts it on the cards about to be written.
    const syncRulebookPlan = ids => {
      if (isShare || !blueprints) return;
      let plan; try { plan = blueprints.plan(); } catch { return; }
      const fx = plan.fixedThemes || {}, traits = plan.traits || [];
      if (!Object.keys(fx).length && !traits.length) return;
      store.update(s => {
        const week = s.week || {}, mine = (week.scenarios || []).filter(c => ids.has(c.id) && !c.laneTab && c.slot !== 'NTR' && c.slot !== 'Bonus' && !isAdded(c));
        for (const c of mine) { const want = fx[c.day]; if (want && !String(c.theme || '').toLowerCase().startsWith(want.toLowerCase())) { const old = String(c.theme || '').split(/\s+\+\s+/).filter(x => x.toLowerCase() !== want.toLowerCase()).join(' + '); c.theme = old ? want + ' + ' + old : want; } }
        for (const t of traits) {
          const all = week.scenarios || [], have = all.filter(c => String(c.trait || '').toLowerCase() === t.name.toLowerCase()).length;
          for (let n = have; n < t.count; n++) {
            const ok = mine.filter(c => !c.trait && t.slots.some(sl => String(c.series || '').toLowerCase() === sl.toLowerCase()));
            const fresh = ok.filter(c => !all.some(x => x.trait && x.day === c.day)), pool = fresh.length ? fresh : ok;
            if (!pool.length) break; pool[Math.floor(Math.random() * pool.length)].trait = t.name;
          }
        }
      });
    };
    const writeCards = async (cards, extra = {}) => {
      syncRulebookPlan(new Set(cards.map(c => c.id)));
      cards = cards.map(c => { const f = WL.findCard(store.get().week, c.id); return f && f.card ? {...c, theme: f.card.theme, ...(f.card.trait ? {trait: f.card.trait} : {})} : c; });
      const st = store.get(), ids = new Set(cards.map(c => c.id));
      const old = extra.scope && extra.scope !== 'week' ? cards.filter(hasStory).map(premise) : [];      // the premises being thrown away: the new cards must not repeat them
      const usedSeed = [...old, ...WL.weekCards(st.week).filter(c => !ids.has(c.id) && !isOpenSlot(c)).map(premise)].slice(0, 40);
      cards = cards.map(c => scrap(c));
      let r;
      try { r = await writer.writeWeek({skeleton: skeletonOf(st, cards), weekStart: st.week.weekStart, usedSeed, ...weekDeps(), ...extra}); }
      finally { if (store.get().scpStart) store.update(s2 => { delete s2.scpStart; }); }      // the SCP number typed for this write is used once
      return {kind: 'week', skippedBuilt: extra.skippedBuilt || [], saved: r.saved, failed: r.failed, raised: r.raised, problems: r.problems, missing: r.missing, adapted: r.adapted, cost: r.cost, costKnown: r.costKnown, state: store.get()};
    };
    const tabCardsOf = (st, tab) => {
      if (tab === 'Bonus') throw new Error('Bonus cards are built from your own ideas, so they are not written with AI here. Use Write with AI in the Bot Builder on a Bonus card.');
      const isLane = WL.isLaneName(tab), laneT = isLane ? laneTabs(blueprints && blueprints.current(), isShare).find(t => WL.laneName(t.key) === tab) : null;
      if (isLane && !laneT) throw new Error('That tab is no longer part of your Weekly Blueprint.');
      if (tab === 'NTR' && !hasNtrTab()) throw new Error('Your Weekly Blueprint has no NTR tab.');
      const list = tab === 'NTR' ? (isCombinedNtr() ? combinedNtrCards(st.week) : (st.week.ntr || [])) : isLane ? (st.week[tab] || []) : (st.week.scenarios || []).filter(x => x.day === tab);
      return {list, label: isLane ? laneT.label : tab === 'NTR' ? 'NTR' : tab};
    };
    // the whole week: the planner builds the week as Generate Week does (the old week is archived), then the AI writes every card, one request each, saving each as it finishes
    // SCP Series: the creator types the SCP number before the AI writes an SCP card; an existing SCP card is renumbered here without any AI
    ipcMain.handle('scp:scope', (_, kind, arg) => {
      const ScpN = require('./lib/scpNumber'), Set2 = require('./lib/settings'), st = store.get();
      let list = [];
      if (kind === 'card') { const f = WL.findCard(st.week, arg); list = f && f.card ? [f.card] : []; }
      else if (kind === 'tab') { try { list = tabCardsOf(st, arg).list.filter(x => String(st.week.statuses?.[x.id] || '') !== 'Built'); } catch { list = []; } }
      else list = WL.weekCards(st.week);
      const scp = list.filter(c => Set2.isScp(c));
      const own = scp.map(c => ScpN.numberOf(c.primaryCharacter)).filter(Boolean);
      return {count: scp.length, suggested: scp.length === 1 && own.length === 1 ? own[0] : ScpN.highest(st, [], scp.map(c => c.id)) + 1, found: ScpN.highest(st, [], scp.map(c => c.id)) > 0};
    });
    ipcMain.handle('scp:setStart', (_, n) => { const v = Math.floor(Number(n)); if (!(v > 0 && v < 10000)) throw new Error('Type the SCP number as a whole number, for example 22.'); store.update(s => { s.scpStart = v; }); return true; });
    ipcMain.handle('scp:rename', (_, id, n) => {
      const ScpN = require('./lib/scpNumber'); let out;
      store.update(s => { const f = WL.findCard(s.week, id); if (!f || !f.card) throw new Error('That card no longer exists.'); out = ScpN.rename(f.card, n); });
      return {...out, state: store.get()};
    });
    ipcMain.handle('ai:writeWeek', async (_, weekStart, eventPlan) => {
      needAi(); needEngines(store.get());
      await generateWeekNow(weekStart, eventPlan);
      const st = store.get(), w = st.week;
      const cards = [...(w.scenarios || []).filter(c => !isAdded(c)), ...(hasNtrTab() ? (w.ntr || []).filter(c => !isAdded(c)) : []), ...Object.keys(w).filter(WL.isLaneName).flatMap(k => w[k] || [])];
      return writeCards(cards);
    });
    // one tab only: the AI rewrites that tab's cards one request each (Built cards stay); everything in the other tabs is left exactly as it is
    // a tab whose cards were deleted goes back to the number of cards the Weekly Blueprint gives it (7 for NTR, 3 for a day...) before the AI writes it
    const topUpTab = tab => {
      if (tab === 'Bonus') return;
      if (tab === 'NTR' && isCombinedNtr()) for (const t of rotationLanes()) topUpTab(WL.laneName(t.key));   // the combined tab: its Preventable / Post-NTR cards too
      const sc = blueprints && blueprints.current(), st0 = store.get(), isLane = WL.isLaneName(tab);
      if (isLane) {
        const lt = laneTabs(sc, isShare).find(t => WL.laneName(t.key) === tab); if (!lt) return;
        const want = lt.cards || 7, have = (st0.week[tab] || []);
        if (have.length >= want) return;
        store.update(s => { const list = s.week[tab] = s.week[tab] || [], orders = new Set(list.map(c => c.order));
          const add = buildLaneCards(lt, want).filter(c => !orders.has(c.order)).slice(0, Math.max(0, want - list.length));
          if (lt.rotation) { const used = new Set(list.map(c => (c.fields || {})['Day Assignment']).filter(Boolean)), free = lt.rotation.days.filter(d => !used.has(d)); add.forEach((c, i) => { if (free[i]) c.fields['Day Assignment'] = free[i]; }); }
          else if (want === 7) { const used = new Set(list.map(c => (c.fields || {})['Day Assignment']).filter(Boolean)), free = RELEASE_DAYS.filter(d => !used.has(d)); add.forEach((c, i) => { if (free[i]) c.fields['Day Assignment'] = free[i]; }); }   // every day exactly once
          list.push(...add); list.sort((a, b) => (a.order || 99) - (b.order || 99)); s.week.statuses = s.week.statuses || {}; for (const c of add) s.week.statuses[c.id] = 'Idea'; scoreWeek(s); });
        return;
      }
      const isNtr = tab === 'NTR', tdef = tabsOf(sc).find(t => isNtr ? t.kind === 'ntr' : (t.kind === 'day' && (t.day === tab || t.label === tab)));
      const want = (tdef && tdef.cards) || (isNtr ? 7 : 3), have = isNtr ? (st0.week.ntr || []) : (st0.week.scenarios || []).filter(x => x.day === tab && !isAdded(x));
      if (have.length >= want) return;
      needPlan();
      const g = generateWeekLocal({engineAnalysis: st0.engineAnalysis, activeEvent: st0.event, weekStart: st0.week.weekStart, performance: st0.performance, plan: weekPlanNow()});
      store.update(s => {
        s.week.statuses = s.week.statuses || {};
        if (isNtr) {
          const list = s.week.ntr = s.week.ntr || [], days = new Set(list.map(c => c.day));
          const nd = ntrDaysNow(), add = ensureIds((g.ntr || []).filter(c => !days.has(c.day) && (!nd || nd.includes(c.day))).slice(0, Math.max(0, want - list.length)).map(x => ({...x, slot: x.slot || 'NTR'})));
          list.push(...add); list.sort((a, b) => RELEASE_DAYS.indexOf(a.day) - RELEASE_DAYS.indexOf(b.day)); for (const c of add) s.week.statuses[c.id] = 'Idea';
        } else {
          const mine = (s.week.scenarios || []).filter(x => x.day === tab && !isAdded(x)), slots = new Set(mine.map(c => c.slot)), theme = (mine[0] || {}).theme;
          const gen = ((g.days || []).find(d => d.day === tab) || {scenarios: []}).scenarios;
          const add = ensureIds(gen.filter(c => !slots.has(c.slot)).slice(0, Math.max(0, want - mine.length)).map(x => ({...x, ...(theme ? {theme} : {})})));
          const at = s.week.scenarios.reduce((n, c, i) => c.day === tab ? i + 1 : n, s.week.scenarios.length);
          s.week.scenarios.splice(at, 0, ...add);
          const num = c => +(String(c.slot || '').match(/Scenario\s+(\d+)/i) || [0, 99])[1];
          const own = s.week.scenarios.filter(c => c.day === tab && !isAdded(c)).sort((a, b) => num(a) - num(b)), it = own[Symbol.iterator]();
          s.week.scenarios = s.week.scenarios.map(c => c.day === tab && !isAdded(c) ? it.next().value : c);
          for (const c of add) s.week.statuses[c.id] = 'Idea';
        }
        scoreWeek(s);
      });
    };
    ipcMain.handle('ai:writeTab', async (_, tab) => {
      needAi(); needEngines(store.get());
      if (tab === 'NTR' && isCombinedNtr()) store.update(s => { if (normalizeNtrRotation(s, blueprints.current())) scoreWeek(s); });
      tabCardsOf(store.get(), tab); topUpTab(tab);                                   // (the first call only checks the tab is writable)
      const st = store.get();
      const {list, label} = tabCardsOf(st, tab);
      const todo = list.filter(x => String(st.week.statuses?.[x.id] || '') !== 'Built');
      if (!todo.length) throw new Error(list.length ? 'Every card in this tab is marked Built, so nothing was written.' : 'This tab has no cards yet.');
      const skippedBuilt = list.filter(x => !todo.includes(x)).map(x => ({sceneName: x.sceneName || 'Untitled', day: cardDay(x)}));   // Built cards are never rewritten: the finished message says which ones were left
      return writeCards(todo, {scope: tab, scopeLabel: label, skippedBuilt});
    });
    // the blank sections of a card: the blueprint's fields it has no text for (the writer is sent the whole card and fills ONLY these)
    const blankFieldsOf = c => {
      const sc = blueprints && blueprints.current(); if (!sc) return [];
      if (!(sc.version || c.laneTab)) return [];
      const tp = sc.types && sc.types[typeForCard(c)]; if (!tp) return [];
      const F = c.fields || {};
      return (tp.fields || []).filter(f => f.label !== 'Scene Name').filter(f => fieldApplies(f.label, f.instruction, c, typeForCard(c))).filter(f => { const k = fieldMatch(f.label, F); const v = k == null || k === false ? '' : F[k]; return !(Array.isArray(v) ? v.length : String(v == null ? '' : v).trim()); }).map(f => ({label: f.label, instruction: f.instruction || ''}));
    };
    ipcMain.handle('ai:fillCard', async (_, id, labels) => {
      needAi(); const st = store.get();
      const f = WL.findCard(st.week, id); if (!f) throw new Error('That card no longer exists.');
      const want = Array.isArray(labels) && labels.length ? new Set(labels) : null;
      const blanks = blankFieldsOf(f.card).filter(b => !want || want.has(b.label));
      if (!blanks.length) throw new Error('This card has no blank sections.');
      const r = await writer.fillCard({card: JSON.parse(JSON.stringify(f.card)), blanks, validate: (c, ch) => CR.check(cardRulesFor(c), c, ch), event: weekDeps().eventFor(f.card), scpRules: weekDeps().scpRules});
      const out = JSON.parse(JSON.stringify(store.get().week[f.list].find(x => x.id === id) || f.card));
      out.fields = out.fields || {};
      for (const [label, text] of Object.entries(r.fields || {})) {
        const k = fieldMatch(label, out.fields); out.fields[k == null || k === false ? label : k] = text;
        if (label === 'Tags') out.tags = String(text).split(/,|\n/).map(t => t.replace(/\(.*?\)/g, '').trim()).filter(Boolean).slice(0, 12);
      }
      out.aiFilled = [...new Set([...(out.aiFilled || []), ...r.filled])]; out.editedAt = new Date().toISOString();
      if (!out.bonusIdea) out.imported = true;                                     // scored by the data-based estimate from now on, like any edited card
      if (r.filled.length) saveWeekCard(out, {first: false});
      return {kind: 'fill', filled: r.filled.length, left: r.left, dropped: r.dropped, cost: r.cost, costKnown: r.costKnown, state: store.get()};
    });
    // Adapt to Event with the AI: the app's own tag and event-field changes first, then surgical AI edits to the story, personality and appearance
    ipcMain.handle('ai:adaptEvent', async (_, ids) => {
      needAi(); const st = store.get();
      if (!Events.anyActive(st)) throw new Error('No active event. Set one up on the Events tab first.');
      const all = flattenWeek(st.week), asked = (Array.isArray(ids) ? ids : []).map(id => all.find(c => c.id === id)).filter(Boolean);
      if (!asked.length) throw new Error('Those cards no longer exist.');
      const list = asked.filter(c => Events.forCard(st, c));
      if (!list.length) throw new Error(asked.length > 1 ? 'None of those cards is an event card, so nothing was adapted. Tick "Event card" on a card to enter it in the event.' : 'This card is not an event card, so it was not adapted. Tick "Event card" on it to enter it in the event.');
      const D = weekDeps();
      const r = await writer.adaptToEventAI({cards: list.map(c => JSON.parse(JSON.stringify(c))), eventFor: D.eventFor, adaptLocal: D.adaptLocal, validate: D.validate, onCard: D.onCard, peersFor: D.peersFor, pastFor: D.pastFor, scope: 'adapt'});
      return {kind: 'adapt', ...r, state: store.get()};
    });
    // the series a card can be written for: read from your rulebook and card template, so a series you add to them shows up here
    const seriesNames = () => { try { return SeriesLib.names(blueprints && blueprints.current(), {share: isShare}); } catch { return SeriesLib.names(null, {share: isShare}); } };
    const seriesInfoOf = name => { try { return SeriesLib.info(name, blueprints && blueprints.current()); } catch { return {text: '', blocks: [], mentions: 0}; } };
    // NTR-tab, other lane-tab and Bonus cards keep their own identity; every other card can be written for a series or as a standalone
    const seriesEditable = c => !(c.laneTab || c.slot === 'NTR' || c.series === 'Likeable NTR' || c.slot === 'Bonus' || isAdded(c));
    ipcMain.handle('series:options', (_, id) => {
      const f = WL.findCard(store.get().week, id); if (!f) throw new Error('That card no longer exists.');
      const names = seriesNames(), cur = String(f.card.series || 'Standalone');
      return {editable: seriesEditable(f.card) && f.list !== 'bonus', current: cur, currentIsSeries: names.some(n => n.toLowerCase() === cur.toLowerCase()),
        options: names.map(n => { const i = seriesInfoOf(n); return {name: n, sections: i.blocks.length, mentions: i.mentions}; })};
    });
    // the card as the AI is asked to write it: on the chosen series (its rules from your files go with it) or as a standalone
    const withSeriesFocus = (card, focus) => {
      const mode = focus && focus.mode; if (!['keep', 'series', 'standalone'].includes(mode)) return card;
      let name = mode === 'standalone' ? 'Standalone' : mode === 'series' ? String(focus.series || '') : String(card.series || 'Standalone');
      if (mode === 'series') { const ok = seriesNames().find(n => n.toLowerCase() === name.toLowerCase()); if (!ok) throw new Error('That series is no longer in your rulebook or card template. Pick another one.'); name = ok; }
      const out = JSON.parse(JSON.stringify(card));
      if (name.toLowerCase() !== String(card.series || '').toLowerCase()) { out.series = name; out.lane = name; delete out.seriesLabel; out.primaryArchetype = chooseArchetype(name); }   // its archetype follows the series it is now in
      if (name === 'Standalone') out.seriesFocus = {mode: 'standalone', name};
      else { const i = seriesInfoOf(name); if (mode !== 'keep' || i.text) out.seriesFocus = {mode: mode === 'keep' ? 'keep' : 'series', name, text: i.text}; }
      return out;
    };
    // one card: written by itself, in its own request, in its own slot
    ipcMain.handle('ai:writeCard', async (_, id, focus) => {
      needAi(); const st = store.get(); needEngines(st);
      const f = WL.findCard(st.week, id); if (!f) throw new Error('That card no longer exists.');
      if (f.list === 'bonus' || f.card.slot === 'Bonus' || isAdded(f.card)) throw new Error('Bonus cards are built from your own ideas, so they are not written with AI here. Use Write with AI in the Bot Builder on a Bonus card.');
      let card = seriesEditable(f.card) ? withSeriesFocus(f.card, focus) : f.card;
      // what the creator typed for this card ("make her a gyaru"): kept as plain text, sent to the AI with the card, never run as anything
      const details = String((focus && focus.details) || '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').replace(/\r\n?/g, '\n').trim().slice(0, 1500);
      if (details) card = {...JSON.parse(JSON.stringify(card)), userDetails: details};
      return writeCards([card], {scope: 'card:' + id, scopeLabel: f.card.sceneName || 'card', title: `Writing "${f.card.sceneName || 'this card'}" with AI`});
    });
    ipcMain.handle('ai:eventRules', async (_, eventId) => {
      if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now.");
      const st = store.get(), ev = (eventId && Events.byId(st, eventId)) || st.event || {}; if (!ev.parsed) throw new Error('Paste and read an event announcement first.');
      const rb = await writer.eventRules(ev.raw || ev.parsed.rawOriginal || '', ev.rulebook || EventRules.fromParsed(ev.parsed));
      return store.update(s => { const t = Events.byId(s, ev.id); if (t) { t.rulebook = rb; require('./lib/eventMenu').clean(t); } });
    });
    // the parts of the week plan the app could not read from the rulebook: the AI reads them from the rulebook's own lines; every answer is checked (counts must add up to the days) before it is used
    ipcMain.handle('ai:readWeekPlan', async () => {
      needAi(); const WP = require('./lib/weekPlan'), plan = blueprints.plan(), miss = WP.missingParts(plan, isShare).filter(p => p !== 'days');
      if (!miss.length) throw new Error('Nothing is missing from the week plan.');
      const excerpt = WP.planExcerpt(blueprints.rulesText()); if (!excerpt) throw new Error('There is no rulebook text to read. Type the missing parts in instead.');
      const got = await writer.readWeekPlan(excerpt, miss, plan.days.length), chk = WP.checkAiPlan(got, miss, plan.days.length);
      for (const [p, e] of Object.entries(chk.found)) blueprints.setPlanPart(p, e);
      return {status: blueprints.status(), found: Object.keys(chk.found), notFound: chk.notFound};
    });
    ipcMain.handle('builder:saveGreetingPlan', (_, templateId, cardId, plan) => {
      const st = store.get(), card = [...allCards(st), ...(st.cardArchive || [])].find(c => c.id === cardId);
      if (!card) throw new Error('That scenario card is no longer available.');
      const checked = require('./renderer/greetingplan').validate(card, plan);
      store.update(s => { s.builder = s.builder || {}; s.builder.greetingPlans = (s.builder.greetingPlans || []).filter(r => r.templateId !== templateId || r.cardId !== cardId); s.builder.greetingPlans.push({templateId,cardId,plan:checked}); });
      return true;
    });
    ipcMain.handle('ai:rewriteSection', async (_, templateId, section, values, notes, greetingPlan) => {
      if (!on()) throw new Error('The AI writer is not configured in this edition.');
      const st = store.get(), card = [...allCards(st), ...(st.cardArchive || [])].find(c => c.id === values?.sourceId);
      if (!card) throw new Error('The linked scenario card is not available. Select the correct card before rewriting.');
      return writer.rewriteSection({templateId, section, values, notes, greetingPlan, card});
    });
    ipcMain.handle('ai:fixEvent', async (_, templateId, values, failing) => {
      if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now.");
      const spec = templatesWithLimits().find(t => t.id === templateId); if (!spec) throw new Error('That template is no longer available.');
      const st = store.get(), card = values && values.sourceId ? [...WL.weekCards(st.week), ...(st.cardArchive || [])].find(c => c.id === values.sourceId) : null;
      return writer.fixForEvent({spec, v: JSON.parse(JSON.stringify(values)), failing: failing || [], card});
    });
    ipcMain.handle('ai:imageKeywords', async (_, templateId, values, rules) => {
      if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now.");
      const spec = templatesWithLimits().find(t => t.id === templateId); if (!spec) throw new Error('That template is no longer available.');
      const st = store.get(), card = values && values.sourceId ? [...WL.weekCards(st.week), ...(st.cardArchive || [])].find(c => c.id === values.sourceId) : null;
      return writer.imageKeywords({spec, v: JSON.parse(JSON.stringify(values || {})), card, rules: Array.isArray(rules) ? rules : []});
    });
    // Suggestions: ideas to consider adding or tweaking, read from the card itself. Nothing is changed and nothing is scored.
    ipcMain.handle('ai:suggestCard', async (_, id) => {
      if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now. You can still copy the request into ChatGPT.");
      const st = store.get(), f = findAny(st, id); if (!f) throw new Error('That card no longer exists.');
      const card = JSON.parse(JSON.stringify(f.card));
      return writer.suggestCard({card, request: c => Suggest.request(c, {rulesText: CR.rulesText(cardRulesFor(c))})});
    });
    ipcMain.handle('ai:resume', async (_, id) => {
      if (!on()) throw new Error("The AI writer isn't connected: the app couldn't find its relay settings, or the relay can't be reached right now.");
      const j = writer.load(id); if (!j || ['done', 'cancelled'].includes(j.state)) throw new Error('That unfinished job is no longer available.');
      if (j.kind === 'week') { const r = await writer.writeWeek(weekDeps(), id); return {kind: 'week', saved: r.saved, failed: r.failed, raised: r.raised, problems: r.problems, missing: r.missing, adapted: r.adapted, cost: r.cost, costKnown: r.costKnown, state: store.get()}; }
      return writer.writeBot({}, id);
    });
    ipcMain.handle('ai:unfinished', () => on() ? writer.unfinished() : []);
    ipcMain.handle('ai:cancel', () => { writer.cancel(); return true; });
    ipcMain.handle('ai:discard', (_, id) => writer.discard(id));
    ipcMain.handle('ai:setMyLimit', (_, v) => { const n = Math.max(0, Number(v) || 0); store.update(s => { s.aiMyLimit = n; }); return n; });
    ipcMain.handle('ai:setMyName', (_, name) => { const n = String(name || '').trim().slice(0, 40); store.update(s => { s.aiMyName = n; }); return n; });
    // relay controls, your edition only: who's spending, caps, on/off, names and blocking (all saved in Cloudflare)
    ipcMain.handle('ai:admin', async (_, op, payload) => {
      if (isShare || !relay.canAdmin) throw new Error('Relay controls are only in your edition.');
      if (op === 'overview') return relay.admin('/admin/overview');
      if (op === 'config') return relay.admin('/admin/config', payload || {});
      if (op === 'device') return relay.admin('/admin/device', payload || {});
      throw new Error('Unknown relay control.');
    });
    ipcMain.handle('ai:setThinking', (_, level) => { const l = ['off', 'low', 'medium', 'high'].includes(level) ? level : 'medium'; store.update(s => { s.aiThinking = l; }); relay.forceLevel = null; return l; });   // a new choice starts fresh
  }
  // ---- updates from the shared Google Drive folder (never installed without the user's click)
  const updater = new Updater({appDir: app.getAppPath(), currentVersion: app.getVersion(), edition: EDITION});
  const updateFolder = () => UPDATE_FOLDER || store.state.settings.updateFolder || '';
  ipcMain.handle('update:info', () => ({current: app.getVersion(), folder: updateFolder(), defaultFolder: UPDATE_FOLDER, auto: store.state.settings.autoUpdateCheck !== false, skipped: store.state.settings.skippedVersion || ''}));
  ipcMain.handle('update:changelog', () => { try { return require('./lib/updater').notesFrom(app.getAppPath(), '0.0.0'); } catch { return []; } });   // this installed version's own release notes, newest first
  ipcMain.handle('update:check', async () => updater.check(updateFolder()));
  ipcMain.handle('update:install', async () => updater.install());
  ipcMain.handle('update:skip', (_, version) => { updater.discard(); return store.update(s => { s.settings.skippedVersion = String(version || ''); }); });
  ipcMain.handle('update:restart', () => { app.relaunch(); app.exit(0); });
  let lastUpdateCheck = 0;
  const autoUpdateCheck = async (manual = false) => {
    if (!manual && (store.state.settings.autoUpdateCheck === false || !updateFolder())) return;
    lastUpdateCheck = Date.now();
    try {
      const r = await updater.check(updateFolder());
      if (!r.available) { if (manual) send('update:none', r); return; }
      const skipped = !manual && r.latest === store.state.settings.skippedVersion;
      send('update:available', {...r, auto: !manual, skipped});
      // the window is hidden in the tray: say so with a notification instead
      if (!skipped && mainWindow && !mainWindow.isVisible()) {
        try { const n = new Notification({title: `Juicy Blueprint Studio ${r.latest} is available`, body: 'Click to see what\'s new and choose whether to update.'}); n.on('click', showMainWindow); n.show(); }
        catch { try { tray && tray.displayBalloon({title: `Version ${r.latest} is available`, content: 'Open Juicy Blueprint Studio to see what\'s new.'}); } catch {} }
      }
    } catch (e) { console.error('update check:', e.message); if (manual) send('update:error', {message: e.message}); }
  };
  if (!SANDBOX) setTimeout(() => autoUpdateCheck(false), 6000);                                   // when the app starts
  if (!SANDBOX) setInterval(() => { if (Date.now() - lastUpdateCheck > 20 * 3600 * 1000) autoUpdateCheck(false); }, 60 * 60 * 1000);   // and once a day while it stays open
  createTray(autoUpdateCheck);
  app.on('before-quit', () => updater.discard());
  ipcMain.handle('blueprint:get', () => { const c = blueprints.current(); return c ? {version: c.version, label: c.label, modes: isShare ? [] : (c.modes || []), types: c.types, fixedThemes: isShare ? {} : (blueprints.plan().fixedThemes || {}), tabs: tabsOf(c), panels: c.panels.map(p => ({title: p.title, text: p.text, kind: p.kind}))} : null; });
  ipcMain.handle('blueprint:status', () => blueprints.status());
  ipcMain.handle('blueprint:choose', async (_, kind) => {
    const html = kind === 'template';
    const {canceled, filePaths} = await dialog.showOpenDialog(mainWindow, {title: html ? 'Choose the Weekly Blueprint HTML template' : 'Choose the Weekly Blueprint rulebook (.txt)', properties: ['openFile'], filters: [html ? {name: 'HTML template', extensions: ['html', 'htm']} : {name: 'Rulebook', extensions: ['txt']}]});
    return canceled || !filePaths.length ? null : {path: filePaths[0], name: path.basename(filePaths[0])};
  });
  const blueprintResult = (r, what) => {
    applyBlueprintTags(r.schema);
    let filled = 0;
    let lanes = {added: [], removed: []};
    const out = store.update(s => { lanes = reconcileLanes(s, r.schema); filled = fillBlueprintFields(s, r.schema); });
    // a fixed day theme the rulebook now states (Smutty Sunday) that the week already built does not carry: the week is not rebuilt for you, so say so
    let staleFixed = [];
    try { const fx = isShare ? {} : (blueprints.plan().fixedThemes || {}); staleFixed = Object.keys(fx).filter(d => { const cs = ((out.week || {}).scenarios || []).filter(c => c.day === d); return cs.length && cs.some(c => !String(c.theme || '').toLowerCase().startsWith(fx[d].toLowerCase())); }).map(d => ({day: d, theme: fx[d]})); } catch {}
    return {state: out, changes: r.changes, filled, lanes, staleFixed, status: blueprints.status(), what};
  };
  ipcMain.handle('blueprint:update', (_, rulesPath, templatePath) => {
    if (!rulesPath && !templatePath) throw new Error('Choose the rulebook (.txt), the HTML template, or both.');
    const out = blueprintResult(blueprints.update(rulesPath || null, templatePath || null), 'updated');
    // a 2-bots-per-day blueprint you upload becomes your 2 bots/day files, so the 2 bots/day button brings it back after the Kill Switch
    try { if (!isShare && scheduleHere() === 2) { const c = blueprints.current() || {}; saveSchedFiles(2, blueprints.rulesText(), blueprints.templateText(), c.rulesName, c.templateName); } } catch (e) { console.error('save 2-per-day files:', e.message); }
    return out;
  });
  // a part of the week plan the rulebook does not state, typed in by the creator (no AI): checked, then used until the rulebook states that part itself
  ipcMain.handle('blueprint:planSet', (_, part, text, none) => {
    const WP = require('./lib/weekPlan'); if (!['themes', 'established', 'mix2', 'slot3'].includes(part)) throw new Error('That part of the week plan is not known.');
    if (none) { if (part === 'themes') throw new Error('Daily themes cannot be left out. Type at least two.'); blueprints.setPlanPart(part, {none: true, source: 'you'}); }
    else { const r = WP.parsePartText(part, text, blueprints.plan().days.length); if (r.error) throw new Error(r.error); blueprints.setPlanPart(part, {value: r.value, source: 'you'}); }
    return blueprints.status();
  });
  ipcMain.handle('blueprint:planClear', (_, part) => { blueprints.setPlanPart(part, null); return blueprints.status(); });
  ipcMain.handle('blueprint:revert', () => blueprintResult(blueprints.revert(), 'reverted'));
  // ---- Weekly schedule switch (personal edition): 2 or 3 bots per day. It loads the bundled rulebook + card template for that schedule as a new blueprint version
  // (so Revert undoes it) and touches nothing else: the NTR tab, the cards already written and every setting stay as they are.
  ipcMain.handle('schedule:status', () => scheduleStatus());
  ipcMain.handle('schedule:set', (_, n) => {
    if (isShare) throw new Error('The schedule switch is not part of this edition.');
    n = +n; if (n !== 2 && n !== 3) throw new Error('Choose 2 or 3 bots per day.');
    const s = scheduleStatus(); if (!s.available) throw new Error('The bundled rulebooks for the 2 and 3 bots-per-day schedules are missing from this install (resources/rules).');
    if (s.perDay === n && s.matches) return {unchanged: true, perDay: n, status: blueprints.status()};
    // leaving 2 bots per day: the blueprint in use is kept as your 2 bots/day files, so pressing 2 bots/day later brings back exactly this
    if (n === 3 && s.perDay === 2) { try { const c = blueprints.current() || {}; saveSchedFiles(2, blueprints.rulesText(), blueprints.templateText(), c.rulesName, c.templateName); } catch (e) { console.error('keep 2-per-day files:', e.message); } }
    const pair = schedulePair(n), r = blueprints.update(pair.rules, pair.template);
    return {...blueprintResult(r, 'updated'), perDay: n, scheduleSet: n, own: pair.own};
  });
  // the Kill Switch files: your 3-bots-per-day rulebook + card template, kept for the 3 bots/day button. Either file can be replaced on its own once both are saved.
  ipcMain.handle('schedule:saveFiles', (_, n, rulesPath, templatePath) => {
    if (isShare) throw new Error('The schedule switch is not part of this edition.');
    n = +n; if (n !== 2 && n !== 3) throw new Error('Choose 2 or 3 bots per day.');
    if (!rulesPath && !templatePath) throw new Error('Choose the rulebook (.txt), the card template (.html), or both.');
    const had = schedInfo(n), dir = schedDir(n);
    if ((!rulesPath || !templatePath) && !had) throw new Error('The first time, choose both files: the rulebook (.txt) and the card template (.html).');
    const rulesText = fs.readFileSync(rulesPath || path.join(dir, had.rulesName), 'utf8'), templateHtml = fs.readFileSync(templatePath || path.join(dir, had.templateName), 'utf8');
    const got = perDayOf(rulesText, templateHtml);
    if (got !== n) throw new Error(`${got ? `These files make ${got} cards a day` : 'The app could not read how many cards a day these files make'}, not ${n}. ${n === 3 ? 'The Kill Switch files must be the 3-bots-per-day rulebook and card template (your KILL_SWITCH files).' : 'These must be the 2-bots-per-day rulebook and card template.'}`);
    const info = saveSchedFiles(n, rulesText, templateHtml, rulesPath ? path.basename(rulesPath) : had.rulesName, templatePath ? path.basename(templatePath) : had.templateName);
    return {saved: n, info, status: scheduleStatus()};
  });
  // copy through the desktop clipboard: works on the first click, even if the window just regained focus
  ipcMain.handle('clipboard:write', (_, text) => { clipboard.writeText(String(text ?? '')); return true; });
  ipcMain.handle('juicy:collect', (_, kind) => collectNow(kind));

  // ---- Performance: read your own bots from JuicyChat and match them to cards
  pullMyBotsNow = async (only = null, quiet = false) => {
    const upd = (fn) => quiet ? (store.updateQuiet(fn), null) : store.update(fn);
    const st = quiet ? store.state : store.get(), links = {main: st.settings.loungeMain, ntr: st.settings.loungeNtr};
    const signed = k => isShare ? k === 'main' : !!st.accounts?.[k]?.signedIn?.ok;
    const lo0 = k => !isShare && !!st.accounts?.[k]?.loggedOut && !signed(k) && !links[k];      // logged out earlier and nothing else to read it from: say so instead of skipping it quietly
    const keys = Object.keys(ACCOUNTS).filter(k => (!only || only === k) && (signed(k) || links[k] || lo0(k)));
    if (!keys.length && !isShare) throw new Error(only ? `Sign in to the ${ACCOUNTS[only]} or add its lounge link first.` : 'Sign in to an account or add a lounge link in the Performance tab first.');
    if (isShare && !collector.hasLoginMarker()) throw new Error('Sign in on the JuicyChat Analysis tab first (paste your magic link there). Performance reads your bots from that account.');
    const done = [], failed = [];
    // A lounge link is read through a signed-in account's browser (NTR first, then Main), so the page opens with that login;
    // the tool's own browser is only the fallback when no account is signed in.
    const loungeCol = () => { if (!isShare) for (const k of ['ntr', 'main']) if (st.accounts?.[k]?.signedIn?.ok && accountCollectors[k]) return accountCollectors[k]; return collector; };
    for (const [ki, k] of keys.entries()) {
      const own = signed(k);
      if (lo0(k)) { failed.push(`${ACCOUNTS[k]}: You need to log back in to scrape. Paste this account's magic link in the sign-in box at the top of the Performance tab to log back in.`); continue; }
      send('collector:progress', {stage: 'batch-start', status: 'starting', pull: true, account: ACCOUNTS[k], accountIndex: ki + 1, accountCount: keys.length, sortName: ACCOUNTS[k], message: own ? `Reading the ${ACCOUNTS[k]} (signed in) in the background...` : `Reading the ${ACCOUNTS[k]} lounge in the background...`, current: 0, target: 0});
      try {
        bgStep(`Reading your bots on the ${ACCOUNTS[k]}${keys.length > 1 ? ` (${ki + 1} of ${keys.length})` : ''}...`, {current: ki, account: ACCOUNTS[k], target: keys.length, indeterminate: true});
        const r = own ? await (isShare ? collector : accountCollectors[k]).collectMyBots('', 'own') : await loungeCol().collectMyBots(links[k], 'lounge');
        if (r.cancelled) break;
        if (!r.rows.length) throw new Error(own ? 'the account has no bots listed' : 'the lounge page showed no bots');
        let n = 0, linked = 0, events = 0;
        bgStep(`Saving ${r.rows.length} bots from the ${ACCOUNTS[k]} and updating their scores...`, {current: ki, account: ACCOUNTS[k], target: keys.length, indeterminate: true});
        // read the collected bots in small slices first, so scoring the new bots does not hold the window for long
        let pre = null; try { pre = learningData(store.state); await require('./lib/bonus').warmRows([...(pre.recent || []), ...(pre.trending || [])], tick); } catch (e) { pre = null; }
        await tick();
        upd(s => { const a = ensureAccounts(s)[k], cards = linkableCards(s, flattenWeek(s.week));
          n = mergePull(a, r.rows, own ? (r.profileUrl || a.url) : links[k]); linked = autoLink(a, cardsFor(k, cards)); syncPerformance(s, cards); scoreNewBots(s, a, pre); refreshAccuracy(s, 'pulled');
          const d = r.diag || {};
          if (Array.isArray(d.events) && d.events.length) events = mergeEvents(a, d.events);
          if (d.me) { a.signedIn = {...(a.signedIn || {}), ok: true, userId: d.me.userId, userName: d.me.userName, checkedAt: new Date().toISOString()}; delete a.loggedOut; }
          a.lastPull = {at: new Date().toISOString(), url: own ? `signed in as ${d.me?.userName || 'this account'}` : links[k], bots: n, withNumbers: (a.bots || []).filter(b => b.chats || b.likes || b.favorites).length, modes: [...new Set((a.bots || []).map(b => b.statMode || 'none'))], cardsOnPage: d.cardsOnPage ?? n, jsonResponses: d.jsonResponses ?? null, sample: d.sample || [], warnings: d.warnings || [], ratingSource: d.ratingSource || '', ratingRule: d.ratingRule || null, loungeUrl: d.loungeUrl || '', ratingsRead: d.ratingsRead ?? null, ratingsTotal: d.ratingsTotal ?? null}; });
        done.push(`${ACCOUNTS[k]}: ${n} bots${linked ? `, ${linked} matched to cards` : ''}${events ? `, ${events} new likes/stars/comments` : ''}`);
      } catch (e) { const m = String(e.message || e), out = /isn.t signed in|not signed in|signed out|logged out|log back in|magic link/i.test(m);
        // a logged-out account is said plainly and remembered, so the Performance tab asks for the magic link instead of still showing it as signed in
        if (out && !isShare) { try { upd(s => { const a = ensureAccounts(s)[k]; a.signedIn = null; a.loggedOut = {at: new Date().toISOString()}; }); } catch {} }
        if (out) askLogin(isShare ? 'tool' : k, m);
        failed.push(isShare ? (out ? 'You need to log back in to scrape. Paste your magic link on the JuicyChat Analysis tab to log back in, then pull again.' : m) : out ? `${ACCOUNTS[k]}: You need to log back in to scrape. Paste this account's magic link in the sign-in box at the top of the Performance tab to log back in.` : `${ACCOUNTS[k]}: ${m}`); }
    }
    send('collector:progress', {stage: failed.length ? 'partial' : 'batch-done', status: failed.length ? 'partial' : 'done', message: [...done, ...failed].join(' · ')});
    if (store.state.engineAnalysis) {
      bgStep('Refreshing the success-engine analysis...', {indeterminate: true});
      try { const a = await runAnalysisAsync(store.state); upd(s => { if (s.engineAnalysis) s.engineAnalysis = a; }); } catch (e) { console.error('analysis refresh:', e.message); }
    }
    if (!done.length && failed.length) throw new Error(failed.join(' · '));
    return quiet ? null : store.get();
  };
  // notifications (likes, stars, comments, follows) are archived per account
  const mergeEvents = (a, evs) => { a.events = a.events || []; const seen = new Set(a.events.map(e => e.id)); let added = 0;
    for (const e of evs) { if (!e.id || seen.has(e.id)) continue; seen.add(e.id); a.events.push(e); added++; }
    a.events.sort((x, y) => (Number(y.at) || Date.parse(y.at) || 0) - (Number(x.at) || Date.parse(x.at) || 0)); if (a.events.length > 8000) a.events.length = 8000; return added; };

  // ---- per-account sign-in (magic link)
  ipcMain.handle('account:openLogin', async (_, account, link) => {
    if (isShare) throw new Error('Sign in on the JuicyChat Analysis tab.');
    if (!ACCOUNTS[account]) throw new Error('Unknown account.');
    const l = String(link || '').trim(); if (!/^https:\/\//i.test(l)) throw new Error('Paste the full https:// magic link for this account.');
    const auth = await accountCollectors[account].signIn(l);
    return store.update(s => { const a = ensureAccounts(s)[account]; a.signedIn = auth?.signedIn ? {ok: true, at: new Date().toISOString()} : null; if (auth?.signedIn) delete a.loggedOut; });
  });
  ipcMain.handle('account:finishLogin', async (_, account) => {
    const auth = await accountCollectors[account].finishLogin();
    return store.update(s => { const a = ensureAccounts(s)[account]; a.signedIn = auth?.signedIn ? {ok: true, at: new Date().toISOString()} : null; if (auth?.signedIn) delete a.loggedOut; });
  });
  ipcMain.handle('account:signOut', async (_, account) => {
    try { await accountCollectors[account].resetLogin(); } catch (e) { console.error(e); }
    return store.update(s => { ensureAccounts(s)[account].signedIn = null; });
  });
  ipcMain.handle('performance:pull', (_, account) => pullMyBotsNow(account && ACCOUNTS[account] ? account : null));
  ipcMain.handle('performance:link', (_, account, scenarioId, botId) => store.update(s => {
    const a = ensureAccounts(s)[account]; if (!a) return;
    if (botId === '__none__') a.links[scenarioId] = null;               // "not published": stop auto-matching this card
    else if (botId) { for (const [k, v] of Object.entries(a.links)) if (v === botId) delete a.links[k]; a.links[scenarioId] = botId; }
    else delete a.links[scenarioId];
    syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
    refreshAccuracy(s, 'linked');
  }));
  ipcMain.handle('performance:setLounge', (_, account, url) => store.update(s => {
    const k = account === 'ntr' ? 'loungeNtr' : 'loungeMain';
    s.settings = cleanSettings({[k]: url});
    if (url && !s.settings[k]) throw new Error('Paste the full https://…juicychat.ai lounge link.');
    ensureAccounts(s)[account === 'ntr' ? 'ntr' : 'main'].url = s.settings[k];
  }));

  // ---- Regenerate Tab: rebuild every card in one tab, leaving Built cards alone
  // the creator picks one of the rulebook's Preventable NTR modes for one card
  ipcMain.handle('lane:setMode', async (_, id, modeNo) => {
    const st = store.get(), found = WL.findCard(st.week, id), card = found && found.card;
    if (!card || !card.laneTab) throw new Error('That card is no longer in the week.');
    const fresh = require('./lib/preventableGen').setCardMode(card, modeNo, blueprints.current());
    store.update(s => {
      for (const name of WL.weekListNames(s.week)) { const i = (s.week[name] || []).findIndex(x => x.id === id); if (i >= 0) s.week[name][i] = fresh; }
      for (const a of Object.values(ensureAccounts(s))) if (a.links[id]) delete a.links[id];
      if (s.predictionLog) delete s.predictionLog[id];
      scoreWeek(s);
    });
    return store.get();
  });
  // ---- Clear & Reset Tab: every card in the tab that is not Built goes back to an empty slot (its day, slot, series and event stay).
  // The cleared cards are archived with their scores, never deleted. Built cards and Bonus ideas you placed on a day are not touched.
  const ensureNtrShape = tab => { if (tab === 'NTR' && isCombinedNtr()) store.update(s => { if (normalizeNtrRotation(s, blueprints.current())) scoreWeek(s); }); };
  ipcMain.handle('week:reset', () => {
    let result;
    const state = store.update(s => { result = resetWeek(s); });
    return {state, ...result};
  });
  ipcMain.handle('week:clearTab', async (_, tab, includeBuilt) => {
    ensureNtrShape(tab);
    if (tab === 'Bonus') throw new Error('Bonus ideas are yours, so they are not cleared. Remove one with its Remove button.');
    const st = store.get(), isLane = WL.isLaneName(tab);
    if (isLane && !laneTabs(blueprints && blueprints.current(), isShare).some(t => WL.laneName(t.key) === tab)) throw new Error('That tab is no longer part of your Weekly Blueprint.');
    if (tab === 'NTR' && !hasNtrTab()) throw new Error('Your Weekly Blueprint has no NTR tab.');
    const list = tab === 'NTR' ? (isCombinedNtr() ? combinedNtrCards(st.week) : (st.week.ntr || [])) : isLane ? (st.week[tab] || []) : (st.week.scenarios || []).filter(x => x.day === tab);
    const built = c => !includeBuilt && String(st.week.statuses?.[c.id] || '') === 'Built';   // includeBuilt: the creator confirmed clearing Built cards too (they are archived with their scores)
    const todo = list.filter(c => !built(c) && !isAdded(c));
    if (!todo.length) throw new Error(list.length ? 'Every card in this tab is marked Built (or is a Bonus idea you placed here), so nothing was cleared.' : 'This tab has no cards yet.');
    const KEEP = ['id', 'day', 'slot', 'theme', 'series', 'seriesLabel', 'seriesFocus', 'lane', 'laneTab', 'order', 'eventKey', 'eventCard', 'eventId', 'noEvent', 'modeChosen', 'modeNo'];
    const blank = c => { const b = {}; for (const k of KEEP) if (c[k] !== undefined) b[k] = JSON.parse(JSON.stringify(c[k]));
      Object.assign(b, {sceneName: 'Untitled', primaryCharacter: '', cast: [], tags: [], fields: {}});
      const d = cardDay(c); if (c.laneTab || (c.fields || {})['Day Assignment']) { if (d) b.fields['Day Assignment'] = d; }
      if (!c.laneTab) b.blankSlot = true;
      return b; };
    const ids = new Set(todo.map(c => c.id));
    store.update(s => {
      const old = WL.weekCards(s.week).filter(c => ids.has(c.id) && !isOpenSlot(c));
      if (old.length) { for (const c of old) freeze(s, c, 'archived'); archiveWeek(s, old, s.week.weekStart || ''); }
      for (const name of WL.weekListNames(s.week)) s.week[name] = (s.week[name] || []).map(c => ids.has(c.id) ? blank(c) : c);
      s.week.statuses = s.week.statuses || {}; for (const id of ids) s.week.statuses[id] = 'Idea';
      for (const a of Object.values(ensureAccounts(s))) for (const id of ids) if (a.links[id]) delete a.links[id];
      if (s.predictionLog) for (const id of ids) delete s.predictionLog[id];
      syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
      scoreWeek(s);
    });
    return {state: store.get(), cleared: todo.length, kept: list.length - todo.length};
  });
  ipcMain.handle('week:regenerateTab', async (_, tab) => {
    if (tab !== 'NTR' || !isCombinedNtr()) return regenerateOneTab(tab);
    ensureNtrShape(tab);
    // the combined NTR tab: the NTR cards and every card type the app can write itself; a type it has no local writer for is left as it is
    let regenerated = 0, kept = 0; const skipped = [];
    for (const name of ['NTR', ...rotationLanes().map(t => WL.laneName(t.key))]) {
      const lt = WL.isLaneName(name) ? rotationLanes().find(t => WL.laneName(t.key) === name) : null;
      if (lt && !hasLocalWriter(lt)) { if ((store.get().week[name] || []).length) skipped.push(lt.label); continue; }
      try { const r = await regenerateOneTab(name); regenerated += r.regenerated; kept += r.kept; }
      catch (e) { if (!/marked Built|has no cards yet/.test(e.message)) throw e; }
    }
    if (!regenerated) throw new Error(`Nothing was regenerated: every card the app can rebuild in this tab is marked Built${skipped.length ? `, and ${skipped.join(' and ')} cards are written with "Write with AI" or uploaded` : ''}.`);
    if (skipped.length) send('week:progress', {message: `${skipped.join(' and ')} cards were left as they are: use Write with AI or Upload my cards for them.`});
    return {state: store.get(), regenerated, kept, skipped};
  });
  const regenerateOneTab = async tab => {
    const st = store.get(), all = flattenWeek(st.week);
    if (WL.isLaneName(tab)) {
      const lt = laneTabs(blueprints && blueprints.current(), isShare).find(t => WL.laneName(t.key) === tab), list = st.week[tab] || [];
      if (!lt || !hasLocalWriter(lt)) throw new Error(`The ${(list[0] || {}).slot || 'this'} tab is written with "Write with AI" or imported from ChatGPT; the app has no local generator for it.`);
      const todo = list.filter(x => String(st.week.statuses?.[x.id] || '') !== 'Built');
      if (!todo.length) throw new Error(list.length ? 'Every card in this tab is marked Built, so nothing was regenerated.' : 'This tab has no cards yet.');
      send('week:progress', {message: `Regenerating ${lt.label}...`});
      const blank = todo.map(x => ({id: x.id, laneTab: x.laneTab, day: x.day, slot: x.slot, theme: x.theme, series: x.series, lane: x.lane, order: x.order, sceneName: 'Untitled', primaryCharacter: '', cast: [], tags: [], modeChosen: x.modeChosen, modeNo: x.modeNo, fields: {'Day Assignment': (x.fields || {})['Day Assignment']}}));
      const fresh = writeLaneLocally(lt, blank, blueprints.current());
      store.update(s => {
        for (const f of fresh) { const i = (s.week[tab] || []).findIndex(x => x.id === f.id); if (i >= 0) { const o = s.week[tab][i]; if (o.noEvent !== undefined) f.noEvent = o.noEvent; if (o.eventId) f.eventId = o.eventId; s.week[tab][i] = f; } }
        for (const a of Object.values(ensureAccounts(s))) for (const f of fresh) if (a.links[f.id]) delete a.links[f.id];
        if (s.predictionLog) for (const f of fresh) delete s.predictionLog[f.id];
        syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
        scoreWeek(s);
      });
      send('week:progress', {message: `${fresh.length} card${fresh.length > 1 ? 's' : ''} regenerated${list.length > todo.length ? `, ${list.length - todo.length} Built card${list.length - todo.length > 1 ? 's' : ''} kept` : ''}.`});
      return {state: store.get(), regenerated: fresh.length, kept: list.length - todo.length};
    }
    const inTab = tab === 'NTR' ? (st.week.ntr || []) : tab === 'Bonus' ? (st.week.bonus || []) : (st.week.scenarios || []).filter(x => x.day === tab);
    const todo = inTab.filter(x => String(st.week.statuses?.[x.id] || '') !== 'Built');
    if (!todo.length) throw new Error(inTab.length ? 'Every card in this tab is marked Built, so nothing was regenerated.' : 'This tab has no cards yet.');
    const fresh = [], peers = all.filter(x => !todo.includes(x));
    for (const [i, cur] of todo.entries()) {
      send('week:progress', {message: `Regenerating ${tab} ${i + 1} of ${todo.length}...`});
      const f = cur.bonusIdea
        ? buildBonusFromIdea({...cur.bonusIdea, __datasets: learningData(st)}, {engineAnalysis: st.engineAnalysis, event: (e => e && e.applyMode !== 'new-only' ? e : null)(Events.forCard(st, cur)), peers: [...peers, ...fresh]})
        : regenerateScenarioLocal({engineAnalysis: st.engineAnalysis, activeEvent: Events.forCard(st, cur) || st.event, scenario: cur, weekPeers: [...peers, ...fresh, ...todo.filter(x => x !== cur).map(x => ({incidentId: x.incidentId, hookRef: x.hookRef, soft: true})), {incidentId: cur.incidentId, hookRef: cur.hookRef, soft: true}]});
      f.id = cur.id; f.day = cur.day; f.slot = cur.slot; if (isAdded(cur)) f.addedBonus = true;
      if (cur.noEvent !== undefined && f.series === cur.series) f.noEvent = cur.noEvent; if (cur.eventId) f.eventId = cur.eventId;        // the Event card switch and the event it was entered in stay on a regenerated card
      keepPolicy(cur, f);
      fresh.push(f);
    }
    store.update(s => {
      for (const f of fresh) for (const listName of WL.weekListNames(s.week)) { const idx = (s.week[listName] || []).findIndex(x => x.id === f.id); if (idx >= 0) s.week[listName][idx] = f; }
      for (const a of Object.values(ensureAccounts(s))) for (const f of fresh) if (a.links[f.id]) delete a.links[f.id];   // a rebuilt card is a new card
      if (s.predictionLog) for (const f of fresh) delete s.predictionLog[f.id];
      syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
      scoreWeek(s);
    });
    send('week:progress', {message: `${fresh.length} card${fresh.length > 1 ? 's' : ''} regenerated${inTab.length > todo.length ? `, ${inTab.length - todo.length} Built card${inTab.length - todo.length > 1 ? 's' : ''} kept` : ''}.`});
    return {state: store.get(), regenerated: fresh.length, kept: inTab.length - todo.length};
  };

  // ---- Daily pulls: separate times, computer timezone or fixed EST (UTC-05:00)
  const RETRY_MS = 45 * 60000;
  let autoBusy = false;
  const parseHm = v => { const m = String(v || '20:00').match(/^(\d{1,2}):(\d{2})$/); const h = m ? Math.min(23, Math.max(0, +m[1])) : 20, min = m ? Math.min(59, Math.max(0, +m[2])) : 0; return {h, min}; };
  const pullTz = () => store.state.settings.pullTimeZone === 'computer' ? (Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC') : 'Etc/GMT+5';
  const pullClock = (d = new Date()) => {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-US', {timeZone: pullTz(), year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23'}).formatToParts(d).map(x => [x.type, x.value]));
    return {day: `${parts.year}-${parts.month}-${parts.day}`, hour: Number(parts.hour), minute: Number(parts.minute)};
  };
  const reached = (now, t) => now.hour > t.h || (now.hour === t.h && now.minute >= t.min);
  const timeFor = (st, kind) => parseHm(st.settings[kind === 'collect' ? 'collectTime' : kind === 'am' ? 'morningTime' : 'perfTime'] || (kind === 'am' ? '08:00' : '20:00'));
  const logRun = (s, kind, ok, message) => { s.schedule = s.schedule || {log: []}; s.schedule.log = [{at: new Date().toISOString(), kind, ok, message}, ...(s.schedule.log || [])].slice(0, 25); };
  const nextRun = () => {
    const now = pullClock(), st = store.state, sch = st.schedule || {};
    const doneToday = (st.settings.autoCollect === false || sch.collectDay === now.day) && (st.settings.autoPerformance === false || sch.perfDay === now.day);
    return {timeZone: st.settings.pullTimeZone === 'computer' ? 'computer' : 'est', zone: pullTz(), today: now.day, doneToday, collectTime: st.settings.collectTime || '20:00', perfTime: st.settings.perfTime || '20:00', morning: st.settings.autoMorning === true, morningTime: st.settings.morningTime || '08:00'};
  };
  async function autoTick() {
    if (autoBusy || !store) return;
    const st = store.state, sch = st.schedule || {}, now = pullClock();
    const yesterday = pullClock(new Date(Date.now() - 24 * 3600000)).day;
    const owedFor = kind => reached(now, timeFor(st, kind)) ? now.day : yesterday;
    const firstEver = !sch.collectDay && !sch.perfDay;
    const holdFirst = firstEver && !reached(now, timeFor(st, 'collect')) && !reached(now, timeFor(st, 'perf'));
    if (collector.loginProc || collector.scanProc || Object.values(accountCollectors).some(c => c.loginProc || c.scanProc)) return;
    const retryOk = kind => Date.now() - Date.parse(sch.lastAttempt?.[kind] || 0) > RETRY_MS;
    // the optional morning pull: only when it is switched on, and only from its time onward, once a day (a missed morning is covered by the evening pull)
    const dueAm = st.settings.autoMorning === true && reached(now, timeFor(st, 'am')) && String(sch.amDay || '') < now.day && retryOk('am');
    const due = kind => kind === 'am' ? dueAm
      : !holdFirst && st.settings[kind === 'collect' ? 'autoCollect' : 'autoPerformance'] !== false && String(sch[kind === 'collect' ? 'collectDay' : 'perfDay'] || '') < owedFor(kind) && retryOk(kind);
    if (!due('collect') && !due('perf') && !due('am')) return;
    autoBusy = true;
    try {
      for (const kind of ['collect', 'perf', 'am']) {
        if (!due(kind)) continue;
        const owedDay = kind === 'am' ? now.day : owedFor(kind);
        store.updateQuiet(s => { s.schedule = s.schedule || {}; s.schedule.lastAttempt = {...(s.schedule.lastAttempt || {}), [kind]: new Date().toISOString()}; });
        const title = kind === 'collect' ? 'Automatic collection: Recent + Trending' : kind === 'am' ? 'Automatic morning pull: your bot stats' : 'Automatic pull: your bot stats';
        bgRun = {kind, title};
        send('auto:run', {kind, stage: 'start', title});
        try {
          if (kind === 'collect') await collectNow('both', true); else await pullMyBotsNow(null, true);
          store.updateQuiet(s => { s.schedule[kind === 'collect' ? 'collectDay' : kind === 'am' ? 'amDay' : 'perfDay'] = owedDay; logRun(s, kind, true, kind === 'collect' ? `Collected Recent + Trending (${(s.datasets.recent || []).length} + ${(s.datasets.trending || []).length}) and updated the analysis.` : `Pulled ${Object.values(s.accounts || {}).map(a => `${a.label}: ${(a.bots || []).length} bots`).join(', ')}.`); });
          bgStep('Finishing up...', {indeterminate: true});
          await tick();
          send('auto:run', {kind, stage: 'done', title, state: store.get()});
        } catch (e) {
          store.updateQuiet(s => logRun(s, kind, false, e.message || String(e)));
          send('auto:run', {kind, stage: 'error', title, message: e.message || String(e), state: store.get()});
        }
        bgRun = null;
        await tick();
      }
    } finally { autoBusy = false; bgRun = null; }
  }
  // backups never run while the app is scraping JuicyChat: a backup that comes due during a collection, a bot-stats pull or the
  // automatic run waits until every scrape has finished (checked every 30 seconds), then runs. "Back up now" in Settings still runs at once.
  let scrapes = 0;
  const scraping = () => scrapes > 0 || autoBusy;
  const whenIdle = fn => { const go = () => { if (scraping()) { setTimeout(go, 30000); return; } try { Promise.resolve(fn()).catch(e => console.error('backup:', e.message)); } catch (e) { console.error('backup:', e.message); } }; go(); };
  {
    const rawCollect = collectNow, rawPull = pullMyBotsNow;
    collectNow = async (...a) => { scrapes++; try { return await rawCollect(...a); } finally { scrapes--; } };
    pullMyBotsNow = async (...a) => { scrapes++; try { return await rawPull(...a); } finally { scrapes--; } };
  }
  // backup after every scrape: each time a collection (Recent + Trending) or a bot-stats pull finishes, automatic or by hand, a backup follows once nothing is being scraped
  if (!SANDBOX && backup) {
    let afterScrapeTimer = null;
    const afterScrape = () => { clearTimeout(afterScrapeTimer); afterScrapeTimer = setTimeout(() => whenIdle(() => backup.runAny('scrape', {force: true})), 8000); };
    const rawCollect = collectNow, rawPull = pullMyBotsNow;
    collectNow = async (...a) => { const r = await rawCollect(...a); afterScrape(); return r; };
    pullMyBotsNow = async (...a) => { const r = await rawPull(...a); afterScrape(); return r; };
  }
  if (!SANDBOX && backup) { let waiting = false; const timed = (why, age) => { try { if (waiting || !backup.due(age)) return; waiting = true; whenIdle(() => { waiting = false; if (backup.due(age)) return backup.runAny(why); }); } catch { waiting = false; } };
    setTimeout(() => timed('launch', 20 * 3600e3), 90000); setInterval(() => timed('timer', 3 * 3600e3), 15 * 60000); }
  if (!SANDBOX) setTimeout(autoTick, 20000);            // catch up shortly after launch if a run was missed
  if (!SANDBOX) setInterval(autoTick, 60000);
  // Windows must start Electron WITH this app's folder; without it, nothing opens at login
  // Windows splits an unquoted path at its first space ("F:\\Downloads\\Juicy Blueprint Studio" became "F:\\Downloads\\Juicy"),
  // and Electron writes the startup entry without quotes, so a path with spaces is quoted here
  const winQuote = a => process.platform === 'win32' && /\s/.test(a) && !/^".*"$/.test(a) ? `"${a}"` : a;
  const loginArgs = () => app.isPackaged ? [] : [winQuote(app.getAppPath())];
  // Start with Windows: written as a normal Windows "Run" entry with the exact, correctly quoted command, rather than
  // through Electron (whose own quoting broke on folders with spaces: "Cannot find module 'F:\Downloads\Juicy'").
  const RUN_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run', RUN_NAME = 'Juicy Blueprint Studio';
  const runCommand = () => `"${process.execPath}"${app.isPackaged ? '' : ` "${app.getAppPath()}"`}`;
  const reg = args => new Promise(res => require('child_process').execFile('reg', args, {windowsHide: true}, (err, out) => res({ok: !err, out: String(out || '')})));
  const clearElectronEntry = () => { try { app.setLoginItemSettings({openAtLogin: false, path: process.execPath, args: loginArgs()}); app.setLoginItemSettings({openAtLogin: false, path: process.execPath, args: [...loginArgs(), '--background']}); app.setLoginItemSettings({openAtLogin: false, path: process.execPath, args: [app.getAppPath(), '--background']}); } catch {} };
  applyLoginItemNow = async on => {
    if (SANDBOX) return;                      // the sandbox never starts with Windows
    if (process.platform !== 'win32') { try { app.setLoginItemSettings({openAtLogin: !!on, path: process.execPath, args: loginArgs()}); } catch (e) { console.error(e); } return; }
    clearElectronEntry();                                           // the old entry with the cut-off path
    const r = on ? await reg(['add', RUN_KEY, '/v', RUN_NAME, '/t', 'REG_SZ', '/d', runCommand(), '/f']) : await reg(['delete', RUN_KEY, '/v', RUN_NAME, '/f']);
    if (on && !r.ok) console.error('Start with Windows: could not write the startup entry.');
  };
  const applyLoginItem = () => applyLoginItemNow(store.state.settings.openAtLogin);
  ipcMain.handle('app:loginItem', async () => {
    if (process.platform === 'win32') { const q = await reg(['query', RUN_KEY, '/v', RUN_NAME]); return {on: q.ok && q.out.includes(app.getAppPath()), supported: true, command: q.ok ? (q.out.match(/REG_SZ\s+(.+)/) || [, ''])[1].trim() : ''}; }
    try { const r = app.getLoginItemSettings({path: process.execPath, args: loginArgs()}); return {on: !!r.openAtLogin, supported: process.platform === 'darwin'}; } catch { return {on: false, supported: false}; } });
  if (!SANDBOX) applyLoginItem();
  ipcMain.handle('juicy:cancelCollect', async () => { for (const c of [collector, ...Object.values(accountCollectors)]) { try { c.cancelCollection(); } catch {} } return true; });

  ipcMain.handle('analysis:run', async () => {
    const state = store.get();
    const sampleSize = (state.datasets.recent?.length||0) + (state.datasets.trending?.length||0);
    if (sampleSize < 5) throw new Error('Collect at least 5 Recent or Trending bots first. A full 100 + 100 sample gives the strongest summary, but either list can be analyzed on its own.');
    send('analysis:progress', {message:`Analyzing ${sampleSize} collected bot records locally...`});
    const analysis = await runAnalysisAsync(state);
    store.update(s => { s.engineAnalysis = analysis; s.historyStats = history.stats(); const all = flattenWeek(s.week), L = withLearning(s); for (const b of s.week.bonus || []) applyAssessment(b, {...L, engineAnalysis: analysis}, all); });
    send('analysis:progress', {message:'Local success-engine analysis complete.'});
    return store.get();
  });

  // the Events tab keeps a list: add one, read its announcement, name it, switch it on or off, remove it
  const evFind = (s, id) => (id && Events.byId(s, id)) || Events.defaultOf(s.events || []);
  ipcMain.handle('event:add', (_, label) => store.update(s => {
    if ((s.events || []).length >= Events.MAX_EVENTS) throw new Error(`Up to ${Events.MAX_EVENTS} events can be kept. Remove one first.`);
    s.events = s.events || []; s.events.push(Events.newEvent(Events.freshId(s.events), String(label || '').slice(0, 60)));
  }));
  ipcMain.handle('event:remove', (_, id) => store.update(s => {
    if (!Events.byId(s, id)) return;
    const gone = Events.byId(s, id), wasDefault = (Events.defaultOf(s.events) || {}).id === id;
    s.events = s.events.filter(e => e.id !== id);
    const EF = require('./lib/eventForget');
    for (const c of flattenWeek(s.week)) if (c.eventId === id || (wasDefault && !c.eventId) || c.eventKey === id) { EF.clearCard(c, gone); Events.annotate(c, s); }       // everything the event put on its cards goes with it; they start clean for the next event
    try { EF.forgetJobs(path.join(app.getPath('userData'), 'ai-jobs'), gone); } catch {}
    scoreWeek(s);
  }));
  ipcMain.handle('event:rename', (_, id, label) => store.update(s => { const e = Events.byId(s, id); if (e) e.label = String(label || '').slice(0, 60); for (const c of flattenWeek(s.week)) Events.annotate(c, s); }));   // a name changes no score, so the cards only take the new label
  ipcMain.handle('event:parse', (_, raw, id) => {
    const parsed = parseEventAnnouncement(raw);
    return store.update(s => {
      s.events = s.events || [];
      let e = id && Events.byId(s, id); if (!e) { e = Events.newEvent(Events.freshId(s.events)); s.events.push(e); }
      e.raw = raw; e.parsed = parsed; e.rulebook = EventRules.fromParsed(parsed); e.active = true; canonEventTags(s); require('./lib/eventMenu').clean(e);       // a filled-in event is on (it can still be switched off)
      scoreWeek(s);
    });
  });
  ipcMain.handle('event:setActive', (_, active, applyMode = 'new-only', id) => store.update(s => { const e = evFind(s, id); if (!e) return; e.active = !!active; e.applyMode = applyMode; scoreWeek(s); }));

  // eventPlan (optional): which event each slot of the week is entered in, {slotKey: eventId | 'none' | ''} (lib/events.js)
  // daysOnly: rebuild Monday to Sunday from the schedule in use; the NTR tab, the Preventable NTR and Post-NTR tabs, other card tabs and Bonus are not touched
  const generateWeekNow = async (weekStart, eventPlan, {daysOnly = false} = {}) => {
    needPlan();
    const state = store.get();
    if (!state.engineAnalysis?.engines?.length) throw new Error('Run Collect Both and Analyze Success Engines first. The local generator builds the week from the measured engine library.');
    send('week:progress',{message:'Building the week locally from your rule library and observed success engines...'});
    let generated, validation;
    for (let attempt=0; attempt<5; attempt++) {
      generated = generateWeekLocal({engineAnalysis:state.engineAnalysis,activeEvent:state.event,weekStart,performance:state.performance,plan:weekPlanNow()});
      validation = validateWeekLocal(generated,state.event,weekPlanNow());
      if (validation.ok) break;
    }
    if (!validation?.ok) throw new Error(`Local generator could not satisfy the weekly hard locks: ${validation.errors.join(' ')}`);
    const core = ensureIds((generated.days || []).flatMap(d => (d.scenarios || []).map(x => ({...x,day:x.day || d.day,theme:x.theme || d.theme}))));
    const ntrDays = ntrDaysNow();
    const ntr = hasNtrTab() ? ensureIds((generated.ntr || []).filter(x => !ntrDays || ntrDays.includes(x.day)).map(x => ({...x,slot:x.slot || 'NTR'}))) : [];
    // Bonus ideas are yours, not the week's: they carry over when a new week is generated.
    // an exact copy: scores, estimates and every field are put back untouched after the new week is scored
    const keptBonus = JSON.parse(JSON.stringify(state.week.bonus || [])), keptStatus = state.week.statuses || {};
    const keptAdded = JSON.parse(JSON.stringify([...(state.week.scenarios || []), ...(state.week.ntr || [])].filter(isAdded)));
    const laneLists = Object.fromEntries(Object.entries(buildLaneLists(blueprints && blueprints.current(), isShare)).map(([k, list]) => [k, ensureIds(writeLaneLocally(laneTabs(blueprints && blueprints.current(), isShare).find(t => WL.laneName(t.key) === k), list, blueprints.current()))]));        // the tabs your template defines beyond the days, NTR and Bonus
    if (daysOnly) {
      store.update(s => {
        const oldDays = (s.week.scenarios || []).filter(c => !isAdded(c));
        if (oldDays.length) { for (const c of oldDays) freeze(s, c, 'archived'); archiveWeek(s, oldDays, s.week.weekStart || ''); }
        const addedDays = JSON.parse(JSON.stringify((s.week.scenarios || []).filter(isAdded)));
        for (const c of oldDays) if (s.week.statuses) delete s.week.statuses[c.id];
        s.week.scenarios = core; s.week.statuses = s.week.statuses || {};
        reattachBonus(s.week, addedDays);
        for (const x of core) s.week.statuses[x.id] = 'Idea';
        if (!s.week.weekStart) s.week.weekStart = generated.weekStart || weekStart;
        s.week.generatedAt = new Date().toISOString();
        scoreWeek(s);
      });
      send('week:progress', {message: 'Day tabs rebuilt from the schedule in use. The NTR tabs and Bonus were not touched.'});
      return store.get();
    }
    store.update(s => { const old = weekOwnCards(s.week).filter(c => !isAdded(c)); if (old.length) { for (const c of old) freeze(s, c, 'archived'); archiveWeek(s, old, s.week.weekStart || ''); } });
    const bonus = [...keptBonus, ...ensureIds(generated.bonus || [])];
    store.update(s => {
      s.week = {weekStart:generated.weekStart || weekStart,generatedAt:new Date().toISOString(),generationMode:'Local procedural generation',validation,scenarios:core,ntr,bonus,...laneLists,statuses:{}};
      reattachBonus(s.week, JSON.parse(JSON.stringify(keptAdded)));   // Bonus ideas you placed on a day stay, after the new cards
      for (const x of [...s.week.scenarios,...s.week.ntr,...bonus,...Object.values(laneLists).flat()]) s.week.statuses[x.id] = keptStatus[x.id] || 'Idea';
      if (eventPlan) for (const c of Events.applyPlan(s, eventPlan)) { try { const ev = Events.forCard(s, c); if (ev) { const r = adaptToEvent(c, ev, flattenWeek(s.week)); for (const k of Object.keys(c)) delete c[k]; Object.assign(c, r.card); } } catch (e) { console.error('event plan:', e.message); } }       // a card given another event gets that event's tags
      scoreWeek(s);
      s.week.bonus = JSON.parse(JSON.stringify(keptBonus));        // Generate / Regenerate Whole Week never changes Bonus cards
    });
    send('week:progress',{message:'Weekly batch generated locally. No AI service was called.'});
    return store.get();
  };
  ipcMain.handle('week:generate', (_, weekStart, eventPlan) => generateWeekNow(weekStart, eventPlan));
  ipcMain.handle('week:generateDays', (_, weekStart) => generateWeekNow(weekStart || store.get().week.weekStart, undefined, {daysOnly: true}));
  // every series your rulebook and card template define (the Events tab's "never in the event" list), not only the ones with a card this week
  ipcMain.handle('series:list', () => { try { return SeriesLib.names(blueprints && blueprints.current(), {share: isShare}); } catch { return SeriesLib.names(null, {share: isShare}); } });
  // suggestions without the AI: read from the card by the app itself (lib/suggestLocal.js)
  ipcMain.handle('card:suggestLocal', (_, id, seed) => { const f = findAny(store.get(), id); if (!f) throw new Error('That card no longer exists.'); return {suggestions: SuggestLocal.suggest(JSON.parse(JSON.stringify(f.card)), {seed: Math.max(0, Math.floor(+seed || 0))}), local: true}; });
  ipcMain.handle('week:eventPlan', () => Events.planOf(store.get()));       // the event each slot of the current week has now: the starting choice in the Write the week step

  // Adapt to event: small tweaks only (event tag, opportunity tags, event fields). Never rebuilds the card.
  const adaptCards = ids => {
    const st = store.get(); if (!Events.anyActive(st)) throw new Error('No active event. Set one up on the Events tab first.');
    const report = [], skippedOff = [];
    const out = store.update(s => {
      for (const list of WL.weekListNames(s.week)) (s.week[list] || []).forEach((c, i) => {
        if (!ids.includes(c.id)) return;
        const evFor = Events.forCard(s, c);
        if (!evFor) { skippedOff.push(c.sceneName); return; }       // not an event card (or its event is off): never adapted
        const r = adaptToEvent(c, evFor, flattenWeek(s.week)); s.week[list][i] = r.card;
        if (r.card.bonusIdea) r.card.bonusIdea = {...r.card.bonusIdea, tags: r.card.tags};
        report.push({id: c.id, sceneName: c.sceneName, changes: r.changes, missingFit: r.missingFit});
      });
      scoreWeek(s);
    });
    return {state: out, report, skippedOff};
  };
  ipcMain.handle('week:adaptEvent', (_, id) => adaptCards([id]));
  ipcMain.handle('week:adaptAllEvent', () => {
    const st = store.get(), all = flattenWeek(st.week), built = id => String(st.week.statuses?.[id] || '') === 'Built';
    const open = all.filter(c => !built(c.id)), eventOnly = open.filter(c => Events.forCard(st, c)), ids = eventOnly.map(c => c.id);
    if (!open.length) throw new Error('Every card this week is marked Built, so nothing was adapted.');
    if (!ids.length) throw new Error('None of the open cards is an event card, so nothing was adapted.');
    const r = adaptCards(ids); return {...r, skippedBuilt: all.length - open.length, skippedNotEvent: open.length - ids.length};
  });
  ipcMain.handle('week:regenerateScenario', async (_, scenarioId, mode='regenerate') => {
    if (mode === 'adapt-event') return adaptCards([scenarioId]).state;     // small tweaks, never a new card
    {                                                                      // a card in a tab the template defines (Preventable NTR): rewritten as that tab's own kind of card, keeping its Mode choice
      const f0 = WL.findCard(store.get().week, scenarioId), c0 = f0 && f0.card;
      if (c0 && c0.laneTab) {
        const lt = laneTabs(blueprints && blueprints.current(), isShare).find(t => t.key === c0.laneTab);
        if (!lt || !hasLocalWriter(lt)) throw new Error(`The ${c0.slot || 'this'} tab is written with "Write with AI" or imported from ChatGPT; the app has no local generator for it.`);
        const others = (store.get().week[WL.laneName(c0.laneTab)] || []).filter(x => x.id !== c0.id).map(x => x.preventableSeed || x.postNtrSeed).filter(Boolean);
        const blank = {id: c0.id, laneTab: c0.laneTab, day: c0.day, slot: c0.slot, theme: c0.theme, series: c0.series, lane: c0.lane, order: c0.order, sceneName: 'Untitled', primaryCharacter: '', cast: [], tags: [], modeChosen: c0.modeChosen, modeNo: c0.modeNo, fields: {'Day Assignment': (c0.fields || {})['Day Assignment']}};
        const fresh0 = writeLaneLocally(lt, [blank], blueprints.current(), others)[0];
        if (c0.noEvent !== undefined) fresh0.noEvent = c0.noEvent;
        store.update(s => {
          const i = (s.week[WL.laneName(c0.laneTab)] || []).findIndex(x => x.id === c0.id); if (i >= 0) s.week[WL.laneName(c0.laneTab)][i] = fresh0;
          if (s.predictionLog) delete s.predictionLog[c0.id];
          for (const a of Object.values(ensureAccounts(s))) if (a.links[c0.id]) delete a.links[c0.id];
          syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
          scoreWeek(s);
        });
        return store.get();
      }
    }
    const state = store.get(), all = flattenWeek(state.week), current = all.find(x => x.id === scenarioId);
    if (!current) throw new Error('Scenario not found.');
    send('week:progress',{message:`${mode==='adapt-event'?'Adapting':'Regenerating'} ${current.sceneName || current.id} locally...`});
    const fresh = current.bonusIdea
      ? buildBonusFromIdea({...current.bonusIdea, __datasets: state.datasets}, {engineAnalysis: state.engineAnalysis, event: mode === 'adapt-event' ? (Events.forCard(state, current) || state.event) : (e => e && e.applyMode !== 'new-only' ? e : null)(Events.forCard(state, current)), peers: all.filter(x => x.id !== scenarioId)})
      : regenerateScenarioLocal({engineAnalysis:state.engineAnalysis,activeEvent:Events.forCard(state,current)||state.event,scenario:current,weekPeers:[...all.filter(x=>x.id!==scenarioId),{incidentId:current.incidentId,hookRef:current.hookRef,soft:true}]});
    fresh.id=current.id;fresh.day=current.day;fresh.slot=current.slot;if(isAdded(current))fresh.addedBonus=true;
    if (current.noEvent !== undefined && fresh.series === current.series) fresh.noEvent = current.noEvent;       // the Event card switch you set stays on a rewritten card
    if (current.eventId) fresh.eventId = current.eventId;                                                         // and so does the event it was entered in
    keepPolicy(current, fresh);
    store.update(s => {
      for (const listName of WL.weekListNames(s.week)) { const idx=(s.week[listName]||[]).findIndex(x=>x.id===scenarioId); if(idx>=0)s.week[listName][idx]=fresh; }
      if (s.predictionLog) delete s.predictionLog[scenarioId];
      for (const a of Object.values(ensureAccounts(s))) if (a.links[scenarioId]) delete a.links[scenarioId];
      syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
      scoreWeek(s);
    });
    send('week:progress',{message:'Scenario regenerated locally.'});
    return store.get();
  });

  ipcMain.handle('week:setStatus', (_, id, status) => store.update(s => { s.week.statuses[id] = String(status); if (String(status) === 'Built') refreshAccuracy(s, 'built'); }));
  // ---- import a week ChatGPT wrote (Weekly Blueprint HTML): preview, revise, then import
  let pendingImport = null;
  const importItem = (c, L, peers) => { applyAssessment(c, L, peers); const plan = WI.proposeImprovements(c, L, peers, 80);
    return {id: c.id, day: c.day, slot: c.slot, series: c.series, sceneName: c.sceneName, primaryCharacter: c.primaryCharacter, score: c.prediction?.score ?? null, confidence: c.prediction?.confidence || '',
      reasons: (c.bonusAssessment?.breakdown || []).map(b => ({label: b.label, delta: b.delta})), plan, fixRequest: plan.before < 80 ? fixRequestWithRules(c, plan) : ''}; };
  ipcMain.handle('week:importChoose', async () => {
    const {canceled, filePaths} = await dialog.showOpenDialog(mainWindow, {title: 'Choose the Weekly Blueprint HTML that ChatGPT wrote', properties: ['openFile'], filters: [{name: 'Weekly Blueprint HTML', extensions: ['html', 'htm']}]});
    return canceled || !filePaths.length ? null : {path: filePaths[0], name: path.basename(filePaths[0])};
  });
  ipcMain.handle('week:importPreview', (_, file) => {
    const html = fs.readFileSync(String(file), 'utf8'), cards = WI.parseWeekHtml(html, {laneTabs: laneTabs(blueprints && blueprints.current(), isShare)}).map(WI.toAppCard);
    const st = store.get(), L = withLearning(st);
    try { if (blueprints) fillBlueprintFields({week: splitImported(cards)}, blueprints.current()); } catch (e) { console.error(e); }
    pendingImport = {file: path.basename(String(file)), cards};
    const items = cards.map(c => importItem(c, L, cards));
    const parts = splitImported(cards), core = parts.scenarios.length, ntr = parts.ntr.length, bonus = parts.bonus.length;
    const laneCounts = Object.fromEntries(Object.keys(parts).filter(WL.isLaneName).map(k => [WL.laneKeyOf(k), parts[k].length]));
    // every card in these files has a Built box and a Copy button: if fewer cards were read, say so
    const boxes = Math.max((html.match(/class="track-check"/g) || []).length, (html.match(/class="copy-btn"/g) || []).length);
    const missed = boxes > cards.length ? `This file seems to have ${boxes} cards but only ${cards.length} could be read. Send the file to have the importer updated before importing.` : '';
    return {file: pendingImport.file, items, counts: {core, ntr, bonus, lanes: laneCounts, laneLabels: laneLabels()}, below: items.filter(i => (i.score ?? 0) < 80).length,
      warning: missed ? missed : !isShare && (core !== coreWanted() || ntr !== ((ntrDaysNow() || []).length || 7)) ? `This file has ${core} day scenarios and ${ntr} NTR scenarios (a full week has ${coreWanted()} and ${(ntrDaysNow() || []).length || 7}).` : (isShare && core !== 21 ? `This file has ${core} day scenarios (a full week has 21).` : '')};
  });
  // ---- upload your own cards into one tab: read here (no AI, no relay), review like any import, then they replace that tab's cards
  ipcMain.handle('week:uploadChoose', async () => {
    const {canceled, filePaths} = await dialog.showOpenDialog(mainWindow, {title: 'Choose the file with your scenario cards', properties: ['openFile'], filters: [{name: 'Scenario cards (text, Markdown or Weekly Blueprint HTML)', extensions: ['txt', 'md', 'markdown', 'html', 'htm']}, {name: 'All files', extensions: ['*']}]});
    return canceled || !filePaths.length ? null : {path: filePaths[0], name: path.basename(filePaths[0])};
  });
  ipcMain.handle('week:uploadPreview', (_, file, tab) => {
    if (tab === 'NTR' && isCombinedNtr()) store.update(s => { if (normalizeNtrRotation(s, blueprints.current())) scoreWeek(s); });
    const st = store.get();
    if (tab === 'Bonus') throw new Error('Bonus cards are added from the Bonus tab (New bonus idea), where you can paste or write your own card.');
    const isLane = WL.isLaneName(tab), laneT = isLane ? laneTabs(blueprints && blueprints.current(), isShare).find(t => WL.laneName(t.key) === tab) : null;
    if (isLane && !laneT) throw new Error('That tab is no longer part of your Weekly Blueprint.');
    if (tab === 'NTR' && !hasNtrTab()) throw new Error('Your Weekly Blueprint has no NTR tab.');
    const slots = (tab === 'NTR' ? (isCombinedNtr() ? combinedNtrCards(st.week) : (st.week.ntr || [])) : isLane ? (st.week[tab] || []) : (st.week.scenarios || []).filter(x => x.day === tab)).map(c => JSON.parse(JSON.stringify(c)));
    if (!slots.length) throw new Error('This tab has no card slots yet. Generate the week first, then upload your cards into its tabs.');
    const label = isLane ? laneT.label : tab === 'NTR' ? 'NTR' : tab;
    const text = fs.readFileSync(String(file), 'utf8');
    const read = CU.readFile(text, laneTabs(blueprints && blueprints.current(), isShare));
    if (!read.cards.length) throw new Error("No scenario cards could be read from this file. Each card needs its field labels (Scene Name, The Setup, ...), either as a label line followed by its text, or as \"Label: text\" lines. Separate cards with a line like === CARD 1 ===, a line of ---, or just start each with its Scene Name.");
    let r;
    const lanesHere = tab === 'NTR' && isCombinedNtr() ? rotationLanes() : [];
    if (lanesHere.length && read.kind === 'html' && read.cards.some(c => c.laneTab || c.day === 'NTR' || c.type === 'ntr')) {
      // a Weekly Blueprint file read into the combined NTR tab: its NTR cards fill the NTR days, its Preventable / Post-NTR cards their own days
      const groups = [{raws: read.cards.filter(c => !c.laneTab && (c.day === 'NTR' || c.type === 'ntr')), slots: slots.filter(s => !s.laneTab), label: 'NTR'},
        ...lanesHere.map(t => ({raws: read.cards.filter(c => c.laneTab === t.key), slots: slots.filter(s => s.laneTab === t.key), label: t.label}))];
      const parts = groups.filter(g => g.slots.length).map(g => CU.intoSlots(g.raws, g.slots, {kind: 'text', tab, label: g.label, laneKey: ''}));
      r = {cards: parts.flatMap(x => x.cards), notes: parts.flatMap(x => x.notes), used: parts.reduce((n, x) => n + x.used, 0), found: read.cards.length};
    } else r = CU.intoSlots(read.cards, slots, {kind: read.kind, tab, label, laneKey: laneT ? laneT.key : ''});
    const cards = r.cards;
    for (const c of cards) if (c.day === 'NTR' && !c.laneTab) c.slot = 'NTR';
    try { if (blueprints) fillBlueprintFields({week: splitImported(cards)}, blueprints.current()); } catch (e) { console.error(e); }
    const L = withLearning(st);
    pendingImport = {file: path.basename(String(file)), cards, tab};
    const built = slots.slice(0, cards.length).filter(c => String((st.week.statuses || {})[c.id] || '') === 'Built').length;
    const items = cards.map(c => importItem(c, L, cards));
    const parts = splitImported(cards), core = parts.scenarios.length, ntr = parts.ntr.length;
    const laneCounts = Object.fromEntries(Object.keys(parts).filter(WL.isLaneName).map(k => [WL.laneKeyOf(k), parts[k].length]));
    const warn = [...r.notes, built ? `${built} of the slots being replaced ${built === 1 ? 'is' : 'are'} marked Built. ${built === 1 ? 'It is' : 'They are'} archived like the others and the new card starts as Idea.` : ''].filter(Boolean).join(' ');
    return {file: pendingImport.file, items, counts: {core, ntr, bonus: 0, lanes: laneCounts, laneLabels: laneLabels()}, below: items.filter(i => (i.score ?? 0) < 80).length, tabOnly: label, warning: warn};
  });
  // ---- paste ONE scenario into ONE scene card: read here (no AI, no relay), show what was found, fill the card only after you confirm
  let pendingPaste = null;
  ipcMain.handle('week:pastePreview', (_, id, text) => {
    const st = store.get(), slot = WL.weekCards(st.week).find(c => c.id === id);
    if (!slot) throw new Error('That card is no longer in the week.');
    const src = String(text || '').trim();
    if (src.length < 40) throw new Error('Paste the whole scenario first: its Scene Name, The Setup, the personality and the other sections.');
    const read = require('./lib/pasteScenario').readPaste(src);
    if (!read.cards.length) throw new Error('No scenario could be read from that text. Each section needs its label (Scene Name, The Setup, Character\'s Personality, Tags, ...) either as "Label:" / **Label:** followed by its text, or as a label line followed by its text.');
    const isLane = !!slot.laneTab, laneT = isLane ? laneTabs(blueprints && blueprints.current(), isShare).find(t => t.key === slot.laneTab) : null;
    const r = CU.intoSlots([read.cards[0]], [JSON.parse(JSON.stringify(slot))], {kind: read.kind, tab: slot.day, label: slot.day, laneKey: laneT ? laneT.key : ''});
    const card = r.cards[0]; card.pasted = true;
    // a Bonus card stays a Bonus card: its slot, its idea record (what lists it on the Bonus tab) and its added-bonus mark carry over to the pasted card
    if (slot.slot === 'Bonus') card.slot = 'Bonus';
    if (slot.bonusIdea) card.bonusIdea = {...slot.bonusIdea, brief: src.slice(0, 40000)};
    if (slot.addedBonus) card.addedBonus = slot.addedBonus;
    if (slot.slot === 'NTR') card.slot = 'NTR';
    try { if (blueprints) fillBlueprintFields({week: splitImported([card])}, blueprints.current()); } catch (e) { console.error(e); }
    const notes = [...(read.notes || []), ...r.notes.filter(n => !/slot/i.test(n))];
    if (read.cards.length > 1) notes.push(`The text holds ${read.cards.length} scenarios. Only the first, "${read.cards[0].title || 'Untitled'}", is used for this card.`);
    const status = String((st.week.statuses || {})[slot.id] || 'Idea');
    if (status === 'Built') notes.push('This card is marked Built. Pasting replaces it (the old card is archived with its scores) and the new one starts as Idea.');
    const Race = require('./renderer/cardrace.js'), Min = require('./renderer/minors.js');
    const race = (() => { try { return Race.of(card); } catch (e) { return null; } })();
    const all = [card.sceneName, ...Object.entries(card.fields || {}).filter(([k]) => !/^(tags|scene name|name|age|race)$/i.test(k)).map(([, v]) => typeof v === 'string' ? v : Array.isArray(v) ? v.join(' ') : '')].join('\n');
    const minors = Min.find(all);
    const prim = (card.cast || []).find(x => /^primary$/i.test(String(x.role || ''))) || (card.cast || [])[0] || {};
    pendingPaste = {id, card};
    return {id, replaces: slot.sceneName || '', found: {sceneName: card.sceneName || '', character: card.primaryCharacter || prim.name || '', age: prim.age || '', race: race ? race.race : '', raceKnown: !!(race && race.known), series: card.series || '', archetype: card.primaryArchetype || '', tags: card.tags || [], cast: card.cast || []},
      fields: Object.entries(card.fields || {}).filter(([, v]) => String(Array.isArray(v) ? v.join(', ') : v || '').trim()).map(([k, v]) => ({label: k, chars: String(Array.isArray(v) ? v.join(', ') : v).length, preview: String(Array.isArray(v) ? v.join(', ') : v).replace(/\s+/g, ' ').slice(0, 110)})),
      notes, minors};
  });
  ipcMain.handle('week:pasteApply', (_, id) => {
    if (!pendingPaste || pendingPaste.id !== id) throw new Error('Paste the scenario again: the preview is no longer open.');
    const card = pendingPaste.card;
    const out = store.update(s => {
      const old = WL.weekCards(s.week).filter(c => c.id === id && !isOpenSlot(c));
      if (old.length) { for (const c of old) freeze(s, c, 'archived'); archiveWeek(s, old, s.week.weekStart || ''); }
      for (const name of WL.weekListNames(s.week)) s.week[name] = (s.week[name] || []).map(c => c.id === id ? card : c);
      s.week.statuses = s.week.statuses || {}; s.week.statuses[id] = 'Idea';
      for (const a of Object.values(ensureAccounts(s))) if (a.links[id]) delete a.links[id];
      if (s.predictionLog) delete s.predictionLog[id];
      syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
      scoreWeek(s);
    });
    pendingPaste = null; return out;
  });
  ipcMain.handle('week:importRevise', (_, id, text) => {
    if (!pendingImport) throw new Error('Choose a file to import first.');
    const i = pendingImport.cards.findIndex(c => c.id === id); if (i < 0) throw new Error('That card is no longer in the import.');
    pendingImport.cards[i] = WI.reviseCard(pendingImport.cards[i], text);
    return importItem(pendingImport.cards[i], withLearning(store.get()), pendingImport.cards);
  });
  ipcMain.handle('week:importApply', (_, accepted) => {
    if (!pendingImport) throw new Error('Choose a file to import first.');
    const L = withLearning(store.get()), cards = pendingImport.cards;
    for (const c of cards) { const want = new Set((accepted || {})[c.id] || []); if (!want.size) continue;
      for (const cand of WI.candidates(c, L)) if (want.has(cand.label)) cand.apply(c); }
    if (pendingImport.tab) {                                                  // one tab: replace just those cards, in place
      const byId = new Map(cards.map(c => [c.id, c])), out1 = store.update(s => {
        const old = WL.weekCards(s.week).filter(c => byId.has(c.id) && !isOpenSlot(c));
        if (old.length) { for (const c of old) freeze(s, c, 'archived'); archiveWeek(s, old, s.week.weekStart || ''); }
        for (const name of WL.weekListNames(s.week)) s.week[name] = (s.week[name] || []).map(c => byId.get(c.id) || c);
        s.week.statuses = s.week.statuses || {}; for (const id of byId.keys()) s.week.statuses[id] = 'Idea';
        for (const a of Object.values(ensureAccounts(s))) for (const id of byId.keys()) if (a.links[id]) delete a.links[id];
        if (s.predictionLog) for (const id of byId.keys()) delete s.predictionLog[id];
        syncPerformance(s, linkableCards(s, flattenWeek(s.week)));
        scoreWeek(s);
      });
      pendingImport = null; return out1;
    }
    const out = store.update(s => {
      const old = weekOwnCards(s.week).filter(c => !isAdded(c));
      if (old.length) { for (const c of old) freeze(s, c, 'archived'); archiveWeek(s, old, s.week.weekStart || ''); }
      const statuses = {};
      for (const b of s.week.bonus || []) statuses[b.id] = (s.week.statuses || {})[b.id] || 'Idea';
      const parts = splitImported(cards), core = parts.scenarios, ntr = parts.ntr, bonus = parts.bonus, laneLists = Object.fromEntries(Object.entries(parts).filter(([k]) => WL.isLaneName(k)));
      // a tab the app writes itself keeps real cards even when the file or the AI supplied none for it
      for (const t of laneTabs(blueprints && blueprints.current(), isShare)) { const k = WL.laneName(t.key); if (hasLocalWriter(t) && !(laneLists[k] || []).length) laneLists[k] = ensureIds(writeLaneLocally(t, buildLaneCards(t), blueprints.current())); }
      const keptAdded = [...(s.week.scenarios || []), ...(s.week.ntr || [])].filter(isAdded); for (const c of keptAdded) statuses[c.id] = (s.week.statuses || {})[c.id] || 'Idea';
      for (const k of Object.keys(s.week)) if (WL.isLaneName(k)) delete s.week[k];            // the old week's extra tabs go with it (archived above)
      s.week = {...s.week, scenarios: core, ntr, bonus: [...bonus, ...(s.week.bonus || [])], ...laneLists, statuses, importedFrom: pendingImport.file, importedAt: new Date().toISOString(), generationMode: 'Imported from ChatGPT'};
      for (const c of [...core, ...ntr, ...bonus, ...Object.values(laneLists).flat()]) s.week.statuses[c.id] = 'Idea';
      reattachBonus(s.week, keptAdded);
      scoreWeek(s);
    });
    pendingImport = null;
    return out;
  });
  // ---- improve any card to 80+ (day, NTR, Bonus): plan, tidy-ups, fix request, revised card
  const findAny = (st, id) => WL.findCard(st.week, id);
  const cardPlan = (b, st) => { const c = JSON.parse(JSON.stringify(b)), L = withLearning(st), peers = flattenWeek(st.week); applyAssessment(c, L, peers); const plan = WI.proposeImprovements(c, L, peers, 80);
    return {id: b.id, sceneName: b.sceneName, score: c.prediction?.score ?? null, shown: b.prediction?.score ?? null, reasons: (c.bonusAssessment?.breakdown || []).map(x => ({label: x.label, delta: x.delta})), plan, fixRequest: fixRequestWithRules(c, plan)}; };
  // the same request the AI gets, to paste into ChatGPT (no AI needed)
  ipcMain.handle('card:suggestRequest', (_, id) => { const st = store.get(), f = findAny(st, id); if (!f) throw new Error('That card no longer exists.'); return Suggest.request(f.card, {rulesText: CR.rulesText(cardRulesFor(f.card))}); });
  // the quick fixes the app itself can make (a tag the story already supports, marking a card for its event): each one is approved by the creator; no scores
  const quickFixes = (b, st) => { const plan = cardPlan(b, st).plan; return {id: b.id, sceneName: b.sceneName, fixes: plan.changes.map(c => ({label: String(c.label).replace(/\s*\(\+?\d+[^)]*\)\s*$/, ''), diff: c.diff}))}; };
  ipcMain.handle('card:quickFixes', (_, id) => { const st = store.get(), f = findAny(st, id); if (!f) throw new Error('That card no longer exists.'); return quickFixes(f.card, st); });
  ipcMain.handle('bonus:applyTidy', (_, id, labels) => {
    const want = new Set(labels || []); if (!want.size) throw new Error('Tick at least one quick fix first.');
    let fixes = null;
    const out = store.update(s => { const f = findAny(s, id); if (!f) return; const b = f.card, L = withLearning(s);
      for (const cand of WI.candidates(b, L)) if (want.has(cand.label)) cand.apply(b);
      if (b.bonusIdea) b.bonusIdea = {...b.bonusIdea, tags: b.tags};
      scoreWeek(s); fixes = quickFixes(b, s); });
    return {state: out, fixes};
  });
  ipcMain.handle('week:importCancel', () => { pendingImport = null; return true; });
  ipcMain.handle('week:rescore', () => store.update(s => refreshAccuracy(s, 'rescore')));
  ipcMain.handle('performance:save', (_, record) => store.update(s => {
    const r={...record,updatedAt:new Date().toISOString()};const idx=s.performance.findIndex(x=>x.scenarioId===r.scenarioId);if(idx>=0)s.performance[idx]={...s.performance[idx],...r};else s.performance.push(r);
  }));
  const cleanIdea = idea => { const i = {}; for (const k of ['brief','title','name','series','relationship','setting','hook','archetype','intensity']) if (idea?.[k]) i[k] = String(idea[k]).slice(0, k === 'brief' ? 40000 : 2000);
    i.cast = Array.isArray(idea?.cast) ? idea.cast.slice(0, 3).map(c => ({name: String(c?.name || '').slice(0, 80).trim(), role: ['Primary','Antagonist','Secondary','Love Rival','Friend','Family','Other'].includes(c?.role) ? c.role : 'Secondary', age: String(c?.age || '').replace(/\D/g, '').slice(0, 3), gender: String(c?.gender || '').slice(0, 40), about: String(c?.about || '').slice(0, 600)})).filter(c => c.name) : []; i.userSet = {title: !!String(idea?.title || '').trim()}; i.futa = !!idea?.futa; i.tags = Array.isArray(idea?.tags) ? idea.tags.slice(0, 8).map(String) : []; if (!i.brief || i.brief.trim().length < 8) throw new Error('Describe the bot idea in at least a few words.'); return i; };
  // the same collapsible success estimate the Bonus cards have, for every other tab's cards (read-only: the card's own score is not changed)
  const assessCache = new Map();
  ipcMain.handle('week:assessments', (_, ids) => {
    const st = store.get(), want = new Set(Array.isArray(ids) ? ids : []), out = {};
    const ctx0 = {engineAnalysis: st.engineAnalysis, datasets: learningData(st), event: st.event, performance: st.performance};
    for (const c of WL.weekCards(st.week)) {
      if (!want.has(c.id) || c.bonusAssessment || !c.fields) continue;
      const ctx = {...ctx0, event: Events.forCard(st, c) || st.event};
      const sig = JSON.stringify([c.fields, c.sceneName, st.engineAnalysis && st.engineAnalysis.generatedAt, st.event && st.event.name, (st.performance || []).length, c.eventId || '']);
      const hit = assessCache.get(c.id); if (hit && hit.sig === sig) { out[c.id] = hit.a; continue; }
      try {
        const a = assessScenario(c, ctx); assessCache.set(c.id, {sig, a}); out[c.id] = a;
      } catch (e) { console.error('assessment failed for', c.id, e.message); }
    }
    return out;
  });
  ipcMain.handle('bonus:check', (_, idea) => { const st = store.get(), i = cleanIdea(idea); return assessIdea({text: ideaText(i)}, {engineAnalysis: st.engineAnalysis, datasets: learningData(st), event: st.event, performance: st.performance}); });
  ipcMain.handle('bonus:add', (_, idea, day) => {
    const st = store.get(), i = cleanIdea(idea), all = flattenWeek(st.week);
    const evPick = String((idea && idea.eventId) || ''), evChosen = evPick && evPick !== 'none' ? Events.byId(st, evPick) : null;          // '' = the default event, 'none' = no event, else one of the events
    const evFor = evPick === 'none' ? null : (evChosen && Events.usable(evChosen) ? evChosen : (Events.defaultOf(st.events || []) && Events.usable(Events.defaultOf(st.events)) ? Events.defaultOf(st.events) : null));
    const s = buildBonusFromIdea({...i, __datasets: learningData(st)}, {engineAnalysis: st.engineAnalysis, event: evFor, peers: all});
    let placedAs = '';
    const out = store.update(x => { if (evPick) Events.assign(s, evPick, x); placedAs = placeBonus(x.week, s, day); x.week.statuses = x.week.statuses || {}; x.week.statuses[s.id] = 'Idea'; try { if (blueprints) fillBlueprintFields({week: {bonus: [s]}}, blueprints.current()); } catch (e) { console.error(e); } applyAssessment(s, withLearning(x), flattenWeek(x.week)); Events.annotate(s, x); });
    return Object.assign(out, {__placed: placedAs, __id: s.id});
  });
  ipcMain.handle('bonus:parse', (_, text) => { const p = parseCard(String(text || '').slice(0, 40000)); if (p.found < 3) return {full: false};
    return {full: true, sceneName: p.fields['Scene Name'] || '', series: p.fields['Series / Category'] || '', archetype: p.fields['Primary Archetypal Personality'] || '', fields: p.order.length, tags: p.tags, cast: p.cast.map(c => ({name: c.name, role: c.role, age: c.age})), more: p.more || []}; });
  // Edit a Bonus card after it was created (the card editor sends the whole edited card).
  // It keeps its id, Built tick and linked bot, and the edits are stored with the idea so
  // Regenerate builds from the edited version instead of the original.
  // edit any card: day scenarios, NTR and Bonus
  const findCard = (w, id) => (WL.findCard(w, id) || {}).card || null;
  const updateCard = (_, id, patch) => {
    const st = store.get(), cur = findCard(st.week || {}, id);
    if (!cur) throw new Error('That card no longer exists.');
    const clip = (v, n) => String(v ?? '').slice(0, n);
    const cast = Array.isArray(patch?.cast) ? patch.cast.slice(0, 3).map((c, i) => ({name: clip(c.name, 80).trim(), role: i === 0 ? 'Primary' : (['Antagonist','Third Party','Secondary','Love Rival','Friend','Family','Other','Third Party'].includes(c.role) ? c.role : 'Secondary'), age: clip(c.age, 3).replace(/\D/g, ''), about: clip(c.about, 600).trim(), gender: (cur.cast || [])[i]?.gender || (c.role === 'Antagonist' ? 'Male' : 'Female')})).filter(c => c.name) : null;
    if (cast && !cast.length) throw new Error('Keep at least the main character.');
    const sceneName = clip(patch?.sceneName, 120).trim();
    if (patch?.sceneName !== undefined && !sceneName) throw new Error('Give the scene a name first.');
    return store.update(x => {
      const b = findCard(x.week, id); if (!b) return;
      if (b.blankSlot) { delete b.blankSlot; b.imported = true; }          // an emptied card you write in by hand is a real card again
      const isBonus = (x.week.bonus || []).includes(b);
      if (sceneName) { b.sceneName = sceneName; if ('Scene Name' in b.fields) b.fields['Scene Name'] = sceneName; }
      const edited = [];
      for (const [k, v] of Object.entries(patch?.fields || {})) {
        // new blueprint fields can be written in too
        if (!(k in b.fields) && (String(k).length > 150 || !String(v).trim())) continue;
        const nv = Array.isArray(b.fields[k]) ? String(v).split(/\n|,/).map(t => t.trim()).filter(Boolean) : String(v);
        if (JSON.stringify(nv) !== JSON.stringify(b.fields[k])) { b.fields[k] = nv; edited.push(k); }
      }
      if (Array.isArray(patch?.tags)) { b.tags = patch.tags.map(t => clip(t, 60).trim()).filter(Boolean).slice(0, 12); if ('Tags' in b.fields) b.fields.Tags = b.tags; }
      if (cast) {
        b.cast = cast; b.primaryCharacter = cast[0].name;
        const who = c => [c.name, c.age ? `age ${c.age}` : '', c.gender ? String(c.gender).toLowerCase() : ''].filter(Boolean).join(', ') + (c.about ? `; ${c.about}` : '');
        const ant = cast.find(c => c.role === 'Antagonist'), sec = cast.filter(c => c.role !== 'Primary' && c.role !== 'Antagonist');
        if (ant) b.fields['Antagonist'] = who(ant); else delete b.fields['Antagonist'];
        if (sec.length) b.fields['Secondary Character'] = sec.map(who).join('\n'); else delete b.fields['Secondary Character'];
      }
      b.autoFilled = (b.autoFilled || []).filter(f => !edited.includes(f));
      if (b.bpNeeds) b.bpNeeds = b.bpNeeds.filter(f => !edited.includes(f) && !String(b.fields[f] || '').trim());
      b.userEdited = [...new Set([...(b.userEdited || []), ...edited])];
      if (b.fields && b.fields['Primary Archetypal Personality'] !== undefined) { const a = Archetype.lead(b.fields['Primary Archetypal Personality']); b.primaryArchetype = a || String(b.fields['Primary Archetypal Personality']).split(/[\n(]/)[0].trim(); }   // keep the card's archetype in step with its field
      b.editedAt = new Date().toISOString();
      if (!isBonus) return;
      // remember the edits with the idea, so Regenerate keeps them
      b.bonusIdea = {...(b.bonusIdea || {}), title: b.sceneName, name: b.primaryCharacter, cast: b.cast, userSet: {...((b.bonusIdea || {}).userSet || {}), title: true, name: true, ...(cast ? {cast: true} : {})}, overrides: {...((b.bonusIdea || {}).overrides || {}), ...Object.fromEntries(edited.map(k => [k, b.fields[k]])), ...(Array.isArray(patch?.tags) ? {Tags: b.tags} : {})}};
      b.editedAt = new Date().toISOString();
      applyAssessment(b, withLearning(x), flattenWeek(x.week));
    });
  };
  ipcMain.handle('card:update', updateCard);
  // the Event card switch: on enters the card in the event again (run Adapt to Event after), off takes the event away from it
  // eventId: '' = the default event, 'none' = no event, or the id of one of the events (the old call, (id, on), still works)
  ipcMain.handle('card:setEvent', (_, id, on, eventId) => {
    if (!findCard(store.get().week || {}, id)) throw new Error('That card no longer exists.');
    return store.update(x => {
      const b = findCard(x.week, id); if (!b) return;
      if (eventId !== undefined) {
        Events.annotate(b, x); const prev = b.eventKey; Events.assign(b, String(eventId || ''), x);
        const now = Events.forCard(x, b);
        if (prev && now && now.id !== prev) { try { const r = adaptToEvent(b, now); for (const k of Object.keys(b)) delete b[k]; Object.assign(b, r.card); } catch (e) { console.error(e.message); } }       // moved from one event to another: the new event's tags go on now
      } else { EventCard.setOn(b, !!on, x.settings); if (!on) delete b.eventId; }
      scoreWeek(x);
    });
  });
  // Give several cards their event at once: map = {cardId: eventId | 'none' | ''}. adapt:false is for cards the AI is about to rewrite anyway.
  ipcMain.handle('week:setEvents', (_, map, opts) => {
    const adapt = !(opts && opts.adapt === false);
    return store.update(x => {
      for (const [id, v] of Object.entries(map && typeof map === 'object' ? map : {})) {
        const b = findCard(x.week, id); if (!b) continue;
        const val = String(v || ''); if (val && val !== 'none' && !Events.byId(x, val)) continue;
        Events.annotate(b, x); const prev = b.eventKey; Events.assign(b, val, x);
        const now = Events.forCard(x, b);
        if (adapt && now && now.id !== prev) { try { const r = adaptToEvent(b, now); for (const k of Object.keys(b)) delete b[k]; Object.assign(b, r.card); } catch (e) { console.error(e.message); } }
      }
      scoreWeek(x);
    });
  });
  // give every slot of the week its event from a plan {slotKey: eventId | 'none' | ''} without writing anything (Adapt the week picks events this way)
  ipcMain.handle('week:applyEventPlan', (_, plan) => store.update(x => { Events.applyPlan(x, plan); scoreWeek(x); }));
  ipcMain.handle('bonus:update', updateCard);
  ipcMain.handle('bonus:move', (_, id, day) => { let placedAs = '';
    const out = store.update(x => { let c = null; for (const k of WL.weekListNames(x.week)) { const i = (x.week[k] || []).findIndex(b => b.id === id); if (i >= 0) { c = x.week[k].splice(i, 1)[0]; break; } }
      if (!c || !c.bonusIdea) return; placedAs = placeBonus(x.week, c, day);
      for (const d of RELEASE_DAYS) { let n = 0; for (const b of x.week.scenarios) if (b.day === d && isAdded(b)) b.slot = `Scenario ${x.week.scenarios.filter(q => q.day === d && !isAdded(q)).length + (++n)}`; }
      let m = 0; for (const b of x.week.ntr) if (isAdded(b)) b.slot = `Scenario ${x.week.ntr.filter(q => !isAdded(q)).length + (++m)}`;
      scoreWeek(x); });
    return Object.assign(out, {__placed: placedAs}); });
  // delete any scenario card (a day card, an NTR card, a Bonus card, or a Bonus idea placed on a day)
  const deleteCard = (_, id) => store.update(x => { if (removeScenarioCard(x, id)) scoreWeek(x); });
  ipcMain.handle('card:delete', deleteCard);
  // move a card to another tab (Monday to Sunday, Bonus): it goes to the top; a day's own slot it leaves is reset (kept empty) or deleted, as chosen
  ipcMain.handle('card:move', (_, id, dest, mode, type) => {
    const CM = require('./lib/cardMove'), err = CM.check(store.get(), String(id), String(dest), String(mode || ''));
    if (err) throw new Error(err);
    let placed = '';
    const out = store.update(x => { placed = CM.move(x, String(id), String(dest), String(mode || ''), type ? String(type) : ''); scoreWeek(x); });
    return Object.assign(out, {__placed: placed});
  });
  // a rating chosen by hand for one bot (SFW / NSFW / 18+), or null to go back to what was detected
  ipcMain.handle('perf:setRating', (_, account, url, label) => store.update(s => {
    const a = s.accounts && s.accounts[account]; if (!a) return;
    a.ratingOverrides = a.ratingOverrides || {};
    if (['SFW', 'NSFW', '18+'].includes(label)) a.ratingOverrides[String(url)] = label; else delete a.ratingOverrides[String(url)];
  }));
  // your own weekly target (how many bots you mean to build each week); null = the number of cards in the week
  ipcMain.handle('week:setTarget', (_, n) => store.update(s => { const v = Math.round(+n); s.weekTarget = v > 0 && v <= 500 ? v : null; }));
  ipcMain.handle('bonus:remove', deleteCard);
  ipcMain.handle('bonus:recheck', () => store.update(x => { const all = flattenWeek(x.week), L = withLearning(x); for (const b of x.week.bonus || []) applyAssessment(b, L, all); }));
  ipcMain.handle('history:clear', () => { history.clear(); return store.update(s => { s.historyStats = history.stats(); }); });
  const botTemplateDirs = () => [path.join(app.getPath('userData'), 'bot-templates'), path.join(resourcesDir, 'bot-templates')];
  templateDirsFn = botTemplateDirs;
  try { const d = botTemplateDirs()[0]; if (fs.existsSync(d)) for (const f of fs.readdirSync(d)) if (/\.txt\.removed-\d+$/.test(f)) fs.unlinkSync(path.join(d, f)); } catch {}
  ipcMain.handle('builder:templates', () => templatesWithLimits());
  // remove a template: yours is deleted (a replaced built-in comes back), a built-in one is taken off the list
  ipcMain.handle('builder:remove', (_, id) => {
    const cur = String(id || ''); if (!/\.txt$/i.test(cur) || cur.includes('/') || cur.includes('\\')) throw new Error('Pick a template first.');
    const mine = path.join(botTemplateDirs()[0], cur), built = path.join(botTemplateDirs()[1], cur);
    if (fs.existsSync(mine)) {
      // deleted for good, together with its backups (the ".previous" copy Replace keeps, and any ".removed" file from v0.68)
      const dir = botTemplateDirs()[0];
      for (const f of fs.readdirSync(dir)) if (f === cur || f === `${cur}.previous` || f.startsWith(`${cur}.removed`)) { try { fs.unlinkSync(path.join(dir, f)); } catch {} }
      return {removed: 'yours', builtInReturns: fs.existsSync(built), templates: templatesWithLimits()};
    }
    if (fs.existsSync(built)) { writeHidden([...readHidden(), cur]); return {removed: 'hidden', templates: templatesWithLimits()}; }
    throw new Error('That template is no longer there.');
  });
  ipcMain.handle('builder:hiddenTemplates', () => templatesWithLimits({includeHidden: true}).filter(t => t.hidden).map(t => ({id: t.id, name: t.name})));
  ipcMain.handle('builder:unhide', (_, id) => { writeHidden(id === 'all' ? [] : readHidden().filter(x => x !== id)); return templatesWithLimits(); });
  ipcMain.handle('builder:setLimits', (_, templateId, limits) => {
    const all = readUserLimits(), cur = all[templateId] || {};
    for (const sec of LIMIT_SECTIONS) { const L = limits && limits[sec]; if (!L) continue; const min = Math.round(+L.min), max = Math.round(+L.max);
      if (!(min > 0) || !(max >= min)) throw new Error(`The ${sec} limit needs a minimum above 0 and a maximum at least as large.`); cur[sec] = {min, max}; }
    all[templateId] = cur; writeUserLimits(all); return templatesWithLimits();
  });
  // ---- built bots saved to their scenario card (kept across weeks, one per card and template)
  const cardById = (st, id) => [...WL.weekCards(st.week), ...(st.cardArchive || [])].find(c => c.id === id);
  // saved bots in one shape: {key: "card::template", cardId, templateId, sceneName, templateName, values, ...}.
  // An earlier version stored them nested (savedBots[cardId][templateId]); those are converted, empty ones dropped.
  const normalizeSaved = (sb, st) => {
    const out = {}, names = {}; try { for (const t of templatesWithLimits({includeHidden: true})) names[t.id] = t.name; } catch {}
    const scene = (cardId, v) => (cardById(st, cardId) || {}).sceneName || (v && v.header && v.header.scene) || 'Untitled bot';
    const put = (key, r, cardId, tid) => { if (!r || typeof r !== 'object' || !r.values || typeof r.values !== 'object') return;
      out[key] = {...r, key, cardId, templateId: tid, sceneName: r.sceneName || scene(cardId, r.values), templateName: r.templateName || names[tid] || tid, savedAt: r.savedAt || ''}; };
    for (const [k, e] of Object.entries(sb || {})) {
      if (!e || typeof e !== 'object') continue;
      if (e.values) { const [c, t] = String(e.key || k).split('::'); put(e.key || k, e, e.cardId || c, e.templateId || t || ''); continue; }
      for (const [tid, r] of Object.entries(e)) put(`${k}::${tid}`, r, k, (r && r.templateId) || tid);
    }
    return out;
  };
  // the day shown beside a saved bot is the card's day NOW (the Weekly Blueprint can move or rewrite a card after the bot was saved), not the day stored when it was saved
  const liveDay = (st, b) => { const c = cardById(st, b.cardId); if (!c) return b.day || ''; return (c.realDay && c.realDay !== 'NTR' ? c.realDay : c.day) || b.day || ''; };
  const savedList = st => Object.values(normalizeSaved(st.savedBots, st)).sort((a, b) => String(b.savedAt).localeCompare(String(a.savedAt))).map(b => ({...b, day: liveDay(st, b), values: undefined, full: undefined}));
  try { store.update(s => { s.savedBots = normalizeSaved(s.savedBots, s); }); } catch (e) { console.error('saved bots', e); }
  ipcMain.handle('builder:saveBot', (_, templateId, values, full) => {
    const cardId = values && values.sourceId;
    if (!cardId) throw new Error('This bot isn\'t linked to a scenario card yet. Choose the card in "Draft from" and click Fill from scenario (or write it with AI), then save.');
    const st = store.get(), card = cardById(st, cardId), tpl = templatesWithLimits().find(t => t.id === templateId);
    const key = `${cardId}::${templateId}`;
    const out = store.update(s => { s.savedBots = s.savedBots || {};
      s.savedBots[key] = {key, cardId, sceneName: values.header?.scene || card?.sceneName || 'Untitled', day: card?.day || '', templateId, templateName: tpl?.name || templateId,
        values: JSON.parse(JSON.stringify(values)), full: String(full || '').slice(0, 60000), savedAt: new Date().toISOString(), chars: String(full || '').length}; });
    return {saved: savedList(out), key};
  });
  ipcMain.handle('builder:savedBots', () => savedList(store.get()));
  ipcMain.handle('builder:loadSavedBot', (_, key) => { const b = normalizeSaved(store.get().savedBots, store.get())[key]; if (!b) throw new Error('That saved bot no longer exists.'); return b; });
  ipcMain.handle('builder:deleteSavedBot', (_, key) => { const out = store.update(s => { s.savedBots = normalizeSaved(s.savedBots, s); delete s.savedBots[key]; }); return savedList(out); });
  // the Bot Builder's closeable "what changed" box: kept until the person closes it
  const pushTemplateLog = l => { if (l) store.update(s => { s.builder = s.builder || {}; s.builder.templateLogs = [l, ...(s.builder.templateLogs || []).filter(x => x.file !== l.file)].slice(0, 12); }); };
  ipcMain.handle('builder:templateLogs', () => (store.get().builder || {}).templateLogs || []);
  ipcMain.handle('builder:closeTemplateLog', (_, id) => { store.update(s => { s.builder = s.builder || {}; s.builder.templateLogs = id === 'all' ? [] : (s.builder.templateLogs || []).filter(x => x.id !== String(id)); }); return (store.get().builder || {}).templateLogs || []; });
  ipcMain.handle('builder:import', async () => {
    const {canceled, filePaths} = await dialog.showOpenDialog(mainWindow, {title: 'Add bot template', properties: ['openFile', 'multiSelections'], filters: [{name: 'Text templates', extensions: ['txt']}]});
    if (canceled || !filePaths.length) return {added: [], errors: []};
    const dir = botTemplateDirs()[0]; fs.mkdirSync(dir, {recursive: true});
    const added = [], errors = [];
    for (const f of filePaths) {
      try { const text = fs.readFileSync(f, 'utf8'); parseTemplate(text, f); const base = path.basename(f), dest = path.join(dir, base), builtIn = path.join(botTemplateDirs()[1], base);
        const old = fs.existsSync(dest) ? fs.readFileSync(dest, 'utf8') : fs.existsSync(builtIn) ? fs.readFileSync(builtIn, 'utf8') : null;
        fs.copyFileSync(f, dest); added.push(base);
        pushTemplateLog(require('./lib/templateLog').make(old == null ? {file: base, kind: 'added', from: base, newText: text} : {file: base, kind: 'updated', from: base, oldText: old, newText: text})); }
      catch (e) { errors.push(`${path.basename(f)}: ${e.message}`); }
    }
    return {added, errors};
  });
  // Replace the selected template with an updated file. Your copy lives in the app's data
  // folder under the same file name, so it takes priority over the built-in one.
  ipcMain.handle('builder:replace', async (_, id) => {
    const cur = String(id || ''); if (!/\.txt$/i.test(cur) || cur.includes('/') || cur.includes('\\')) throw new Error('Pick a template first.');
    const {canceled, filePaths} = await dialog.showOpenDialog(mainWindow, {title: 'Choose the updated template', properties: ['openFile'], filters: [{name: 'Text templates', extensions: ['txt']}]});
    if (canceled || !filePaths.length) return {replaced: false};
    const text = fs.readFileSync(filePaths[0], 'utf8');
    parseTemplate(text, cur);                                   // stops here with a clear message if it isn't a bot template
    const dir = botTemplateDirs()[0]; fs.mkdirSync(dir, {recursive: true});
    const dest = path.join(dir, cur), builtIn = path.join(botTemplateDirs()[1], cur);
    const before = fs.existsSync(dest) ? fs.readFileSync(dest, 'utf8') : fs.existsSync(builtIn) ? fs.readFileSync(builtIn, 'utf8') : '';
    if (fs.existsSync(dest)) fs.copyFileSync(dest, dest + '.previous');   // one-step undo
    fs.writeFileSync(dest, text, 'utf8');
    pushTemplateLog(require('./lib/templateLog').make({file: cur, kind: 'updated', from: path.basename(filePaths[0]), oldText: before, newText: text}));
    return {replaced: true, id: cur, from: path.basename(filePaths[0])};
  });
  ipcMain.handle('builder:restore', (_, id) => {
    const cur = String(id || ''); if (!/\.txt$/i.test(cur) || cur.includes('/') || cur.includes('\\')) throw new Error('Pick a template first.');
    const dest = path.join(botTemplateDirs()[0], cur), builtIn = path.join(botTemplateDirs()[1], cur);
    if (!fs.existsSync(dest)) return {restored: false, reason: 'This template is already the original.'};
    if (!fs.existsSync(builtIn)) return {restored: false, reason: 'This template was added by you, so there is no built-in version to go back to.'};
    fs.renameSync(dest, dest + '.previous'); return {restored: true};
  });
  ipcMain.handle('builder:templateInfo', (_, id) => {
    const cur = String(id || ''); const mine = path.join(botTemplateDirs()[0], cur);
    return {replaced: fs.existsSync(mine) && fs.existsSync(path.join(botTemplateDirs()[1], cur)), yours: fs.existsSync(mine) && !fs.existsSync(path.join(botTemplateDirs()[1], cur)),
      updatedAt: fs.existsSync(mine) ? fs.statSync(mine).mtime.toISOString() : null};
  });
  ipcMain.handle('builder:saveDraft', (_, id, values) => { store.update(s => { s.builder = s.builder || {drafts: {}}; s.builder.drafts = s.builder.drafts || {}; s.builder.drafts[id] = values; s.builder.lastTemplate = id; }); return true; });
  ipcMain.handle('builder:export', async (_, name, text) => {
    const {canceled, filePath} = await dialog.showSaveDialog(mainWindow, {title: 'Save bot', defaultPath: String(name || 'Bot.txt').replace(/[\\/:*?"<>|]/g, ''), filters: [{name: 'Text', extensions: ['txt']}]});
    if (canceled || !filePath) return null;
    fs.writeFileSync(filePath, String(text || ''), 'utf8'); return filePath;
  });
  ipcMain.handle('builder:openBot', async () => {
    const {canceled, filePaths} = await dialog.showOpenDialog(mainWindow, {title: 'Upload a built bot (.txt)', properties: ['openFile'], filters: [{name: 'Built bot', extensions: ['txt']}]});
    if (canceled || !filePaths || !filePaths[0]) return null;
    return {name: path.basename(filePaths[0]), text: fs.readFileSync(filePaths[0], 'utf8')};
  });
  ipcMain.handle('export:weekHtml', async () => {
    const state=store.get();const {canceled,filePath}=await dialog.showSaveDialog(mainWindow,{title:'Export Weekly Blueprint',defaultPath:`Weekly Blueprint Batch ${state.week.weekStart||''}.html`,filters:[{name:'HTML',extensions:['html']}]});
    if(canceled||!filePath)return{canceled:true};fs.writeFileSync(filePath,weekToHtml(state),'utf8');return{canceled:false,filePath};
  });
});

app.on('before-quit',()=>{app.isQuitting=true;try{if(webpMaker)webpMaker.dispose();}catch(e){console.error('WebP Maker cleanup:',e.message);} try{if(store)store.flush();}catch(e){console.error('final save:',e.message);}try{if(backup&&!SANDBOX&&backup.due(3600e3))backup.run('quit');}catch(e){console.error('quit backup:',e.message);}});
app.on('window-all-closed',()=>{if(process.platform!=='darwin'&&!(tray&&store&&store.state.settings.openAtLogin))app.quit();});
app.on('activate',()=>{if(BrowserWindow.getAllWindows().length===0)createMainWindow();});
