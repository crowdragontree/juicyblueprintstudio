/* Finds where the character's age is written into the Introduction or the Greeting, and says how to take it out.
   - find(text, charAge): [{start, end, text, rep, age, mine, explicit}]   (non-overlapping, in text order)
       text = what is written there, rep = what stays in its place, age = the number, mine = it equals the character's age,
       explicit = it can only be an age ("28-year-old", "28 years old", "aged 28", "28th birthday", "in her late twenties")
   - apply(text, hits): the text with those hits taken out, tidied only right where each one was
   - preview(text, hit): {before, after} a short stretch of the text around the hit, with and without it
   Only the age goes. Nothing else in the text is touched.                                                              */
(function () {
  const TENS = {twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90};
  const ONES = {one: 1, two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9};
  const WORD = '(?:twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety)(?:[- ](?:one|two|three|four|five|six|seven|eight|nine))?';
  const NUM = '(?:[2-9]\\d|' + WORD + ')';
  const YO = NUM + '[- ]years?[- ]old';
  const UNITS = '(?!\\s*(?:%|a\\.?m\\b|p\\.?m\\b|minutes?|mins?\\b|hours?|days?|weeks?|months?|seconds?|miles?|feet|ft\\b|inch|inches|cm\\b|kg\\b|lbs?\\b|pounds?|dollars?|bucks|percent|years\\b|st\\b|nd\\b|rd\\b|th\\b|degrees|[:/.]\\d))';
  const BE = "(?:is|are|was|am|[’']s|[’']m|[’']re)";
  const TURN = '(?:just\\s+)?(?:turned|turning|turns)';
  const DECADE = '(?:early|mid|late)?[- ]?(?:twenties|thirties|forties|fifties|sixties)';

  const val = s => {
    s = String(s).toLowerCase().trim(); const d = s.match(/^\d+/); if (d) return +d[0];
    const m = s.match(/^([a-z]+)(?:[- ](one|two|three|four|five|six|seven|eight|nine))?/); return m && TENS[m[1]] ? TENS[m[1]] + (ONES[m[2]] || 0) : NaN;
  };
  const startsVowel = w => (/^[aeiou]/i.test(w) && !/^(uni|use|usu|one|eu|ubi)/i.test(w)) || /^(hour|honest|heir|honou?r)/i.test(w);
  const art = (a, next) => { const n = startsVowel(next) ? 'an' : 'a'; return a[0] === a[0].toUpperCase() ? n[0].toUpperCase() + n.slice(1) : n; };

  const ADJ = NUM + '(?:[- ]years?[- ]old|[- ]?yo\\b|[- ]?y\\/o\\b)';         // "28-year-old", "28 year old", "28yo"
  const PRED = NUM + '(?:\\s+years?\\s+old|\\s*yo\\b|\\s*y\\/o\\b)';            // "28 years old", "28yo"
  // the word after "and" is a verb ("works", "has", "runs"): then "is 28 years old and works" can lose "is ... and" and still read right
  const VERBISH = w => /^(?:has|does|is|was|were|are|can|will|would|could|should|did|had|goes|does)$/i.test(w) || (/^\w{2,}s$/i.test(w) && !/(?:ss|us|is)$/i.test(w));
  // each pattern: re, explicit, and build(match, text) -> {rep, age, s?, e?, manual?}; a manual hit can't be taken out without breaking the sentence
  const P = [
    // a whole short sentence that only says the age: "Mia is 28." / "She's a 31-year-old." / "Mia is 28 years old."
    {re: new RegExp('(?:^|(?<=[.!?]["”’)]?\\s)|(?<=\\n)|(?<=\\]\\s))([^.!?\\n,"“”\\[\\]]{0,50}?\\b' + BE + '\\s+(?:an?\\s+)?(' + NUM + ')(?:[- ]years?[- ]old|\\s+years?\\s+old|\\s*yo\\b)?[.!]+)(?:[ \\t]+|(?=\\n|$))', 'gi'), explicit: false,
     sentence: true, build: m => ({rep: '', age: val(m[2])})},
    // "a 28-year-old barista", "the 28-year-old", "28-year-old Mia": the age goes, the article is fixed for the next word
    {re: new RegExp('\\b(?:(an?)\\s+(' + ADJ + ')|(' + NUM + '(?:-years?-old|-?yo\\b|-?y\\/o\\b))),?\\s+(?!(?:and|but|who|with)\\b)(?=(\\w+))', 'gi'), explicit: true,
     build: m => ({rep: m[1] ? art(m[1], m[4]) + ' ' : '', age: val(m[2] || m[3])})},
    // "Mia is 28 years old and ...", "Mia is 28 years old, ..." / "Mia is 28 years old."
    {be: true, re: new RegExp('(\\s*)\\b(' + BE + ')\\s+(' + PRED + ')(?:(\\s*,?\\s*and\\s+)(\\w+))?', 'gi'), explicit: true,
     build: m => m[4] ? (VERBISH(m[5]) ? {rep: m[1] || (/^[’']/.test(m[2]) ? ' ' : ''), age: val(m[3]), s: 0, e: m[0].length - m[5].length} : {rep: m[1] + m[2] + ' ', age: val(m[3]), s: 0, e: m[0].length - m[5].length}) : {rep: '', age: val(m[3])}},
    // "she's 28 and ..." / "Mia is 28," (bare number, so only the ones that say so with a verb after "and")
    {be: true, re: new RegExp('(\\s*)\\b(' + BE + ')\\s+([2-9]\\d)\\b' + UNITS + '(?:(\\s*,?\\s*and\\s+)(\\w+))?', 'gi'), explicit: false,
     build: m => m[4] ? (VERBISH(m[5]) ? {rep: m[1] || (/^[’']/.test(m[2]) ? ' ' : ''), age: val(m[3]), s: 0, e: m[0].length - m[5].length} : {rep: m[1] + m[2] + ' ', age: val(m[3]), s: 0, e: m[0].length - m[5].length}) : {rep: '', age: val(m[3])}},
    // "just turned 28 last week": the sentence depends on it
    {re: new RegExp('\\b' + TURN + '\\s+([2-9]\\d)\\b' + UNITS, 'gi'), explicit: false, build: m => ({rep: '', age: val(m[1]), manual: true})},
    // "Mia, 28, ..." / "Mia, 28 years old, ..."
    {re: new RegExp(',\\s*(' + NUM + ')(?:[- ]years?[- ]old|\\s+years?\\s+old)?\\s*,', 'gi'), explicit: false, build: m => ({rep: '', age: val(m[1])})},
    // "(28)" / "(age 28)" / "(28 years old)"
    {re: new RegExp('\\s*\\((?:age[d:]?\\s*)?(' + NUM + ')(?:[- ]years?[- ]old|\\s+years?\\s+old|\\s*yo)?\\)', 'gi'), explicit: false, build: m => ({rep: '', age: val(m[1])})},
    // "aged 28" / "at the age of 28" / "age: 28"
    {re: new RegExp('\\s*,?\\s*\\b(?:aged|at the age of|age:?)\\s+(' + NUM + ')\\b' + UNITS, 'gi'), explicit: true, build: m => ({rep: '', age: val(m[1])})},
    // "28th birthday"
    {re: /\b([2-9]\d)(?:st|nd|rd|th)\s+(?=birthday)/gi, explicit: true, build: m => ({rep: '', age: val(m[1])})},
    // "28-year-old" at the end of a phrase ("a woman, 28 years old.")
    {re: new RegExp('\\s*,?\\s*\\b(' + PRED + '|' + ADJ + ')', 'gi'), explicit: true, build: m => ({rep: '', age: val(m[1])})},
    // "in her late twenties"
    {re: new RegExp('\\s*,?\\s*\\bin\\s+(?:her|his|their|your)\\s+' + DECADE + '\\b', 'gi'), explicit: true, build: () => ({rep: '', age: NaN})},
    // "twenty-something"
    {re: /\b(?:(an?)\s+)?(?:twenty|thirty|forty|fifty)[- ]?something\s+(?=(\w+))/gi, explicit: true, build: m => ({rep: m[1] ? art(m[1], m[2]) + ' ' : '', age: NaN})}
  ];

  function find(text, charAge) {
    text = String(text || ''); const want = parseInt(charAge, 10), hits = [];
    for (const p of P) {
      p.re.lastIndex = 0; let m;
      while ((m = p.re.exec(text))) {
        if (m[0] === '') { p.re.lastIndex++; continue; }
        const b = p.build(m), s = m.index + (b.s || 0), e = m.index + (b.e != null ? b.e : m[0].length);
        if (hits.some(h => s < h.end && e > h.start)) continue;                      // already covered by a stronger pattern
        // a line of dialogue says it in the speaker's own words ("I'm 28", "you're 28"), or it is the whole of a quote: leave those to the person
        let manual = !!b.manual;
        if (p.be && /(?:^|\W)(?:I|you|we)\s*$/i.test(text.slice(0, m.index + (m[1] || '').length))) manual = true;
        if (p.sentence && (/["“]$/.test(text.slice(0, s)) && /^["”]/.test(text.slice(e)) || /^(?:I|you|we)\b/i.test(m[1]))) manual = true;
        hits.push({start: s, end: e, text: text.slice(s, e), rep: b.rep, age: b.age, explicit: p.explicit, manual, mine: !isNaN(want) && b.age === want});
      }
    }
    hits.sort((a, b) => a.start - b.start);
    return hits;
  }
  // tidy only where an age came out: spaces and punctuation within a few characters of the edit
  function tidyAt(text, i, len) {
    const a = Math.max(0, i - 3), b = Math.min(text.length, i + len + 3);
    let w = text.slice(a, b);
    w = w.replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+([,.;!?])/g, '$1').replace(/,\s*([.!?])/g, '$1').replace(/,\s*,/g, ',');
    return text.slice(0, a) + w + text.slice(b);
  }
  function apply(text, hits) {
    text = String(text || '');
    for (const h of [...hits].filter(h => !h.manual).sort((a, b) => b.start - a.start)) {
      const atEnd = h.end >= text.length, head = text.slice(0, h.start);
      text = (atEnd && !h.rep ? head.replace(/[ \t]+$/, '') : head) + h.rep + text.slice(h.end);
      text = tidyAt(text, Math.min(h.start, text.length), h.rep.length);
    }
    return text;
  }
  function preview(text, h, reach = 38) {
    text = String(text || '');
    const a = Math.max(0, h.start - reach), b = Math.min(text.length, h.end + reach), cut = s => s.replace(/\s+/g, ' ');
    const around = (t, from, to) => (from > 0 ? '…' : '') + cut(t.slice(from, to)) + (to < t.length ? '…' : '');
    const after = apply(text, [h]);
    const shift = after.length - text.length;
    return {before: around(text, a, b), after: around(after, a, Math.max(a, b + shift))};
  }
  // ---- the other facts that belong in the Personality only: the archetype and the race
  // findMeta(text, {archetype, race}) -> hits shaped like find()'s. A short sentence that only states the archetype or the race
  // can be taken out whole; a phrase inside a longer sentence is shown but left to be edited by hand (manual).
  const esc = x => String(x || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function findMeta(text, ctx) {
    text = String(text || ''); ctx = ctx || {}; const hits = [];
    const arch = String(ctx.archetype || '').trim(), race = String(ctx.race || '').split(/[\n,;(\/]/)[0].trim();
    const A = arch && arch.length > 2 ? esc(arch) : '', R = race && race.length > 2 && !/^\[|^(?:n\/a|none|unknown)$/i.test(race) ? esc(race) : '';
    const ART = '(?:an?|the)', GAP = '(?:[\\w-]+\\s+){0,2}?', NOUN = '(?:\\s+(?:woman|girl|lady|female|being|creature|type|archetype|personality|at heart))?';
    const tests = [
      ['archetype', /\barchetype\b|\barchetypal\b/i],
      A && ['archetype', new RegExp("\\b(?:is|was|as|being|[’']s)\\s+" + ART + "\\s+" + GAP + A + "\\b" + NOUN, 'i')],
      A && ['archetype', new RegExp("\\b(?:her|his|their)\\s+" + A + "\\s+(?:side|nature|personality|type|persona|streak|energy)\\b", 'i'), true],
      R && ['race', new RegExp("\\b(?:is|was|as|being|[’']s)\\s+" + ART + "\\s+" + GAP + R + "\\b" + NOUN, 'i')],
      ['race', /\b(?:her|his|their|the)\s+(?:race|species)\s+(?:is|was)\b|\bRace\s*:|\bSpecies\s*:/i],
    ].filter(Boolean);
    const re = /[^.!?\n]*[.!?]+|[^.!?\n]+$/g; let m;
    while ((m = re.exec(text))) {
      const raw = m[0], lead = raw.match(/^[\s*_]*/)[0].length;
      let s0 = m.index + lead, e0 = m.index + raw.length;
      const sent = text.slice(s0, e0); if (!sent.trim()) continue;
      const hit = tests.find(t => t[1].test(sent)); if (!hit) continue;
      const sp = text.slice(e0).match(/^[ \t]*/)[0].length; const dialogue = /["“”]/.test(sent), long = sent.length > 150, wrapped = text[s0 - 1] === '*' && text[e0] === '*';
      const mm = sent.match(hit[1]);
      if (dialogue || long || wrapped || hit[2]) {                                           // not a bare sentence: show the phrase, leave the edit to the person
        hits.push({start: s0 + mm.index, end: s0 + mm.index + mm[0].length, text: mm[0], rep: '', age: NaN, explicit: true, manual: true, mine: false, kind: hit[0]});
      } else hits.push({start: s0, end: e0 + sp, text: sent, rep: '', age: NaN, explicit: true, manual: false, mine: false, kind: hit[0], sentence: true});
    }
    return hits;
  }
  const api = {find, findMeta, apply, preview};
  if (typeof window !== 'undefined') window.AgeMention = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
