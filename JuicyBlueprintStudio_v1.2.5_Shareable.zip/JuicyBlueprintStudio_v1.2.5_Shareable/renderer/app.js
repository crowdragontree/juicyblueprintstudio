// One copy function for every Copy button: the desktop clipboard first (works on the
// first click), then the browser clipboard, then an old-style fallback.
let IS_SHARE=false;
async function copyText(text){
  const t=String(text??'');
  try{if(window.juicyApp&&window.juicyApp.copyText){await window.juicyApp.copyText(t);return true;}}catch(_){}
  try{await copyText(t);return true;}catch(_){}
  try{const ta=document.createElement('textarea');ta.value=t;ta.style.position='fixed';ta.style.opacity='0';document.body.appendChild(ta);ta.select();const ok=document.execCommand('copy');ta.remove();return ok;}catch(_){return false;}
}
window.copyText=copyText;
let state = null;
let activeDay = 'Monday';
// collapse / expand a card: click the empty space of its header (or of the folded card). Which cards are folded is kept on this computer.
const collapsedCards=(()=>{try{return new Set(JSON.parse(localStorage.getItem('jbs.collapsedCards')||'[]'));}catch{return new Set();}})();
const saveCollapsed=()=>{try{localStorage.setItem('jbs.collapsedCards',JSON.stringify([...collapsedCards].slice(-600)));}catch{}};
const cardCollapsed=s=>collapsedCards.has(s.id)&&editingBonus!==s.id&&sugWeekOpen!==s.id;
document.addEventListener('click',e=>{
  const t=e.target,card=t&&t.closest?t.closest('.scenario-card[data-scenario]'):null;if(!card)return;
  if(t.closest('button,a,input,select,textarea,label,summary,details,.cast-chip'))return;       // a control does its own job
  const folded=card.classList.contains('collapsed');
  if(!t.closest('.scenario-head')&&!(folded&&t===card))return;                                     // only the header (and the folded card's own background) folds or opens a card
  try{if(String(window.getSelection&&window.getSelection()||'').trim())return;}catch{}              // selecting the name's text to copy it is not a click on the card
  const id=card.dataset.scenario;if(folded)collapsedCards.delete(id);else collapsedCards.add(id);
  card.classList.toggle('collapsed',!folded);saveCollapsed();
});
let authStatus = {signedIn:null,status:'unknown',message:'Session not checked yet.'};
let collectorUi = {active:false,startedAt:0,lastIncreaseAt:0,lastCurrent:0,lastSource:'',lastLogKey:'',timer:null};
const $ = id => document.getElementById(id);
const qsa = sel => [...document.querySelectorAll(sel)];

const viewMeta = {
  dashboard:['Dashboard','Research signals, local procedural scenarios, events, and performance in one place.'],
  analysis:['JuicyChat Analysis','Collect Recent + Trending data and turn it into reusable success engines locally.'],
  bonus:['Bonus Ideas','Turn a one-line bot idea into a full scenario card, score it against the collected data, and save it to Weekly Blueprint › Bonus.'],
  weekly:['Weekly Blueprint','Build, track, refresh, and adapt your weekly scenario batch without an AI service.'],
  builder:['Bot Builder','Build a finished bot from your templates. Every box, character limit and rule comes from the template itself.'],
  webpmaker:['WebP Maker','Merge MP4 clips in any order into a locally optimized animated WebP under 9.99 MB.'],
  events:['Events','Paste a full event announcement and convert it into local generation constraints.'],
  performance:['Performance','Compare predicted engagement with your bots\' actual results.'],
  engines:['Engine Library','Inspect the structural patterns measured across Recent and Trending.'],
  settings:['Settings','Configure collection targets and review the local procedural generator.']
};

// ---- hover explanations for everything in the analysis (a floating tip, so it is never clipped by a panel)
const TIPS={
  summaryHead:"A local summary of what the bots you collected have in common. It is built on your computer from the saved bots: the newest scrape plus your whole scrape history, weighted toward recent scrapes. No AI is used.",
  localChip:"Worked out on your computer from the saved bots. No AI is called, so it costs nothing.",
  dnaRelationship:"The relationship to the player (wife, ex, roommate, rival...) that appears most among the collected bots. Trending bots and higher-ranked bots count for more.",
  dnaHook:"The opening situation (a return, a discovery, a deadline, a confession...) that the collected bots use most to get the first reply.",
  dnaSetting:"The kind of place or world the collected bots are most often set in.",
  dnaArchetype:"The personality archetype (Tsundere, Kuudere...) that shows up most among the collected bots, when one clearly leads.",
  metricRecent:"How many bots were collected from JuicyChat's Recent feed: the newest bots.",
  metricTrending:"How many bots were collected from the Trending feed: the bots people are chatting with right now.",
  metricUnique:"How many different bots there are across both samples. A bot in both lists counts once. A bigger unique sample makes the analysis more reliable.",
  metricEngines:"How many success engines were measured. An engine is a repeatable combination of relationship + opening hook + setting that the collected bots share.",
  metricProgress:"How many of this week's cards are marked Built out of this week's target.",
  metricAvg:"The average Success Estimate of this week's cards. It is an estimate from your collected data, not a result.",
  metricBest:"The week's card with the highest Success Estimate.",
  sourceTop:"The most common relationship + hook + setting combination in this list.",
  sourceMedian:"The middle visible engagement number across this list: half the bots have more, half have less. A few huge bots do not distort it.",
  sourceAvg:"The average visible engagement (the chat and like numbers the page shows) across this list. A few huge bots can pull it up.",
  engineRank:"Rank among the measured engines. #1 is the strongest.",
  engineStrength:"How strong this engine is, from 35 to 99. It combines how often the engine appears with extra weight for Trending bots, high ranks and engagement, plus a small bonus (up to +5) when your own bots on this engine got conversations.",
  engineBots:"How many collected bots use this engine, and what share of the whole sample that is.",
  engineRT:"R = how many of those bots came from Recent, T = from Trending. More T means the engine holds attention, not just newly posted bots.",
  engineTrend:"Where the engine shows up: stronger in Trending (keeps people chatting), stronger in Recent (new and rising), mainly in one list, or stable across both.",
  engineSat:"Saturation is how crowded the engine is. High = more than 18% of the sample uses it, Medium = more than 9%. A crowded engine needs a fresher twist to stand out.",
  engineMomentum:"Whether the engine is gaining or losing share among the newest bots compared with older scrapes (needs scrapes on different days). Rising = 1.3x or more, Fading = 0.75x or less.",
  engineConf:"How much evidence stands behind the engine: High = 12 or more bots, Medium = 6 or more, Low = fewer.",
  enginePct:"The share of the whole collected sample that uses this engine.",
  mechanism:"How the engine works: the emotional stake, the opening hook and the setting that keep the pressure repeating.",
  whyWorks:"Why bots built this way keep people chatting.",
  historyPanel:"Every bot you collect is kept. Engines are measured on the whole history, weighted toward recent scrapes, with extra credit for bots that stay on Trending.",
  botsAnalyzed:"The bots the analysis was built from, with their rank in each feed.",
  successEstimate:"A score out of 100 for how well this idea should do, judged against the bots you collected from Recent and Trending: how well it matches a measured success engine, how the most similar collected bots perform, whether similar bots sit on Trending, how clear the opening and the relationship are, and (when an event is on) event fit and your own past results. It is an estimate from your data, not a guarantee.",
  band:"The Success Estimate in words: Strong = 75 or more, Promising = 60 to 74, Average = 45 to 59, Weak = under 45.",
  confidence:"How much data stands behind the Success Estimate. High = 150 or more collected bots and 6 or more similar bots found. Medium = 60 or more bots and 3 or more similar. Low = less than that, or nothing collected yet.",
  novelty:"How different this card is from the OTHER cards in the same week: 100 = nothing else this week reads like it, a low number = it overlaps heavily with another card. It compares this card's Scene Name and Setup with every other card's. It is not a prediction of success (that is the Success Estimate, which looks at the collected Recent and Trending bots). It only nudges the estimate: a small bonus at 75 or more, a penalty under 45.",
  observedEngine:"The measured success engine this card was built on, or matches best.",
  learned:"Real results from your own bots (Performance tab) showed the estimates running high or low, so this card's estimate was moved by this many points.",
  eventTag:"The event this card is entered in. None means it is not entered in an event.",
  moved:"Each line is something that raised (+) or lowered (-) the estimate, and by how many points.",
  raise:"Changes that would raise the Success Estimate.",
  similarBots:"The collected bots whose idea is closest to this card. Similarity is how much of the story building blocks and wording they share.",
  'Matches a measured success engine':"The card shares the opening hook and/or setting (and the relationship, when the idea has one) of one of the measured engines. A story is never marked down for not having the engine's relationship. The closer the match and the stronger the engine, the more points.",
  'Crowded engine':"The best-matching engine is already very common in the collected bots, so this card needs a fresh angle to stand out. A small penalty.",
  'No measured engine match':"None of the measured engines share a relationship, opening or setting with this idea. A small penalty.",
  'How similar bots perform':"How the most similar collected bots do on engagement compared with the rest of their feed (percentile). Similar bots near the top raise the estimate; ones near the bottom lower it.",
  'Presence on Trending':"Whether similar bots are on Trending more than the sample as a whole. Trending means people keep chatting, so being over-represented there is a good sign.",
  'Similar bots in Trending top 25':"Similar bots sitting in the Trending top 25 prove the idea can reach the top. Up to +6.",
  'Saturation':"Many collected bots are very close to this idea, so it will have to compete with near copies. Up to -10.",
  'Rising in Recent':"Similar brand-new bots are already getting top-quarter engagement in Recent: the idea is catching on. Up to +5.",
  'Nothing similar collected':"No collected bot is close to this idea. That can mean an open niche, but there is no evidence either way, so no points either way.",
  'Clear opening situation':"The idea says what is happening when the chat starts, which gives the player something to react to immediately.",
  'No clear opening situation':"The idea does not yet say what is happening at the first message.",
  'Built-in relationship stakes':"The idea names a relationship to the player (wife, ex, roommate...) or says the two meet for the first time, which gives a reason to care from the first line.",
  'Fits the active event':"The card uses one of the active event's opportunity tags.",
  'Your past results with this engine':"How your own bots on this engine did compared with your average (conversations). Between -5 and +5.",
  tableSource:"Which list the bot was collected from: Recent or Trending.",
  tableRank:"The bot's position in that list when it was collected (1 = top).",
  tableEng:"The engagement number the page showed for the bot (chats and likes), scaled to a comparable estimate.",
  tableCard:"The bot's name and the text of its card as collected."
};
const tip=k=>TIPS[k]?`data-tip="${esc(TIPS[k])}"`:'';
const tipI=k=>TIPS[k]?`<span class="tip-i" tabindex="0" role="note" data-tip="${esc(TIPS[k])}">ⓘ</span>`:'';
(function(){let box=null,cur=null;
  const ensure=()=>{if(!box){box=document.createElement('div');box.id='jbs-tip';box.setAttribute('role','tooltip');document.body.appendChild(box);}return box;};
  const hide=()=>{if(box)box.style.display='none';cur=null;};
  const show=el=>{const t=el.getAttribute('data-tip');if(!t)return;const b=ensure();b.textContent=t;b.style.display='block';const r=el.getBoundingClientRect(),w=b.offsetWidth,h=b.offsetHeight;
    const x=Math.min(Math.max(8,r.left+r.width/2-w/2),Math.max(8,window.innerWidth-w-8));let y=r.top-h-8;if(y<8)y=Math.min(r.bottom+8,window.innerHeight-h-8);b.style.left=x+'px';b.style.top=y+'px';cur=el;};
  document.addEventListener('mouseover',e=>{const el=e.target&&e.target.closest?e.target.closest('[data-tip]'):null;if(el){if(el!==cur)show(el);}else if(cur)hide();});
  document.addEventListener('focusin',e=>{const el=e.target&&e.target.closest?e.target.closest('[data-tip]'):null;if(el)show(el);});
  document.addEventListener('focusout',hide);document.addEventListener('scroll',hide,true);document.addEventListener('mousedown',hide,true);
  document.addEventListener('keydown',e=>{if(e.key==='Escape')hide();});
})();
const themeNote=()=>state?.event?.parsed?.theme?" The event's theme in the personality and appearance is only adapted with the AI, which isn't connected right now.":'';
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function fmtNum(n){if(n==null||n==='')return'–';const x=Number(n);if(!Number.isFinite(x))return String(n);if(x>=1e6)return(x/1e6).toFixed(x>=1e7?0:1)+'M';if(x>=1e3)return(x/1e3).toFixed(x>=1e4?0:1)+'k';return x.toLocaleString();}
function fmtDate(s){if(!s)return'Never';const d=new Date(s);return Number.isNaN(d.getTime())?s:d.toLocaleString();}
function toast(msg,error=false){const el=$('toast');el.textContent=msg;el.className='toast show'+(error?' error':'');clearTimeout(toast.t);toast.t=setTimeout(()=>el.className='toast',4000);}
function fmtElapsedMs(ms){ms=Math.max(0,Number(ms)||0);const sec=Math.floor(ms/1000),m=Math.floor(sec/60),s=sec%60;return `${m}:${String(s).padStart(2,'0')}`;}
function setCollectorStatus(label,cls=''){const el=$('busy-status-pill');if(!el)return;el.textContent=label;el.className='busy-status-pill'+(cls?' '+cls:'');}
function collectorLog(message,kind=''){const box=$('collector-live-log');if(!box||!message)return;const now=new Date(),stamp=now.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});const line=document.createElement('div');line.className='collector-log-line'+(kind?' '+kind:'');line.innerHTML=`<span class="collector-log-time">${esc(stamp)}</span>${esc(message)}`;box.appendChild(line);while(box.children.length>500)box.removeChild(box.firstChild);box.scrollTop=box.scrollHeight;}
function startCollectorUiReset(){collectorUi.pull=null;const h=document.getElementById('pull-steps');if(h){h.classList.add('hidden');h.innerHTML='';}const g=document.getElementById('collector-stat-grid');if(g)g.classList.remove('hidden');const l=document.querySelector('.collector-progress-label span');if(l)l.textContent='Current feed';}
function startCollectorUi(){startCollectorUiReset();collectorUi.active=true;collectorUi.startedAt=Date.now();collectorUi.lastIncreaseAt=Date.now();collectorUi.lastCurrent=0;collectorUi.lastSource='';collectorUi.lastLogKey='';$('collector-live')?.classList.remove('hidden');if($('collector-live-log'))$('collector-live-log').innerHTML='';for(const [id,value] of [['collector-live-source','Preparing'],['collector-live-count','0 / 100'],['collector-source-percent','0%'],['collector-pass','0 / 260'],['collector-page-cards','0'],['collector-network','0'],['collector-duplicates','0'],['collector-stagnant','0'],['collector-batch','1 / 1'],['collector-elapsed','0:00'],['collector-stall-label','Starting']])if($(id))$(id).textContent=value;if($('collector-source-bar'))$('collector-source-bar').style.width='0%';if($('collector-overall-bar'))$('collector-overall-bar').style.width='0%';$('collector-overall-block')?.classList.add('hidden');setCollectorStatus('STARTING');collectorLog('Collector started. Waiting for the JuicyChat feed...');clearInterval(collectorUi.timer);collectorUi.timer=setInterval(()=>{if(!collectorUi.active)return;if($('collector-elapsed'))$('collector-elapsed').textContent=fmtElapsedMs(Date.now()-collectorUi.startedAt);const quiet=Date.now()-collectorUi.lastIncreaseAt;if(quiet>12000&&collectorUi.lastCurrent>0){if($('collector-stall-label'))$('collector-stall-label').textContent=`No new bots for ${Math.floor(quiet/1000)}s`;if(quiet>20000)setCollectorStatus('STALLED','stalled');}},1000);}
function stopCollectorUi(){collectorUi.active=false;clearInterval(collectorUi.timer);collectorUi.timer=null;}
// ---- bot pulls: a step list and a bar that fills, instead of the Recent/Trending scan boxes
const PULL_STEPS=[['Your bots','Reading your bots'],['Feed positions','Checking feed positions'],['Ratings','Reading SFW / NSFW / 18+ ratings']];
function updatePullProgress(p){const u=collectorUi;if(p.message&&p.message!==u.lastPullMsg){u.lastPullMsg=p.message;collectorLog(p.message,p.status==='done'||p.status==='saved'?'good':'');}u.pull=u.pull||{accountIndex:1,accountCount:1,account:'',step:0,steps:PULL_STEPS.map(x=>x[0])};const P=u.pull;
  if(p.pull){P.account=p.account||P.account;P.accountIndex=p.accountIndex||1;P.accountCount=p.accountCount||1;P.step=0;P.extra=null;}
  const ph=p.sortName||'';const i=PULL_STEPS.findIndex(x=>x[0]===ph);
  if(i>=0&&i>=P.step)P.step=i;else if(/Finding bots|Reading bot pages/.test(ph)){P.extra=ph;P.step=0;}
  const done=p.stage==='batch-done'||p.stage==='partial';
  const stepsDone=done?PULL_STEPS.length:P.step+((Number(p.target)>0&&Number(p.current)>=Number(p.target))?1:0);
  const overall=Math.round(((P.accountIndex-1)+Math.min(1,stepsDone/PULL_STEPS.length))/P.accountCount*100);
  const host=$('pull-steps');if(!host)return;host.classList.remove('hidden');
  ['collector-stat-grid'].forEach(id=>{const e=$(id);if(e)e.classList.add('hidden');});
  const lbl=document.querySelector('.collector-progress-label span');if(lbl)lbl.textContent=P.accountCount>1?`${P.account} (${P.accountIndex} of ${P.accountCount}) · overall`:`${P.account||'Your bots'} · overall`;
  if($('collector-source-percent'))$('collector-source-percent').textContent=`${done&&P.accountIndex===P.accountCount?100:overall}%`;if($('collector-source-bar'))$('collector-source-bar').style.width=(done&&P.accountIndex===P.accountCount?100:overall)+'%';
  if($('collector-live-source'))$('collector-live-source').textContent=P.account||'Your bots';
  if(done&&P.accountIndex===P.accountCount){if($('collector-source-percent'))$('collector-source-percent').textContent='100%';if($('collector-source-bar'))$('collector-source-bar').style.width='100%';}
  if($('collector-live-count'))$('collector-live-count').textContent=done?'Done':`Step ${Math.min(P.step+1,PULL_STEPS.length)} of ${PULL_STEPS.length}`;
  host.innerHTML=PULL_STEPS.map(([k,label],j)=>{const st=done||j<P.step?'done':j===P.step?'now':'next';const det=st==='now'&&Number(p.target)>0&&Number(p.current)>0?` <small>${Number(p.current)} / ${Number(p.target)}</small>`:'';
    return `<div class="ps ${st}"><span class="ps-dot">${st==='done'?'✓':st==='now'?'●':''}</span><span>${j===0&&P.extra&&st==='now'?esc(P.extra):label}${det}</span></div>`;}).join('');
}
function updateCollectorLive(p={}){if(!collectorUi.active)startCollectorUi();
  // a line from the collector's own log (a bot name, who made it, a note) is always shown, one line each, and moves no bars
  if(p.stage==='log'&&p.message){if(p.message!==collectorUi.lastPullMsg){collectorUi.lastPullMsg=p.message;collectorLog(p.message);}if(!collectorUi.pull&&$('busy-text'))$('busy-text').textContent=p.message;return;}
  // once a bot pull has started, every message belongs to it (including the final 'done')
  if(p.pull||p.source==='Mine'||collectorUi.pull){updatePullProgress(p);return;}const source=p.stage==='batch-done'?'All feeds':(p.sortName||p.source||collectorUi.lastSource||'Preparing');const current=Number(p.current)||0,known=Number(p.target)>0,target=known?Number(p.target):Math.max(1,current);if(source!==collectorUi.lastSource){collectorUi.lastSource=source;collectorUi.lastCurrent=0;collectorUi.lastIncreaseAt=Date.now();collectorLog(`Now collecting ${source}.`);}const grew=current>collectorUi.lastCurrent;if(grew){collectorUi.lastIncreaseAt=Date.now();collectorUi.lastCurrent=current;}const pct=Math.max(0,Math.min(100,Math.round(current/target*100)));if($('collector-live-source'))$('collector-live-source').textContent=source;if($('collector-live-count'))$('collector-live-count').textContent=known?`${current} / ${target}`:`${current} found`;if($('collector-source-percent'))$('collector-source-percent').textContent=`${pct}%`;if($('collector-source-bar'))$('collector-source-bar').style.width=pct+'%';if($('collector-pass'))$('collector-pass').textContent=`${Number(p.pass)||0} / ${Number(p.maxPasses)||260}`;if($('collector-page-cards'))$('collector-page-cards').textContent=Number(p.pageCards)||0;if($('collector-network'))$('collector-network').textContent=Number(p.networkRecords)||0;if($('collector-duplicates'))$('collector-duplicates').textContent=Number(p.duplicates)||0;if($('collector-stagnant'))$('collector-stagnant').textContent=Number(p.stagnantPasses)||0;if($('collector-batch'))$('collector-batch').textContent=`${Number(p.batchIndex)||1} / ${Number(p.batchCount)||1}`;if($('collector-elapsed'))$('collector-elapsed').textContent=fmtElapsedMs(Date.now()-collectorUi.startedAt);if(Number(p.overallTarget)>target||Number(p.batchCount)>1){$('collector-overall-block')?.classList.remove('hidden');const oc=Number(p.overallCurrent)||0,ot=Math.max(1,Number(p.overallTarget)||target);if($('collector-overall-count'))$('collector-overall-count').textContent=`${oc} / ${ot}`;if($('collector-overall-bar'))$('collector-overall-bar').style.width=Math.max(0,Math.min(100,Math.round(oc/ot*100)))+'%';}else $('collector-overall-block')?.classList.add('hidden');const status=String(p.status||p.stage||'collecting');if(status==='done'||status==='saved')setCollectorStatus(status==='saved'?'SAVED':'DONE','done');else if(status==='error')setCollectorStatus('ERROR','error');else if(status==='cancelled')setCollectorStatus('CANCELLED','stalled');else if(status==='cancelling')setCollectorStatus('CANCELLING','stalled');else if(status==='stalled'||Number(p.stagnantPasses)>=16)setCollectorStatus('STALLED','stalled');else if(status==='waiting'||Number(p.stagnantPasses)>=6)setCollectorStatus('WAITING','stalled');else setCollectorStatus(status==='starting'?'STARTING':'COLLECTING');if($('collector-stall-label'))$('collector-stall-label').textContent=Number(p.stagnantPasses)>=6?`No-new passes: ${Number(p.stagnantPasses)||0}`:'Scanning';if($('busy-text'))$('busy-text').textContent=p.message||`${source}: ${current}/${target}`;const key=`${p.stage}|${source}|${current}|${p.pass}|${p.status}`;if(key!==collectorUi.lastLogKey&&(p.stage!=='collecting'||grew||Number(p.pass)%5===0||Number(p.stagnantPasses)>=6)){collectorUi.lastLogKey=key;collectorLog(p.message||`${source}: ${current}/${target}`,status==='done'||status==='saved'?'good':status==='stalled'||status==='waiting'?'warn':'');}}
function busy(on,title='Working...',text='Please keep this window open.',mode='default'){ $('busy').classList.toggle('hidden',!on);$('busy-title').textContent=title;$('busy-text').textContent=text;if(on&&mode==='collector')startCollectorUi();else if(on)$('collector-live')?.classList.add('hidden');if(!on)stopCollectorUi(); }
async function runBusy(title,fn,mode='default'){try{busy(true,title,'Please keep this window open.',mode);const res=await fn();if(res)state=res;renderAll();return res;}catch(e){console.error(e);if(mode==='collector'){setCollectorStatus('ERROR','error');collectorLog(e.message||String(e),'warn');}toast(e.message||String(e),true);}finally{if(mode==='collector'){if(collectorUi.analysisDone){await holdCollectorResult();}else await new Promise(r=>setTimeout(r,collectorUi.analysisSeen?1800:350));}collectorUi.analysisSeen=false;collectorUi.analysisDone=false;busy(false);}}
// after a collection that ran the analysis, the window stays open with the result until Close is pressed (it used to vanish after two seconds)
function holdCollectorResult(){return new Promise(res=>{const c=$('collector-close'),x=$('cancel-collection');if(!c){setTimeout(res,1800);return;}stopCollectorUi();if(x)x.classList.add('hidden');c.classList.remove('hidden');document.querySelector('#busy .spinner')?.classList.add('hidden');document.querySelector('#busy .busy-head')?.classList.add('no-spin');const done=()=>{c.classList.add('hidden');if(x)x.classList.remove('hidden');document.querySelector('#busy .spinner')?.classList.remove('hidden');document.querySelector('#busy .busy-head')?.classList.remove('no-spin');c.onclick=null;res();};c.onclick=done;try{c.focus();}catch(_){}});}
function switchView(name){if(name==='builder')setTimeout(()=>window.renderBuilderUnfinished&&window.renderBuilderUnfinished(),50);qsa('.view').forEach(v=>v.classList.remove('active'));qsa('.nav-btn').forEach(b=>b.classList.toggle('active',b.dataset.view===name));$('view-'+name).classList.add('active');$('view-title').textContent=viewMeta[name][0];$('view-subtitle').textContent=viewMeta[name][1];if(name==='builder'&&window.builderOnShow)window.builderOnShow();}
{const _switchView=switchView;switchView=function(name){const m=$('ai-modal');if(m&&m.style.display!=='none'&&AI.job&&name!=='builder')aiMinimize();const r=_switchView.apply(this,arguments);if(name==='builder'&&AI.min&&AI.job)aiRestore();return r;};}   // choosing another tab while the AI box is open sends it to the corner; coming back to the Bot Builder opens it again
// the week's extra tabs (the ones the Weekly Blueprint template defines beyond the days, NTR and Bonus) are stored as "lane:<tab>"
function weekLanes(){const w=state?.week||{};return Object.keys(w).filter(k=>k.startsWith('lane:')&&Array.isArray(w[k]));}
function currentWeekAll(){const w=state?.week||{};return[...(w.scenarios||[]),...(w.ntr||[]),...(w.bonus||[]),...weekLanes().flatMap(k=>w[k])];}
const WEEK_DAYS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
const isNtrTabDef=t=>!!t&&(t.kind==='ntr'||(t.kind==='lane'&&/ntr|netorare/i.test(`${t.key||''} ${t.label||''}`.replace(/anti[\s_-]*ntr/gi,''))));
// the combined NTR tab: Likeable NTR, Preventable NTR and Post-NTR alternate over the 7 days on ONE tab (each kind keeps its own list and its own blueprint rules)
const ntrRotLanes=()=>IS_SHARE?[]:(BP&&Array.isArray(BP.tabs)?BP.tabs:[]).filter(t=>t.kind==='lane'&&t.rotation);
const cardDayOf=c=>WEEK_DAYS.includes(c&&c.day)?c.day:String(((c&&c.fields)||{})['Day Assignment']||'').trim();
function ntrTabCards(){const w=state?.week||{},out=[...(w.ntr||[]),...ntrRotLanes().flatMap(t=>w['lane:'+t.key]||[])],ix=c=>{const i=WEEK_DAYS.indexOf(cardDayOf(c));return i<0?9:i;};return ntrRotLanes().length?out.sort((a,b)=>ix(a)-ix(b)):out;}
// the tabs of the Weekly Blueprint: the seven days, then every NTR / extra tab the template defines (in its order), then Bonus.
// They come from the active blueprint, so a tab added to (or removed from) the template appears (or goes) when it is updated.
function weekTabs(){
  const src=BP&&Array.isArray(BP.tabs)&&BP.tabs.length?BP.tabs:[{kind:'ntr',key:'ntr',label:'NTR'}];
  const out=WEEK_DAYS.map(d=>({id:d,label:d,kind:'day'}));
  if(weeklyCount())for(const t of src){
    if(t.kind==='ntr'){if(!IS_SHARE)out.push({id:'NTR',label:t.label||'NTR',kind:'ntr'});}
    else if(t.kind==='lane'&&!t.rotation&&!(IS_SHARE&&isNtrTabDef(t)))out.push({id:'lane:'+t.key,label:t.label,kind:'lane',key:t.key});      // a tab that is part of the combined NTR tab shows inside it
  }
  out.push({id:'Bonus',label:'Bonus',kind:'bonus'});return out;
}
function tabInfo(id){return weekTabs().find(t=>t.id===id)||{id,label:id};}
function tabCardsAll(){const w=state?.week||{};return Object.keys(w).filter(k=>k==='scenarios'||k==='ntr'||k==='bonus'||k.startsWith('lane:')).flatMap(k=>Array.isArray(w[k])?w[k]:[]);}
function tabCards(id){const w=state?.week||{};return id==='NTR'?ntrTabCards():id==='Bonus'?(w.bonus||[]):id.startsWith('lane:')?(w[id]||[]):(w.scenarios||[]).filter(s=>s.day===id);}
function normStatus(x){return x==='Built'||x==='Published'?'Built':'Idea';}
// The tracker counts every current card: weekly scenarios, NTR, and bonus ideas.
function trackedItems(){return currentWeekAll();}
function builtCount(){const st=state?.week?.statuses||{};return trackedItems().filter(s=>normStatus(st[s.id])==='Built').length;}
function requiredCount(){const t=+state?.weekTarget;return t>0?t:trackedItems().length;}
// the desktop app doesn't support prompt(), so questions that need typing use this small window instead
function askText({title,message='',value='',placeholder='',type='text',okLabel='Save'}){return new Promise(resolve=>{
  const ov=document.createElement('div');ov.className='ask-overlay';
  ov.innerHTML=`<div class="ask-box" role="dialog" aria-modal="true"><h3>${esc(title)}</h3>${message?`<p>${esc(message)}</p>`:''}<input class="ask-input" type="${type}" ${type==='number'?'min="1" step="1"':''} placeholder="${esc(placeholder)}" value="${esc(value)}"><div class="button-row"><button class="primary ask-ok">${esc(okLabel)}</button><button class="ghost ask-cancel">Cancel</button></div></div>`;
  document.body.appendChild(ov);const inp=ov.querySelector('.ask-input');setTimeout(()=>{inp.focus();inp.select();},30);
  const done=v=>{ov.remove();resolve(v);};
  ov.querySelector('.ask-ok').onclick=()=>done(inp.value);ov.querySelector('.ask-cancel').onclick=()=>done(null);
  ov.onclick=e=>{if(e.target===ov)done(null);};inp.onkeydown=e=>{if(e.key==='Enter')done(inp.value);if(e.key==='Escape')done(null);};});}
window.askText=askText;
// Shown when an account is logged out: asks for the magic link and signs in in the background (no browser opens).
let loginPopupOpen=false;
function askMagicLink({account='tool',label='This account',message=''}={}){
  if(loginPopupOpen)return;loginPopupOpen=true;
  const ov=document.createElement('div');ov.className='ask-overlay';
  ov.innerHTML=`<div class="ask-box" role="dialog" aria-modal="true"><h3>${esc(label)} is logged out</h3><p>You need to log back in to scrape. Paste a fresh magic link from the account's email. The app signs in by itself in the background; no browser opens.</p><input class="ask-input" type="password" placeholder="https://... magic link"><p class="ask-msg" style="margin:10px 0 0"></p><div class="button-row"><button class="primary ask-ok">Sign in</button><button class="ghost ask-cancel">Not now</button></div></div>`;
  document.body.appendChild(ov);const inp=ov.querySelector('.ask-input'),msg=ov.querySelector('.ask-msg'),ok=ov.querySelector('.ask-ok');setTimeout(()=>inp.focus(),30);
  const close=()=>{loginPopupOpen=false;ov.remove();};
  const go=async()=>{const link=inp.value.trim();if(!/^https:\/\//i.test(link)){msg.textContent='Paste the full https:// magic link.';return;}
    ok.disabled=true;inp.disabled=true;msg.textContent='Signing in in the background...';
    try{
      let signed;
      if(account==='tool'){const r=await window.juicyApp.openLogin(link);signed=!!r?.ok;if(!signed)msg.textContent=r?.auth?.message||'The sign-in was not confirmed.';}
      else{state=await window.juicyApp.accountOpenLogin(account,link);signed=!!(state.accounts||{})[account]?.signedIn?.ok;if(!signed)msg.textContent='The sign-in was not confirmed. The magic link may be expired or already used.';renderAll();}
      if(signed){close();toast(`${label} is signed in. Start the collection again.`);return;}
    }catch(e){msg.textContent=e.message||String(e);}
    ok.disabled=false;inp.disabled=false;inp.focus();};
  ok.onclick=go;ov.querySelector('.ask-cancel').onclick=close;inp.onkeydown=e=>{if(e.key==='Enter')go();if(e.key==='Escape')close();};}
window.askMagicLink=askMagicLink;
async function setWeekTarget(){const cur=+state.weekTarget||'',cards=trackedItems().length;const v=await askText({title:'Weekly target',message:`How many bots do you want to build each week? Leave it empty to count every card in your week${cards?` (${cards})`:''}.`,value:cur,placeholder:'for example 5',type:'number'});if(v===null)return;const n=v.trim()===''?null:Math.round(+v);if(v.trim()!==''&&!(n>0))return toast('Enter a number of bots, like 5.',true);try{state=await window.juicyApp.weekSetTarget(n);renderAll();toast(n?`Weekly target set to ${n} bots.`:'Weekly target cleared: progress counts every card in your week.');}catch(e){toast(e.message,true);}}
function weeklyCount(){const w=state?.week||{};return(w.scenarios?.length||0)+(w.ntr?.length||0)+weekLanes().reduce((n,k)=>n+w[k].length,0);}
function bonusCount(){return state?.week?.bonus?.length||0;}
const METRIC_TIP={'Recent':'metricRecent','Trending':'metricTrending','Unique URLs':'metricUnique','Recent sample':'metricRecent','Trending sample':'metricTrending','Success engines':'metricEngines','Week progress':'metricProgress','Built':'metricProgress','Avg prediction':'metricAvg','Best candidate':'metricBest'};
function metric(label,value,detail=''){return`<div class="metric"><div class="label" ${tip(METRIC_TIP[label])}>${esc(label)}</div><div class="value">${esc(value)}</div><div class="detail">${esc(detail)}</div></div>`;}

function renderAuthStatus(status=authStatus){authStatus=status||authStatus;const el=$('session-status');if(!el)return;const cls=authStatus.status==='signed-in'?'signed-in':authStatus.status==='signed-out'?'signed-out':authStatus.status==='checking'?'checking':'unknown';const title=authStatus.status==='signed-in'?'Signed in':authStatus.status==='signed-out'?'Not signed in':authStatus.status==='checking'?'Checking session':'Session not confirmed';el.className=`session-status ${cls}`;el.innerHTML=`<span class="session-dot"></span><div><strong>${esc(title)}</strong><small>${esc(authStatus.message||'')}</small></div>`;}
async function checkSession(showToast=false){renderAuthStatus({signedIn:null,status:'checking',message:'Checking the saved JuicyChat session...'});try{const status=await window.juicyApp.authStatus();renderAuthStatus(status);if(showToast)toast(status.signedIn===true?'JuicyChat session confirmed.':status.signedIn===false?'JuicyChat is not signed in.':'Session could not be confirmed.',status.signedIn===false);return status;}catch(e){const status={signedIn:null,status:'unknown',message:e.message||String(e)};renderAuthStatus(status);if(showToast)toast(status.message,true);return status;}}
function renderEventPill(){const p=$('active-event-pill'),on=evList().filter(e=>e.active&&e.parsed);if(on.length){p.classList.remove('hidden');p.textContent=on.length===1?`Event: ${evName(on[0],evList().indexOf(on[0]))}`:`Events: ${on.length} on`;p.title=on.map(e=>evName(e,evList().indexOf(e))).join(', ');}else p.classList.add('hidden');}

function renderDashboard(){
  const d=state.datasets||{},req=requiredCount(),built=builtCount(),eng=state.engineAnalysis?.engines||[];
  $('dashboard-metrics').innerHTML=[metric('Recent sample',d.recent?.length||0,`Target ${state.settings.targetRecent}`),metric('Trending sample',d.trending?.length||0,`Target ${state.settings.targetTrending}`),metric('Success engines',eng.length,state.engineAnalysis?'Local analysis loaded':'Not analyzed'),metric('Week progress',req?`${built}/${req}`:(IS_SHARE?'0':'0/28'),req?(built>=req?'Target reached':`${Math.round(built/req*100)}% built`)+(+state.weekTarget?` · your target: ${req}`:''):(IS_SHARE?'Set a weekly target':'Generate a week'))].join('');
  {const wp=[...document.querySelectorAll('#dashboard-metrics .metric')].find(m=>/Week progress/.test(m.textContent));if(wp&&!wp.querySelector('.set-target')){wp.insertAdjacentHTML('beforeend','<button class="ghost sm set-target">🎯 Set weekly target</button>');wp.querySelector('.set-target').onclick=setWeekTarget;}}
  const signals=(state.engineAnalysis?.topSignals||[]).slice(0,8);$('dashboard-signals').innerHTML=signals.length?signals.map((x,i)=>`<div class="signal"><strong>${esc(x)}</strong><span>#${i+1}</span></div>`).join(''):'Run JuicyChat Analysis to populate this section.';
  if(!req){$('dashboard-week').innerHTML='<div class="empty">No weekly batch yet.</div>';return;}
  const pct=req?Math.min(100,Math.round(built/req*100)):0;const scores=currentWeekAll().map(x=>x.prediction?.score).filter(Number.isFinite);const avg=scores.length?Math.round(scores.reduce((a,b)=>a+b,0)/scores.length):'–';const best=currentWeekAll().filter(x=>x.prediction?.score).sort((a,b)=>b.prediction.score-a.prediction.score)[0];
  $('dashboard-week').innerHTML=`<div class="metric-grid compact">${metric('Built',`${built}/${req}`,`${pct}% complete`)}${metric('Avg prediction',avg+'/100','Local heuristic score')}${metric('Best candidate',best?best.prediction.score+'/100':'–',best?.sceneName||'No scored scenario')}</div><div class="tracker"><div class="tracker-top"><span>Build progress</span><span>${pct}%</span></div><div class="tracker-bar"><div style="width:${pct}%"></div></div></div>`;
}
function botLabel(x){const t=String(x.title||x.name||'').trim();if(t)return t;const id=String(x.url||'').match(/(\d{6,})/);return id?`Bot ${id[1]}`:'Untitled bot';}
function botChip(x){const name=esc(botLabel(x)),meta=`<small>${esc(x.source||'')} #${esc(x.rank??'–')}${x.creator?` · by ${esc(x.creator)}`:''}</small>`;return x.url?`<a class="bot-chip" href="${esc(x.url)}" target="_blank" rel="noopener" title="Open on JuicyChat">${name} ${meta}</a>`:`<span class="bot-chip">${name} ${meta}</span>`;}
function sortBots(xs){return [...xs].sort((a,b)=>(a.source===b.source?0:a.source==='Trending'?-1:1)||((Number(a.rank)||999)-(Number(b.rank)||999)));}
function engineExampleLinks(e){const xs=sortBots(e?.evidence?.examples||[]);if(!xs.length)return'';const first=xs.slice(0,10),rest=xs.slice(10);return `<div class="engine-examples"><div class="bots-heading">🤖 Bots using this engine <span>${xs.length}</span></div>${first.map(botChip).join('')}${rest.length?`<details class="bot-more"><summary>Show all ${xs.length} bot names</summary><div class="bot-chip-wrap">${rest.map(botChip).join('')}</div></details>`:''}</div>`;}
function renderAnalyzedBots(){const rec=state.datasets?.recent||[],tr=state.datasets?.trending||[];if(!rec.length&&!tr.length)return'';const col=(label,xs)=>`<div class="analyzed-col"><h5>${esc(label)} <span>${xs.length}</span></h5><ol>${sortBots(xs).map(x=>`<li><span class="bot-rank">#${esc(x.rank??'–')}</span>${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(botLabel(x))}</a>`:esc(botLabel(x))}${x.creator?`<span class="bot-by">by ${esc(x.creator)}</span>`:''}</li>`).join('')}</ol></div>`;return `<details class="analyzed-bots" open><summary ${tip('botsAnalyzed')}><span class="bots-big-title">🤖 Bots analyzed</span><span class="bots-count">${rec.length} Recent · ${tr.length} Trending</span></summary><div class="analyzed-grid">${col('Recent',rec)}${col('Trending',tr)}</div></details>`;}
function renderSourceSummary(label,src){if(!src||!src.count)return`<article class="source-summary"><h4>${esc(label)}</h4><p>No records collected.</p></article>`;const top=src.topCombination?.name||'No dominant combination';return`<article class="source-summary"><div class="source-summary-head"><h4>${esc(label)}</h4><span>${esc(src.count)} bots</span></div><p>${esc(src.narrative||'')}</p><div class="source-stat-row"><span ${tip('sourceTop')}>Top combination <strong>${esc(top.replace(/ \+ /g,' → '))}</strong></span><span ${tip('sourceMedian')}>Median visible engagement <strong>${fmtNum(src.medianEngagement)}</strong></span><span ${tip('sourceAvg')}>Average visible engagement <strong>${fmtNum(src.averageEngagement)}</strong></span></div></article>`;}

const OPP_WHY={Magic:'the core conflict depends on visible magic, so the tag is earned by the plot, not just listed',Isekai:'the premise depends on crossing into another world and its social rules',RPG:'a quest, party, guild, contract or progression system directly shapes the interaction',Kemonomimi:'the lead is a humanoid kemonomimi adult, with the animal traits part of who she is',"Monster Girl":'the lead is a clearly humanoid monster woman with human motives',Hero:'a concrete heroic duty or public reputation drives the conflict'};
function whyBlock(s,p){
  const a=state.engineAnalysis,engines=a?.engines||[],ids=s.successSignals?.engineMatches||[];
  const matched=engines.filter(e=>ids.includes(e.id));
  const named=!matched.length&&s.successSignals?.observedEngine?engines.filter(e=>e.name===s.successSignals.observedEngine):[];
  const used=matched.length?matched:named;
  let eng='';
  if(used.length){
    eng=used.map(e=>{const ex=sortBots(e.evidence?.examples||[]).slice(0,4).map(botLabel);return `<div class="why-item"><div class="why-item-head"><strong>${esc(e.name)}</strong><span>${esc(e.strength??'–')}/100</span></div>
      <p>${esc(e.whyItWorks||e.mechanism||'')}</p>
      <p class="why-evidence">Found in ${esc(e.evidence?.totalCount??0)} collected bots (${esc(e.evidence?.trendingCount??0)} Trending, ${esc(e.evidence?.recentCount??0)} Recent)${e.trend?` · ${esc(e.trend)}`:''}${e.saturationRisk?` · saturation ${esc(e.saturationRisk)}`:''}.</p>
      ${e.hookPattern?`<p><b>Hook it borrows:</b> ${esc(e.hookPattern)}</p>`:''}
      ${ex.length?`<p class="why-evidence"><b>Bots using it:</b> ${ex.map(esc).join(', ')}</p>`:''}</div>`;}).join('');
  }else{
    const lines=s.successSignals?.whyThisMayWork||[];
    eng=`<div class="why-item"><p>${a?'This scenario isn\'t linked to one of the current engines, so it was built from the Weekly Blueprint rule library.':'No engine analysis yet. Run JuicyChat Analysis, then Regenerate, to link this scenario to measured engines.'}</p>${lines.length?`<ul>${lines.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}</div>`;
  }
  let ev='';const E=evList().find(x=>x.id===s.eventKey)||null;
  if(s.eventCard===false)ev='<p class="why-evidence">This card is not an event card, so the event\'s requirements are not checked on it. It has no Event tag and is skipped by Adapt to Event. Tick <b>Event card</b> on the card to enter it.</p>';
  else if(E?.active&&E.parsed){
    const P=E.parsed,checks=p.eventChecks||[],opp=(s.opportunityTags||[]).filter(Boolean);
    const adapted=!!(s.eventTag||opp.length);
    const pts=[];
    if(!adapted)pts.push(`<li class="bad">! This scenario hasn't been adapted to <b>${esc(P.name||P.eventTag||'the event')}</b> yet. Click <b>Adapt to Event</b> to make it eligible.</li>`);
    if(P.eventTag)pts.push(`<li class="${s.eventTag===P.eventTag?'ok':'bad'}">${s.eventTag===P.eventTag?'✓':'!'} Uses the event tag <b>${esc(P.eventTag)}</b>, which the event requires for entry.</li>`);
    for(const t of opp){const ck=checks.find(c=>c.label===`${t} is in the story`);
      if(ck&&!ck.ok)pts.push(`<li class="bad">! Opportunity tag <b>${esc(t)}</b>: the story doesn't feature it yet. ${P.tagRelevanceReviewed?'The event reviews whether tags are relevant. ':''}Click <b>Adapt to Event</b> so the AI writes it into the Setup, add a ${esc(t)} detail yourself (✎ Edit), or remove the tag.</li>`);
      else pts.push(`<li class="ok">✓ Opportunity tag <b>${esc(t)}</b>: ${esc(OPP_WHY[t]||'it is built into the story, not just added as a tag')}${P.tagRelevanceReviewed?'. That matters because the event reviews whether tags are actually relevant.':'.'}</li>`);}
    if(P.opportunityTags?.length&&!opp.length&&adapted)pts.push(`<li class="bad">! Needs at least ${esc(P.minOpportunityTags||1)} of: ${esc(P.opportunityTags.join(', '))}.</li>`);
    for(const c of checks.filter(c=>!/^Event tag|Opportunity Tag|reflected in content| is in the story$/.test(c.label)))pts.push(`<li class="${c.ok?'ok':'bad'}">${c.ok?'✓':'!'} ${esc(c.label)}</li>`);
    if(P.deepEngagementIsAwardSignal)pts.push(`<li>The event rewards deep, long chats. ${findLong(s)?'This scenario has a long-engagement engine that keeps new beats coming after the first reply, which is what the judges measure.':'Add a stronger long-engagement beat, since the judges measure chat depth.'}</li>`);
    if(P.conversationRewardThreshold)pts.push(`<li>Rewards start at <b>${fmtNum(P.conversationRewardThreshold)}</b> conversations${used.length&&used.some(e=>(e.evidence?.trendingCount||0)>0)?', and this engine is already pulling Trending-level traffic in the sample, which helps it get there.':'.'}</li>`);
    const other=(P.hardRequirements||[]).filter(r=>/public|another Event Tag|created after|published/i.test(r));
    if(other.length)pts.push(`<li class="note">When you publish: ${other.map(esc).join(' · ')}.</li>`);
    ev=`<ul class="why-event">${pts.join('')}</ul>`;
  }else ev='<p class="why-evidence">No event is active, so this scenario is judged on the engines alone.</p>';
  return `<details class="why" open><summary>Why this may work</summary>
    <div class="why-section"><h5>🔥 Engines used</h5>${eng}</div>
    <div class="why-section"><h5>🎯 Event requirements${E?.active&&E.parsed?` · ${esc(E.parsed.name||E.parsed.eventTag||'')}`:''}</h5>${ev}</div></details>`;
}
function findLong(s){const f=s.fields||{};const k=Object.keys(f).find(k=>/long-engagement/i.test(k));return k&&String(f[k]||'').length>120;}
function historyPanel(){const h=state.historyStats;if(!h||!h.bots)return'';const d=x=>x?new Date(x).toLocaleDateString(undefined,{month:'short',day:'numeric'}):'';
  const list=(xs,f)=>xs.map(x=>`${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.title||'Untitled')}</a>`:esc(x.title||'Untitled')}<small>${f(x)}</small>`).join('');
  const rising=(state.engineAnalysis?.engines||[]).filter(e=>e.momentum==='Rising'||e.momentum==='New this week'),fading=(state.engineAnalysis?.engines||[]).filter(e=>e.momentum==='Fading');
  return `<details class="history-panel" ${h.scrapes>1?'open':''}><summary ${tip('historyPanel')}><span class="hp-title">📚 Learning from ${Number(h.bots).toLocaleString()} bots across ${h.scrapes} scrape${h.scrapes>1?'s':''}</span><span class="hp-sub">since ${esc(d(h.since))} · last ${esc(d(h.lastAt))}${h.lastAdded?` · ${h.lastAdded} new last time`:''}</span></summary>
  <p class="hp-note">Every collected bot is kept. Engines are measured on the whole history, weighted toward recent scrapes, with extra credit for bots that stay on Trending. ${h.scrapes<2?'Collect again on another day to start seeing what is rising and fading.':''}</p>
  <div class="hp-grid">
    <div><h5>Engines gaining ground</h5>${rising.length?rising.map(e=>`<div class="hp-row up">▲ ${esc(e.name)}<small>${esc(e.momentumDetail||'')}</small></div>`).join(''):'<p class="hp-empty">Needs a few scrapes on different days.</p>'}</div>
    <div><h5>Engines losing ground</h5>${fading.length?fading.map(e=>`<div class="hp-row down">▼ ${esc(e.name)}<small>${esc(e.momentumDetail||'')}</small></div>`).join(''):'<p class="hp-empty">Nothing fading yet.</p>'}</div>
    <div><h5>Staying on Trending</h5>${h.risers?.length?list(h.risers,x=>` · #${x.from} → #${x.to} over ${x.times} scrapes`):`<p class="hp-empty">${h.trendingRepeat?`${h.trendingRepeat} bots have been on Trending more than once.`:'Nothing has repeated on Trending yet.'}</p>`}</div>
    <div><h5>Climbed from Recent to Trending</h5>${h.graduated?.length?list(h.graduated,()=>''):'<p class="hp-empty">None spotted yet.</p>'}</div>
  </div>
  <div class="hp-actions"><button class="ghost" id="history-clear">Clear history</button></div></details>`;}
function renderAnalysis(){
  $('analysis-target-label').textContent=`${state.settings.targetRecent} Recent + ${state.settings.targetTrending} Trending`;$('analysis-last-run').textContent=state.datasets.lastCollectedAt?`Last collected ${fmtDate(state.datasets.lastCollectedAt)}`:'';
  $('dataset-metrics').innerHTML=[metric('Recent',state.datasets.recent.length,`Target ${state.settings.targetRecent}`),metric('Trending',state.datasets.trending.length,`Target ${state.settings.targetTrending}`),metric('Unique URLs',new Set([...state.datasets.recent,...state.datasets.trending].map(x=>x.url)).size,'Across both samples')].join('');
  const a=state.engineAnalysis;
  if(!a){$('analysis-summary').innerHTML='No analysis yet. Collection automatically builds this summary, or click Analyze Success Engines.';}
  else{
    const dna=a.winnerDNA||{};
    const topEngines=(a.engines||[]).slice(0,8);
    $('analysis-summary').innerHTML=`
      <div class="analysis-report">
        <div class="analysis-report-head"><div><div class="eyebrow" ${tip('summaryHead')}>WHY THE COLLECTED BOTS ARE WORKING</div><h3>${esc(a.sample?.total??((a.sample?.recent||0)+(a.sample?.trending||0)))}-bot engine summary</h3></div><span class="local-chip" ${tip('localChip')}>LOCAL · NO AI</span></div>
        <p class="analysis-lead">${esc(a.summary||'')}</p>
        ${historyPanel()}
        ${renderAnalyzedBots()}
        <div class="winner-dna-grid">
          <div><span ${tip('dnaRelationship')}>Dominant relationship</span><strong>${esc((dna.relationship||'Not detected').replace(/-/g,' '))}</strong></div>
          <div><span ${tip('dnaHook')}>Dominant opening hook</span><strong>${esc((dna.hook||'Not detected').replace(/-/g,' '))}</strong></div>
          <div><span ${tip('dnaSetting')}>Dominant setting</span><strong>${esc((dna.setting||'Not detected').replace(/-/g,' '))}</strong></div>
          <div><span ${tip('dnaArchetype')}>Archetype signal</span><strong>${esc(dna.archetype||'No dominant archetype')}</strong></div>
        </div>
        <div class="source-summary-grid">${renderSourceSummary('Recent',a.sourceSummaries?.Recent)}${renderSourceSummary('Trending',a.sourceSummaries?.Trending)}</div>
        <h4 class="section-mini-title">Strongest measured engines</h4>
        <div class="engine-summary-list">${topEngines.map((e,i)=>`<article class="engine-summary-row"><div class="engine-rank" ${tip('engineRank')}>#${i+1}</div><div class="engine-summary-main"><div class="engine-summary-title"><strong>${esc(e.name)}</strong><span ${tip('engineStrength')}>${esc(e.strength)}/100</span></div><p><b ${tip('mechanism')}>Mechanism:</b> ${esc(e.mechanism||e.description||'')}</p><p><b ${tip('whyWorks')}>Why it works:</b> ${esc(e.whyItWorks||'')}</p><div class="engine-meta"><span class="badge" ${tip('engineBots')}>${esc(e.evidence?.totalCount??0)} bots · ${esc(e.prevalencePercent??0)}%</span><span class="badge" ${tip('engineRT')}>R ${esc(e.evidence?.recentCount??0)} / T ${esc(e.evidence?.trendingCount??0)}</span>${e.momentum&&e.momentum!=='Steady'?`<span class="badge momentum ${e.momentum.toLowerCase().replace(/\s+/g,'-')}" data-tip="${esc((e.momentumDetail?e.momentumDetail+'. ':'')+TIPS.engineMomentum)}">${e.momentum==='Rising'?'▲ ':e.momentum==='Fading'?'▼ ':''}${esc(e.momentum)}</span>`:''}<span class="badge" ${tip('engineTrend')}>${esc(e.trend||'')}</span><span class="badge" ${tip('engineSat')}>Saturation ${esc(e.saturationRisk||'')}</span></div>${engineExampleLinks(e)}</div></article>`).join('')}</div>
        <details class="methodology"><summary>How the app reached this conclusion</summary><p>${esc(a.methodology||'')}</p></details>
      </div>`;
  }
  const rows=[...state.datasets.recent,...state.datasets.trending];$('bot-table').innerHTML=rows.slice(0,240).map(r=>`<tr><td><span class="source-badge ${String(r.source).toLowerCase()}">${esc(r.source)}</span></td><td>${r.rank}</td><td>${fmtNum(r.engagementEstimate)}</td><td class="cardtext"><strong>${esc(r.title||'')}</strong><br>${esc(String(r.rawText||r.description||r.anchorText||'').slice(0,700))}</td></tr>`).join('')||'<tr><td colspan="4">No bots collected.</td></tr>';
}
document.addEventListener('click',async e=>{if(e.target&&e.target.id==='history-clear'){if(!confirm('Delete the whole scrape history? The latest Recent and Trending lists stay.'))return;state=await window.juicyApp.historyClear();renderAll();toast('Scrape history cleared.');}});
function renderEngines(){
  const a=state.engineAnalysis;if(!a?.engines?.length){$('engine-library').innerHTML='No engine analysis yet.';return;}
  $('engine-library').innerHTML=`<div class="local-note">Local statistical analysis. These are measured combinations from the collected bots, not AI-written guesses.</div><div class="engine-grid">${a.engines.map(e=>`<article class="engine-card"><div class="engine-strength" ${tip('engineStrength')}>${esc(e.strength??'–')}</div><h4>${esc(e.name||e.id)}</h4><p><b ${tip('mechanism')}>Mechanism:</b> ${esc(e.mechanism||e.description||'')}</p><p><b ${tip('whyWorks')}>Why it works:</b> ${esc(e.whyItWorks||'')}</p><div class="engine-meta"><span class="badge" ${tip('engineConf')}>${esc(e.confidence||'')} confidence</span>${e.momentum&&e.momentum!=='Steady'?`<span class="badge momentum ${e.momentum.toLowerCase().replace(/\s+/g,'-')}" data-tip="${esc((e.momentumDetail?e.momentumDetail+'. ':'')+TIPS.engineMomentum)}">${e.momentum==='Rising'?'▲ ':e.momentum==='Fading'?'▼ ':''}${esc(e.momentum)}</span>`:''}<span class="badge" ${tip('enginePct')}>${esc(e.prevalencePercent??0)}% of sample</span><span class="badge" ${tip('engineTrend')}>${esc(e.trend||'')}</span><span class="badge" ${tip('engineSat')}>Saturation ${esc(e.saturationRisk||'')}</span><span class="badge" ${tip('engineRT')}>R ${esc(e.evidence?.recentCount??'–')} / T ${esc(e.evidence?.trendingCount??'–')}</span></div><details><summary>Measured pattern and evidence</summary><p><strong>Hook:</strong> ${esc(e.hookPattern||'')}<br><strong>Setup:</strong> ${esc(e.setupPattern||'')}<br><strong>Tags:</strong> ${esc((e.tagPatterns||[]).join(', '))}<br><strong>Mapped Blueprint engine:</strong> ${esc(e.recommendedScenarioEngine||'')} · ${esc(e.recommendedScenarioEngineDescription||'')}</p></details>${engineExampleLinks(e)}</article>`).join('')}</div>`;
}
let BP=null;
const bpNorm=l=>String(l||'').toLowerCase().replace(/\{\{user\}\}/g,'you').replace(/[’']/g,"'").replace(/[^a-z0-9']+/g,' ').trim();
const MOVE_TABS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
function bpType(s){if(!s)return'standard';if(s.laneTab)return s.laneTab;if(s.movedType)return s.movedType;if(s.series==='ANTI-NTR Series'&&!s.bonusIdea&&s.slot!=='Bonus'&&BP&&BP.types&&BP.types.antintr)return'antintr';if(s.bonusIdea||s.slot==='Bonus')return'bonus';if(s.slot==='NTR'||s.series==='Likeable NTR')return'ntr';if(/High-Reaction/i.test(String(s.slot))||/High-Reaction/i.test(String(s.series)))return'pilot';if(s.series==='Futa Friday Series')return'futa';if(/Established/i.test(String(s.slot))||/^Scenario 1/.test(String(s.slot)))return'established';return'standard';}
const BP_ANT=/antagonist|\{\{name2\}\}|name2|third party|other man|rival/i;
// fields about the antagonist never borrow the main character's answer, and the reverse
function claimedByCloser(m,n,labels){const d=Math.abs(m.length-n.length);return labels.some(o=>o!==n&&(o===m||(m.length>8&&o.length>8&&(m.includes(o)||o.includes(m))&&Math.abs(m.length-o.length)<d)));}
function bpMatch(label,fields,labels){const own=Array.isArray(labels)?[...new Set(labels.map(bpNorm))]:null;if(/\{\{name[12]\}\}/i.test(label)){const rx=new RegExp('^'+bpNorm(label.replace(/\{\{name[12]\}\}/gi,'NAMEHOLDER')).split('nameholder').map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join("[a-z' ]{2,40}")+'$');const hit=Object.keys(fields||{}).find(k=>rx.test(bpNorm(k)));if(hit)return hit;}
  const n=bpNorm(label),a=BP_ANT.test(label);return Object.keys(fields||{}).find(k=>{if(BP_ANT.test(k)!==a)return false;const m=bpNorm(k);if(m===n)return true;if(own&&claimedByCloser(m,n,own))return false;return m.length>8&&n.length>8&&(m.includes(n)||n.includes(m));});}
// a field that belongs to other cards (ANTI-NTR's Antagonist, Antagonist Appearance, The Reveal, or one marked "REQUIRED ONLY IF <series>") is not asked of this card
function bpApplies(f,s){const has=Object.keys(s.fields||{}).some(k=>bpNorm(k)===bpNorm(f.label)&&String(s.fields[k]==null?'':s.fields[k]).trim());if(has)return true;
  // a "[Mode 2] ..." field belongs to the cards written in that mode: on a card in another mode it is not shown (the writer already skips it, so "Fill with AI" had nothing to fill)
  const mm=String(f.label).match(/^\s*\[\s*Mode\s+(\d+)\s*\]/i);if(mm){const cm=s.modeNo||((String((s.fields||{})['Selected Mode']||'').match(/MODE\s*(\d+)/i)||[])[1]);if(cm&&+cm!==+mm[1])return false;}
  const series=String(s.series||'').toLowerCase(),cond=String(f.instruction||'').match(/^\s*\[?\s*(?:required|only|use)\s+only\s+(?:if|when|for)\b([^.]*)/i);
  if(cond){const named=[...cond[1].matchAll(/([A-Za-z][A-Za-z-]*(?: [A-Za-z-]+)? Series)\b/g)].map(m=>m[1].toLowerCase());if(named.length&&!named.some(n=>n===series||n.endsWith(' '+series)))return false;}
  if(/^(antagonist|antagonist appearance( requirements)?|the reveal)$/i.test(String(f.label).trim())&&['established','standard','pilot','futa'].includes(bpType(s))&&s.series!=='ANTI-NTR Series'&&!(s.cast||[]).some(x=>/antagonist|third party/i.test(x.role||'')))return false;
  return true;}
// with an uploaded blueprint (version 1+) cards follow its fields, in its order; otherwise the app's own fields
function fieldEntries(s){const t=BP&&(BP.version||s.laneTab)&&BP.types&&BP.types[bpType(s)];if(!t)return Object.entries(s.fields||{});
  const allLabels=bpType(s)==='ntr'?t.fields.map(f=>f.label):null;const rows=t.fields.filter(f=>bpApplies(f,s)).map(f=>{const k=bpMatch(f.label,s.fields,allLabels);const v=k!=null?s.fields[k]:'';return [f.label,v,f.instruction,k==null||(Array.isArray(v)?!v.length:!String(v==null?'':v).trim()),k];});
  return rows;}
function scenarioText(s){return[`${s.sceneName||''} ${s.series&&s.series!=='Standalone'?`[${s.series}]`:''}`,...fieldEntries(s).map(([k,v,ins,missing])=>`${k}:\n${missing?`(to write: ${String(ins||'').slice(0,400)})`:Array.isArray(v)?v.join(', '):v}`),policyCopyText(s)].filter(Boolean).join('\n\n');}
function raceChip(s){let r=null;try{r=window.CardRace&&window.CardRace.of(s);}catch{}return r?`<span class="cast-chip race-chip ${r.known?'':'race-guess'}" title="Race, read from ${esc(r.source)}${r.known?'':'. The card does not name a race, so this is a guess; write the race into her Appearance to change it.'}"><small>Race</small>${esc(r.race)}</span>`:'';}
function classChip(s){try{if(!/^SCP Series$/i.test(String(s.series||'')))return'';const txt=[s.sceneName,...Object.values(s.fields||{}).map(v=>Array.isArray(v)?v.join(' '):String(v==null?'':v))].join('\n');const m=txt.match(/\b(Safe|Euclid|Keter|Thaumiel|Apollyon|Archon|Unknown)[- ]class\b/i);if(!m)return'';const c=m[1][0].toUpperCase()+m[1].slice(1).toLowerCase();return `<span class="cast-chip class-chip" title="SCP Object Class, read from the card"><small>Class</small>${esc(c)}</span>`;}catch{return'';}}
// NTR tab cards: only three tags, the day, the archetype and the NTR type (Emotional NTR, Misunderstanding NTR, Light NTR, Emotional Post-NTR, Preventable NTR or Post-NTR). ANTI-NTR is never on this tab.
function ntrTypeLabel(s){const lane=`${s.laneTab||''} ${s.series||''} ${s.lane||''}`;if(/preventable/i.test(lane))return 'Preventable NTR';if(/post[\s_-]*ntr/i.test(lane))return 'Post-NTR';const N=window.NtrCanon;if(!N)return '';const t=N.typeKey((s.fields||{})['NTR Type'])||N.TYPE_BY_DAY[cardDayOf(s)]||'';return t?N.NAME[t]:'';}
function ntrKicker(s){const d0=cardDayOf(s),day=WEEK_DAYS.includes(d0)?d0:(WEEK_DAYS.find(d=>new RegExp('\\b'+d+'\\b','i').test(d0))||''),arch=s.primaryArchetype||String((s.fields||{})['Primary Archetypal Personality']||'').trim().split(/[\s,.(]/)[0],type=ntrTypeLabel(s);return `${day?`<span class="badge day-badge">${esc(day)}</span>`:''}${arch?`<span class="badge">${esc(arch)}</span>`:''}${type?`<span class="badge">${esc(type)}</span>`:''}`;}
function minorBadge(s){try{const M=window.Minors;if(!M)return'';const txt=[s.sceneName,...Object.entries(s.fields||{}).filter(([k])=>!/^(tags|scene name|name|age|race|day assignment|themes?)$/i.test(k)).map(([,v])=>typeof v==='string'?v:Array.isArray(v)?v.join(' '):''),...(s.cast||[]).map(x=>x&&x.about)].filter(Boolean).join('\n');const h=M.find(txt);return h.length?`<span class="badge minor-badge" title="Everyone in a story is 18 or older. This card mentions: ${esc(h.slice(0,4).join(', '))}. Rewrite it (Edit or Rewrite Card) so no child, teenager or school setting appears.">Mentions a minor: ${esc(h.slice(0,2).join(', '))}</span>`:'';}catch(e){return'';}}
function castStrip(s){const c=s.cast||[];if(!c.length)return'';const pi=Math.max(0,c.findIndex(x=>/^primary$/i.test(String(x.role||''))));return `<div class="cast-strip">${c.map((x,i)=>`<span class="cast-chip role-${esc(String(x.role||'').toLowerCase().replace(/\s+/g,'-'))}"><small>${esc(x.role||'')}</small>${esc(x.name)}${x.age?` <em>${esc(x.age)}</em>`:''}</span>${i===pi?raceChip(s)+classChip(s):''}`).join('')}</div>`;}
let editingBonus=null;
const CAST_ROLES=['Primary','Secondary','Antagonist','Third Party','Love Rival','Friend','Family','Other'];
function bonusEditor(s){
  const cast=[...(s.cast||[])];while(cast.length<3)cast.push({name:'',role:cast.length?'Secondary':'Primary',age:'',about:''});
  const hidden=new Set(['Antagonist','Secondary Character']);          // these come from the cast rows
  const rows=fieldEntries(s).map(([label,v,ins,missing,key])=>[key||label,v??'',ins,missing,label]).filter(([k])=>!hidden.has(k)&&k!=='Scene Name'&&k!=='Tags');
  const tags=Array.isArray(s.tags)?s.tags.join(', '):'';
  return `<div class="bonus-edit" data-id="${esc(s.id)}">
    <div class="be-row"><label>Scene name<input class="be-in" data-k="sceneName" value="${esc(s.sceneName||'')}"></label></div>
    <h5>Characters <small>(first row is the main character; leave a row's name empty to remove it)</small></h5>
    ${cast.slice(0,3).map((c,i)=>`<div class="be-cast"><input class="be-cast-in" data-i="${i}" data-f="name" value="${esc(c.name||'')}" placeholder="Name"><select class="be-cast-in" data-i="${i}" data-f="role">${CAST_ROLES.map(r=>`<option ${r===(c.role||(i?'Secondary':'Primary'))?'selected':''}>${r}</option>`).join('')}</select><input class="be-cast-in" data-i="${i}" data-f="age" value="${esc(c.age||'')}" placeholder="Age"><input class="be-cast-in wide" data-i="${i}" data-f="about" value="${esc(c.about||'')}" placeholder="Who they are"></div>`).join('')}
    <h5>Fields</h5>
    ${rows.map(([k,v,ins,missing,label])=>`<label class="be-field${missing?' needs-writing':''}"><span>${esc(label||k)}${ins?` <span class="bp-ins" title="${esc(String(ins).slice(0,1500))}">ⓘ</span>`:''}${missing?' <em class="nw">Needs writing</em>':''}</span><textarea class="be-fld" data-k="${esc(k)}" placeholder="${missing?esc(String(ins||'').slice(0,300)):''}" rows="${Math.min(10,Math.max(2,Math.ceil(String(Array.isArray(v)?v.join(', '):v).length/110)))}">${esc(Array.isArray(v)?v.join(', '):v)}</textarea></label>`).join('')}
    <label class="be-field"><span>Tags <small>(comma separated)</small></span><input class="be-in" data-k="tags" value="${esc(tags)}"></label>
    <div class="button-row be-actions"><button class="primary be-save" data-id="${esc(s.id)}">Save changes</button><button class="ghost be-cancel">Cancel</button><span class="micro">${s.slot==='Bonus'?'Saving keeps this card\'s place, Built tick and linked bot, and re-checks its success estimate. Regenerate will build from your edited version.':'Saving keeps this card\'s place, Built tick and linked bot. Regenerate replaces it with a brand-new card, so your edits would be lost.'}</span></div>
  </div>`;
}
function renderScenario(s){
  const p=s.prediction||{},status=normStatus(state.week.statuses?.[s.id]),fields=fieldEntries(s),why=s.successSignals?.whyThisMayWork||p.reasons||[];
  return `<article class="scenario-card status-${esc(status)}${cardCollapsed(s)?' collapsed':''}" data-scenario="${esc(s.id)}"><div class="scenario-head" title="Click the empty space to fold or open this card"><div><div class="scenario-kicker">${activeDay==='NTR'?ntrKicker(s):`<span>${s.movedFrom?`Moved from ${esc(s.movedFrom)}`:esc(s.slot||'')}</span><span>•</span><span>${esc(s.seriesLabel||s.lane||s.series||'')}</span>${s.primaryArchetype?`<span class="badge">${esc(s.primaryArchetype)}</span>`:''}`}${minorBadge(s)}${s.blankSlot&&!s.imported&&!s.aiWritten&&!s.localWritten?`<span class="badge" title="The app has no story writer for ${esc(s.series||'this slot')}, so this card is empty: write it with AI, upload your own or fill it in.">Needs writing</span>`:''}</div>${s.preventableSeed?`<div class="pv-mode-row"><label class="micro">Mode <select class="pv-mode" data-id="${esc(s.id)}">${pvModeOptions(s).map(([n,l])=>`<option value="${n}" ${(s.modeNo||1)===n?'selected':''}>${esc(l)}</option>`).join('')}</select></label></div>`:''}<h3>${esc(s.sceneName||'Untitled Scenario')}</h3>${castStrip(s)}</div><div class="scenario-actions"><div class="score-block" ${tip('successEstimate')}><div class="score-num"><b>${esc(p.score??'–')}</b><span>/100</span></div><small ${tip('confidence')}>${esc(p.confidence||'–')} confidence</small></div><label class="built-toggle ${status==='Built'?'on':''}"><input type="checkbox" class="built-check" data-id="${esc(s.id)}" ${status==='Built'?'checked':''}><span class="bt-box">${status==='Built'?'✓':''}</span><span>Built</span></label>${evList().length>=2?eventPickHtml(s):`<label class="built-toggle event-toggle ${s.eventCard===false?'off':'on'}" title="${s.eventCard===false?'Not entered in the event: no Event tag, and Adapt to Event skips it. Tick to enter it.':'Entered in the event. Untick for a card that is not part of it (for example the SCP series): it loses the Event tag and is skipped by Adapt to Event.'}"><input type="checkbox" class="event-check" data-id="${esc(s.id)}" ${s.eventCard===false?'':'checked'}><span class="bt-box">${s.eventCard===false?'':'✓'}</span><span>Event card</span></label>`}${policyToggle(s)}<button class="copy-btn copy-scenario" data-id="${esc(s.id)}">⧉ Copy</button><button class="secondary regen-scenario" data-id="${esc(s.id)}">Regenerate</button>${evList().some(e=>e.active&&e.parsed)?`<button class="primary adapt-event" data-id="${esc(s.id)}">❖ Adapt to Event</button>`:''}${(window.builderSavedFor?window.builderSavedFor(s.id):[]).length?`<button class="secondary open-saved" data-id="${esc(s.id)}" title="Open the bot you saved for this card in the Bot Builder">📄 Saved bot</button>`:''}${(()=>{const n=fieldEntries(s).filter(e=>e[3]).length;return n?`<button class="primary ai-fill ai-only" data-id="${esc(s.id)}" style="${AI.on?'':'display:none'}" title="Send the whole card to the AI, which writes only the ${n} blank section${n>1?'s':''} and touches nothing else.">✦ Fill ${n} blank${n>1?'s':''} with AI</button>`:'';})()}${/\bscp\b/i.test([s.series,s.seriesLabel,s.lane,s.type,s.slot].filter(Boolean).join(' '))?`<button class="ghost scp-num" data-id="${esc(s.id)}" title="Change this card's SCP number without the AI rewriting it: the main character's name and the Scene Name prefix become the new number, everything else stays.">SCP number</button>`:''}${s.slot==='Bonus'||s.bonusIdea?'':`<button class="ghost ai-card ai-only" data-id="${esc(s.id)}" style="${AI.on?'':'display:none'}" title="Have the AI scrap and rewrite only this card, in its own request. The card is saved as soon as it is finished and nothing else changes.">✦ Rewrite Card</button>`}<button class="ghost week-improve" data-id="${esc(s.id)}" title="Ideas to consider adding or tweaking, read from this scenario">${sugWeekOpen===s.id?'Close':'💡 Suggestions'}</button><button class="ghost edit-bonus" data-id="${esc(s.id)}">${editingBonus===s.id?'Editing…':'✎ Edit'}</button>${(activeDay==='Bonus'||MOVE_TABS.includes(activeDay))&&!(s.blankSlot&&!s.imported&&!s.aiWritten&&!s.localWritten)?`<button class="ghost card-move" data-id="${esc(s.id)}" title="Move this card to another tab (Monday to Sunday or Bonus). It goes to the top of that tab.">↗ Move</button>`:''}<button class="ghost card-paste" data-id="${esc(s.id)}" title="Paste a whole scenario into this card: the app reads its name, scene name, race, setup and every other section for you">📋 Paste scenario</button><button class="ghost card-del" data-id="${esc(s.id)}" title="Delete this card">🗑 Delete</button><button class="primary build-bot" data-id="${esc(s.id)}" title="Write this card's bot with AI. This opens the AI writing window straight away, and the app builds nothing locally.">✎ Build Bot</button>${s.slot==='Bonus'||s.bonusIdea?`<button class="ghost remove-bonus" data-id="${esc(s.id)}">Remove</button>`:''}</div></div>
    <div class="scenario-summary-grid"><div><span ${tip('observedEngine')}>Observed engine</span><strong>${esc(s.successSignals?.observedEngine||'Rule-library fallback')}</strong></div><div><span ${tip('novelty')}>Novelty ${tipI('novelty')}</span><strong>${esc(p.novelty??'–')}/100</strong></div>${p.calibrated?`<div class="cal-note" data-tip="${esc((p.calNote?p.calNote+' ':'')+TIPS.learned)}"><span>Learned adjustment</span><strong class="${p.calibrated>0?'up':'down'}">${p.calibrated>0?'+':''}${esc(p.calibrated)} from real results</strong></div>`:''}<div><span ${tip('eventTag')}>Event</span><strong>${esc(s.eventTag||'None')}</strong></div></div>
    ${s.bonusAssessment?assessHtml(s.bonusAssessment,false,s.id):''}${whyBlock(s,p)}
    ${sugWeekOpen===s.id?`<div class="week-imp">${suggestHtml(s.id)}</div>`:''}${editingBonus===s.id?bonusEditor(s):`    ${s.pasted?`<p class="pasted-note">Built from your pasted scenario: ${Object.keys(s.fields||{}).length-(s.autoFilled||[]).length} fields kept exactly as written${(s.autoFilled||[]).length?`, ${s.autoFilled.length} added by the app (marked)`:''}.</p>`:''}
    <div class="scenario-fields">${fields.map(([k,v,ins,missing])=>`<div class="scenario-field${(s.autoFilled||[]).includes(k)?' auto-filled':''}${missing?' needs-writing':''}"><strong>${esc(k)}${ins?` <span class="bp-ins" title="${esc(String(ins).slice(0,1500))}">ⓘ</span>`:''}${(s.autoFilled||[]).includes(k)?' <small>added by app</small>':''}${(s.aiFilled||[]).includes(k)?' <small>added by AI</small>':''}</strong><div>${missing?`<em class="nw">Needs writing</em> <span class="nw-ins">${esc(String(ins||'').slice(0,260))}${String(ins||'').length>260?'…':''}</span> <button class="ghost sm ai-fill ai-only" data-id="${esc(s.id)}" data-label="${esc(k)}" style="${AI.on?'':'display:none'}" title="Send the whole card to the AI and have it write just this section.">✦ Fill with AI</button>`:esc(Array.isArray(v)?v.join(', '):v)}</div></div>`).join('')}</div>${policyPanel(s)}${trackerPanel(s)}`}</article>`;
}
// the Mode choices on a Preventable NTR card are the modes in the active rulebook (BP.modes), so they change when the rulebook does
function pvModeOptions(s){const nice=t=>String(t).toLowerCase().replace(/(^|[\s/(])([a-z])/g,(m,a,b)=>a+b.toUpperCase());
  const list=(BP&&BP.modes&&BP.modes.length)?BP.modes:[{no:1,name:'PREVENT THE DRIFT',isDefault:true}];
  const opts=list.map(m=>[m.no,`Mode ${m.no} – ${nice(m.name)}${m.isDefault?' (default)':''}${m.creatorOnly?' (creator selection only)':''}`]);
  if(s.modeNo&&!list.some(m=>m.no===s.modeNo))opts.push([s.modeNo,`${s.mode||'Mode '+s.modeNo} (no longer in your rulebook)`]);return opts;}
function renderWeek(){{const ab=$('adapt-all');if(ab)ab.style.display=evList().some(e=>e.active&&e.parsed)?'':'none';}
  const week=state.week||{};if(week.weekStart)$('week-start').value=week.weekStart;const req=requiredCount(),built=builtCount(),pct=req?Math.min(100,Math.round(built/req*100)):0;
  $('week-tracker').innerHTML=req?`<div class="tracker"><div class="tracker-top"><span>${built} / ${req} built <small class="tracker-split">${weeklyCount()?`${weeklyCount()} weekly`:''}${weeklyCount()&&bonusCount()?' + ':''}${bonusCount()?`${bonusCount()} bonus`:''}</small></span><span>${built>=req?'Target reached':`${req-built} remaining`} · ${pct}% <button class="ghost sm set-target" title="How many bots you mean to build each week">🎯 ${+state.weekTarget?`Target ${req}`:'Set weekly target'}</button></span></div><div class="tracker-bar"><div style="width:${pct}%"></div></div>${week.generationMode?`<div class="micro">${esc(week.generationMode)} · ${week.validation?.warnings?.length?`${week.validation.warnings.length} validation warning(s)`:'hard-lock validation passed'}</div>`:''}</div>`:'<div class="micro">No weekly batch generated yet.</div>';
  {const tb=document.querySelector('#week-tracker .set-target');if(tb)tb.onclick=setWeekTarget;}
  const tabs=weekTabs().map(t=>t.id);if(!tabs.includes(activeDay))activeDay='Monday';
  $('week-tabs').innerHTML=tabs.map(d=>{const cards=tabCards(d),count=cards.length,done=cards.filter(s=>normStatus(week.statuses?.[s.id])==='Built').length;return`<button class="tab ${d===activeDay?'active':''} ${count&&done===count?'complete':''}" data-day="${esc(d)}" title="${done} of ${count} built">${esc(tabInfo(d).label)} <span>${done}/${count}</span></button>`;}).join('')+(activeDay.startsWith('lane:')&&!/preventable/i.test(activeDay+' '+tabInfo(activeDay).label)?'':`<button class="ghost regen-tab" id="regen-tab" title="Rebuild every card in this tab. Cards marked Built are kept.">↻ Regenerate Tab</button>`)+(activeDay==='Bonus'?'':`<button class="ghost clear-tab" id="clear-tab" title="Empty every card in this tab that is not marked Built, back to a blank slot to write with AI, upload or fill in yourself. The cleared cards are archived.">⟲ Clear &amp; Reset Tab</button>`)+(activeDay==='Bonus'?'':`<button class="ghost ai-tab" id="ai-tab" style="${AI.on?'':'display:none'}" title="Have the AI write only this tab's cards. Built cards and every other tab stay exactly as they are.">✎ Write with AI</button>`)+(activeDay==='Bonus'?'':`<button class="ghost upload-tab" id="upload-tab" title="Upload your own cards (.txt, .md or Weekly Blueprint .html) into this tab. You review them first. No AI needed.">⬆ Upload my cards</button>`)+(req?`<span class="tabs-progress" title="Built so far"><b>${built}</b> / ${req} built<i style="width:${pct}%"></i></span>`:'');
  if(!weeklyCount()&&activeDay!=='Bonus'){$('week-content').innerHTML='<div class="panel empty">Choose a week start date and click Generate Week. You can add Bonus ideas any time from the Bonus tab.</div>';return;}
  let list,title,theme='';if(activeDay==='NTR'){list=ntrTabCards();const rl=ntrRotLanes();title=rl.length?'NTR':'Likeable NTR';if(rl.length)theme='One card a day, alternating '+['Likeable NTR',...rl.map(x=>x.label)].join(' / ');}else if(activeDay.startsWith('lane:')){list=week[activeDay]||[];title=tabInfo(activeDay).label;}else if(activeDay==='Bonus'){list=week.bonus||[];title='Bonus';}else{list=(week.scenarios||[]).filter(s=>s.day===activeDay);title=activeDay;theme=list[0]?.theme||'';}
  if(activeDay==='Bonus'){$('week-content').innerHTML=`<div class="day-heading"><h2>Bonus</h2><span>Your own bot ideas, built into full scenarios and scored against the collected data</span></div><div class="bonus-list-head"><h3>${list.length?`${list.length} bonus idea${list.length>1?'s':''}`:''}</h3><div class="button-row">${list.length?'<button id="bonus-recheck" class="ghost">Re-check all against latest data</button>':''}<button class="secondary" data-go-bonus>＋ New bonus idea</button></div></div>${list.map(renderScenario).join('')||'<div class="panel empty">No bonus ideas yet. Add one from the Bonus Ideas tab.</div>'}`;bindScenarioButtons();bindBonusList();return;}
  $('week-content').innerHTML=`<div class="day-heading"><h2>${esc(title)}</h2>${(()=>{const fx=(BP&&BP.fixedThemes)||{},want=fx[activeDay];return want&&list.length&&list.some(c=>!String(c.theme||'').toLowerCase().startsWith(want.toLowerCase()))?`<div class="fixed-warn">Your rulebook fixes ${esc(activeDay)} = ${esc(want)}, but these cards were built without it. Press Generate Week to build the week with it.</div>`:'';})()}<span>${(()=>{const p=String(theme).split(/\s+\+\s+/).filter(Boolean);return p.length>1?`<b class="th-primary" title="This day's fixed primary theme. The other theme is the secondary.">${esc(p[0])}</b> + ${esc(p.slice(1).join(' + '))}`:esc(theme);})()}</span></div>${list.map(renderScenario).join('')||'<div class="panel empty">No scenarios in this tab.</div>'}`;bindScenarioButtons();
}
const PART_LABEL={personality:'Personality',scenario:'Scenario',greeting:'Greeting',image:'Image Generation',tags:'Tags',publishing:'Publishing'};
// ---- the events: JuicyChat runs more than one, so the Events tab keeps a list (state.events) and every card is entered in one of them, or none
let evSel=null,evShown=null;
const evList=()=>(state&&state.events)||[];
const evName=(e,i)=>e.label||(e.parsed&&(e.parsed.name||e.parsed.eventTag))||`Event ${(i<0?0:i)+1}`;
function curEvent(){const l=evList();if(!l.length)return null;return l.find(e=>e.id===evSel)||l[0];}
function eventForCardId(cardId){const c=currentWeekAll().find(x=>x.id===cardId);if(!c)return undefined;if(c.eventCard===false)return null;const e=evList().find(x=>x.id===c.eventKey);return e&&e.active&&e.parsed?e:null;}
function eventPickHtml(s){const l=evList().filter(e=>e.parsed||e.raw),val=s.eventCard===false?'none':(s.eventKey||'');
  const opt=(v,t)=>`<option value="${esc(v)}" ${val===v?'selected':''}>${esc(t)}</option>`;
  return `<label class="event-pick-wrap" title="Which event this scenario is entered in. Pick No event for a card that is not part of any event."><span>Event</span><select class="event-pick" data-id="${esc(s.id)}">${opt('none','No event')}${val===''?opt('','(none is on)'):''}${l.map(e=>opt(e.id,evName(e,evList().indexOf(e))+(e.active?'':' (off)'))).join('')}</select></label>`;}
function renderEventList(){const h=$('event-list');if(!h)return;const l=evList(),cur=curEvent();if(cur)evSel=cur.id;
  h.innerHTML=`<div class="panel-head"><div><h3>Your events</h3><p>JuicyChat runs more than one event. Add each one here. When you write the week you choose which scenarios go in which event, and every scenario card has an Event menu.</p></div></div>
  <div class="ev-strip">${l.map((e,i)=>`<button type="button" class="ev-pick ${cur&&e.id===cur.id?'on':''}" data-id="${esc(e.id)}"><b>${esc(evName(e,i))}</b><small>${e.parsed?(e.active?'on':'off'):'not read yet'}</small></button>`).join('')}<button type="button" class="secondary" id="ev-add">＋ Add event</button></div>
  ${cur?`<div class="ev-edit"><label class="micro">Name <input id="ev-label" maxlength="60" value="${esc(cur.label||'')}" placeholder="${esc(cur.parsed?(cur.parsed.name||cur.parsed.eventTag||''):'Name this event')}"></label><button type="button" class="ghost" id="ev-remove">Remove this event</button></div>`:'<p class="micro">No event yet. Paste an announcement below and click Analyze Event.</p>'}`;
  h.querySelectorAll('.ev-pick').forEach(b=>b.onclick=()=>{evSel=b.dataset.id;renderEvent();});
  const add=$('ev-add');if(add)add.onclick=async()=>{try{const before=new Set(evList().map(e=>e.id));state=await window.juicyApp.addEvent('');const fresh=evList().find(e=>!before.has(e.id));evSel=fresh?fresh.id:evSel;evShown=null;renderAll();$('event-text').focus();}catch(e){toast(e.message,true);}};
  const lb=$('ev-label');if(lb)lb.onchange=async()=>{try{state=await window.juicyApp.renameEvent(cur.id,lb.value.trim());renderAll();}catch(e){toast(e.message,true);}};
  const rm=$('ev-remove');if(rm)rm.onclick=async()=>{if(!confirm(`Remove "${evName(cur,evList().indexOf(cur))}"? The scenarios that were entered in it go back to the default event.`))return;try{state=await window.juicyApp.removeEvent(cur.id);evSel=null;evShown=null;renderAll();toast('Event removed.');}catch(e){toast(e.message,true);}};}
function renderEventRulebook(){const host=$('event-rulebook');if(!host)return;const cur=curEvent(),rb=cur&&cur.rulebook;if(!cur?.parsed||!rb){host.innerHTML='';return;}
  const by=p=>rb.rules.filter(r=>r.part===p);
  host.innerHTML=`<div class="panel-head"><div><h3>❖ Event checklist</h3><p>Every bot is checked against these rules in the Bot Builder while the event is on${AI.on?', and the AI writer treats them as non-negotiable':''}. Read from the announcement by the app itself (no AI, no cost).</p></div></div>
  ${['personality','scenario','greeting','image','tags','publishing'].filter(p=>by(p).length).map(p=>`<div class="ev-part"><h5>${PART_LABEL[p]}</h5>${by(p).map(r=>`<div class="ev-rule"><b>${r.mode==='reminder'?'☐ ':''}${esc(r.requirement)}</b>${r.signs&&r.signs.length&&r.mode!=='reminder'?`<span>Recognised by: ${esc(r.signs.slice(0,12).join(', '))}${r.signs.length>12?'…':''}</span>`:r.mode==='reminder'?'<span>A reminder to tick in the Bot Builder: the app cannot check this one itself.</span>':''}</div>`).join('')}</div>`).join('')}`;}
function renderEventSkip(){const h=$('event-skip');if(!h)return;
  const skip=(state.settings&&state.settings.eventSkipSeries)||[];
  if(window.__allSeriesFor!==BP){window.__allSeriesFor=BP;window.__allSeries=null;}
  if(!window.__allSeries&&!window.__allSeriesAsking&&window.juicyApp.seriesList){window.__allSeriesAsking=true;window.juicyApp.seriesList().then(l=>{window.__allSeries=Array.isArray(l)?l:[];window.__allSeriesAsking=false;renderEventSkip();}).catch(()=>{window.__allSeries=[];window.__allSeriesAsking=false;});}
  const names=[...new Set([...skip,...(IS_SHARE?[]:['SCP Series']),...(window.__allSeries||[]),...currentWeekAll().map(c=>c.series).filter(x=>x&&/ Series$/.test(x))])].sort();
  h.innerHTML=`<div class="panel-head"><div><h3>Cards that are never in the event</h3><p>Tick a series that is not part of events (for example SCP). Its cards start with <b>Event card</b> switched off: no Event tag, and Adapt to Event skips them. You can still switch one card on by hand.</p></div></div>
  <div class="event-skip-list">${names.map(n=>`<label class="toggle-line"><input type="checkbox" class="event-skip-check" data-series="${esc(n)}" ${skip.includes(n)?'checked':''}> ${esc(n)}</label>`).join('')||'<p class="micro">Series appear here once a week has cards.</p>'}</div>`;
  h.querySelectorAll('.event-skip-check').forEach(el=>el.onchange=async()=>{const next=[...h.querySelectorAll('.event-skip-check')].filter(x=>x.checked).map(x=>x.dataset.series);try{state=await window.juicyApp.saveSettings({eventSkipSeries:next});renderAll();toast(el.checked?`${el.dataset.series} cards are no longer event cards.`:`${el.dataset.series} cards are event cards again (their Event tag comes back when you switch a card on).`);}catch(e){toast(e.message,true);}});}
function renderEvent(){renderEventList();renderEventRulebook();renderEventSkip();
  const cur=curEvent();if(evShown!==(cur?cur.id:'')){$('event-text').value=cur?cur.raw||'':'';evShown=cur?cur.id:'';}
  const p=cur&&cur.parsed,box=$('event-parsed'),actions=$('event-actions');if(!p){box.innerHTML='No event analyzed yet.';actions.classList.add('hidden');return;}actions.classList.remove('hidden');$('event-active').checked=!!cur.active;
  box.innerHTML=`${['name','eventTag','startDate','endDate','timezone'].map(k=>p[k]?`<div class="event-rule"><strong>${esc(k.replace(/[A-Z]/g,m=>' '+m).toUpperCase())}</strong><div>${esc(p[k])}</div></div>`:'').join('')}<div class="event-rule"><strong>OPPORTUNITY TAGS</strong><div>${esc((p.opportunityTags||[]).join(', ')||'None detected')}</div>${(p.opportunityTagsPosted&&JSON.stringify(p.opportunityTagsPosted)!==JSON.stringify(p.opportunityTags||[]))?`<div class="micro">Posted as: ${esc(p.opportunityTagsPosted.join(', '))}. Renamed to JuicyChat's own tag names.</div>`:''}</div>${p.theme?`<div class="event-rule"><strong>THEME</strong><div>${esc(p.theme)}</div></div>`:''}${p.setting?`<div class="event-rule"><strong>SETTING</strong><div>${esc(p.setting)}</div></div>`:''}<div class="event-rule"><strong>HARD REQUIREMENTS</strong><ul class="hard-list">${(p.hardRequirements||[]).map(x=>`<li>${esc(x)}</li>`).join('')}</ul></div>`;
}
let perfAccount='main',perfSort='placed',perfCol=null,perfFeed='all';   // perfCol: {key,dir} when a column heading was clicked
const PERF_ACCTS_ALL={main:'Main Account',ntr:'NTR Account'};let PERF_ACCTS=PERF_ACCTS_ALL;
// every card a bot can belong to: this week, earlier weeks, and cards whose score was frozen
function perfCards(key){const ntr=c=>window.CardIdentity.isNtrCard(c)||(!!c.laneTab&&/ntr|netorare/i.test(`${c.laneTab} ${c.slot||''}`.replace(/anti[\s_-]*ntr/gi,'')));const by=new Map();
  for(const c of currentWeekAll())by.set(c.id,c);for(const c of state.cardArchive||[])if(!by.has(c.id))by.set(c.id,{...c,archived:true});
  for(const [id,p] of Object.entries(state.predictionLog||{}))if(!by.has(id)&&p.sceneName)by.set(id,{id,sceneName:p.sceneName,series:p.series,slot:p.slot,day:p.day||'',prediction:{score:p.score},archived:true});
  return [...by.values()].filter(c=>key==='ntr'?ntr(c):!ntr(c));}
function botAppScore(acc,b,cards){if(b.card){const c=appScore(b.card,cards);if(c)return{...c,kind:'card'};}const a=(acc.botScores||{})[b.id];return a?{score:a.score,frozen:true,kind:'auto',retro:a.retro,at:a.at}:null;}
function appScore(cardId,cards){const f=(state.predictionLog||{})[cardId];if(f&&f.score!=null)return{score:f.score,frozen:true,at:f.frozenAt};const c=cards.find(x=>x.id===cardId);return c?.prediction?.score!=null?{score:c.prediction.score,frozen:false}:null;}
function spark(pulls,key){const pts=(pulls||[]).slice(-30);if(pts.length<2)return'<div class="perf-chart-empty">The growth chart appears after the second pull.</div>';
  const W=560,H=120,P=8,vals=pts.map(p=>p[key]||0),min=Math.min(...vals),max=Math.max(...vals),sx=i=>P+i*(W-2*P)/(pts.length-1),sy=v=>H-P-(max===min?0.5:(v-min)/(max-min))*(H-2*P);
  const d=vals.map((v,i)=>`${i?'L':'M'}${sx(i).toFixed(1)},${sy(v).toFixed(1)}`).join(' ');
  const lbl=x=>new Date(x).toLocaleDateString(undefined,{month:'short',day:'numeric'});
  return `<svg viewBox="0 0 ${W} ${H}" class="perf-spark" preserveAspectRatio="none"><path d="${d} L${sx(vals.length-1)},${H-P} L${sx(0)},${H-P} Z" class="area"/><path d="${d}" class="line"/>${vals.map((v,i)=>`<circle cx="${sx(i)}" cy="${sy(v)}" r="2.6"><title>${lbl(pts[i].at)}: ${v.toLocaleString()} ${key}</title></circle>`).join('')}</svg><div class="perf-axis"><span>${lbl(pts[0].at)}</span><span>${lbl(pts[pts.length-1].at)}</span></div>`;}
// 18+ can arrive in a different field than "rating" depending on who is looking,
// so a bot counts as 18+ by (1) a field you marked, (2) a field clearly named for
// adult content, or (3) rating code 2.
function ratingOf(b,key,detectedOnly){
  // a rating you set by hand for this bot always wins
  const ov=!detectedOnly&&(state.accounts?.[key]?.ratingOverrides||{})[b.url];if(ov)return {SFW:'0',NSFW:'1','18+':'2'}[ov];
  // then the badge read from the lounge page
  if(b.ratingLabel)return {SFW:'0',NSFW:'1','18+':'2'}[b.ratingLabel];
  const rule=(state.settings.ratingRules||{})[key];
  if(rule&&b.raw&&String(b.raw[rule.field])===String(rule.value))return '2';
  if(b.raw)for(const [k,v] of Object.entries(b.raw))if(/r18|18plus|adult|mature|over18/i.test(k)&&(v===true||v===1||v==='1'||v==='true'))return '2';
  return b.rating;
}
function ratingCheck(bots,key){
  const fields={};for(const b of bots)for(const [k,v] of Object.entries(b.raw||{})){(fields[k]=fields[k]||{})[String(v)]=((fields[k]||{})[String(v)]||0)+1;}
  const cand=Object.entries(fields).filter(([,vals])=>{const n=Object.keys(vals).length;return n>=2&&n<=6;}).sort((a,b)=>(/rat|nsfw|adult|18|level|grade|mature|content|audit/i.test(b[0])-/rat|nsfw|adult|18|level|grade|mature|content|audit/i.test(a[0])));
  if(!bots.some(b=>b.raw))return '<p class="micro">Pull again with this version to see which fields JuicyChat sends for each bot.</p>';
  if(!cand.length)return '<p class="micro">JuicyChat sent no field that splits these bots into groups.</p>';
  const rule=(state.settings.ratingRules||{})[key];
  return `<p class="micro">Every field JuicyChat sent that splits these bots into a few groups, with how many bots have each value. If one of these matches your 18+ count, mark it and the split above will use it.</p><div class="rc-list">${cand.slice(0,14).map(([f,vals])=>`<div class="rc-row"><b>${esc(f)}</b>${Object.entries(vals).sort((a,b)=>b[1]-a[1]).map(([v,n])=>`<span class="rc-val ${rule&&rule.field===f&&String(rule.value)===v?'on':''}">${esc(v)} <i>${n}</i><button class="rc-mark" data-field="${esc(f)}" data-value="${esc(v)}" title="Count bots with ${esc(f)} = ${esc(v)} as 18+">${rule&&rule.field===f&&String(rule.value)===v?'✓ 18+':'mark 18+'}</button></span>`).join('')}</div>`).join('')}</div>${rule?`<button class="ghost rc-clear">Stop using ${esc(rule.field)} = ${esc(rule.value)}</button>`:''}`;
}
// ---- readable line chart: real time axis, value axis, hover anywhere
let perfChartMetric='chats';
function niceTicks(min,max,n=4){if(max===min){max=min+1;}const span=max-min,step0=span/n,mag=Math.pow(10,Math.floor(Math.log10(step0))),step=[1,2,2.5,5,10].map(m=>m*mag).find(x=>x>=step0)||10*mag;const lo=Math.floor(min/step)*step,hi=Math.ceil(max/step)*step,out=[];for(let v=lo;v<=hi+step/2;v+=step)out.push(v);return out;}
const fmtK=n=>Math.abs(n)>=1e6?(n/1e6).toFixed(n%1e6?1:0)+'M':Math.abs(n)>=1e4?(n/1e3).toFixed(n%1e3?1:0)+'k':Math.round(n).toLocaleString();
// axis labels carry just enough precision for the gap between ticks (1.511M, 1.512M ... not 1.5M, 1.5M)
function fmtTick(v,step){const a=Math.abs(v);if(step<1000&&a<1e5)return Math.round(v).toLocaleString();
  const [div,suf]=a>=1e6?[1e6,'M']:a>=1e3?[1e3,'k']:[1,''];const dec=Math.max(0,Math.min(3,Math.ceil(-Math.log10(step/div)+1e-9)));return (v/div).toFixed(dec).replace(/\.0+$/,'')+suf;}
function lineChart(pts,{label='chats',height=190}={}){
  pts=pts.filter(p=>p&&isFinite(p.t)&&isFinite(p.v)).sort((a,b)=>a.t-b.t);
  if(pts.length<2)return `<div class="perf-chart-empty">The chart fills in after the next pull${pts.length?` (1 point so far: ${pts[0].v.toLocaleString()} ${label})`:''}.</div>`;
  const W=760,H=height,L=58,R=14,T=12,B=34,t0=pts[0].t,t1=pts[pts.length-1].t,vs=pts.map(p=>p.v);
  const ticks=niceTicks(Math.min(...vs),Math.max(...vs)),y0=ticks[0],y1=ticks[ticks.length-1];
  const sx=t=>L+(t1===t0?0.5:(t-t0)/(t1-t0))*(W-L-R),sy=v=>T+(1-(v-y0)/Math.max(1e-9,y1-y0))*(H-T-B);
  const span=t1-t0,sameDay=new Date(t0).toDateString()===new Date(t1).toDateString();
  const xl=t=>new Date(t).toLocaleString(undefined,span<2*864e5?{hour:'numeric',minute:'2-digit',...(sameDay?{}:{month:'short',day:'numeric'})}:{month:'short',day:'numeric'});
  const xt=[...Array(5).keys()].map(i=>t0+span*i/4);
  const d=pts.map((p,i)=>`${i?'L':'M'}${sx(p.t).toFixed(1)},${sy(p.v).toFixed(1)}`).join(' ');
  const data=JSON.stringify(pts.map(p=>[p.t,p.v]));
  return `<div class="lc" data-pts='${esc(data)}' data-label="${esc(label)}" data-l="${L}" data-r="${R}" data-w="${W}" data-t0="${t0}" data-t1="${t1}"><svg viewBox="0 0 ${W} ${H}" class="lc-svg" preserveAspectRatio="none">
    ${ticks.map(v=>`<line x1="${L}" x2="${W-R}" y1="${sy(v)}" y2="${sy(v)}" class="lc-grid"/><text x="${L-8}" y="${sy(v)+4}" class="lc-y">${fmtTick(v,ticks[1]-ticks[0])}</text>`).join('')}
    ${xt.map((t,i)=>`<text x="${sx(t)}" y="${H-12}" class="lc-x" text-anchor="${i===0?'start':i===4?'end':'middle'}">${esc(xl(t))}</text>`).join('')}
    <path d="${d} L${sx(t1)},${sy(y0)} L${sx(t0)},${sy(y0)} Z" class="lc-area"/><path d="${d}" class="lc-line"/>
    ${pts.map(p=>`<circle cx="${sx(p.t)}" cy="${sy(p.v)}" r="3.4" class="lc-dot"/>`).join('')}
    <line class="lc-cross" x1="0" x2="0" y1="${T}" y2="${H-B}" style="display:none"/><circle class="lc-hot" r="6" style="display:none"/></svg><div class="lc-tip" style="display:none"></div></div>`;
}
function bindCharts(){qsa('.lc').forEach(box=>{if(box.__bound)return;box.__bound=true;const pts=JSON.parse(box.dataset.pts),svg=box.querySelector('svg'),tip=box.querySelector('.lc-tip'),cross=box.querySelector('.lc-cross'),hot=box.querySelector('.lc-hot'),circles=[...box.querySelectorAll('.lc-dot')];
  const W=+box.dataset.w,L=+box.dataset.l,R=+box.dataset.r,t0=+box.dataset.t0,t1=+box.dataset.t1,label=box.dataset.label;
  const move=e=>{const r=svg.getBoundingClientRect(),x=(e.clientX-r.left)/r.width*W,t=t0+(Math.min(W-R,Math.max(L,x))-L)/(W-L-R)*(t1-t0);
    let i=0;for(let k=1;k<pts.length;k++)if(Math.abs(pts[k][0]-t)<Math.abs(pts[i][0]-t))i=k;
    const c=circles[i],cx=+c.getAttribute('cx'),cy=+c.getAttribute('cy');cross.setAttribute('x1',cx);cross.setAttribute('x2',cx);cross.style.display='';hot.setAttribute('cx',cx);hot.setAttribute('cy',cy);hot.style.display='';
    const [tt,v]=pts[i],prev=i?pts[i-1][1]:null,dv=prev==null?null:v-prev;
    tip.innerHTML=`<b>${v.toLocaleString()} ${esc(label)}</b>${dv!=null?`<span class="${dv>0?'up':dv<0?'down':''}">${dv>0?'+':''}${dv.toLocaleString()} since previous pull</span>`:'<span>first pull shown</span>'}<small>${esc(new Date(tt).toLocaleString(undefined,{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}))}</small>`;
    tip.style.display='';const px=cx/W*r.width,left=Math.min(Math.max(px-80,0),r.width-170);tip.style.left=left+'px';};
  svg.addEventListener('mousemove',move);svg.addEventListener('mouseleave',()=>{tip.style.display='none';cross.style.display='none';hot.style.display='none';});});}
function chartSummary(pts,label){if(pts.length<2)return'';pts=[...pts].sort((x,y)=>x.t-y.t);const a=pts[0],z=pts[pts.length-1],days=(z.t-a.t)/864e5;
  const num=(n,l)=>`<b class="${n>0?'up':n<0?'down':''}">${n>0?'+':''}${n.toLocaleString()} ${esc(l)}</b>`;
  // two stacked lines with the same layout: the last day, then everything since the first pull the chart holds
  let yb=null;for(const p of pts){if(p.t<=z.t-864e5)yb=p;else break;}
  const ytip=yb?`Compared with the pull from ${new Date(yb.t).toLocaleString(undefined,{weekday:'short',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}, the last one at least 24 hours before the newest`:'';
  const first=new Date(a.t).toLocaleDateString(undefined,{month:'short',day:'numeric'});
  return (yb?`<span class="lc-k">Since yesterday:</span><span class="lc-v" title="${esc(ytip)}">${num(z.v-yb.v,label)}</span>`:'')
    +`<span class="lc-k">Since ${esc(first)} (first pull):</span><span class="lc-v">${num(z.v-a.v,label)} <small>${pts.length} pulls${days>=1?` \u00B7 ${fmtK(Math.round((z.v-a.v)/days))}/day`:''}</small></span>`;}
let perfBot=null,perfQuery='',perfWorkView='series',accCol={key:'miss',dir:'desc'},accOpen=true;   // accCol: sort of the Prediction accuracy table
const FEED_NAMES=[['popular','Popular'],['trending','Trending'],['recent','Recent'],['new','New'],['immersive','Immersive'],['editor',"Editor's Choice"]];
const feedChips=f=>FEED_NAMES.filter(([k])=>f&&f[k]).map(([k,l])=>`<span class="feed-chip f-${k}">${l} <b>#${f[k]}</b></span>`).join('');
const RATING_LABEL={'0':'SFW','1':'NSFW','2':'18+'};
const TZ='America/Toronto';
const tsMs=v=>{if(v==null||v==='')return null;if(typeof v==='number'||/^\d+$/.test(String(v))){let t=Number(v);if(t<1e11)t*=1000;return t;}const d=Date.parse(v);return isNaN(d)?null:d;};
const median=a=>{const x=a.filter(v=>v!=null&&isFinite(v)).sort((p,q)=>p-q);if(!x.length)return null;const m=Math.floor(x.length/2);return x.length%2?x[m]:(x[m-1]+x[m])/2;};
function fansBlock(acc,b){
  const ev=(acc.events||[]).filter(e=>e.characterId===b.id&&(e.kind==='like'||e.kind==='favorite'));
  if(!acc.signedIn?.ok&&!ev.length)return `<div class="fx-note"><b>Who liked / starred</b><p class="micro">JuicyChat only shows this in the account's own notifications. Sign in to this account with its magic link (top of this tab) and the next pull fills it in.</p></div>`;
  if(!ev.length)return `<div class="fx-note"><b>Who liked / starred</b><p class="micro">No likes or stars for this bot in the notifications read so far. New ones are added on every pull.</p></div>`;
  const per=new Map();for(const e of ev){const k=e.userId||e.name;const p=per.get(k)||{name:e.name,likes:0,stars:0};if(e.kind==='like')p.likes++;else p.stars++;per.set(k,p);}
  const people=[...per.values()],allEv=(acc.events||[]).filter(e=>e.kind==='like'||e.kind==='favorite');
  const botsOf=new Map();for(const e of allEv){const k=e.userId||e.name;if(!botsOf.has(k))botsOf.set(k,new Set());botsOf.get(k).add(e.characterId);}
  const returned=[...per.keys()].filter(k=>(botsOf.get(k)||new Set()).size>1).length;
  const shared=new Map();for(const k of per.keys())for(const cid of botsOf.get(k)||[])if(cid!==b.id)shared.set(cid,(shared.get(cid)||0)+1);
  const names=new Map((acc.bots||[]).map(x=>[x.id,x.title]));const top=[...shared.entries()].sort((p,q)=>q[1]-p[1]).slice(0,3).filter(([id])=>names.has(id));
  const list=(xs,f)=>xs.slice(0,60).map(p=>`<div><span>${esc(p.name)}</span><small>${f(p)}</small></div>`).join('');
  const likers=people.filter(p=>p.likes).sort((p,q)=>q.likes-p.likes),stars=people.filter(p=>p.stars).sort((p,q)=>q.stars-p.stars);
  return `<div class="fx-note"><b>👥 Who liked / starred</b><div class="fx-pred fans"><div><span>People</span><b>${people.length}</b></div><div><span>Likers</span><b>${likers.length}</b></div><div><span>Stars</span><b>${stars.reduce((a,p)=>a+p.stars,0)}</b></div><div><span>Also on your other bots</span><b>${returned}</b></div></div>
    ${top.length?`<p class="micro">Shared crowd with ${top.map(([id,n])=>`<b>${esc(names.get(id))}</b> (${n})`).join(' · ')}</p>`:''}
    <div class="fx-two fans-lists"><div><h5>♡ Likes</h5><div class="fx-comments">${list(likers,p=>`${p.likes}×${p.stars?` · ${p.stars}★`:''}`)||'<p class="micro">None yet</p>'}</div></div><div><h5>☆ Stars</h5><div class="fx-comments">${list(stars,p=>`${p.stars}★${p.likes?` · ${p.likes} like${p.likes>1?'s':''}`:''}`)||'<p class="micro">None yet</p>'}</div></div></div></div>`;
}
function botForensics(acc,b,cards){
  const fmt=n=>n==null?'–':Number(n).toLocaleString(),snaps=(acc.snapshots||{})[b.id]||[],comments=(acc.comments||{})[b.id]||[];
  const pub=tsMs(b.created)||(snaps[0]?Date.parse(snaps[0].at):null),ageD=pub?Math.max(1/24,(Date.now()-pub)/864e5):null,perDay=ageD?b.chats/ageD:null;
  const perDayOf=x=>{const p=tsMs(x.created)||(((acc.snapshots||{})[x.id]||[])[0]?Date.parse(acc.snapshots[x.id][0].at):null);return p?(x.chats||0)/Math.max(1/24,(Date.now()-p)/864e5):null;};
  const all=(acc.bots||[]).map(x=>({x,pd:perDayOf(x)})),medAll=median(all.map(a=>a.pd));
  const prev=snaps.length>1?snaps[snaps.length-2]:null,delta=prev?b.chats-prev.chats:null;
  const deltas=(acc.bots||[]).map(x=>{const s=(acc.snapshots||{})[x.id]||[];return s.length>1?x.chats-s[s.length-2].chats:null;}).filter(v=>v!=null&&v>0),medDelta=median(deltas);
  // why it performed
  const why=[];
  if(delta!=null)why.push({hot:true,title:`${delta>=0?'+':''}${fmt(delta)} chats vs the previous pull`,sub:`Change since ${new Date(prev.at).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})}${medDelta?` · a typical bot on this account gained ${fmt(Math.round(medDelta))}`:''}`,x:medDelta&&delta>0?delta/medDelta:null});
  const lifts=(b.tags||[]).map(t=>{const w=all.filter(a=>(a.x.tags||[]).includes(t));const m=median(w.map(a=>a.pd));return{t,n:w.length,lift:m&&medAll?m/medAll:null};}).filter(l=>l.lift!=null).sort((p,q)=>q.lift-p.lift);
  for(const l of lifts)why.push({title:l.t,sub:`${l.n} of your bots · ${l.lift.toFixed(2)}× chats/day vs this account's median`,x:l.lift});
  if(perDay!=null&&medAll)why.push({title:'This bot overall',sub:`${fmt(Math.round(perDay))} chats/day · ${(perDay/medAll).toFixed(2)}× this account's median`,x:perDay/medAll});
  // when it performed
  const series=[...(pub?[{t:pub,c:0}]:[]),...snaps.map(s=>({t:Date.parse(s.at),c:s.chats}))].filter(p=>p.t).sort((p,q)=>p.t-q.t);
  const at=t=>{for(let i=1;i<series.length;i++)if(series[i].t>=t){const a=series[i-1],z=series[i];return a.c+(z.c-a.c)*(t-a.t)/Math.max(1,z.t-a.t);}return null;};
  let firstWeek=null,fwNote='';
  if(pub){const t7=pub+7*864e5;if(Date.now()<t7){firstWeek=b.chats;fwNote='so far (still in its first week)';}else{const v=at(t7);if(v!=null&&snaps.length&&Date.parse(snaps[0].at)<=t7+2*864e5){firstWeek=Math.round(v);fwNote='';}else fwNote='not tracked: this bot was already past its first week when tracking began';}}
  let spike=null;for(let i=1;i<series.length;i++){const d=series[i].c-series[i-1].c;if(!spike||d>spike.d)spike={d,t:series[i].t,span:(series[i].t-series[i-1].t)/864e5};}
  const hours=Array(24).fill(0),wd=Array(7).fill(0);
  const timed=[...comments,...(acc.events||[]).filter(e=>e.characterId===b.id)];
  for(const c of timed){const t=tsMs(c.at);if(!t)continue;const parts=new Intl.DateTimeFormat('en-US',{timeZone:TZ,hour:'numeric',hourCycle:'h23',weekday:'short'}).formatToParts(new Date(t));const h=+parts.find(p=>p.type==='hour').value,w=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(parts.find(p=>p.type==='weekday').value);hours[h%24]++;if(w>=0)wd[w]++;}
  const nC=hours.reduce((a,v)=>a+v,0),bestH=nC?hours.indexOf(Math.max(...hours)):null,bestW=nC?['Sun','Mon','Tue','Wed','Thu','Fri','Sat'][wd.indexOf(Math.max(...wd))]:null;
  const dstr=t=>new Date(t).toLocaleString(undefined,{timeZone:TZ,day:'numeric',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
  const bseries=series.filter((p,i)=>!(i&&p.c===0&&series.slice(i+1).some(q=>q.c>0))).map(p=>({t:p.t,v:p.c}));
  const chart=`<p class="lc-sum">${chartSummary(bseries,'chats')}</p>${lineChart(bseries,{label:'chats',height:170})}`;
  const bars=(arr,labels,cls)=>{const m=Math.max(...arr,1);return `<div class="fx-bars ${cls}">${arr.map((v,i)=>`<div class="fx-bar" title="${esc(labels[i])}: ${v} comment${v===1?'':'s'}"><i style="height:${Math.round(v/m*100)}%"></i><span>${labels[i]}</span></div>`).join('')}</div>`;};
  // prediction
  const ev=(state.accuracy?.evals||[]).find(e=>e.account===perfAccount&&e.botId===b.id),cardId=Object.keys(acc.links||{}).find(k=>acc.links[k]===b.id),fr=cardId?(state.predictionLog||{})[cardId]:null,card=cardId?cards.find(c=>c.id===cardId):null;
  const pred=ev?`<div class="fx-pred"><div><span>Initial score</span><b>${ev.predicted}</b></div><div><span>Actual score</span><b>${ev.actual}</b></div><div><span>Miss</span><b class="${ev.error>0?'up':ev.error<0?'down':''}">${ev.error>0?'+':''}${ev.error}</b></div><div><span>Verdict</span><b>${esc(ev.verdict)}</b></div></div>`
    :cardId?`<p class="micro">Linked to <b>${esc(card?.sceneName||fr?.sceneName||'a scenario card')}</b>${fr?` · initial score <b>${fr.score}</b> (frozen ${esc(new Date(fr.frozenAt).toLocaleDateString())})`:card?.prediction?.score!=null?` · current score <b>${card.prediction.score}</b>`:''}. It gets an actual score once it has been live 3 days and this account has 4 bots that old.</p>`
    :(()=>{const a=(acc.botScores||{})[b.id];return a?`<div class="fx-pred"><div><span>App score</span><b>${a.score}</b></div><div><span>Scored</span><b style="font-size:13px">${esc(new Date(a.at).toLocaleDateString(undefined,{month:'short',day:'numeric'}))}</b></div><div><span>When</span><b style="font-size:13px">${a.retro?'after launch':'before it performed'}</b></div><div><span>Actual score</span><b style="font-size:13px">after ${3} days live</b></div></div><p class="micro">Scored automatically from its title, description and tags against the collected market bots, never its own numbers. ${a.retro?'This bot was already live when the app first saw it, so this is a look-back score rather than a true prediction.':''}</p>`:'<p class="micro">This bot gets an automatic score on the next pull.</p>';})();
  const uniq=new Set(comments.map(c=>c.name)).size;
  const linkRow=`<div class="fx-link"><span>Built from one of your scenario cards?</span>${(()=>{const cur=Object.keys(acc.links||{}).find(k=>acc.links[k]===b.id);const opt=c=>`<option value="${esc(c.id)}" ${cur===c.id?'selected':''}>${esc(c.day?c.day+' · ':'')}${esc(c.sceneName)}${c.weekStart?` (${esc(c.weekStart)})`:''}</option>`;return `<select class="perf-link" data-bot="${esc(b.id)}"><option value="">${cur?'— unlink —':'Optional: link it to use that card\'s score'}</option><optgroup label="This week">${cards.filter(c=>!c.archived).map(opt).join('')}</optgroup><optgroup label="Earlier weeks">${cards.filter(c=>c.archived).map(opt).join('')}</optgroup></select>`;})()}<small>Bots are matched to Built cards by name automatically; this is only for ones it missed.</small></div>`;
  return `<div class="fx" id="fx"><div class="fx-head"><div><h3>${esc(b.title)}</h3><div class="fx-sub">${fmt(b.chats)} chats · ${fmt(b.likes)} likes · ${fmt(b.favorites)} favourites${ageD?` · ${ageD<1?'under a day':Math.round(ageD)+'d'} old · ${fmt(Math.round(perDay))} chats/day`:''}</div><div class="fx-tags">${(r=>{const ov=(state.accounts?.[perfAccount]?.ratingOverrides||{})[b.url],det=RATING_LABEL[ratingOf(b,perfAccount,true)]||'not read';return `<select class="rt rt-pick rt-${r==='2'?'adult':(RATING_LABEL[r]||'unknown').toLowerCase()}" data-url="${esc(b.url)}" title="Rating: click to set it yourself if it's wrong"><option value="" ${ov?'':'selected'}>${ov?`Auto (${det})`:(RATING_LABEL[r]||'Rating?')}</option>${['SFW','NSFW','18+'].map(x=>`<option value="${x}" ${ov===x?'selected':''}>${x}${ov===x?' ✎':''}</option>`).join('')}</select>`;})(ratingOf(b,perfAccount))}${(b.tags||[]).map(t=>`<span>${esc(t)}</span>`).join('')}</div>${b.description?`<p class="fx-desc">${esc(b.description.slice(0,420))}${b.description.length>420?'…':''}</p>`:''}</div><div class="fx-actions"><a href="${esc(b.url)}" target="_blank" rel="noopener" class="ghost fx-open">Open on JuicyChat ↗</a><button class="ghost" id="fx-close">Close</button></div></div>
  <div class="fx-grid"><div class="perf-card"><div class="perf-card-head"><h4>📈 Why it performed</h4></div>${why.length?why.map(w=>`<div class="fx-why ${w.hot?'hot':''}"><div><b>${esc(w.title)}</b><small>${esc(w.sub)}</small></div>${w.x!=null?`<span>${w.x.toFixed(2)}×</span>`:''}</div>`).join(''):'<p class="micro">Needs tags from the lounge data or a second pull.</p>'}</div>
  <div class="perf-card"><div class="perf-card-head"><h4>🕒 When it performed</h4><small>times in Toronto (Eastern)</small></div>
    <div class="fx-kv"><span>First published</span><b>${pub?esc(dstr(pub)):'–'}</b></div>
    <div class="fx-kv"><span>First-week chats</span><b>${firstWeek!=null?`+${fmt(firstWeek)} ${fwNote}`:esc(fwNote||'–')}</b></div>
    <div class="fx-kv"><span>Biggest jump</span><b>${spike&&spike.d>0?`+${fmt(spike.d)} chats · ${esc(new Date(spike.t).toLocaleDateString(undefined,{month:'short',day:'numeric'}))}${spike.span>1.5?` (over ${Math.round(spike.span)} days)`:''}`:'–'}</b></div>
    <div class="fx-kv"><span>Best hour</span><b>${bestH!=null?`${String(bestH).padStart(2,'0')}:00 · from ${nC} ${(acc.events||[]).some(e=>e.characterId===b.id)?'likes, stars and comments':'comment'+(nC===1?'':'s')}`:'– (no comments with times yet)'}</b></div>
    <div class="fx-kv"><span>Best weekday</span><b>${bestW||'–'}</b></div>
    <div class="fx-kv"><span>Latest pull</span><b>${snaps.length?esc(new Date(snaps[snaps.length-1].at).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})):'–'}${delta!=null?` · ${delta>=0?'+':''}${fmt(delta)}`:''}</b></div>
    ${chart}${nC?`<div class="fx-two"><div><h5>Activity by hour (Toronto)</h5>${bars(hours,[...Array(24).keys()].map(h=>String(h).padStart(2,'0')),'hours')}</div><div><h5>Activity by weekday</h5>${bars(wd,['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],'days')}</div></div>`:''}</div></div>
  <div class="perf-card fx-placed"><div class="perf-card-head"><h4>📍 Where it's placed</h4><small>JuicyChat feeds, top 500 of each, as seen by the account that pulled it</small></div>${(()=>{const fh=(acc.feedHistory||{})[b.id]||{},now=b.feeds||{};const dd=t=>t?new Date(t).toLocaleDateString(undefined,{month:'short',day:'numeric'}):'–';
    return `<div class="fx-feeds">${FEED_NAMES.map(([k,l])=>{const h=fh[k];return `<div class="fx-feed ${now[k]?'on':''}"><span>${l}</span><b>${now[k]?'#'+now[k]:'not in top 500'}</b><small>${h?`best #${h.best} (${dd(h.bestAt)}) · first seen ${dd(h.firstAt)}`:'never seen in this feed yet'}</small></div>`;}).join('')}</div>`;})()}</div>
  <div class="fx-grid"><div class="perf-card"><div class="perf-card-head"><h4>💬 Archived commenters</h4><small>${comments.length} comment${comments.length===1?'':'s'} from ${uniq} ${uniq===1?'person':'people'}, kept even after JuicyChat stops listing them</small></div>${comments.length?`<div class="fx-comments">${comments.slice(0,40).map(c=>`<div><span>${esc(c.name)}</span><small>${tsMs(c.at)?esc(dstr(tsMs(c.at))):''}</small></div>`).join('')}</div>`:'<p class="micro">No comments read yet. They are collected with every pull.</p>'}</div>
  <div class="perf-card"><div class="perf-card-head"><h4>🎯 Prediction accuracy</h4></div>${pred}${linkRow}${fansBlock(acc,b)}</div></div></div>`;
}
function renderPerformance(){if(IS_SHARE){PERF_ACCTS={main:'Your Account'};perfAccount='main';}
  const acc=(state.accounts||{})[perfAccount]||{bots:[],pulls:[],links:{},snapshots:{}},bots=acc.bots||[],pulls=acc.pulls||[],links=acc.links||{};
  const lounge=state.settings[perfAccount==='ntr'?'loungeNtr':'loungeMain']||'',cards=perfCards(perfAccount),fmt=n=>n==null?'–':Number(n).toLocaleString();
  const last=pulls[pulls.length-1],prev=pulls[pulls.length-2],delta=k=>last&&prev?last[k]-prev[k]:null;
  const chg=n=>n==null||n===0?'':`<small class="${n>0?'up':'down'}">${n>0?'+':''}${Number(n).toLocaleString()}</small>`;
  const days=last&&prev?Math.max(1/24,(Date.parse(last.at)-Date.parse(prev.at))/864e5):null;
  const snap=b=>(acc.snapshots||{})[b.id]||[],bprev=b=>{const s=snap(b);return s.length>1?s[s.length-2]:null;};
  const live=b=>{const f=Date.parse(b.created||'')||Date.parse(b.firstSeen||'')||null;return f?Math.max(1,Math.round((Date.now()-f)/864e5)):null;};
  const rows=bots.map(b=>{const p=bprev(b),d=live(b);return{...b,dc:p?b.chats-p.chats:null,dl:p?b.likes-p.likes:null,days:d,perDay:d?Math.round(b.chats/d):null,card:Object.keys(links).find(k=>links[k]===b.id)};});
  const feedRank=r=>{const f=r.feeds||{};if(perfFeed==='all'){const v=Object.values(f);return v.length?Math.min(...v):null;}return f[perfFeed]??null;};
  const feedCount=k=>rows.filter(r=>k==='all'||(r.feeds||{})[k]).length;
  const sorters={chats:(a,b)=>b.chats-a.chats,growth:(a,b)=>(b.dc??-1)-(a.dc??-1),perDay:(a,b)=>(b.perDay??-1)-(a.perDay??-1),likes:(a,b)=>b.likes-a.likes,newest:(a,b)=>(a.days??1e9)-(b.days??1e9),placed:(a,b)=>((feedRank(a)??1e9)-(feedRank(b)??1e9))||((b.chats||0)-(a.chats||0))};
  if(perfCol){const best=feedRank,rel=r=>Date.parse(r.published||r.created||'')||null;
    const val={bot:r=>String(r.title||'').toLowerCase(),score:r=>{const sc=botAppScore(acc,r,cards);return sc&&Number.isFinite(+sc.score)?+sc.score:null;},chats:r=>r.chats??null,likes:r=>r.likes??null,favorites:r=>r.favorites??null,release:rel,days:r=>r.days??null,perDay:r=>r.perDay??null,placed:r=>{const n=Object.keys(r.feeds||{}).length;return n||null;}}[perfCol.key];      // Placement sorts by how many feeds the bot is in (most first when descending); bots in no feed go last
    // the first click is ascending (A to Z, lowest first); Release Date's first click is newest first. Missing values always go last.
    const asc=perfCol.key==='release'?perfCol.dir==='desc':perfCol.dir==='asc';
    if(val)rows.sort((a,b)=>{const x=val(a),y=val(b);if(x==null&&y==null)return 0;if(x==null)return 1;if(y==null)return -1;const c=typeof x==='string'?x.localeCompare(y):x-y;if(c===0&&perfCol.key==='placed')return ((feedRank(a)??1e9)-(feedRank(b)??1e9))||((b.chats||0)-(a.chats||0));return asc?c:-c;});}
  else rows.sort(sorters[perfSort]||sorters.chats);
  const byId=new Map(cards.map(c=>[c.id,c]));
  const opt=c=>`<option value="${esc(c.id)}">${esc(c.day?c.day+' · ':'')}${esc(c.sceneName)}${c.weekStart?` (${esc(c.weekStart)})`:''}</option>`,cur=cards.filter(c=>!c.archived),old=cards.filter(c=>c.archived);
  const select=b=>`<select class="perf-link" data-bot="${esc(b.id)}"><option value="">${b.card?'— unlink —':'Link to a card…'}</option><optgroup label="This week">${cur.map(opt).join('')}</optgroup>${old.length?`<optgroup label="Earlier weeks">${old.map(opt).join('')}</optgroup>`:''}</select>`.replace(`value="${esc(b.card||'')}">`,`value="${esc(b.card||'')}" selected>`);
  const tabs=IS_SHARE?'':`<div class="perf-tabs">${Object.entries(PERF_ACCTS).map(([k,l])=>{const a=(state.accounts||{})[k]||{};return`<button class="perf-tab ${k===perfAccount?'active':''}" data-acct="${k}">${l}<span>${(a.bots||[]).length?`${(a.bots||[]).length} bots`:'not set up'}</span></button>`;}).join('')}</div>`;
  const si=acc.signedIn;
  const signBox=IS_SHARE?'':`<div class="acct-sign ${si?.ok?'on':''}">${si?.ok?`<div><b>✓ Signed in${si.userName?` as ${esc(si.userName)}`:''}</b><span class="micro">Pulls read this account's own bots directly, plus who liked, starred, commented and followed. No lounge link needed.</span></div><button class="ghost" id="acct-signout">Sign out</button>`
    :`${acc.loggedOut?`<div class="bd-warn acct-lo"><b>${esc(PERF_ACCTS[perfAccount]||'This account')} is logged out.</b> You need to log back in to scrape. Paste the magic link here to log back in.</div>`:''}<div class="acct-sign-row"><label>Sign in with this account's magic link <small>(optional: adds who liked / starred)</small><input id="acct-link" type="url" placeholder="https://www.juicychat.ai/... magic link from this account's email"></label><button class="primary" id="acct-open">Sign in</button></div><p class="micro">The sign-in runs in the background; no browser opens. Your tool account's sign-in is kept separate.</p>`}</div>`;
  const setup=IS_SHARE?`<div class="perf-lounge share-own"><div><b>${acc.signedIn?.userName?`Your bots from ${esc(acc.signedIn.userName)}`:'Your bots'}</b><span class="micro">Read straight from the account you signed in with on the JuicyChat Analysis tab: every bot you own, SFW, NSFW and 18+. No lounge link needed.</span></div><button class="primary" id="perf-pull-one">↻ Pull my bots</button></div>
    <p class="micro perf-when">${acc.pulledAt?`Last pulled ${esc(new Date(acc.pulledAt).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}))} · ${pulls.length} pull${pulls.length===1?'':'s'} recorded · pulled automatically every day at 8:00 PM Eastern`:'Not pulled yet. Sign in on the JuicyChat Analysis tab, then click Pull my bots.'}</p>`:`<div class="perf-lounge"><label>${PERF_ACCTS[perfAccount]} lounge link<input id="lounge-url" type="url" value="${esc(lounge)}" placeholder="https://www.juicychat.ai/... (the public lounge page of this account)"></label><button class="secondary" id="lounge-save">Save link</button><button class="primary" id="perf-pull-one" ${lounge||acc.signedIn?.ok?'':'disabled'}>↻ Pull ${esc(PERF_ACCTS[perfAccount])}</button></div>
    <p class="micro perf-when">${acc.pulledAt?`Last pulled ${esc(new Date(acc.pulledAt).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}))} · ${pulls.length} pull${pulls.length===1?'':'s'} recorded · pulled automatically every day at 8:00 PM Eastern`:lounge?'Not pulled yet. Click Pull, or wait for the 8:00 PM Eastern run.':'Paste the public lounge link of this account. The tool reads the bots listed there, so it never needs to sign in as this account.'}</p>`;
  const lp=acc.lastPull,noNums=lp&&lp.bots&&!lp.withNumbers;
  const details=lp?`<details class="pull-details ${noNums?'bad':''}" ${noNums?'open':''}><summary>${noNums?`⚠ Found ${lp.bots} bots but couldn't read their chat, like or favourite numbers`:`Pull details · ${lp.bots} bots, numbers read for ${lp.withNumbers}`}</summary>
    <p class="micro">Read from ${esc(lp.url||'')} · ${esc(new Date(lp.at).toLocaleString())} · numbers read ${esc((lp.modes||[]).map(m=>({labeled:'from words on the card',icons:'from the icons beside them',position:'by position (chats, likes, favourites)',data:"from JuicyChat's data",'bot page':"from each bot's own page",api:"from JuicyChat's data service",account:"from the signed-in account",none:'not found'})[m]||m).join(', '))}${lp.jsonResponses!=null?` · ${lp.jsonResponses} data responses seen`:''}${lp.ratingSource==='field'?` · ratings from your lounge's SFW / NSFW / 18+ badges (they match JuicyChat's "${esc(lp.ratingRule?.field||'')}" field)`:lp.ratingSource==='badges'?` · ratings read from the SFW / NSFW / 18+ badges on your lounge page${lp.ratingsTotal?` (${lp.ratingsRead} of ${lp.ratingsTotal} bots)`:''}`:lp.ratingsTotal!=null&&!lp.loungeUrl?' · <b>your lounge page couldn\'t be found, so ratings come from JuicyChat\'s data (18+ bots can show as NSFW): open a bot to set its rating</b>':''}</p>
    ${noNums?'<p class="micro">The page layout is different from what the tool expects. Send me a screenshot of one bot card on the lounge page plus the sample below, and I can adjust the reader to it.</p>':''}
    ${(lp.sample||[]).length?`<pre class="pull-sample">${esc(lp.sample.map(x=>`${x.title}\n  text: ${String(x.text||'').replace(/\n/g,' | ').slice(0,200)}\n  numbers: ${(x.stats||[]).map(st=>st.value).join(', ')||'none'}`).join('\n\n'))}</pre>`:''}</details>`:'';
  if(!bots.length){$('performance-content').innerHTML=tabs+signBox+setup+(lp?`<div class="pull-details bad"><b>The last pull found no bots on this lounge link.</b> <span class="micro">Check the link opens the account's lounge with its bots listed. If it does, send me a screenshot of that page.</span></div>`:'');bindPerf();return;}
  const kpi=(l,v,c,sub='')=>`<div class="perf-kpi"><span>${l}</span><b>${v}</b>${c||''}${sub?`<small class="sub">${sub}</small>`:''}</div>`;
  const tot=k=>bots.reduce((a,b)=>a+(b[k]||0),0);
  const rc={};for(const b of bots){const r=RATING_LABEL[ratingOf(b,perfAccount)]||'Unknown';rc[r]=(rc[r]||0)+1;}
  const ratingLine=`<div class="rating-split">${['SFW','NSFW','18+'].map(r=>`<span class="rt rt-${r==='18+'?'adult':r.toLowerCase()}">${r} <b>${rc[r]||0}</b></span>`).join('')}<button class="ghost sm rt-copy" title="Copy what JuicyChat reported for each bot's rating, to send for checking">Copy rating details</button>${rc.Unknown?`<span class="rt">Rating not read <b>${rc.Unknown}</b></span>`:''}</div><details class="rating-check" ${!rc['18+']?'open':''}><summary>${rc['18+']?'Rating check':'⚠ 18+ bots showing as 0? Check which field holds the rating'}</summary>${IS_SHARE?'<p class="micro">Your own bots are read from your signed-in account, so every rating is included. If 18+ still shows 0, pull again: pulls from before this version used the public lounge list.</p>':''}${!IS_SHARE&&!acc.signedIn?.ok?'<p class="micro"><b>Most reliable fix:</b> sign this account in with its magic link (box above). A creator\'s own bot list always carries the true rating. Viewed through a lounge link by an account without 18+ access, JuicyChat may report 18+ bots as NSFW.</p>':''}${ratingCheck(bots,perfAccount)}</details>`;
  const kpis=`<div class="perf-kpis">${kpi('Bots',fmt(bots.length),last?.newBots?`<small class="up">+${last.newBots} new</small>`:'')}${kpi('Total chats',fmt(tot('chats')),chg(delta('chats')),days&&delta('chats')!=null?`${fmt(Math.round(delta('chats')/days))} per day since last pull`:'')}${kpi('Total likes',fmt(tot('likes')),chg(delta('likes')))}${kpi('Favourites',fmt(tot('favorites')),chg(delta('favorites')))}${tot('views')?kpi('Views',fmt(tot('views')),chg(delta('views'))):''}${kpi('In a feed now',fmt(bots.filter(b=>Object.keys(b.feeds||{}).length).length),'',FEED_NAMES.map(([k,l])=>{const n=bots.filter(b=>(b.feeds||{})[k]).length;return n?`${l} ${n}`:'';}).filter(Boolean).join(' · '))}${kpi('Avg chats per bot',fmt(Math.round(tot('chats')/Math.max(1,bots.length))))}${kpi('Likes per 100 chats',tot('chats')?(tot('likes')/tot('chats')*100).toFixed(1):'–')}</div>`;
  const M={chats:'chats',likes:'likes',favorites:'favourites',bots:'bots'},mk=perfChartMetric;
  const firstReal=pulls.findIndex(p=>(p.chats||0)+(p.likes||0)+(p.favorites||0)>0),usable=firstReal<0?pulls:pulls.slice(firstReal),hidden=firstReal>0?firstReal:0;
  const cpts=usable.map(p=>({t:Date.parse(p.at),v:Number(p[mk])||0}));
  const chart=`<div class="perf-card"><div class="perf-card-head"><h4>Total ${M[mk]} over time</h4><div class="perf-sorts">${Object.entries(M).map(([k,l])=>`<button class="perf-sort chart-metric ${k===mk?'on':''}" data-metric="${k}">${l[0].toUpperCase()+l.slice(1)}</button>`).join('')}</div></div>
    <p class="lc-sum">${chartSummary(cpts,M[mk])}</p>${lineChart(cpts,{label:M[mk]})}</div>`;
  // what's working: every bot, grouped by series (card, description prefix or title) or by tag
  const linked=rows.filter(r=>r.card&&byId.get(r.card));
  const SER=['Bully','Dommy Mommy','Stepmom','Stepsister','Gentle Giant','Tomboy','Yandere','Bakadere','Futa Friday'];
  // Keep NTR and ANTI-NTR separate. They are opposite story types.
  // The NTR account must never gain an ANTI-NTR series from a generic /ntr/ match.
  function perfSeriesName(raw){
    const n=String(raw||'').trim().replace(/^["“”]+|["“”]+$/g,'').trim();
    if(/^(?:ANTI[\s_-]*NTR|NTR\?)(?:\s+Series)?$/i.test(n))
      return perfAccount==='ntr'?'NTR (no series)':'ANTI-NTR Series';
    if(/^(?:NTR|Netorare)(?:\s+Series)?$/i.test(n))return 'NTR (no series)';
    if(/^Likeable[\s_-]*NTR(?:\s+Series)?$/i.test(n))return 'Likeable NTR';
    if(/^Post[\s_-]*NTR(?:\s+Series)?$/i.test(n))return 'Post-NTR';
    if(/^Preventable[\s_-]*NTR(?:\s+Series)?$/i.test(n))return 'Preventable NTR';
    return n;
  }
  const seriesOf=r=>{
    const t=String(r.title||'').trim();
    // This particular NTR bot was incorrectly displayed under ANTI-NTR.
    if(perfAccount==='ntr'&&/^his mug in the sink(?:\s*[\[(].*)?$/i.test(t))
      return {name:'NTR (no series)',from:'none'};
    const c=r.card&&byId.get(r.card);
    if(c&&c.series)return {name:perfSeriesName(c.series),from:'card'};
    const d=String(r.description||'').trim();
    const m=d.match(/^\[\s*["“]?([^\]"”]*?)["”]?\s*Series\s*\d*\s*\]/i)||
      d.match(/^\[\s*["“]?(Preventable NTR)["”]?\s*\d*\s*\]/i);
    if(m){
      const n=m[1].trim(),parsed=perfSeriesName(n);
      // The series name is read from the actual prefix; not every NTR label is ANTI-NTR.
      if(/ntr|netorare/i.test(n)||parsed!==n)return {name:parsed,from:'description'};
      if(IS_SHARE)return {name:n+' Series',from:'description'};
      const hit=SER.find(x=>x.toLowerCase()===n.toLowerCase());
      return {name:(hit||n)+' Series',from:'description'};
    }
    if(!IS_SHARE&&/^your bully\b/i.test(t))return {name:'Bully Series',from:'title'};
    if(/^your step-?mom\b/i.test(t))return {name:'Stepmom Series',from:'title'};
    if(/^(your )?step-?sister/i.test(t))return {name:'Stepsister Series',from:'title'};
    return {name:perfAccount==='ntr'?'NTR (no series)':'Standalone (no series)',from:'none'};
  };
  const group=keyOf=>{const g={};for(const r of rows){for(const k of [].concat(keyOf(r)).filter(Boolean)){const x=g[k]=g[k]||{n:0,chats:0,likes:0,pd:[],best:null};x.n++;x.chats+=r.chats||0;x.likes+=r.likes||0;if(r.perDay!=null)x.pd.push(r.perDay);if(!x.best||(r.chats||0)>(x.best.chats||0))x.best=r;}}
    const med=a=>{const z=[...a].sort((p,q)=>p-q);return z.length?(z.length%2?z[(z.length-1)/2]:(z[z.length/2-1]+z[z.length/2])/2):null;};
    return Object.entries(g).map(([k,x])=>({k,...x,med:med(x.pd)}));};
  const allMed=(()=>{const z=rows.map(r=>r.perDay).filter(v=>v!=null).sort((p,q)=>p-q);return z.length?z[Math.floor(z.length/2)]:null;})();
  const bySeries=group(r=>seriesOf(r).name).sort((a,b)=>(b.med??-1)-(a.med??-1));
  const byTag=group(r=>(r.tags||[]).filter(t=>perfAccount!=='ntr'||!/^anti[\s_-]*ntr(?:\s+series)?$/i.test(String(t).trim()))).filter(x=>x.n>=3).sort((a,b)=>(b.med??-1)-(a.med??-1));
  const from={card:0,description:0,title:0,none:0};for(const r of rows)from[seriesOf(r).from]++;
  const view=perfWorkView==='tags'?byTag:bySeries;
  const workRows=view.slice(0,perfWorkView==='tags'?14:12).map(x=>`<tr><td>${esc(x.k)}</td><td>${x.n}</td><td>${x.med!=null?`${fmt(Math.round(x.med))}${allMed?` <small class="${x.med>=allMed?'up':'down'}">${(x.med/allMed).toFixed(1)}×</small>`:''}`:'–'}</td><td>${fmt(Math.round(x.chats/x.n))}</td><td>${fmt(Math.round(x.likes/x.n))}</td><td>${esc(x.best?.title||'')}</td></tr>`).join('');
  const working=`<div class="perf-card"><div class="perf-card-head"><h4>What's working on this account</h4><div class="perf-sorts"><button class="perf-sort work-view ${perfWorkView!=='tags'?'on':''}" data-view="series">By series</button><button class="perf-sort work-view ${perfWorkView==='tags'?'on':''}" data-view="tags">By tag</button></div></div>
    <p class="micro work-note">All ${rows.length} bots${perfWorkView==='tags'?`, tags used by 3 or more bots`:``}, ranked by median chats per day${allMed?` (this account's median: ${fmt(Math.round(allMed))}/day; ×1.0 = typical)`:''}.${perfWorkView!=='tags'?` Series from ${[from.card?`${from.card} linked card${from.card>1?'s':''}`:'',from.description?`${from.description} description prefix${from.description>1?'es':''}`:'',from.title?`${from.title} title${from.title>1?'s':''}`:''].filter(Boolean).join(', ')||'no series markers'}${from.none?`; ${from.none} with no series`:''}.`:''}</p>
    ${workRows?`<div class="perf-table-wrap work-wrap"><table class="perf-table"><tr><th>${perfWorkView==='tags'?'Tag':'Series'}</th><th>Bots</th><th title="Median chats per day, and how that compares with this account's median">Chats/day</th><th>Avg chats</th><th>Avg likes</th><th>Best bot</th></tr>${workRows}</table></div>`:`<p class="micro">${perfWorkView==='tags'?'No tag is used by 3 or more bots yet.':'No bots yet.'}</p>`}</div>`;
  // prediction accuracy: frozen initial score vs how the bot actually did
  const A=state.accuracy||{},cal=state.calibration||{},ev=(A.evals||[]).filter(e=>e.account===perfAccount),mat=(A.maturing||[]).filter(e=>e.account===perfAccount);
  const avg=f=>ev.length?ev.reduce((a,e)=>a+f(e),0)/ev.length:null,mae=avg(e=>Math.abs(e.error)),bias=avg(e=>e.error),hit=ev.length?Math.round(100*ev.filter(e=>Math.abs(e.error)<=12).length/ev.length):null;
  const rk=(()=>{const n=ev.length;if(n<3)return null;const r=v=>{const o=v.map((x,i)=>[x,i]).sort((a,b)=>a[0]-b[0]),out=[];o.forEach(([,i],k)=>out[i]=k);return out;},x=r(ev.map(e=>e.predicted)),y=r(ev.map(e=>e.actual));return 1-6*x.reduce((a,v,i)=>a+(v-y[i])**2,0)/(n*(n*n-1));})();
  const tone=mae==null?'':mae<=10?'good':mae<=18?'mid':'weak';
  const learned=[...Object.entries(cal.bySeries||{}).map(([k,v])=>({k,v,type:'series'})),...Object.entries(cal.byEngine||{}).map(([k,v])=>({k:(state.engineAnalysis?.engines||[]).find(e=>e.id===k)?.name||k,v,type:'engine'}))].filter(x=>x.v.adj).sort((a,b)=>Math.abs(b.v.adj)-Math.abs(a.v.adj)).slice(0,8);
  const overall=cal.n?Math.round(cal.a*60+cal.b-60):0;
  const accHtml=ev.length?`<div class="acc-summary ${tone}"><div><span>Bots judged</span><b>${ev.length}</b></div><div><span>Average miss</span><b>${mae.toFixed(1)} pts</b></div><div><span>Within 12 points</span><b>${hit}%</b></div><div><span>Tendency</span><b>${Math.abs(bias)<3?'Balanced':bias>0?`${Math.round(bias)} pts too low`:`${Math.round(-bias)} pts too high`}</b></div><div><span>Order agreement</span><b>${rk==null?'–':rk.toFixed(2)}</b></div></div>
    ${(()=>{
      const accA=(state.accounts||{})[perfAccount]||{},newOf=e=>{const sn=(accA.snapshots||{})[e.botId]||[];return sn.length>1?{n:(sn[sn.length-1].chats||0)-(sn[sn.length-2].chats||0),since:sn[sn.length-2].at}:null;},dayOf=t=>{const d=new Date(t);return isNaN(d)?'':d.toLocaleDateString(undefined,{month:'short',day:'numeric'});};
      const cols=[['bot','Bot','Bot name, A to Z when ascending'],['predicted','Initial score','The score frozen when the bot was built'],['actual','Actual score',"How it really did, ranked against this account's bots"],['perDay','Chats/day',''],['days','Days live','Fewest days = newest bot'],['newChats','New chats','Chats the bot gained since the previous pull (the date under it is when that pull was)'],['miss','Miss','Size of the miss, ignoring whether it was too high or too low'],['verdict','Verdict','Over-predicted, then On target, then Under-predicted']];
      const val={bot:e=>String(e.botTitle||e.sceneName||'').toLowerCase(),predicted:e=>e.predicted,actual:e=>e.actual,perDay:e=>e.perDay||0,days:e=>e.days||0,newChats:e=>{const x=newOf(e);return x?x.n:-1;},miss:e=>Math.abs(e.error),verdict:e=>(e.verdict==='On target'?0:e.error>0?1:-1)*1000+e.error};
      const f=val[accCol.key]||val.miss,dir=accCol.dir==='asc'?1:-1;
      const sorted=[...ev].sort((a,b)=>{const x=f(a),y=f(b);return (x<y?-1:x>y?1:0)*dir||String(a.botTitle||'').localeCompare(String(b.botTitle||''));});
      const newCell=e=>{const x=newOf(e);if(!x)return '<td title="This bot has only been pulled once, so there is nothing to compare with yet">–<small>first pull</small></td>';return x.n>0?`<td class="up">+${fmt(x.n)}<small>since ${esc(dayOf(x.since))}</small></td>`:x.n<0?`<td class="down">${fmt(x.n)}<small>since ${esc(dayOf(x.since))}</small></td>`:`<td class="down">none<small>since ${esc(dayOf(x.since))}</small></td>`;};
      const row=e=>`<tr><td>${esc(e.botTitle||e.sceneName)}<small>${esc(e.series||'')}${e.backfilled?' · score recorded at first pull':''}${e.auto?(e.retro?' · automatic score, after launch':' · automatic score'):' · scenario card score'}</small></td><td>${e.predicted}</td><td>${e.actual}</td><td>${fmt(e.perDay)}</td><td>${e.days}</td>${newCell(e)}<td class="${e.error>0?'up':e.error<0?'down':''}">${e.error>0?'+':''}${e.error}</td><td><span class="acc-v ${e.verdict==='On target'?'ok':e.error>0?'under':'over'}" ${e.error>0&&e.verdict!=='On target'?'title="It did better than the score predicted"':''}>${e.error>0&&e.verdict!=='On target'?'&#128081; ':''}${esc(e.verdict)}</span></td></tr>`;
      const head='<tr>'+cols.map(([k,l,t])=>{const on=accCol.key===k;return `<th class="sortable${on?' on':''}" data-acccol="${k}" title="${esc((t?t+' · ':'')+'Click to sort; click again to reverse')}">${l}<span class="sort-arrow">${on?(accCol.dir==='asc'?' ▲':' ▼'):''}</span></th>`;}).join('')+'</tr>';
      return `<div class="perf-table-wrap acc-scroll"><table class="perf-table acc">${head}${sorted.map(row).join('')}</table></div><p class="micro">${sorted.length} judged bot${sorted.length>1?'s':''}, sorted by ${esc((cols.find(c=>c[0]===accCol.key)||cols[5])[1].toLowerCase())} (${accCol.dir==='asc'?'lowest first':'highest first'}). Scroll for the rest; click any heading to re-sort.</p>`;})()}`
    :`<p class="micro">${mat.length?`${mat.length} linked bot${mat.length>1?'s are':' is'} still maturing. A bot is judged once it has been live ${3} days and this account has at least 4 bots old enough to compare against.`:'Mark cards Built (or link bots to cards) and pull. Each card\'s score is frozen when you build it, then compared with how the bot actually does.'}</p>`;
  const learnHtml=cal.n?`<div class="acc-learned"><h5>What the app learned from ${cal.n} real result${cal.n>1?'s':''}</h5><p class="micro">New and current scores are adjusted automatically. Adjustments stay small until enough bots back them up.</p>
    <div class="acc-chips">${overall?`<span class="acc-chip ${overall>0?'up':'down'}">Overall ${overall>0?'+':''}${overall} at a typical score</span>`:''}${learned.map(x=>`<span class="acc-chip ${x.v.adj>0?'up':'down'}">${esc(x.k)} ${x.v.adj>0?'+':''}${x.v.adj}<small>${x.v.n} bot${x.v.n>1?'s':''}</small></span>`).join('')||(!overall?'<span class="micro">No consistent misses found yet.</span>':'')}</div></div>`:'';
  const predicted=`<details class="perf-card acc-card" id="acc-card" ${accOpen?'open':''}><summary class="perf-card-head"><h4>Prediction accuracy${ev.length?` <span class="acc-count">${ev.length} bots judged</span>`:''}</h4><small>initial score (frozen when built) vs actual score (chats per day, total chats and like rate, ranked against this account's bots)</small></summary>${accHtml}${mat.length&&ev.length?`<p class="micro">${mat.length} more linked bot${mat.length>1?'s are':' is'} still maturing.</p>`:''}${learnHtml}</details>`;
  const sortBtn=(k,l)=>`<button class="perf-sort ${!perfCol&&perfSort===k?'on':''}" data-sort="${k}">${l}</button>`;
  const table=`<div class="perf-card"><div class="perf-card-head"><h4>All bots</h4><div class="perf-sorts">${sortBtn('placed','Best placed')}${sortBtn('chats','Most chats')}${sortBtn('likes','Most likes')}${sortBtn('growth','Fastest growing')}${sortBtn('perDay','Chats per day')}${sortBtn('newest','Newest')}<span class="perf-sort-sep"></span><button class="perf-sort perf-clear" title="Clear any filter and column sort, and go back to Fastest growing">✕ Clear filter</button></div></div>
    <div class="bots-search"><input id="bots-search" type="search" placeholder="Search bot names... (use #tag to search tags, e.g. #hero)" value="${esc(perfQuery)}" autocomplete="off"><span id="bots-search-count" class="micro"></span></div><div class="feed-filter"><span class="micro">Show</span>${[['all','All'],...FEED_NAMES].map(([k,l])=>`<button class="perf-sort feed-flt ${perfFeed===k?'on':''}" data-feed="${k}" title="${k==='all'?'Every bot':'Only bots currently in the top 500 of the '+esc(l)+' feed'}">${esc(l)} <small>${feedCount(k)}</small></button>`).join('')}</div><div class="perf-table-wrap"><table class="perf-table bots"><tr>${[['bot','Bot',''],['score','App score',"Scored by the app from the bot's own title, description and tags the first time it was pulled, then frozen. If the bot was built from one of the app's cards, that card's frozen score is used instead."],['chats','Chats',''],['likes','Likes',''],['favorites','Favourites',''],['release','Release Date',"The bot's Publish date on JuicyChat"],['days','Days live*',"Counted from the bot's Publish date when JuicyChat shows it; otherwise from the first pull, so older bots may show fewer days at first."],['perDay','Chats/day',''],['placed','Placement',"Where the bot sits in JuicyChat's feeds right now, as seen by the account that pulled it. Sorting puts the bots in the most feeds first (descending), and the best position first among bots in the same number of feeds"]].map(([k,l,t])=>{const on=perfCol&&perfCol.key===k,arrow=on?(k==='release'?(perfCol.dir==='asc'?' ↓ newest':' ↑ oldest'):(perfCol.dir==='asc'?' ▲':' ▼')):'';return `<th class="sortable${on?' on':''}" data-col="${k}" title="${esc((t?t+' · ':'')+(k==='release'?'Click: newest first, click again: oldest first':'Click: ascending, click again: descending'))}">${l}<span class="sort-arrow">${arrow}</span></th>`;}).join('')}</tr>${(perfFeed==='all'?rows:rows.filter(r=>(r.feeds||{})[perfFeed])).map(r=>{const sc=botAppScore(acc,r,cards);return `<tr class="${perfBot===r.id?'sel':''}" data-search="${esc(String(r.title||'').toLowerCase())}" data-tags="${esc((r.tags||[]).join('|').toLowerCase())}"><td><button class="fx-pick" data-bot="${esc(r.id)}" title="Show this bot's forensics">${esc(r.title||r.id)}</button> <a href="${esc(r.url)}" target="_blank" rel="noopener" class="fx-ext" title="Open on JuicyChat">↗</a></td><td>${sc?`<span class="app-score ${sc.kind==='auto'?'auto':''}" title="${sc.kind==='card'?(sc.frozen?'The score its scenario card had when you marked it Built':'Its scenario card\'s current score (not frozen yet)'):sc.retro?'Scored automatically the first time a pull saw this bot, after it had already launched':'Scored automatically when this bot first appeared, before it had time to perform'}">${esc(sc.score)}${sc.kind==='card'&&!sc.frozen?'<small>live</small>':sc.kind==='card'?'<small>card</small>':sc.retro?'<small>after launch</small>':''}</span>`:'<span class="micro">next pull</span>'}</td><td>${fmt(r.chats)} ${chg(r.dc)}</td><td>${fmt(r.likes)} ${chg(r.dl)}</td><td>${fmt(r.favorites)}</td><td>${(d=>d?`<span title="${esc(new Date(d).toLocaleString())}">${new Date(d).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'})}</span>`:'<span class="micro" title="Not in JuicyChat\'s data yet: pull again">–</span>')(Date.parse(r.published||r.created||'')||null)}</td><td>${fmt(r.days)}</td><td>${fmt(r.perDay)}</td><td class="feed-cell">${feedChips(r.feeds)||'<span class="micro">–</span>'}</td></tr>`;}).join('')}</table></div><p class="micro">*Days live uses the bot's creation date when JuicyChat shows it, otherwise the date of its first pull.</p></div>`;
  const selBot=perfBot&&bots.find(x=>x.id===perfBot);
  $('performance-content').innerHTML=tabs+signBox+setup+details+ratingLine+kpis+(selBot?botForensics(acc,selBot,cards):'<p class="micro fx-hint">Click any bot in the table below to see its forensics: why it performed, when it performed, its commenters and its prediction accuracy.</p>')+`<div class="perf-grid">${chart}${working}</div>`+predicted+table;bindPerf();
  qsa('.rt-pick').forEach(el=>el.onchange=async()=>{try{state=await window.juicyApp.perfSetRating(perfAccount,el.dataset.url,el.value||null);renderPerformance();toast(el.value?`Rating set to ${el.value}. Your choice is kept on every pull.`:'Back to the detected rating.');}catch(e){toast(e.message,true);}});
  {const cp=document.querySelector('.rt-copy');if(cp)cp.onclick=async()=>{const acc=state.accounts?.[perfAccount]||{},list=acc.bots||[];
    const lines=list.map(b=>{const raw=b.raw||{},keys=Object.keys(raw).filter(k=>k!=='rating'&&/rat|nsfw|adult|18|level|grade|mature|content|audit|visib/i.test(k));
      return [b.title,`rating=${b.rating??'-'}`,...keys.map(k=>`${k}=${raw[k]}`),`badge=${b.ratingLabel||'none'}`,`shown=${RATING_LABEL[ratingOf(b,perfAccount)]||'?'}`,(acc.ratingOverrides||{})[b.url]?'set by hand':''].filter(Boolean).join(' | ');});
    await window.copyText(`Juicy Blueprint Studio rating details (${list.length} bots, ${IS_SHARE?'shareable':'personal'} edition)\n`+lines.join('\n'));toast('Rating details copied. Paste them into a message to send for checking.');};}
}
function bindPerf(){
  const applyBotSearch=()=>{const q=perfQuery.trim().toLowerCase(),rows=qsa('.perf-table.bots tr[data-search]');let shown=0;
    // plain words search bot names only; words starting with # search tags ("#hero")
    const words=q.split(/\s+/).filter(Boolean);
    for(const tr of rows){const name=tr.dataset.search,tags=(tr.dataset.tags||'').split('|');
      const hit=!words.length||words.every(w=>w.startsWith('#')?(w.length<2||tags.some(t=>t.includes(w.slice(1)))):name.includes(w));
      tr.style.display=hit?'':'none';if(hit)shown++;}
    const c=$('bots-search-count');if(c)c.textContent=q?`${shown} of ${rows.length} bots`:`${rows.length} bots`;};
  const sb=$('bots-search');if(sb){sb.oninput=()=>{perfQuery=sb.value;applyBotSearch();};sb.onkeydown=e=>{if(e.key==='Escape'){sb.value='';perfQuery='';applyBotSearch();}};}
  applyBotSearch();
  qsa('.perf-tab').forEach(b=>b.onclick=()=>{perfAccount=b.dataset.acct;perfBot=null;perfQuery='';renderPerformance();});
  bindCharts();qsa('.chart-metric').forEach(b=>b.onclick=()=>{perfChartMetric=b.dataset.metric;renderPerformance();});
  qsa('.feed-flt').forEach(b=>b.onclick=()=>{perfFeed=b.dataset.feed;renderPerformance();});
  qsa('.fx-pick').forEach(b=>b.onclick=()=>{perfBot=b.dataset.bot;renderPerformance();const f=$('fx');if(f)f.scrollIntoView({block:'start'});});
  const fc=$('fx-close');if(fc)fc.onclick=()=>{perfBot=null;renderPerformance();};
  qsa('.work-view').forEach(b=>b.onclick=()=>{perfWorkView=b.dataset.view;renderPerformance();});
  qsa('.perf-sort[data-sort]:not(.chart-metric):not(.work-view)').forEach(b=>b.onclick=()=>{perfSort=b.dataset.sort;perfCol=null;renderPerformance();});
  qsa('th[data-acccol]').forEach(th=>th.onclick=()=>{const k=th.dataset.acccol,sc=document.querySelector('.acc-scroll'),top=sc?sc.scrollTop:0;accCol=accCol.key===k?{key:k,dir:accCol.dir==='asc'?'desc':'asc'}:{key:k,dir:(k==='bot'||k==='days')?'asc':'desc'};renderPerformance();const n=document.querySelector('.acc-scroll');if(n)n.scrollTop=top;});
  {const ac=$('acc-card');if(ac)ac.ontoggle=()=>{accOpen=ac.open;};}
  qsa('.perf-table.bots th[data-col]').forEach(th=>th.onclick=()=>{const k=th.dataset.col;perfCol=perfCol&&perfCol.key===k?{key:k,dir:perfCol.dir==='asc'?'desc':'asc'}:{key:k,dir:'asc'};renderPerformance();});
  {const c=document.querySelector('.perf-clear');if(c)c.onclick=()=>{perfCol=null;perfSort='growth';perfQuery='';perfFeed='all';renderPerformance();};}
  {;}
  const ao=$('acct-open');if(ao)ao.onclick=async()=>{try{ao.disabled=true;ao.textContent='Signing in...';state=await window.juicyApp.accountOpenLogin(perfAccount,$('acct-link').value.trim());const ok=(state.accounts||{})[perfAccount]?.signedIn?.ok;renderAll();toast(ok?`${PERF_ACCTS[perfAccount]} signed in. Click Pull to read its bots and notifications.`:'The sign-in was not confirmed. The magic link may be expired or already used.',!ok);}catch(e){renderAll();toast(e.message,true);}};
  const af=$('acct-finish');if(af)af.onclick=async()=>{try{state=await window.juicyApp.accountFinishLogin(perfAccount);renderAll();const ok=(state.accounts||{})[perfAccount]?.signedIn?.ok;toast(ok?`${PERF_ACCTS[perfAccount]} signed in. Click Pull to read its bots and notifications.`:'Sign-in not confirmed yet. Finish it in the sign-in window first.',!ok);}catch(e){toast(e.message,true);}};
  const so=$('acct-signout');if(so)so.onclick=async()=>{if(!confirm(`Sign the tool out of the ${PERF_ACCTS[perfAccount]}? Its data stays.`))return;state=await window.juicyApp.accountSignOut(perfAccount);renderAll();toast('Signed out.');};
  qsa('.rc-mark').forEach(btn=>btn.onclick=async()=>{const rules={...(state.settings.ratingRules||{}),[perfAccount]:{field:btn.dataset.field,value:btn.dataset.value}};state=await window.juicyApp.saveSettings({ratingRules:rules});renderAll();toast(`Bots with ${btn.dataset.field} = ${btn.dataset.value} now count as 18+.`);});
  const rcc=document.querySelector('.rc-clear');if(rcc)rcc.onclick=async()=>{const rules={...(state.settings.ratingRules||{})};delete rules[perfAccount];state=await window.juicyApp.saveSettings({ratingRules:rules});renderAll();};
  const save=$('lounge-save');if(save)save.onclick=async()=>{try{state=await window.juicyApp.performanceSetLounge(perfAccount,$('lounge-url').value.trim());renderAll();toast(`${PERF_ACCTS[perfAccount]} lounge link saved.`);}catch(e){toast(e.message,true);}};
  const one=$('perf-pull-one');if(one)one.onclick=()=>runBusy(`Reading the ${PERF_ACCTS[perfAccount]} lounge...`,async()=>window.juicyApp.performancePull(perfAccount),'collector');
  qsa('.perf-link').forEach(sel=>sel.onchange=async()=>{const bot=sel.dataset.bot,acc=(state.accounts||{})[perfAccount]||{},cur=Object.keys(acc.links||{}).find(k=>acc.links[k]===bot);
    try{if(sel.value)state=await window.juicyApp.performanceLink(perfAccount,sel.value,bot);else if(cur)state=await window.juicyApp.performanceLink(perfAccount,cur,'');renderAll();toast(sel.value?'Linked. Its numbers now count toward that card.':'Unlinked.');}catch(e){toast(e.message,true);}});
}
function renderCollectAs(){const sel=$('collect-as');if(!sel||IS_SHARE)return;const A=state.accounts||{},v=state.settings.collectAs||'tool';
  for(const o of sel.options){if(o.value==='tool')continue;const ok=A[o.value]?.signedIn?.ok;o.textContent=`${o.value==='main'?'Main':'NTR'} Account${ok?` (signed in${A[o.value].signedIn.userName?` as ${A[o.value].signedIn.userName}`:''})`:' (not signed in)'}`;o.disabled=!ok;}
  sel.value=v!=='tool'&&A[v]?.signedIn?.ok?v:'tool';
  $('collect-as-note').textContent=sel.value==='tool'?"JuicyChat only shows 18+ bots to accounts allowed to see them. To include 18+ bots in Recent/Trending, sign an account with that access in (Performance tab) and choose it here.":'Recent/Trending are collected as this account, so everything it is allowed to see (including 18+) is included.';}

// ---- Import a ChatGPT week: review scores, approve tidy-ups, revise weak cards, import
let IMP=null,impAccept={},impOpen=null;
const scoreCls=n=>n==null?'':n>=80?'good':n>=60?'mid':'weak';
function renderImportPanel(){const host=$('import-panel');if(!host)return;if(!IMP){host.innerHTML='';return;}
  const it=IMP.items,below=it.filter(i=>(i.score??0)<80).length,laneNames=Object.values(IMP.counts.laneLabels||{}),order=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday','NTR',...laneNames,'Bonus'];
  const rows=[...it].sort((a,b)=>order.indexOf(a.day)-order.indexOf(b.day));
  host.innerHTML=`<div class="panel imp"><div class="imp-head"><div><h3>Import: ${esc(IMP.file)}</h3><p>${IMP.counts.core} day scenarios${IMP.counts.ntr?` · ${IMP.counts.ntr} NTR`:''}${Object.entries(IMP.counts.lanes||{}).map(([k,n])=>n?` · ${n} ${esc((IMP.counts.laneLabels||{})[k]||k)}`:'').join('')}${IMP.counts.bonus?` · ${IMP.counts.bonus} Bonus`:''} · <b class="${below?'imp-low':'imp-ok'}">${below?`${below} under 80`:'every card is 80 or above'}</b>${IMP.warning?` · <span class="imp-warn">${esc(IMP.warning)}</span>`:''}</p>
    <p class="micro">Scores come from your collected JuicyChat data. Scene names and story text are never changed here. The app only offers safe tidy-ups; for anything that needs rewriting, copy the fix request into ChatGPT and paste its revised card back.</p></div>
    <div class="button-row"><button class="secondary" id="imp-tick-all">Tick all tidy-ups</button><button class="primary" id="imp-apply">Import all ${IMP.items.length} cards</button><button class="ghost" id="imp-cancel">Cancel</button></div></div>
    <div class="imp-list">${rows.map(i=>{const p=i.plan||{changes:[],advice:[]},open=impOpen===i.id,acc=new Set(impAccept[i.id]||[]);
      return `<div class="imp-row ${open?'open':''}"><button class="imp-sum" data-id="${esc(i.id)}"><span class="imp-day">${esc(i.day)}</span><span class="imp-name"><b>${esc(i.sceneName)}</b><small>${esc(i.primaryCharacter||'')}${i.series&&i.series!=='Standalone'?` · ${esc(i.series)}`:''}</small></span><span class="imp-score ${scoreCls(i.score)}">${i.score??'–'}<small>/100</small></span><span class="imp-flag">${(i.score??0)<80?(p.changes.length?`${p.changes.length} tidy-up${p.changes.length>1?'s':''} · needs revising`:'needs revising'):'✓'}</span></button>
      ${open?`<div class="imp-body">
        <div class="imp-col"><h5>What moved the score</h5>${(i.reasons||[]).map(r=>`<div class="imp-reason"><span class="${r.delta>=0?'up':'down'}">${r.delta>=0?'+':''}${r.delta}</span> <span ${tip(r.label)}>${esc(r.label)}</span></div>`).join('')||'<p class="micro">No breakdown.</p>'}</div>
        <div class="imp-col">${p.changes.length?`<h5>Tidy-ups the app can make (approve each)</h5>${p.changes.map(ch=>`<label class="imp-chg"><input type="checkbox" class="imp-acc" data-id="${esc(i.id)}" data-label="${esc(ch.label)}" ${acc.has(ch.label)?'checked':''}><span><b>${esc(ch.label)}</b>${ch.gain?` <em class="up">+${ch.gain}</em>`:' <em>no score change</em>'}${ch.diff.map(d=>`<span class="imp-diff"><i>${esc(d.field)}</i><del>${esc(d.from||'(empty)')}</del><ins>${esc(d.to)}</ins></span>`).join('')}</span></label>`).join('')}`:''}
          ${(i.score??0)<80?`<h5>To reach 80, ChatGPT needs to revise the story</h5>${p.advice.length?`<ul class="imp-adv">${p.advice.map(a=>`<li>${esc(a)}</li>`).join('')}</ul>`:'<p class="micro">Collect Recent + Trending data so the app can say exactly what is holding this card back.</p>'}
          <div class="button-row"><button class="secondary imp-fix" data-id="${esc(i.id)}">⧉ Copy fix request for ChatGPT</button></div>
          <textarea class="imp-rev" data-id="${esc(i.id)}" rows="4" placeholder="Paste ChatGPT's revised card here, then click Use revised card"></textarea><button class="primary imp-use" data-id="${esc(i.id)}">Use revised card</button>`:''}</div>
      </div>`:''}</div>`;}).join('')}</div></div>`;
  qsa('.imp-sum').forEach(b=>b.onclick=()=>{impOpen=impOpen===b.dataset.id?null:b.dataset.id;renderImportPanel();});
  qsa('.imp-acc').forEach(cb=>cb.onchange=()=>{const a=new Set(impAccept[cb.dataset.id]||[]);cb.checked?a.add(cb.dataset.label):a.delete(cb.dataset.label);impAccept[cb.dataset.id]=[...a];});
  qsa('.imp-fix').forEach(b=>b.onclick=async()=>{const i=IMP.items.find(x=>x.id===b.dataset.id);await copyText(i.fixRequest);toast('Fix request copied. Paste it into ChatGPT, then paste its revised card back here.');});
  qsa('.imp-use').forEach(b=>b.onclick=async()=>{const ta=document.querySelector(`.imp-rev[data-id="${CSS.escape(b.dataset.id)}"]`);try{const before=IMP.items.find(x=>x.id===b.dataset.id).score;const it2=await window.juicyApp.importRevise(b.dataset.id,ta.value);IMP.items=IMP.items.map(x=>x.id===it2.id?it2:x);delete impAccept[it2.id];renderImportPanel();toast(`Revised card scored ${it2.score}/100 (was ${before}).`);}catch(e){toast(e.message,true);}});
  $('imp-tick-all').onclick=()=>{let n=0;for(const i of IMP.items){const ch=(i.plan?.changes||[]).map(c=>c.label);if(ch.length){impAccept[i.id]=ch;n+=ch.length;}}renderImportPanel();toast(n?`Ticked ${n} tidy-up${n>1?'s':''} across the week. They're applied when you import.`:'There are no tidy-ups to tick.');};
  $('imp-cancel').onclick=async()=>{await window.juicyApp.importCancel();IMP=null;impAccept={};renderImportPanel();};
  $('imp-apply').onclick=async()=>{const n=IMP.items.length,tabOnly=IMP.tabOnly;if(!confirm(IMP.tabOnly?`Replace the ${n} ${IMP.tabOnly} cards with these? The old versions are archived (with their scores) and every other tab stays as it is.`:`Import these ${n} cards as this week? The current week's cards are archived (with their scores), and your Bonus cards are kept.`))return;
    try{busy(true,'Importing the week...','Scoring and filling every card.');state=await window.juicyApp.importApply(impAccept);IMP=null;impAccept={};renderAll();toast(tabOnly?`Replaced the ${n} ${tabOnly} cards.`:`Imported ${n} cards from ChatGPT.`);}catch(e){toast(e.message,true);}finally{busy(false);renderImportPanel();}};
}

// ---- updates: a pop-up that says exactly what changed; nothing installs without a click
let UPD=null;
function showUpdate(r){UPD=r;setTimeout(renderDashUpdate,0);const m=$('upd-modal'),badge=$('upd-badge');if(badge)badge.style.display=r&&r.available?'':'none';if(!m)return;
  if(!r){m.style.display='none';return;}
  if(r.stage==='done'){m.innerHTML=`<div class="upd-box"><h3>Updated to v${esc(r.installed)}</h3>${r.removedFiles?`<p class="micro">Removed ${r.removedFiles} old file${r.removedFiles===1?'':'s'} this version no longer uses.${r.keptEdited?` ${r.keptEdited} you had changed ${r.keptEdited===1?'was':'were'} left alone.`:''}</p>`:''}${r.needsSetup?`<p>This update adds new parts that need installing. Close the app, then start it with <b>START_JUICY_BLUEPRINT_STUDIO.bat</b> as usual.</p><div class="button-row"><button class="primary" id="upd-close">OK</button></div>`:`<p>Restart the app to start using the new version. Your data, sign-ins and settings are kept.</p><div class="button-row"><button class="primary" id="upd-restart">Restart now</button><button class="ghost" id="upd-close">Later</button></div>`}</div>`;}
  else if(r.stage==='working'){m.innerHTML=`<div class="upd-box"><h3>Updating to v${esc(r.latest)}…</h3><p>Unpacking the new version into your app folder. This takes a few seconds.</p></div>`;}
  else{const notes=r.notes||[];m.innerHTML=`<div class="upd-box"><h3>Version ${esc(r.latest)} is available</h3><p class="upd-sub">You have v${esc(r.current)}. Here is exactly what the update adds and changes:</p>
    <div class="upd-notes">${notes.length?notes.map(n=>`<div class="upd-ver"><h5>v${esc(n.version)}</h5><ul>${n.lines.map(l=>`<li>${esc(l)}</li>`).join('')}</ul></div>`).join(''):'<p class="micro">This version came without release notes.</p>'}</div>
    <p class="micro">Updating replaces the app's files in the folder it is installed in. Your data, sign-ins, settings and templates are stored separately and are not touched. The downloaded file is deleted afterwards.</p>
    <div class="button-row"><button class="primary" id="upd-go">Update now</button><button class="ghost" id="upd-no">Not now</button></div></div>`;}
  m.style.display='';
  const go=$('upd-go');if(go)go.onclick=async()=>{const latest=r.latest;showUpdate({...r,stage:'working'});try{const x=await window.juicyApp.updateInstall();showUpdate({stage:'done',...x,available:false});}catch(e){toast('The update could not be installed: '+e.message+' Your current version still works.',true);showUpdate({...r,stage:null});}};
  const no=$('upd-no');if(no)no.onclick=async()=>{try{state=await window.juicyApp.updateSkip(r.latest);}catch{}m.style.display='none';toast(`Staying on v${r.current}. You can update any time from Settings or the sidebar.`);};
  const rs=$('upd-restart');if(rs)rs.onclick=()=>window.juicyApp.updateRestart();
  const cl=$('upd-close');if(cl)cl.onclick=()=>{m.style.display='none';if(badge)badge.style.display='none';};
}
async function checkForUpdates(manual){const b0=$('du-btn');if(b0){b0.disabled=true;b0.textContent='Checking…';}try{const r=await window.juicyApp.updateCheck();if(r.available)showUpdate(r);else{if(manual)toast(r.latest?`You have the latest version (v${r.current}).`:(r.note||'No update found.'));const b=$('upd-badge');if(b)b.style.display='none';}}catch(e){if(manual)toast(e.message,true);}renderUpdateSettings();renderDashUpdate();}
async function renderDashUpdate(){const host=$('dash-update');if(!host)return;let i=null;try{i=await window.juicyApp.updateInfo();}catch{}if(!i)return;
  const avail=UPD&&UPD.available;
  host.innerHTML=`<div class="du-text"><span class="du-dot ${avail?'on':''}"></span><b>${avail?`Version ${esc(UPD.latest)} is available`:`Juicy Blueprint Studio v${esc(String(i.current).replace(/\.0$/,''))}`}</b><span>${avail?`You have v${esc(String(i.current).replace(/\.0$/,''))}. See what's new before deciding.`:i.folder?'Updates are checked when the app starts.':'No update folder is set (Settings › Updates).'}</span></div>
    <button class="${avail?'primary':'secondary'}" id="du-btn" ${i.folder?'':'disabled'}>${avail?"See what's new":'Check for updates'}</button>`;
  $('du-btn').onclick=()=>avail?showUpdate({...UPD,stage:null}):checkForUpdates(true);}
// the locked Appearance quality prompt and Negative Prompt every bot gets: set here, they replace the template's own (each person sets theirs)
async function renderImageLockSettings(){const host=$('img-settings');if(!host)return;
  const L=(state&&state.settings&&state.settings.imageLocks)||{};let tq='',tn='';
  try{const t=(await window.juicyApp.builderTemplates()).find(x=>x.image&&x.image.present&&(x.image.templateQuality||x.image.templateNegative));if(t){tq=t.image.templateQuality||'';tn=t.image.templateNegative||'';}}catch{}
  host.innerHTML=`<p class="micro">Every bot's Image Generation section starts with a locked quality prompt before the Appearance keywords, and ends with a locked Negative Prompt. Set yours here and every template uses them, in the Bot Builder, in the copy buttons and in what the AI writes. Leave a box empty to use each template's own.</p>
  <label class="stack">Appearance quality prompt, locked <small>Written in front of the Appearance keywords in every bot.</small><textarea id="img-lock-quality" rows="3" placeholder="${esc(tq||'(masterpiece, best quality, ...)')}">${esc(L.quality||'')}</textarea></label>
  <label class="stack">Negative Prompt, locked <small>Written as the Negative Prompt in every bot.</small><textarea id="img-lock-negative" rows="3" placeholder="${esc(tn||'(low quality, blurry, ...)')}">${esc(L.negative||'')}</textarea></label>
  <div class="button-row"><button class="primary" id="img-lock-save">Save prompts</button><button class="ghost" id="img-lock-reset" ${L.quality||L.negative?'':'disabled'}>Use each template's own</button></div>`;
  const save=async(q,n,msg)=>{try{state=await window.juicyApp.saveSettings({imageLocks:{quality:q,negative:n}});toast(msg);if(window.refreshImageLocks)await window.refreshImageLocks();renderImageLockSettings();}catch(e){toast(e.message,true);}};
  $('img-lock-save').onclick=()=>save($('img-lock-quality').value,$('img-lock-negative').value,'Image Generation prompts saved. Every bot now uses them.');
  $('img-lock-reset').onclick=()=>save('','','Back to each template\'s own prompts.');}
async function renderUpdateSettings(){const host=$('upd-settings');if(!host)return;let i=null;try{i=await window.juicyApp.updateInfo();}catch{}if(!i)return;
  let log=[];try{log=(await window.juicyApp.updateChangelog())||[];}catch{}
  host.innerHTML=`<p class="micro">You're on <b>v${esc(i.current)}</b>. ${i.folder?'When a newer version is put in the update source, the app shows what changed and asks before updating.':'Set an update folder to get update notices.'}</p>
  ${IS_SHARE||i.defaultFolder?`<p class="micro">Updates come from the update source this app was set up with.</p>`:`<label class="stack">Update source (a Google Drive folder link shared "Anyone with the link", or a public GitHub repository link) <small>Use a different one from the one you share with friends.</small><input id="upd-folder" type="url" value="${esc(i.folder||'')}" placeholder="https://github.com/OWNER/REPO or https://drive.google.com/drive/folders/..."></label>`}
  <label class="check-row"><input type="checkbox" id="upd-auto" ${i.auto?'checked':''}> Check for updates when the app starts</label>
  <div class="button-row">${IS_SHARE||i.defaultFolder?'':'<button class="secondary" id="upd-save">Save folder</button>'}<button class="primary" id="upd-check" ${i.folder?'':'disabled'}>Check for updates</button></div>
  ${log.length?`<div class="upd-log"><h4>What changed in v${esc(log[0].version)} (the version you have)</h4><div class="upd-notes"><div class="upd-ver"><ul>${log[0].lines.map(l=>`<li>${esc(l)}</li>`).join('')}</ul></div></div>
  ${log.length>1?`<details class="upd-older"><summary>Earlier versions (${log.length-1})</summary><div class="upd-notes">${log.slice(1).map(n=>`<div class="upd-ver"><h5>v${esc(n.version)}</h5><ul>${n.lines.map(l=>`<li>${esc(l)}</li>`).join('')}</ul></div>`).join('')}</div></details>`:''}</div>`:''}`;
  const sv=$('upd-save');if(sv)sv.onclick=async()=>{state=await window.juicyApp.saveSettings({updateFolder:$('upd-folder').value.trim()});toast($('upd-folder').value.trim()?'Update folder saved.':'Update folder cleared.');renderUpdateSettings();};
  $('upd-auto').onchange=async e=>{state=await window.juicyApp.saveSettings({autoUpdateCheck:e.target.checked});};
  $('upd-check').onclick=()=>checkForUpdates(true);
}

// ---- AI writer (both editions): through the relay, no keys in the app
let AI={on:false,status:null,job:null,t0:0,timer:null,lastResult:null};
async function aiCheck(){{try{AI.status=await window.juicyApp.aiStatus();}catch{AI.status=null;}AI.on=!!(AI.status&&AI.status.configured);window.AI_ON=AI.on;}
  qsa('.ai-only').forEach(e=>e.style.display=AI.on?'':'none');qsa('.bb-rewrite-section').forEach(e=>e.disabled=!AI.on);return AI.on;}
// ---- relay controls (your edition): who's spending, caps, on/off, names and blocking, saved straight to Cloudflare
let RC={data:null,err:'',busy:false};
const COUNTRY=c=>{try{return new Intl.DisplayNames(['en'],{type:'region'}).of(c)||c;}catch{return c;}};
async function renderRelayControls(refresh=true){const host=$('relay-ctl');if(!host)return;
  if(!(AI.on&&AI.status&&AI.status.admin)){host.style.display='none';return;}host.style.display='';
  if(refresh){RC.busy=true;draw();try{RC.data=await window.juicyApp.aiAdmin('overview');RC.err='';}catch(e){RC.err=e.message;RC.data=null;}RC.busy=false;}
  draw();
  function draw(){const D=RC.data,money=x=>`$${(+x||0).toFixed(2)}`;
    if(RC.err){host.innerHTML=`<div class="panel-head"><div><h3>Relay controls</h3></div></div>${/version 3/.test(RC.err)?`<div class="relay-old"><b>Your relay needs updating (version 3)</b><span>Paste the new worker.js into Cloudflare once (Workers &amp; Pages › your relay › Edit code › select everything › paste › Deploy). After that, everything here is changed from the app.</span></div>`:`<p class="micro" style="color:#f3a3b2">${esc(RC.err)}</p>`}<div class="button-row"><button class="ghost" id="rc-refresh">Try again</button></div>`;
      const b=$('rc-refresh');if(b)b.onclick=()=>renderRelayControls();return;}
    if(!D){host.innerHTML='<div class="panel-head"><div><h3>Relay controls</h3><p>Loading…</p></div></div>';return;}
    const C=D.config,pct=C.totalMonthlyUSD?Math.min(100,Math.round(D.total/C.totalMonthlyUSD*100)):0,when=t=>{if(!t)return'never';const d=new Date(t),days=Math.floor((Date.now()-d)/864e5);return days<=0?'today':days===1?'yesterday':d.toLocaleDateString(undefined,{day:'numeric',month:'short'});};
    host.innerHTML=`<div class="panel-head"><div><h3>Relay controls</h3><p>Who's using your AI relay this month (${esc(D.month)}), and its limits. Changes save straight to Cloudflare.</p></div><button class="ghost" id="rc-refresh">${RC.busy?'Refreshing…':'↻ Refresh'}</button></div>
      <div class="rc-total"><b>${money(D.total)}</b> of ${money(C.totalMonthlyUSD)} this month<div class="rc-bar"><span style="width:${pct}%"></span></div></div>
      <div class="rc-row"><label>Per computer, per month $<input type="number" id="rc-dev" min="0" step="0.5" value="${C.perDeviceMonthlyUSD}"></label><label>Total, per month $<input type="number" id="rc-tot" min="0" step="1" value="${C.totalMonthlyUSD}"></label><button class="primary" id="rc-save">Save limits</button>
        <label class="rc-switch"><input type="checkbox" id="rc-on" ${C.enabled?'checked':''}> AI on for everyone</label></div>
      <div class="rc-table"><div class="rc-h"><span>Computer</span><span>Limit</span><span>Spent</span><span>Requests</span><span>Last used</span><span></span></div>
      ${D.devices.length?D.devices.map(d=>`<div class="rc-r${d.blocked?' blocked':''}"><span><b>${d.you?'This computer (you)':esc(d.name||d.selfName||'Unnamed')}</b><small>${(()=>{const f=[d.country?COUNTRY(d.country):'',d.region].filter(Boolean).join(' · ');return f?esc(f)+' · ':'';})()}${d.you&&d.name?esc(d.name)+' · ':''}${!d.name&&d.selfName&&!d.you?'their own name · ':''}${esc(d.id.slice(0,10))}…${d.blocked?' · <em>AI is off</em>':''}</small></span><span class="rc-lim">$<input type="number" min="0" step="1" class="rc-limit" data-id="${esc(d.id)}" data-you="${d.you?1:0}" placeholder="${d.you?'0':'default'}" value="${d.you?(AI.status&&AI.status.myLimit||0):(d.limitUSD!=null?d.limitUSD:'')}" title="${d.you?'The most this computer may spend in a month. 0 means no limit.':'The most this computer may spend in a month. Empty uses the per-computer limit above; 0 means no limit.'}"></span><span>${money(d.spent)}</span><span>${d.requests}</span><span>${when(d.lastUsed)}</span>
        <span>${d.you?'':`<button class="ghost sm rc-name" data-id="${esc(d.id)}" data-name="${esc(d.name||d.selfName||'')}">✎ Name</button><button class="${d.blocked?'secondary':'ghost'} sm rc-block" data-id="${esc(d.id)}" data-b="${d.blocked?'0':'1'}">${d.blocked?'Turn on AI':'Turn off AI'}</button>`}</span></div>`).join(''):'<p class="micro">No computer has used the relay yet.</p>'}</div>`;
    $('rc-refresh').onclick=()=>renderRelayControls();
    $('rc-save').onclick=async()=>{const dev=+$('rc-dev').value,tot=+$('rc-tot').value;if(!(dev>=0)||!(tot>=0))return toast('Enter the limits in dollars.',true);try{await window.juicyApp.aiAdmin('config',{perDeviceMonthlyUSD:dev,totalMonthlyUSD:tot});toast(`Limits saved: $${dev} per computer, $${tot} in total.`);renderRelayControls();}catch(e){toast(e.message,true);}};
    $('rc-on').onchange=async ev=>{const on=ev.target.checked;if(!on&&!confirm('Turn AI off for everyone, including your friends? You can turn it back on here any time.')){ev.target.checked=true;return;}try{await window.juicyApp.aiAdmin('config',{enabled:on});toast(on?'AI is on for everyone.':'AI is off for everyone.');renderRelayControls();}catch(e){toast(e.message,true);ev.target.checked=!on;}};
    qsa('#relay-ctl .rc-limit').forEach(inp=>inp.onchange=async()=>{const raw=inp.value.trim(),you=inp.dataset.you==='1';if(raw!==''&&!(+raw>=0)){toast('Enter the limit in dollars (0 = no limit).',true);return;}
      try{if(you){const n=await window.juicyApp.aiSetMyLimit(raw===''?0:+raw);if(AI.status)AI.status.myLimit=n;toast(n>0?`This computer may spend up to $${n} a month.`:'This computer has no spending limit.');renderRelayControls(false);return;}
        await window.juicyApp.aiAdmin('device',{id:inp.dataset.id,limitUSD:raw===''?null:+raw});await renderRelayControls();
        const d=((RC.data||{}).devices||[]).find(x=>x.id===inp.dataset.id);if(raw!==''&&d&&d.limitUSD==null)toast('Saved, but your relay does not apply a limit to one computer yet. It needs the updated worker.js (Settings > AI writer shows how).',true);else toast(raw===''?'That computer uses the per-computer limit.':(+raw>0?`That computer may spend up to $${+raw} a month.`:'That computer has no spending limit.'));}catch(e){toast(e.message,true);}});
    qsa('#relay-ctl .rc-name').forEach(b=>b.onclick=async()=>{const n=await askText({title:'Name this computer',message:'The name shown for this computer in your relay controls.',value:b.dataset.name||'',placeholder:'for example Verithos'});if(n===null)return;try{await window.juicyApp.aiAdmin('device',{id:b.dataset.id,name:n});renderRelayControls();}catch(e){toast(e.message,true);}});
    qsa('#relay-ctl .rc-block').forEach(b=>b.onclick=async()=>{const block=b.dataset.b==='1';if(block&&!confirm('Turn AI off for this computer? Everyone else keeps working.'))return;try{await window.juicyApp.aiAdmin('device',{id:b.dataset.id,blocked:block});toast(block?'AI is off for that computer.':'AI is on for that computer.');renderRelayControls();}catch(e){toast(e.message,true);}});
  }}
async function renderAiSettings(){const host=$('ai-settings');if(!host)return;await aiCheck();if(!AI.on)return;const st=AI.status||{};let unf=[];try{unf=await window.juicyApp.aiUnfinished();}catch{}
  const relayOld=AI.status&&AI.status.ok&&!(AI.status.version>=2);host.innerHTML=`${relayOld?`<div class="relay-old"><b>Your relay needs updating (version ${AI.status.version||1})</b><span>DeepSeek V4.1 Flash thinks before it writes, and your relay can't switch that off yet, so replies can come back empty. Update it once: Cloudflare dashboard › Workers & Pages › your relay › Edit code › select everything and paste the new worker.js › Deploy. Nothing else changes.</span></div>`:''}${IS_SHARE?`<div class="ai-think"><label>Your name <input id="ai-myname" maxlength="40" placeholder="optional" value="${esc(AI.status&&AI.status.myName||'')}"></label><span class="micro">Shown to the person who runs the shared AI service, so they know whose use is whose.</span></div>`:''}<div class="ai-think"><label>Thinking <select id="ai-thinking">${[['off','Off: fastest, cheapest'],['low','Low'],['medium','Medium (recommended)'],['high','High: slowest, most careful']].map(([v,l])=>`<option value="${v}" ${(state.aiThinking||'medium')===v?'selected':''}>${l}</option>`).join('')}</select></label><span class="micro">How much the AI plans against your template before writing. Thinking is billed, so higher costs a little more. Character limits are measured and fixed either way.</span></div><p class="micro">The Bot Builder's <b>✦ Write with AI</b> writes every part of a bot from your template and a scenario card. It goes through your Cloudflare relay, which holds your OpenRouter key and enforces your limits, so there's no key in the app.</p>
  <div class="bp-cur">${st.ok?`<b>✓ Connected to your relay${st.enabled?'':' · AI writing is turned OFF in your relay settings'}</b><span>Model: ${esc(st.defaultModel||'')}${IS_SHARE?'':' (change it in your relay\'s "config" setting)'}</span>`:`<b>✗ Can't reach your relay</b><span>${esc(st.error||'Check your internet connection.')}</span>`}</div>
  <div class="button-row"><button class="secondary" id="ai-test" ${st.ok&&st.enabled?'':'disabled'}>Run the long writing test</button></div>
  <p class="micro">The test writes one full-length story (about the size of a whole bot) so you can check it finishes while you're away from the computer, and what it costs.</p>
  ${AI.lastResult?`<div class="ai-result"><b>Last test:</b> ${AI.lastResult.words} words in ${AI.lastResult.seconds}s · cost $${(+AI.lastResult.cost).toFixed(4)}</div>`:''}
  ${unf.length?`<div class="ai-unf"><b>Unfinished bot${unf.length>1?'s':''}:</b>${unf.map(j=>`<div class="ai-unf-row"><span>${esc(j.title)} · ${j.steps.filter(x=>x.state==='done').length} of ${j.steps.length} steps done</span><span class="ai-unf-btns"><button class="secondary ai-resume" data-id="${esc(j.id)}">Resume</button><button class="ghost ai-discard" data-id="${esc(j.id)}">Discard</button></span></div>`).join('')}${unf.length>1?'<div class="ai-unf-row"><span></span><button class="ghost" id="ai-discard-all">Discard all</button></div>':''}</div>`:''}`;{const th=$('ai-thinking');if(th)th.onchange=async()=>{state.aiThinking=await window.juicyApp.aiSetThinking(th.value);toast(`Thinking set to ${th.value}.`);};}{const mn=$('ai-myname');if(mn)mn.onchange=async()=>{await window.juicyApp.aiSetMyName(mn.value);toast(mn.value.trim()?`Your name is set to ${mn.value.trim()}.`:'Name removed.');};}renderRelayControls();
  const t=$('ai-test');if(t)t.onclick=()=>aiRun(()=>window.juicyApp.aiLongTest(),'Long writing test');
  qsa('.ai-resume').forEach(b=>b.onclick=()=>aiRun(()=>window.juicyApp.aiResume(b.dataset.id),'Resuming a bot'));
  qsa('.ai-discard').forEach(b=>b.onclick=async()=>{if(!confirm('Discard this unfinished bot? What it wrote so far is deleted.'))return;try{await window.juicyApp.aiDiscard(b.dataset.id);}catch(e){toast(e.message,true);}renderAiSettings();renderBuilderUnfinished&&renderBuilderUnfinished();});
  {const da=$('ai-discard-all');if(da)da.onclick=async()=>{let list=[];try{list=await window.juicyApp.aiUnfinished();}catch{}if(!list.length||!confirm(`Discard all ${list.length} unfinished bots? What they wrote so far is deleted.`))return;for(const j of list){try{await window.juicyApp.aiDiscard(j.id);}catch{}}renderAiSettings();renderBuilderUnfinished&&renderBuilderUnfinished();};}
}
// ---- the AI writer in the background: a progress card in the bottom-right corner while the person uses other tabs
function aiMinimize(){const m=$('ai-modal');if(m)m.style.display='none';AI.min=true;aiMini((AI.job&&AI.job.last)||{});}
function aiMiniHide(){AI.min=false;const e=$('ai-mini');if(e)e.remove();document.body.classList.remove('ai-mini-on');}
function aiRestore(){aiMiniHide();aiModal({...((AI.job&&AI.job.last)||{})});}
function aiMini(p){
  const J=AI.job||{},steps=(p.steps||J.steps||[]),total=steps.length,done=steps.filter(x=>x.state==='done').length,now=steps.find(x=>x.state==='writing')||steps.find(x=>x.state!=='done');
  const state=p.error?'error':p.done?'done':'run',secs=Math.max(0,Math.round((Date.now()-AI.t0)/1000)),mm=`${Math.floor(secs/60)}:${String(secs%60).padStart(2,'0')}`;
  const live=String(p.live||J.live||'').replace(/\s+/g,' ').trim();
  let el=$('ai-mini');if(!el){el=document.createElement('div');el.id='ai-mini';el.className='ai-mini';el.setAttribute('role','status');document.body.appendChild(el);document.body.classList.add('ai-mini-on');}
  if(el.dataset.state!==state){   // the buttons are only redrawn when the state changes, so a click is never lost to the once-a-second refresh
    el.dataset.state=state;
    const btns=state==='run'?'<button class="secondary sm" id="aim-open">Open</button><button class="ghost sm" id="aim-stop">Stop and save</button>'
      :state==='done'?`${p.kind==='bot'||AI.lastBot?'<button class="primary sm" id="aim-bot">Open in Bot Builder</button>':'<button class="primary sm" id="aim-open">Open</button>'}<button class="ghost sm" id="aim-x">Dismiss</button>`
      :`${p.canResume?'<button class="primary sm" id="aim-cont">Continue</button>':''}<button class="${p.canResume?'secondary':'primary'} sm" id="aim-builder">Go to Bot Builder</button><button class="ghost sm" id="aim-x">Dismiss</button>`;
    el.className='ai-mini '+state;
    el.innerHTML=`<div class="aim-top"><b id="aim-title"></b><span id="aim-time"></span></div><div class="aim-bar"><i id="aim-fill"></i></div><div class="aim-stage" id="aim-stage"></div><div class="aim-live" id="aim-live"></div><div class="aim-btns">${btns}</div>`;
    const go=(id,fn)=>{const b=$(id);if(b)b.onclick=fn;};
    go('aim-open',aiRestore);go('aim-stop',()=>window.juicyApp.aiCancel());go('aim-x',aiMiniHide);
    go('aim-bot',()=>{aiMiniHide();switchView('builder');if(window.builderLoadDraft&&AI.lastBot)window.builderLoadDraft(AI.lastBot.templateId,AI.lastBot.values);});
    go('aim-builder',()=>{aiMiniHide();switchView('builder');});
    go('aim-cont',()=>{const id=p.id;aiMiniHide();aiRun(()=>window.juicyApp.aiResume(id),'Resuming a bot');});
  }
  const set=(id,t)=>{const e=$(id);if(e&&e.textContent!==t)e.textContent=t;};
  set('aim-title',p.title||J.title||'AI writer');set('aim-time',mm);
  const f=$('aim-fill');if(f)f.style.width=(state==='done'?100:total?Math.round(done/total*100):4)+'%';
  set('aim-stage',state==='error'?(p.error||'It stopped.').slice(0,220):state==='done'?'Finished.':total?`Step ${Math.min(done+1,total)} of ${total}${now?': '+now.label:''}`:(p.message||'Starting...'));
  set('aim-live',state==='run'?live.slice(-240):'');
}
function aiModal(p){const m=$('ai-modal');if(!m)return;if(AI.min){aiMini(p);return;}const J=AI.job||{};const steps=(p.steps||J.steps||[]);
  // the box is redrawn on every update, which used to throw every scroll position back to the top: remember them first
  const keep=(()=>{const b=m.querySelector('.ai-box'),l=m.querySelector('.ai-live'),s=m.querySelector('.pull-steps');const pinned=e=>!e||e.scrollHeight-e.scrollTop-e.clientHeight<40;
    return {fresh:!b||m.style.display==='none',box:b?b.scrollTop:0,boxPinned:pinned(b),live:l?l.scrollTop:0,livePinned:pinned(l),steps:s?s.scrollTop:0};})();
  const secs=Math.round((Date.now()-AI.t0)/1000),mm=`${Math.floor(secs/60)}:${String(secs%60).padStart(2,'0')}`;
  const icon=s=>s==='done'?'✓':s==='writing'?'●':s==='stopped'||s==='cancelled'?'!':'';
  m.innerHTML=`<div class="upd-box ai-box"><h3>${esc(p.title||J.title||'AI writer')}</h3>
    <div class="ai-meta"><span>Time ${mm}</span>${(p.costKnown||(+(p.cost||0)>0))?`<span>Cost so far $${(+(p.cost??J.cost??0)).toFixed(4)}</span>`:(p.requests||0)?`<span title="Your relay is not sending the cost of each request back to the app, so it can't be shown here. The writing is not affected.">Cost: not reported by your relay</span>`:'<span>Cost: –</span>'}${p.chars?`<span>${p.chars.toLocaleString()} characters</span>`:''}</div>
    <div class="pull-steps" style="max-height:240px;overflow:auto">${steps.map(s=>`<div class="ps ${s.state==='done'?'done':s.state==='writing'?'now':''}"><span class="ps-dot">${icon(s.state)}</span><span>${esc(s.label)}</span></div>`).join('')}</div>
    ${p.message?`<p class="ai-msg ${p.warn?'warn':''}">${esc(p.message)}</p>`:''}
    <pre class="ai-live">${esc(p.live||J.live||'')}</pre>
    ${p.error?`<p class="ai-msg err">${esc(p.error)}${p.canResume?' Everything finished so far is saved: Continue picks up from the step that stopped, or Start over the next time you click Write with AI.':''}${p.canContinue?' What the AI wrote is kept: Continue asks it to carry on from where it stopped, with the same plan.':''}${p.savedPartial?' What the AI wrote so far is saved: run the same action again and it carries on from there instead of starting over.':''}</p>`:''}
    ${p.done&&p.result?`<p class="ai-msg ok">${p.kind==='section'?'The section rewrite is ready for your review.':p.kind==='test'?`Finished: ${p.result.words} words in ${p.result.seconds} seconds, cost ${p.result.costKnown?'$'+(+p.result.cost).toFixed(4):'not reported by your relay'}. Nothing interrupted it.`:p.kind==='event'?'Finished. The event checklist is in the Events tab.':p.kind==='fix'?'Finished. The bot was fixed for the event; check the event checklist in the Bot Builder.':p.kind==='image'?'Finished. The Appearance keywords were written.':p.kind==='suggest'?'Finished. The suggestions are in the Suggestions panel.':p.kind==='adapt'?`Finished: ${p.result.adapted} card${p.result.adapted===1?'':'s'} adapted to the event${p.result.costKnown?` for $${(+p.result.cost).toFixed(4)}`:''}. Story, personality and appearance were edited only where the event needed it; each card was saved as it finished.`:p.kind==='fill'?`Filled ${(p.result.filled||[]).length} blank section${(p.result.filled||[]).length===1?'':'s'}${p.result.costKnown?` for $${(+p.result.cost).toFixed(4)}`:''}: ${esc((p.result.filled||[]).join(', '))}. Nothing else on the card was changed.${(p.result.left||[]).length?` Still blank (the AI did not return them): ${esc(p.result.left.join(', '))}.`:''}${(p.result.dropped||[]).length?` Left blank because they broke your blueprint's rules: ${esc(p.result.dropped.map(d=>d.field).join(', '))}.`:''}`:p.kind==='week'?`Finished: ${p.result.saved??(p.result.cards||[]).length} card${(p.result.saved??(p.result.cards||[]).length)===1?'':'s'} written and saved${p.result.costKnown?` for $${(+p.result.cost).toFixed(4)}`:''}${p.result.adapted?`, ${p.result.adapted} adapted to the event`:''}${p.result.missing?` (${p.result.missing} came back empty and kept the planner's version)`:''}${p.result.failed&&p.result.failed.length?`. ${p.result.failed.length} skipped because the AI's reply could not be read (they keep their current version; use Rewrite Card on the card to try again): ${esc(p.result.failed.slice(0,6).map(f=>f.sceneName).join(', '))}`:''}${p.result.skippedBuilt&&p.result.skippedBuilt.length?`. ${p.result.skippedBuilt.length} card${p.result.skippedBuilt.length===1?' is':'s are'} marked Built, so ${p.result.skippedBuilt.length===1?'it was':'they were'} left as ${p.result.skippedBuilt.length===1?'it is':'they are'} and not rewritten: ${esc(p.result.skippedBuilt.slice(0,8).map(f=>(f.day?f.day+' · ':'')+f.sceneName).join(', '))}. Untick Built on ${p.result.skippedBuilt.length===1?'it':'a card'} to have the AI write it too`:''}${p.result.problems&&p.result.problems.length?`. Still breaking your blueprint's rules: ${esc(p.result.problems.slice(0,4).map(f=>f.sceneName).join(', '))}`:''}. Every card is already in the week.`:`Finished. The bot is in the Bot Builder${p.result.remaining&&p.result.remaining.length?`, with ${p.result.remaining.length} thing${p.result.remaining.length>1?'s':''} still to check: ${esc(p.result.remaining.join(' · ').slice(0,240))}`:' and passes your template'}. Total cost ${p.result.costKnown?'$'+(+p.result.cost).toFixed(4):'not reported by your relay'}.`}</p>`:''}
    <div class="button-row">${p.done||p.error?`${p.done&&p.kind==='bot'?'<button class="primary" id="ai-open">Open in Bot Builder</button>':''}${p.done&&p.kind==='week'?'<button class="primary" id="ai-review">Show the week</button>':''}${p.canResume?`<button class="primary" id="ai-resume-now" data-id="${esc(p.id)}">Continue</button>`:''}${p.canContinue?`<button class="primary" id="ai-continue-section" data-section="${esc(p.section)}">Continue</button>`:''}<button class="ghost" id="ai-close">Close</button>`:'<button class="secondary" id="ai-min" title="Keep it running and use the other tabs. A progress card stays in the bottom-right corner.">Keep working in other tabs</button><button class="danger" id="ai-cancel">Stop and save progress</button><span class="micro">Stuck or too slow? Stop it: everything already written is saved, and next time you can Continue or Start over. You can switch windows or minimize the app; it keeps writing.</span>'}</div></div>`;
  m.style.display='';
  // the tab bar stays clickable while the AI works: choosing another tab minimizes this box into the progress card in the bottom-right corner
  {const nv=$('main-nav');if(nv){const r=nv.getBoundingClientRect();if(r.width>=r.height){m.style.top=Math.max(0,Math.round(r.bottom))+'px';m.style.left='0px';}else{m.style.left=Math.round(r.right)+'px';m.style.top='0px';}}}
  {const box=m.querySelector('.ai-box'),list=m.querySelector('.pull-steps'),live=m.querySelector('.ai-live'),now=m.querySelector('.ps.now')||[...m.querySelectorAll('.ps')].filter(e=>!e.classList.contains('done'))[0];
    // the step list follows the step being written (kept in the middle of the list), the live text follows the newest words, the box keeps where the person put it
    if(list&&now){const lr=list.getBoundingClientRect(),nr=now.getBoundingClientRect();list.scrollTop+=(nr.top-lr.top)-(lr.height-nr.height)/2;}else if(list)list.scrollTop=list.scrollHeight;
    if(live)live.scrollTop=keep.fresh||keep.livePinned?live.scrollHeight:keep.live;
    if(box)box.scrollTop=keep.fresh?0:keep.box;}
  const c=$('ai-cancel');if(c)c.onclick=()=>window.juicyApp.aiCancel();
  const mn=$('ai-min');if(mn)mn.onclick=()=>aiMinimize();
  const x=$('ai-close');if(x)x.onclick=()=>{m.style.display='none';clearInterval(AI.timer);};
  const o=$('ai-open');if(o)o.onclick=()=>{m.style.display='none';clearInterval(AI.timer);switchView('builder');if(window.builderLoadDraft&&AI.lastBot)window.builderLoadDraft(AI.lastBot.templateId,AI.lastBot.values);};
  const rv=$('ai-review');if(rv)rv.onclick=()=>{m.style.display='none';clearInterval(AI.timer);switchView('weekly');renderAll();};
  const cs=$('ai-continue-section');if(cs)cs.onclick=()=>{m.style.display='none';clearInterval(AI.timer);if(window.builderRewriteSection)window.builderRewriteSection(cs.dataset.section,{again:true});};
  const r=$('ai-resume-now');if(r)r.onclick=()=>aiRun(()=>window.juicyApp.aiResume(r.dataset.id),'Resuming a bot');
}
// before any Write/Build with AI: if an earlier run of the same thing was stopped, offer Continue (keeps everything it already wrote) or Start over
function aiChoose(match,what){return new Promise(async res=>{let list=[];try{list=await window.juicyApp.aiUnfinished();}catch{}
  const j=list.filter(match)[0];if(!j)return res({mode:'fresh'});
  const total=j.steps.length,done=j.steps.filter(x=>x.state==='done').length,at=j.steps.find(x=>x.state!=='done');
  let m=$('ai-choice');if(!m){m=document.createElement('div');m.id='ai-choice';m.className='upd-modal';document.body.appendChild(m);}
  m.innerHTML=`<div class="upd-box ai-box"><h3>An earlier ${esc(what)} was stopped</h3><p>${done} of ${total} step${total>1?'s':''} already written and saved${at?` (it stopped at: ${esc(at.label)})`:''}${j.cost?`, $${(+j.cost).toFixed(4)} spent`:''}.</p><p class="micro">Continue picks up where it stopped and keeps everything already written. Start over throws the saved progress away and writes it all again.</p><div class="button-row"><button class="primary" id="aic-continue">Continue</button><button class="secondary" id="aic-fresh">Start over</button><button class="ghost" id="aic-cancel">Cancel</button></div></div>`;
  m.style.display='';const close=v=>{m.style.display='none';m.innerHTML='';res(v);};
  $('aic-continue').onclick=()=>close({mode:'continue',id:j.id});
  $('aic-fresh').onclick=async()=>{try{await window.juicyApp.aiDiscard(j.id);}catch{}close({mode:'fresh'});};
  $('aic-cancel').onclick=()=>close({mode:'cancel'});});}
// SCP Series: the creator types the SCP number before the AI writes an SCP card (null = cancelled)
// The X of the window: Exit / Close to System Tray / Cancel, asked inside the app in its own style (the main process waits for the answer)
function closeAskHide(){for(const id of ['close-ask','webp-abort-ask']){const m=document.getElementById(id);if(m)m.remove();}}
function closeAskShow(d){closeAskHide();const tray=!(d&&d.tray===false);
  const m=document.createElement('div');m.className='upd-modal';m.id='close-ask';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-labelledby','close-ask-h');
  m.innerHTML=`<div class="upd-box close-ask-box"><div class="close-ask-head"><div class="brand-mark">JB</div><h3 id="close-ask-h">Close Juicy Blueprint Studio?</h3></div><p>${tray?'<b>Exit</b> closes the app completely. <b>Close to System Tray</b> hides the window and keeps the app running in the background for the scheduled pulls and backups; open it again from the tray icon.':'The system tray is not available on this computer, so the app cannot keep running in the background.'}</p><div class="button-row close-ask-row"><button type="button" class="danger" id="close-ask-exit">Exit</button>${tray?'<button type="button" class="primary" id="close-ask-tray">Close to System Tray (run in background)</button>':''}<button type="button" class="ghost" id="close-ask-cancel">Cancel</button></div></div>`;
  document.body.appendChild(m);
  const answer=c=>{closeAskHide();try{window.juicyApp.closeChoice(c);}catch{}};
  m.querySelector('#close-ask-exit').onclick=()=>answer('exit');const t=m.querySelector('#close-ask-tray');if(t)t.onclick=()=>answer('tray');
  const cn=m.querySelector('#close-ask-cancel');cn.onclick=()=>answer('cancel');cn.focus();
  m.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();answer('cancel');}});
  try{window.juicyApp.closeShown();}catch{}}
// Exit during an active WebP Maker job requires an explicit second confirmation.
// Keeping the job running cancels only the exit request; it never cancels encoding.
function closeWebpAbortShow(){
  closeAskHide();
  const m=document.createElement('div');m.className='upd-modal';m.id='webp-abort-ask';
  m.setAttribute('role','alertdialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-labelledby','webp-abort-title');
  m.setAttribute('aria-describedby','webp-abort-message');
  m.innerHTML=`<div class="upd-box close-ask-box webp-abort-box"><div class="close-ask-head"><div class="brand-mark">JB</div><h3 id="webp-abort-title">Abort WebP conversion and exit?</h3></div><p id="webp-abort-message"><b>WebP Maker is still converting your MP4s.</b> Exiting will stop the conversion and discard the unfinished WebP. You can keep the conversion running by choosing <b>Keep converting</b> or <b>Close to System Tray</b> in the previous dialog.</p><div class="button-row close-ask-row"><button type="button" class="danger" id="webp-abort-confirm">Abort conversion &amp; Exit</button><button type="button" class="primary" id="webp-abort-keep">Keep converting</button></div></div>`;
  document.body.appendChild(m);
  let answered=false;
  const answer=(choice)=>{if(answered)return;answered=true;closeAskHide();try{window.juicyApp.closeChoice(choice);}catch{}};
  m.querySelector('#webp-abort-confirm').onclick=()=>answer('abort-exit');
  const keep=m.querySelector('#webp-abort-keep');keep.onclick=()=>answer('cancel');keep.focus();
  m.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();answer('cancel');}});
}
function scpAsk(sc){return new Promise(res=>{const m=document.createElement('div');m.className='upd-modal';m.id='scp-ask';
  m.innerHTML=`<div class="upd-box ai-box"><h3>What is the SCP number?</h3><p>${sc.count>1?`There are ${sc.count} SCP cards to write. Type the number of the first one; the next gets the number after it.`:'Type the number of this SCP card.'} The main character is named by it (SCP-022) and the Scene Name starts with it (SCP-022: Anomaly Name). The AI does not name the anomaly's number or invent a person's name for it.</p><p class="micro">${sc.found?'The tool found the highest SCP number it can see and suggests the next one. Change it if that is wrong.':'The tool could not find any SCP number on your bots, so type yours.'}</p><label>SCP-<input id="scp-ask-n" type="number" min="1" max="9999" step="1" value="${sc.found||sc.suggested>1?esc(String(sc.suggested)):''}" style="width:6em"></label><div class="button-row"><button type="button" class="ghost" id="scp-ask-cancel">Cancel</button><button type="button" class="primary" id="scp-ask-go">Write</button></div></div>`;
  document.body.appendChild(m);const inp=m.querySelector('#scp-ask-n');inp.focus();inp.select();
  const close=v=>{m.remove();res(v);};
  const go=()=>{const n=Math.floor(Number(inp.value));if(!(n>0&&n<10000)){inp.focus();return toast('Type the SCP number as a whole number, for example 22.',true);}close(n);};
  m.querySelector('#scp-ask-go').onclick=go;m.querySelector('#scp-ask-cancel').onclick=()=>close(null);inp.onkeydown=e=>{if(e.key==='Enter')go();if(e.key==='Escape')close(null);};});}
async function scpGate(scope){if(!scope)return true;let sc;try{sc=await window.juicyApp.scpScope(scope[0],scope[1]);}catch{return true;}
  if(!sc||!sc.count)return true;const n=await scpAsk(sc);if(n===null)return false;try{await window.juicyApp.scpSetStart(n);}catch(e){toast(e.message,true);return false;}return true;}
async function aiWriteOrContinue(match,what,confirmText,startFn,label,pickFn,scpScope){const c=await aiChoose(match,what);if(c.mode==='cancel')return;
  if(c.mode==='continue')return aiRun(()=>window.juicyApp.aiResume(c.id),`Continuing: ${label}`);
  // pickFn: a dialog of its own in place of the plain confirm (null = cancelled, false = no dialog for this one)
  if(pickFn){const p=await pickFn();if(p===null)return;if(p){if(!await scpGate(scpScope))return;return aiRun(()=>startFn(p),label);}}
  if(confirmText&&!confirm(confirmText))return;if(!await scpGate(scpScope))return;return aiRun(startFn,label);}
// ---- Choosing the event(s) before a write. One dialog for the whole week, one for a tab, a small one for a single card.
// Each answers the plan ({slotKey or cardId: eventId | 'none'}), null when cancelled, false when no event is on (the plain confirm is used then).
const EVP_KEY='jbs.eventPatterns';
function evpPatterns(){try{const o=JSON.parse(localStorage.getItem(EVP_KEY)||'{}');return o&&typeof o==='object'?o:{};}catch{return {};}}
function evpStore(o){try{localStorage.setItem(EVP_KEY,JSON.stringify(o));}catch{}}
const evpActive=()=>evList().filter(e=>e.active&&e.parsed);
const evpOpts=(evs,v,ph)=>`${ph?`<option value="" ${v===''?'selected':''}>${esc(ph)}</option>`:''}<option value="none" ${v==='none'?'selected':''}>No event</option>${evs.map(e=>`<option value="${esc(e.id)}" ${v===e.id?'selected':''}>${esc(evName(e,evList().indexOf(e)))}</option>`).join('')}`;
// sections: [{heading, cols:[label]|null, cls, rows:[{head, set:bool, cells:[{k,v,col,day}]}]}]
function evPlanDialog({title,intro,goLabel,sections,note,days,patterns,bulkLabel}){
  const evs=evpActive(),def=evs[0]?evs[0].id:'';
  const cell=(c,secIdx,rowIdx)=>`<label><select class="evp" data-k="${esc(c.k)}" data-sec="${secIdx}" data-row="${rowIdx}" ${c.col!=null?`data-col="${c.col}"`:''} ${c.day?`data-day="${esc(c.day)}"`:''}>${evpOpts(evs,c.v)}</select></label>`;
  const secHtml=sections.map((sec,si)=>`${sec.heading?`<h5>${esc(sec.heading)}</h5>`:''}<div class="ev-plan ${sec.cls||''}"${sec.cols?` style="grid-template-columns:110px repeat(${sec.cols.length},minmax(0,1fr))"`:''}>${sec.cols?`<span></span>${sec.cols.map((c,i)=>`<span class="ev-head">${esc(c)}<select class="evp-set" data-colset="${si}:${i}" title="Set the whole ${esc(c)} column">${evpOpts(evs,'','Set all…')}</select></span>`).join('')}`:''}${sec.rows.map((r,ri)=>`<span class="ev-head">${esc(r.head)}${r.set?`<select class="evp-set" data-rowset="${si}:${ri}" title="Set this whole row">${evpOpts(evs,'','Set all…')}</select>`:''}</span>${r.cells.map(c=>cell(c,si,ri)).join('')}`).join('')}</div>`).join('');
  const dayBox=days?`<div class="ev-days"><b>Apply an event to several days</b><div class="ev-daychecks">${WEEK_DAYS.map(d=>`<label><input type="checkbox" class="evp-day" value="${d}"> ${d.slice(0,3)}</label>`).join('')}</div>
      <div class="button-row"><button type="button" class="ghost evp-quick" data-days="Monday,Tuesday,Wednesday,Thursday,Friday">Weekdays</button><button type="button" class="ghost evp-quick" data-days="Saturday,Sunday">Weekend</button><button type="button" class="ghost evp-quick" data-days="Monday,Wednesday,Friday">Mon / Wed / Fri</button><button type="button" class="ghost evp-quick" data-days="Tuesday,Thursday">Tue / Thu</button><button type="button" class="ghost evp-quick" data-days="">Clear</button></div>
      <div class="ev-bulk"><select id="evp-daysel">${evpOpts(evs,def)}</select><label class="ev-inline"><input type="checkbox" id="evp-daysall" checked> also the NTR and extra tabs on those days</label><button type="button" class="secondary" id="evp-dayapply">Apply to ticked days</button></div></div>`:'';
  const pats=patterns?(()=>{const P=evpPatterns();return `<div class="ev-pat"><b>Patterns</b><select id="evp-patsel"><option value="">Saved patterns…</option>${Object.keys(P).map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')}</select><button type="button" class="ghost" id="evp-patload">Load</button><button type="button" class="ghost" id="evp-patdel">Delete</button><input id="evp-patname" maxlength="40" placeholder="Name this setup"><button type="button" class="secondary" id="evp-patsave">Save pattern</button></div>`;})():'';
  return new Promise(res=>{const root=document.createElement('div');root.className='upd-modal sr-modal';root.id='ai-event-modal';
    root.innerHTML=`<section class="upd-box sr-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>${esc(title)}</h3><p>${intro}</p></header>
    <div class="sr-body"><div class="ev-bulk"><span class="micro"><b>${esc(bulkLabel||'Set every scenario to')}</b></span><select id="evp-bulk">${evpOpts(evs,def)}</select><button type="button" class="secondary" id="evp-apply">Apply to all</button></div>${dayBox}${pats}
      <div class="ev-group">${secHtml}</div></div>
    <footer><span class="micro">${esc(note||'Each scenario card keeps an Event menu, so you can change it later.')}</span><div class="button-row"><button type="button" class="ghost" id="evp-cancel">Cancel</button><button type="button" class="primary" id="evp-go">${esc(goLabel||'Write')}</button></div></footer></section>`;
    document.body.appendChild(root);
    const cells=()=>[...root.querySelectorAll('select.evp')],close=v=>{root.remove();res(v);};
    const setAll=(list,v)=>list.forEach(x=>{if([...x.options].some(o=>o.value===v))x.value=v;});
    root.querySelector('#evp-apply').onclick=()=>setAll(cells(),root.querySelector('#evp-bulk').value);
    root.querySelectorAll('select.evp-set').forEach(x=>x.onchange=()=>{const v=x.value;if(!v)return;
      if(x.dataset.colset){const [si,ci]=x.dataset.colset.split(':');setAll(cells().filter(c=>c.dataset.sec===si&&c.dataset.col===ci),v);}
      else{const [si,ri]=x.dataset.rowset.split(':');setAll(cells().filter(c=>c.dataset.sec===si&&c.dataset.row===ri),v);}
      x.value='';});
    root.querySelectorAll('.evp-quick').forEach(b=>b.onclick=()=>{const on=new Set(b.dataset.days.split(',').filter(Boolean));root.querySelectorAll('.evp-day').forEach(c=>c.checked=on.has(c.value));});
    const da=root.querySelector('#evp-dayapply');if(da)da.onclick=()=>{const on=new Set([...root.querySelectorAll('.evp-day:checked')].map(c=>c.value)),all=root.querySelector('#evp-daysall').checked;
      if(!on.size)return toast('Tick at least one day first.',true);
      setAll(cells().filter(c=>c.dataset.day&&on.has(c.dataset.day)&&(all||c.dataset.sec==='0')),root.querySelector('#evp-daysel').value);};
    const plan=()=>{const o={};cells().forEach(x=>{if(x.dataset.k)o[x.dataset.k]=x.value;});return o;};
    if(patterns){
      const refresh=()=>{const P=evpPatterns(),sel=root.querySelector('#evp-patsel');sel.innerHTML='<option value="">Saved patterns…</option>'+Object.keys(P).map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('');};
      root.querySelector('#evp-patsave').onclick=()=>{const n=(root.querySelector('#evp-patname').value||'').trim();if(!n)return toast('Give the pattern a name first.',true);const P=evpPatterns();P[n]=plan();evpStore(P);refresh();root.querySelector('#evp-patsel').value=n;root.querySelector('#evp-patname').value='';toast(`Saved pattern "${n}".`);};
      root.querySelector('#evp-patload').onclick=()=>{const n=root.querySelector('#evp-patsel').value,P=evpPatterns();if(!n||!P[n])return toast('Pick a saved pattern first.',true);const m=P[n];cells().forEach(x=>{if(m[x.dataset.k]!==undefined&&[...x.options].some(o=>o.value===m[x.dataset.k]))x.value=m[x.dataset.k];});toast(`Loaded "${n}". Events that no longer exist were skipped.`);};
      root.querySelector('#evp-patdel').onclick=()=>{const n=root.querySelector('#evp-patsel').value,P=evpPatterns();if(!n||!P[n])return;delete P[n];evpStore(P);refresh();toast(`Deleted "${n}".`);};
    }
    root.querySelector('#evp-cancel').onclick=()=>close(null);
    root.querySelector('#evp-go').onclick=()=>close(plan());
    root.addEventListener('keydown',e=>{if(e.key==='Escape')close(null);});root.querySelector('.upd-box').focus();});}

// Write a whole new week: which event each scenario of the week is entered in (or none) before anything is written
async function aiWeekEventPick(o){o=o||{};
  const evs=evpActive();if(!evs.length)return false;
  let cur={};try{cur=(await window.juicyApp.weekEventPlan())||{};}catch{}
  const def=evs[0].id,val=k=>cur[k]==='none'?'none':evs.some(e=>e.id===cur[k])?cur[k]:def;
  const tabsAll=BP&&Array.isArray(BP.tabs)?BP.tabs:[];
  const perDay=Math.max(1,...tabsAll.filter(t=>t.kind==='day').map(t=>t.cards||0))||3,perCols=Array.from({length:perDay},(_,i)=>i+1);      // 2 bots a day: two columns; 3: three
  const sections=[{heading:'Days',cols:perCols.map(n=>'Scenario '+n),rows:WEEK_DAYS.map(d=>({head:d,set:true,cells:perCols.map((n,i)=>({k:`d|${d}|${n}`,v:val(`d|${d}|${n}`),col:i,day:d}))}))}];
  const ntrT=!IS_SHARE&&tabsAll.find(t=>t.kind==='ntr');
  if(ntrT&&ntrT.rotation){const rot=tabsAll.filter(t=>t.rotation);      // the combined NTR tab: one row per day, each day's own card type
    sections.push({heading:ntrT.label||'NTR',cls:'one',rows:WEEK_DAYS.map(d=>{const t=rot.find(x=>x.rotation.days.includes(d));if(!t)return null;const k=t.kind==='ntr'?`ntr|${d}`:`lane|${t.key}|${t.rotation.days.indexOf(d)+1}`;return {head:`${d} · ${t.kind==='ntr'?'NTR':t.label}`,cells:[{k,v:val(k),day:d}]};}).filter(Boolean)});}
  else if(ntrT)sections.push({heading:ntrT.label||'NTR',cls:'one',rows:WEEK_DAYS.map(d=>({head:d,cells:[{k:`ntr|${d}`,v:val(`ntr|${d}`),day:d}]}))});
  for(const t of tabsAll.filter(t=>t.kind==='lane'&&!t.rotation&&!(IS_SHARE&&isNtrTabDef(t)))){const n=t.cards||7;
    sections.push({heading:t.label,cls:'one',rows:Array.from({length:n},(_,i)=>({head:n===7?WEEK_DAYS[i]:'Card '+(i+1),cells:[{k:`lane|${t.key}|${i+1}`,v:val(`lane|${t.key}|${i+1}`),day:n===7?WEEK_DAYS[i]:''}]}))});}
  return evPlanDialog({title:o.title||'Write a whole new week with AI',intro:o.intro||'The app plans the series, slots and engines as usual, the AI writes every card, and you review everything before anything replaces your current week. First choose which event each scenario is entered in, or no event at all. Use a column or row menu, or the day buttons, to fill many at once. SCP Series cards stay out of events unless you switch them on afterwards.',goLabel:o.goLabel||'Write the week',sections,days:true,patterns:true});}
// Write (or Regenerate) one tab: the event of each card in it
async function aiTabEventPick(tab,verb){
  const evs=evpActive();if(!evs.length)return false;
  const cards=tabCards(tab).filter(c=>normStatus(state.week.statuses?.[c.id])!=='Built');if(!cards.length)return false;
  const name=tab.startsWith('lane:')?tabInfo(tab).label:tab;
  const val=c=>c.eventCard===false?'none':evs.some(e=>e.id===c.eventKey)?c.eventKey:'none';
  const sections=[{heading:'',cls:'one',rows:cards.map(c=>({head:`${tab==='NTR'&&cardDayOf(c)?cardDayOf(c)+' · ':''}${c.slot||''}${c.sceneName&&c.sceneName!=='Untitled'?' · '+c.sceneName:''}`.replace(/^ · /,'').slice(0,60)||'Card',cells:[{k:c.id,v:val(c)}]}))}];
  return evPlanDialog({title:`${verb} the ${name} tab`,intro:'Choose the event each card in this tab is entered in, or no event. Cards marked Built are not in this list and stay as they are.',goLabel:verb,sections,bulkLabel:'Set every card in this tab to',note:'Only this tab changes.'});}
// Write with AI / Regenerate on one card
async function aiCardEventPick(id,nm,verb,o){o=o||{};
  const evs=evpActive();if(!evs.length)return false;
  const c=currentWeekAll().find(x=>x.id===id);if(!c)return false;
  const v=c.eventCard===false||!evs.some(e=>e.id===c.eventKey)?(o.adapt?evs[0].id:'none'):c.eventKey;
  const optsHtml=o.adapt?evs.map(e=>`<option value="${esc(e.id)}" ${v===e.id?'selected':''}>${esc(evName(e,evList().indexOf(e)))}</option>`).join(''):evpOpts(evs,v);
  return new Promise(res=>{const root=document.createElement('div');root.className='upd-modal sr-modal';root.id='ai-card-event-modal';
    root.innerHTML=`<section class="upd-box sr-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>${esc(verb)} "${esc(nm)}"</h3><p>${o.intro||'Choose the event this scenario is entered in, or no event.'}</p></header>
      <div class="sr-body"><div class="ev-bulk"><span class="micro"><b>${o.adapt?'Adapt to':'Event'}</b></span><select id="evc-sel">${optsHtml}</select></div></div>
      <footer><span class="micro">Only this card changes.</span><div class="button-row"><button type="button" class="ghost" id="evc-cancel">Cancel</button><button type="button" class="primary" id="evc-go">${esc(verb)}</button></div></footer></section>`;
    document.body.appendChild(root);const done=r=>{root.remove();res(r);};
    root.querySelector('#evc-cancel').onclick=()=>done(null);root.querySelector('#evc-go').onclick=()=>done({[id]:root.querySelector('#evc-sel').value});
    root.addEventListener('keydown',e=>{if(e.key==='Escape')done(null);});root.querySelector('.sr-box').focus();});}
// the events of cards that changed are saved before the write starts (adapt:false: the AI rewrites those cards anyway)
async function evApplyPlan(map,adapt){const cur=currentWeekAll(),ch={};for(const [id,v] of Object.entries(map||{})){const c=cur.find(x=>x.id===id);if(!c)continue;const now=c.eventCard===false?'none':(c.eventKey||'none');if(v!==now)ch[id]=v;}
  if(Object.keys(ch).length){state=await window.juicyApp.weekSetEvents(ch,{adapt:adapt!==false});renderAll();}return ch;}
// Write with AI on one card: write it for a series (its rules from your rulebook and template go to the AI) or as a standalone scenario
async function aiCardSeriesPick(id,nm,built){let o=null;try{o=await window.juicyApp.seriesOptions(id);}catch{}
  if(!o)return false;
  const canSeries=!!o.editable;
  return new Promise(res=>{const root=document.createElement('div');root.className='upd-modal sr-modal';root.id='ai-series-modal';
    const lc=x=>String(x||'').toLowerCase(),curOpt=o.options.find(x=>lc(x.name)===lc(o.current)),stand=lc(o.current)==='standalone';
    const keepText=stand?'Keep it a standalone scenario':curOpt?`Keep its series: ${curOpt.name}`:`Keep it as it is (${o.current})`;
    const first=(curOpt||o.options.find(x=>x.name!==o.current)||o.options[0]||{}).name||'';
    const opts=o.options.map(x=>`<option value="${esc(x.name)}" ${x.name===first?'selected':''}>${esc(x.name)}</option>`).join('');
    root.innerHTML=`<section class="upd-box sr-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>Rewrite "${esc(nm)}"</h3><p>Only this card is scrapped and written again from scratch (new characters, new story, nothing carried over), in its own request, and saved as soon as it is finished. The old version is archived with its score${built?', and the card is marked Built, so it goes back to Idea':''}. Every other card stays as it is.</p></header>
    <div class="sr-body ai-series-body">${canSeries?`<p class="micro"><b>What should this card be?</b></p>
      <label class="bb-check"><input type="radio" name="ai-series" value="keep" checked> ${esc(keepText)}</label>
      ${stand?'':'<label class="bb-check"><input type="radio" name="ai-series" value="standalone"> A standalone scenario (no series)</label>'}
      ${o.options.length?`<label class="bb-check"><input type="radio" name="ai-series" value="series"> A series: <select id="ai-series-pick">${opts}</select></label>`:''}
      <p class="micro" id="ai-series-note"></p>`:`<p class="micro">This card keeps its own tab and lane (${esc(o.current)}), so there is no series to choose.</p>`}
      ${(()=>{const evs=evpActive(),c=currentWeekAll().find(x=>x.id===id);if(!evs.length||!c)return '';const v=c.eventCard===false?'none':evs.some(e=>e.id===c.eventKey)?c.eventKey:'none';return `<p class="micro"><b>Event</b></p><div class="ev-bulk"><select id="ai-card-event" data-was="${esc(v)}">${evpOpts(evs,v)}</select></div>`;})()}
      <p class="micro ai-details-head"><b>Details for the AI</b> (optional)</p>
      <textarea id="ai-card-details" rows="4" maxlength="1500" placeholder="Anything you want in this card, for example: make the main character a gyaru (tanned, bleached hair, loud and teasing) who ... The AI builds the card around it, and the template's own rules still apply."></textarea>
      <p class="micro">Leave it empty and the card is written as usual.</p></div>
    <footer><span class="micro">The list comes from your rulebook and card template.</span><div class="button-row"><button type="button" class="ghost" id="ai-series-cancel">Cancel</button><button type="button" class="primary" id="ai-series-go">Rewrite Card</button></div></footer></section>`;
    document.body.appendChild(root);
    const mode=()=>{const r=root.querySelector('input[name=ai-series]:checked');return r?r.value:'';},pick=()=>{const e=root.querySelector('#ai-series-pick');return e?e.value:'';};
    const note=()=>{const m=mode(),n=m==='series'?pick():m==='keep'&&curOpt?curOpt.name:'';
      const x=o.options.find(y=>y.name===n);
      const nt=root.querySelector('#ai-series-note');if(!nt)return;nt.textContent=m==='standalone'?'No series rules are sent: the AI is told this card belongs to no series.':!n?'':x&&(x.sections||x.mentions)?`The AI gets what your rulebook and card template say about ${n}: ${x.sections?`${x.sections} section${x.sections>1?'s':''}`:''}${x.sections&&x.mentions?' and ':''}${x.mentions?`${x.mentions} other rule line${x.mentions>1?'s':''}`:''}.`:`Your rulebook and card template have no section about ${n}, so the AI only gets its name.`;};
    root.querySelectorAll('input[name=ai-series]').forEach(r=>r.onchange=note);
    const sel=root.querySelector('#ai-series-pick');if(sel)sel.onchange=()=>{root.querySelector('input[value=series]').checked=true;note();};
    note();
    const done=v=>{root.remove();res(v);};
    root.querySelector('#ai-series-cancel').onclick=()=>done(null);
    root.querySelector('#ai-series-go').onclick=()=>{const m=mode(),details=(root.querySelector('#ai-card-details').value||'').trim().slice(0,1500),out=!canSeries?{}:m==='series'?{mode:'series',series:pick()}:{mode:m};if(details)out.details=details;{const e=root.querySelector('#ai-card-event');if(e&&e.value!==e.dataset.was)out.eventId=e.value;}done(out);};
    root.addEventListener('keydown',ev=>{if(ev.key==='Escape')done(null);});root.querySelector('.sr-box').focus();});}
async function aiRun(fn,label){aiMiniHide();AI.t0=Date.now();AI.job={title:label,steps:[],cost:0};clearInterval(AI.timer);aiModal({title:label,message:'Starting...'});
  AI.timer=setInterval(()=>{if(AI.job&&!AI.job.finished)aiModal(AI.job.last||{});},1000);
  AI.lastReturn=null;try{const r=await fn();AI.lastReturn=r;if(r&&r.suggestions){const m=$('ai-modal');if(m)m.style.display='none';}if(r&&r.words!=null){AI.lastResult=r;}if(r&&r.kind!=='section'&&r.values&&r.templateId){AI.lastBot=r;state=await window.juicyApp.getState();}if(r&&r.preview){AI.lastWeek=r;IMP=r.preview;impAccept={};impOpen=null;}if(r&&(r.kind==='week'||r.kind==='fill'||r.kind==='adapt')&&r.state){state=r.state;renderAll();}}
  catch(e){if(!(AI.job&&AI.job.last&&AI.job.last.error))aiModal({title:label,error:e.message});}
  finally{if(AI.job)AI.job.finished=true;clearInterval(AI.timer);renderAiSettings();renderBuilderUnfinished();
    // cards are saved one at a time, so after any stop or error the week already holds everything that was finished
    if(AI.job&&AI.job.last&&(AI.job.last.kind==='week'||AI.job.last.kind==='fill'||AI.job.last.kind==='adapt')){try{state=await window.juicyApp.getState();renderAll();}catch{}}}return AI.lastReturn;}
// aiRun is a top-level function, so it is already window.aiRun (re-assigning it here made it call itself)
async function renderBuilderUnfinished(){const host=$('bb-unfinished');if(!host)return;if(!AI.on){host.style.display='none';return;}let list=[];try{const live=AI.job&&!AI.job.finished&&AI.job.last&&AI.job.last.id;list=(await window.juicyApp.aiUnfinished()).filter(j=>j.kind!=='week'&&j.id!==live);}catch{}
  if(!list.length){host.style.display='none';host.innerHTML='';return;}host.style.display='';
  host.innerHTML=`<b>Unfinished AI bot${list.length>1?'s':''}</b>${list.map(j=>{const at=(j.steps||[]).find(x=>x.state!=='done');return `<div class="bb-unf-row"><span>${esc(j.title)}<small>${at?`stopped at: ${esc(at.label)}`:'stopped'}${j.cost?` · $${(+j.cost).toFixed(4)} spent`:''}</small></span><button class="primary bb-unf-resume" data-id="${esc(j.id)}">Resume</button><button class="ghost bb-unf-drop" data-id="${esc(j.id)}">Discard</button></div>`;}).join('')}`;
  host.querySelectorAll('.bb-unf-resume').forEach(b=>b.onclick=()=>aiRun(()=>window.juicyApp.aiResume(b.dataset.id),'Resuming the bot').then(renderBuilderUnfinished));
  host.querySelectorAll('.bb-unf-drop').forEach(b=>b.onclick=async()=>{if(!confirm('Discard this unfinished bot? What it wrote so far is deleted.'))return;await window.juicyApp.aiDiscard(b.dataset.id);renderBuilderUnfinished();});}
window.renderBuilderUnfinished=renderBuilderUnfinished;
let greetingPlanning = false;
window.aiWriteBot = async (templateId, cardId, pov, writerSettings = {}) => {
  if (!cardId) return toast('Choose a scenario in "Draft from" first.', true);
  if (greetingPlanning) return;
  if (AI.job && !AI.job.finished) return toast('The AI writer is already working. Wait for it to finish or cancel it.', true);
  greetingPlanning = true;
  try {
    if (!window.GreetingPlanner) throw new Error('The Greeting planner did not load. Restart the app before writing.');
    // an earlier run of this same bot that was stopped: Continue keeps everything it already wrote, Start over discards it
    const ch = await aiChoose(j => j.kind === 'bot' && j.cardId === cardId && j.templateId === templateId, 'bot write');
    if (ch.mode === 'cancel') return;
    if (ch.mode === 'continue') { greetingPlanning = false; return aiRun(() => window.juicyApp.aiResume(ch.id), 'Continuing the bot'); }
    // Read the complete current card locally, not a rendered/truncated preview.
    const snapshot = await window.juicyApp.getState();
    const card = [...(snapshot.week?.scenarios || []), ...(snapshot.week?.ntr || []), ...(snapshot.week?.bonus || []), ...Object.keys(snapshot.week || {}).filter(k => k.startsWith('lane:')).flatMap(k => snapshot.week[k] || []), ...(snapshot.cardArchive || [])].find(c => c.id === cardId);
    if (!card) throw new Error('That scenario card is no longer available. Choose another card in "Draft from".');
    const builder = window.__builderCore && window.__builderCore.state;
    const spec = builder && builder.spec && builder.spec.id === templateId ? builder.spec : (await window.juicyApp.builderTemplates()).find(t => t.id === templateId);
    const records = Array.isArray(snapshot.builder?.greetingPlans) ? snapshot.builder.greetingPlans : [];
    const remembered = records.find(r => r.templateId === templateId && r.cardId === cardId);
    const previous = remembered ? remembered.plan : builder && builder.spec?.id === templateId ? builder.v?.greetingPlan : null;
    // step 1: choose the story (Story engine); step 2: plan the Greeting. Cancel in either step starts nothing.
    if (window.StoryPicker && window.juicyApp.storyPlan) {
      const story = await window.StoryPicker.open({card, spec, story: writerSettings && writerSettings.story});
      if (!story) return;
      writerSettings = {...(writerSettings || {}), story};
    }
    const plan = await window.GreetingPlanner.open({card, spec, previous, eventName: snapshot.event?.active ? snapshot.event.rulebook?.event || snapshot.event.parsed?.name || '' : ''});
    if (!plan) return; // Cancel/Escape never starts a job or changes the draft.
    await aiRun(() => window.juicyApp.aiWriteBot(templateId, cardId, pov || 'you', plan, writerSettings), 'Writing a whole bot');
  } catch (err) { toast(err.message || 'The Greeting planner could not open.', true); }
  finally { greetingPlanning = false; }
};
function pullMode(){return ($('pull-timezone')&&$('pull-timezone').value)||(state.settings.pullTimeZone==='computer'?'computer':'est');}
function pullTzName(mode){return mode==='computer'?(Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC'):'Etc/GMT+5';}
// "Next: Oct 27, 8:00 PM EST": the next time a daily pull runs. Worked out directly (the wall-clock time wanted, on each of the next few days, turned into the real
// instant), not by trying every minute of the next 48 hours with a new date formatter each time, which took about 100 ms and ran several times per screen redraw.
// Same answer as before: the first minute from now (this minute included) whose local time in that zone is hh:mm.
const pullFmtCache={};
function pullFmts(tz){return pullFmtCache[tz]||(pullFmtCache[tz]={
  wall:new Intl.DateTimeFormat('en-US',{timeZone:tz,year:'numeric',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}),
  name:new Intl.DateTimeFormat('en-US',{timeZone:tz,hour:'2-digit',minute:'2-digit',hourCycle:'h23',timeZoneName:'short'}),
  when:new Intl.DateTimeFormat('en-US',{timeZone:tz,month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})});}
function nextPullText(hhmm,mode,nowMs){
  const tz=pullTzName(mode), parts=hhmm&&String(hhmm).match(/^(\d{1,2}):(\d{2})$/), h=parts?+parts[1]:20, m=parts?+parts[2]:0;
  if(h>23||m>59)return 'Next: —';          // not a real clock time (the old way never found a match either)
  const now=nowMs==null?Date.now():nowMs, F=pullFmts(tz), MIN=60000, DAY=86400000;
  // the wall-clock time in the zone at instant t, written as if it were UTC (so two of them can be subtracted)
  const wall=t=>{const o={};for(const x of F.wall.formatToParts(new Date(t)))o[x.type]=x.value;return Date.UTC(+o.year,+o.month-1,+o.day,+o.hour%24,+o.minute,+o.second);};
  const w0=wall(now), midnight=w0-((w0%DAY)+DAY)%DAY;
  let best=null;
  for(let day=-1;day<=3;day++){
    const target=midnight+day*DAY+(h*60+m)*MIN;
    const guess=target-(wall(now)-Math.floor(now/1000)*1000), t0=target-(wall(guess)-Math.floor(guess/1000)*1000);
    for(let k=-2;k<=2;k++){                         // the zone's offset can change in between (daylight saving), so a few nearby instants are checked
      const c=t0+k*1800000; if(wall(c)!==target)continue;
      if(c+MIN>now&&c-now<=2880*MIN&&(best===null||c<best))best=c;
    }
  }
  if(best===null)return 'Next: —';
  const d=new Date(best), p=Object.fromEntries(F.name.formatToParts(d).map(x=>[x.type,x.value]));
  return `Next: ${F.when.format(d)} ${p.timeZoneName} (${mode==='computer'?'computer time':'EST, fixed UTC-05:00'}).`;
}
function refreshPullNotes(){
  const mode=pullMode(), zone=Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';
  const note=$('pull-zone-note'), follow=$('pull-zone-follow');
  if(note)note.textContent=`Detected computer timezone: ${zone}. Ordinary timestamps use your computer's clock.`;
  if(follow)follow.textContent=mode==='computer'?'These times follow the computer timezone, including daylight-saving and timezone changes.':'These times stay on fixed UTC-05:00, with no daylight-saving shift.';
  const cn=$('collect-next'), pn=$('perf-next');
  if(cn)$('collect-next').textContent=nextPullText(($('collect-time')||{}).value||state.settings.collectTime||'20:00', mode);
  if(pn)$('perf-next').textContent=nextPullText(($('perf-time')||{}).value||state.settings.perfTime||'20:00', mode);
  const mn=$('morning-next');if(mn)mn.textContent=($('auto-morning')||{}).checked?nextPullText(($('morning-time')||{}).value||state.settings.morningTime||'08:00',mode).replace('Next:','Next morning pull:'):'Optional. Off by default.';
  const perf=$('auto-performance');
  if(perf&&perf.parentElement)perf.parentElement.lastChild.textContent=IS_SHARE?' Pull your bots for the Performance tab every day':' Pull the Main and NTR lounges for the Performance tab every day';
}
function renderAutoStatus(){const el=$('auto-status');if(!el)return;const S=state.settings,sch=state.schedule||{},log=(sch.log||[])[0];
  const on=S.autoCollect!==false||S.autoPerformance!==false||S.autoMorning===true;
  const mode=S.pullTimeZone==='computer'?'computer':'est', ct=S.collectTime||'20:00', pt=S.perfTime||'20:00';
  const mt=S.morningTime||'08:00',am=S.autoMorning===true;const when=(ct===pt?`at ${ct}`:`analysis at ${ct}, performance at ${pt}`)+(am?` · morning pull at ${mt}`:'');
  const where=mode==='computer'?'computer time':'EST (fixed UTC-05:00)';
  el.innerHTML=on?`<span class="auto-dot ${log&&!log.ok?'bad':'ok'}"></span><b>Automatic:</b> every day ${when} ${where}${S.autoCollect!==false?' · collects Recent + Trending':''}${S.autoPerformance!==false?(IS_SHARE?' · pulls your bots':' · pulls your Main and NTR lounges'):''}. ${nextPullText(ct,mode).replace('Next: ','Next analysis: ')}${ct!==pt?` ${nextPullText(pt,mode).replace('Next: ','Next performance: ')}`:''}${log?` <span class="auto-last ${log.ok?'':'bad'}">Last: ${esc(new Date(log.at).toLocaleString(undefined,{month:'short',day:'numeric',hour:'numeric',minute:'2-digit'}))} · ${esc(log.message)}</span>`:''} <a href="#" data-jump-settings>Change</a>`:`<b>Automatic daily pulls are off.</b> <a href="#" data-jump-settings>Turn them on in Settings</a>`;
  qsa('[data-jump-settings]').forEach(a=>a.onclick=e=>{e.preventDefault();switchView('settings');});}
let bpPick={rules:null,template:null},bpLast=null,ksPick={rules:null,template:null};
// The week plan the app read from the rulebook and template. A part it could not read is shown here with a box to type it in (no AI), an example line to add to the rulebook,
// and a Read with AI button; Generate Week stays stopped until every part is read, typed in or marked as not used. Nothing is filled in from old defaults.
function planPanelHtml(pv){
  const miss=pv.missing||[],rows=(pv.parts||[]).map(p=>{
    const bad=p.state===false,fine=p.state===true||p.state==='you'||p.state==='ai'||p.state==='none';
    const head=`<b>${esc(p.label)}</b> <span class="micro">${esc(p.source)}</span>`;
    if(!bad)return `<div class="bp-plan-row ok">${head}<span>${p.state==='none'?'-':esc(p.text||'-')}</span>${(p.state==='you'||p.state==='ai'||p.state==='none')?`<button class="ghost" data-plan-clear="${p.key}">Clear</button>`:''}</div>`;
    return `<div class="bp-plan-row bad">${head}
      <span class="micro">Add a line like this to your rulebook and load it again, or type the value below:</span>
      <code class="micro">${esc(p.hint)}</code>
      <textarea data-plan-in="${p.key}" rows="2" placeholder="${p.key==='themes'?'Theme one, Theme two, Theme three':'2 Some Series, 1 Other Series, 2 Standalone'}">${esc(p.prefill||'')}</textarea>
      <span class="micro">${p.key==='themes'?'Separate the themes with commas.':`Put a count in front of each name. The counts must add up to ${p.days} (one card per day in this slot).`}${p.prefill?' The box holds what you typed for your earlier blueprint; check it, then Save.':''}</span>
      <div class="button-row"><button class="secondary" data-plan-save="${p.key}">Save</button>${p.canNone?`<button class="ghost" data-plan-none="${p.key}">My rulebook does not use this</button>`:''}</div></div>`;
  }).join('');
  return `<div class="bp-cur"><b>The week plan the app read from your files</b><span>${(pv.lines||[]).map(esc).join('<br>')}</span></div>
  ${miss.length?`<div class="bp-changes"><h5 class="bp-warn">Generate Week is stopped: ${miss.length} part${miss.length>1?'s':''} of the week plan could not be read from your files</h5>
    <p class="micro">The app does not fill these in from old settings. Type them in below (no AI needed), or let the AI read your rulebook for them, or add the line shown to your rulebook and update the blueprint. Whatever your rulebook states itself always wins over what you type here.</p>
    <div class="button-row"><button class="secondary" id="bp-plan-ai">Read with AI</button></div>${rows}</div>`
    :(rows&&(pv.parts||[]).some(p=>p.state==='you'||p.state==='ai'||p.state==='none')?`<div class="bp-changes"><h5>Parts you filled in</h5>${rows}</div>`:'')}`;
}
function bindPlanPanel(host,refresh){
  const run=async(fn,okMsg)=>{try{const r=await fn();if(okMsg)toast(typeof okMsg==='function'?okMsg(r):okMsg);}catch(e){toast(e.message,true);}finally{refresh();}};
  host.querySelectorAll('[data-plan-save]').forEach(b=>b.onclick=()=>run(()=>window.juicyApp.blueprintPlanSet(b.dataset.planSave,(host.querySelector(`[data-plan-in="${b.dataset.planSave}"]`)||{}).value||'',false),'Saved. The week plan now uses it.'));
  host.querySelectorAll('[data-plan-none]').forEach(b=>b.onclick=()=>run(()=>window.juicyApp.blueprintPlanSet(b.dataset.planNone,'',true),'Saved. That slot is written as a Standalone.'));
  host.querySelectorAll('[data-plan-clear]').forEach(b=>b.onclick=()=>run(()=>window.juicyApp.blueprintPlanClear(b.dataset.planClear),'Cleared.'));
  const ai=host.querySelector('#bp-plan-ai');
  if(ai)ai.onclick=async()=>{try{busy(true,'Reading your rulebook with AI...','Looking for the missing parts of the week plan.');const r=await window.juicyApp.aiReadWeekPlan();toast(r.found.length?`The AI read ${r.found.length} part${r.found.length>1?'s':''}.${r.notFound.length?` It could not find ${r.notFound.length} (or its counts did not add up): type ${r.notFound.length>1?'those':'that'} in.`:''}`:'The AI could not find those parts in your rulebook with counts that add up. Type them in.',!r.found.length);}catch(e){toast(e.message,true);}finally{busy(false);refresh();}};
}
// ---- the "Updated: what changed" panel: a change log, section by section, with the lines added, removed and reworded (lib/textDiff.js makes the entries)
const bpCount=d=>{const m=d.more||{};return {add:(d.added||[]).length+(m.added||0),rem:(d.removed||[]).length+(m.removed||0),chg:(d.changed||[]).length+(m.changed||0)};};
const bpTally=d=>{const c=bpCount(d),a=[];if(c.add)a.push(`${c.add} added`);if(c.chg)a.push(`${c.chg} reworded`);if(c.rem)a.push(`${c.rem} removed`);return a.join(' · ')||(d.spacingOnly?'spacing only':'');};
const bpParts=ps=>(ps||[]).map(([op,s])=>op===0?esc(s):op<0?`<del>${esc(s)}</del>`:`<ins>${esc(s)}</ins>`).join('');
function bpEntryHtml(e,title){
  const d=e.diff||{},m=d.more||{},more=(m.added||0)+(m.removed||0)+(m.changed||0);
  const lines=[...(d.changed||[]).map(c=>`<li class="chg"><i>~</i><span>${bpParts(c.parts)}</span></li>`),...(d.added||[]).map(x=>`<li class="add"><i>+</i><span>${esc(x)}</span></li>`),...(d.removed||[]).map(x=>`<li class="rem"><i>&minus;</i><span>${esc(x)}</span></li>`)];
  if(d.spacingOnly)lines.push('<li class="note"><span>Only spacing or line breaks changed. The wording is the same.</span></li>');
  if(more)lines.push(`<li class="note"><span>...and ${more} more line${more>1?'s':''} (not shown).</span></li>`);
  const kind=e.kind&&e.kind!=='changed'?` <em>${e.kind==='added'?'new section':'section removed'}</em>`:'';
  return `<details class="bp-log" open><summary><b>${esc(title)}</b>${kind}<span>${esc(bpTally(d))}</span></summary><ul class="bp-lines">${lines.join('')}</ul></details>`;
}
function bpLogHtml(ch){
  const secs=(ch.sectionLog||[]),ins=(ch.instructionLog||[]);
  const sec=secs.length?`<h6>Rule sections (${secs.length})</h6><p class="micro">${'<ins>Green</ins> = words put in, <del>red</del> = words taken out. A line marked + is new, &minus; was removed, ~ was reworded.'}</p>${secs.map(e=>bpEntryHtml(e,e.title)).join('')}`:'';
  const fld=ins.length?`<h6>Field instructions changed (${ins.length})</h6>${ins.map(e=>bpEntryHtml(e,e.name)).join('')}`:'';
  return sec+fld;
}
function bpSummary(ch){
  const secs=ch.sectionLog||[],tot={add:0,rem:0,chg:0};for(const e of secs){const c=bpCount(e.diff||{});tot.add+=c.add;tot.rem+=c.rem;tot.chg+=c.chg;}
  const bits=[];const n=(x,w)=>x.length?bits.push(`${x.length} ${w}`):0;
  n(ch.sectionsChanged||[],`rule section${(ch.sectionsChanged||[]).length>1?'s':''} changed`);n(ch.sectionsAdded||[],'rule section(s) added');n(ch.sectionsRemoved||[],'rule section(s) removed');
  n(ch.instructionsChanged||[],'field instruction(s) changed');n(ch.fieldsAdded||[],'field(s) added');n(ch.fieldsRemoved||[],'field(s) removed');n(ch.planChanges||[],'week plan change(s)');n(ch.tagsAdded||[],'tag(s) added');n(ch.tagsRemoved||[],'tag(s) removed');n(ch.tabsAdded||[],'tab(s) added');n(ch.tabsRemoved||[],'tab(s) removed');n(ch.typesAdded||[],'card type(s) added');n(ch.typesRemoved||[],'card type(s) removed');
  const lines=[tot.add?`${tot.add} line${tot.add>1?'s':''} added`:'',tot.chg?`${tot.chg} reworded`:'',tot.rem?`${tot.rem} removed`:''].filter(Boolean).join(', ');
  return bits.length?`${bits.join(' · ')}${lines?`. In the rule text: ${lines}.`:''}`:'No differences found: the new files read the same as the ones in use.';
}
function bpLogText(ch,label){
  const L=[`${label}: what changed`,bpSummary(ch),''],list=(t,a)=>{if(a&&a.length)L.push(`${t}: ${a.join('; ')}`);};
  list('Week plan changes',ch.planChanges);list('Fields added',ch.fieldsAdded);list('Fields removed',ch.fieldsRemoved);list('Tabs added',ch.tabsAdded);list('Tabs removed',ch.tabsRemoved);list('Card types added',ch.typesAdded);list('Card types removed',ch.typesRemoved);list('Approved tags added',ch.tagsAdded);list('Approved tags removed',ch.tagsRemoved);
  const ent=(e,title)=>{const d=e.diff||{};L.push('',`${title}${e.kind&&e.kind!=='changed'?` (${e.kind==='added'?'new section':'section removed'})`:''}`);if(d.spacingOnly)L.push('  Only spacing or line breaks changed.');
    for(const c of d.changed||[])L.push('  ~ '+(c.parts||[]).map(([op,s])=>op===0?s:op<0?`[-${s.trim()}-] `:`{+${s.trim()}+} `).join('').replace(/\s+/g,' ').trim());
    for(const x of d.added||[])L.push('  + '+x);for(const x of d.removed||[])L.push('  - '+x);const m=d.more||{},more=(m.added||0)+(m.removed||0)+(m.changed||0);if(more)L.push(`  ...and ${more} more`);};
  for(const e of ch.sectionLog||[])ent(e,e.title);for(const e of ch.instructionLog||[])ent(e,`Instruction: ${e.name}`);
  return L.join('\n').trim();
}
async function renderBlueprintSettings(){const host=$('bp-settings');if(!host)return;let st=null;try{st=await window.juicyApp.blueprintStatus();}catch{}
  const cur=st?.current,dt=t=>t?new Date(t).toLocaleString(undefined,{month:'short',day:'numeric',year:'numeric',hour:'numeric',minute:'2-digit'}):'';
  let sch=null;if(!IS_SHARE){try{sch=await window.juicyApp.scheduleStatus();}catch{}}
  const ownLine=(n,label)=>{const o=sch&&sch.own&&sch.own[n];return o?`<span><b style="display:inline">${label}:</b> ${esc(o.rulesName)} + ${esc(o.templateName)} · saved ${esc(dt(o.savedAt))}</span>`:`<span><b style="display:inline">${label}:</b> none saved yet, so this button loads the files that came with the app.</span>`;};
  const ksPickHtml=`<div class="bp-pick"><button class="secondary" id="ks-rules">Choose Kill Switch rulebook (.txt)</button><span>${ksPick.rules?esc(ksPick.rules.name):(sch&&sch.own&&sch.own[3]?`not changing (keeps ${esc(sch.own[3].rulesName)})`:'none chosen')}</span></div><div class="bp-pick"><button class="secondary" id="ks-template">Choose Kill Switch card template (.html)</button><span>${ksPick.template?esc(ksPick.template.name):(sch&&sch.own&&sch.own[3]?`not changing (keeps ${esc(sch.own[3].templateName)})`:'none chosen')}</span></div><div class="button-row"><button class="primary" id="ks-save" ${ksPick.rules||ksPick.template?'':'disabled'}>Save Kill Switch files</button></div>`;
  const schedHtml=sch&&sch.available?`<div class="bp-cur sched-box"><b>Daily schedule: ${sch.perDay?sch.perDay+' bots per day':'not read yet'}${sch.perDay&&!sch.bundled?' (a rulebook not saved for either button)':''}</b><span>The kill switch for the weekly make-up. <b style="display:inline">2 bots/day</b>: 2 cards a day (Crush Series in Scenario 1, one SCP Series, no High-Reaction Pilots or Standalone). <b style="display:inline">3 bots/day</b>: 3 cards a day (Crush Series and SCP Series in Scenario 3 alongside the High-Reaction Pilots). Pressing one loads that schedule's rulebook and card template at once, as a new blueprint version, so Revert to Previous Version undoes it. The NTR tab, the cards already in this week and your settings are not touched; the next Generate Week follows the schedule.</span>${ownLine(3,'3 bots/day (Kill Switch) files')}${ownLine(2,'2 bots/day files (your last 2-bots-per-day upload)')}<div class="button-row"><button class="${sch.bundled===2?'primary':'secondary'}" data-sched="2" ${sch.bundled===2?'title="Already in use"':''}>2 bots/day</button><button class="${sch.bundled===3?'primary':'secondary'}" data-sched="3" ${sch.bundled===3?'title="Already in use"':''}>3 bots/day</button></div>
  <div class="bp-ks"><b>Kill Switch files (3 bots/day)</b><span class="micro">Upload your KILL_SWITCH rulebook and card template here. They are kept for the 3 bots/day button and are not loaded until you press it. Pressing 2 bots/day brings back your own 2-bots-per-day files (the ones you upload with Update Blueprint below).</span>${ksPickHtml}</div></div>`:'';
  const ch=bpLast&&bpLast.changes,list=(t,a)=>a&&a.length?`<div class="bp-ch"><b>${t} (${a.length})</b><span>${a.slice(0,12).map(esc).join(' · ')}${a.length>12?` · and ${a.length-12} more`:''}</span></div>`:'';
  host.innerHTML=`<p class="micro">The Weekly Blueprint follows your rulebook (.txt) and card template (.html). Upload updated versions here: cards gain new fields, drop removed ones and show each field's instruction. You can update just the rulebook, just the template, or both: a file you leave out stays as it is now. If your rulebook lists the card fields itself (a line such as "Scene Name:" followed by its [instruction]), the rulebook alone is enough; the card template is optional. Card content is never deleted, so Revert brings everything back.</p>
  <div class="bp-cur">${cur?`<b>Using: ${esc(cur.label)}</b><span>${cur.version?`${esc(cur.rulesName||'')} + ${esc(cur.templateName||'')} · updated ${esc(dt(cur.createdAt))}`:'the blueprint the app was built from'} · ${cur.counts.fields} fields across ${cur.counts.types} card types · ${cur.counts.tags} approved tags</span>`:'<b>No blueprint yet</b><span>Upload your rulebook to start (add the card template too if the rulebook does not list the card fields).</span>'}</div>
  ${schedHtml}
  ${cur&&cur.plan?planPanelHtml(cur.plan):''}
  <div class="bp-pick"><button class="secondary" id="bp-rules">Choose rulebook (.txt)</button><span>${bpPick.rules?esc(bpPick.rules.name):`not changing${cur&&cur.rulesName?` (keeps ${esc(cur.rulesName)})`:' (keeps the rulebook in use)'}`}</span></div>
  <div class="bp-pick"><button class="secondary" id="bp-template">Choose card template (.html)</button><span>${bpPick.template?esc(bpPick.template.name):`not changing${cur&&cur.templateName?` (keeps ${esc(cur.templateName)})`:' (keeps the template in use)'}`}</span></div>
  <div class="button-row"><button class="primary" id="bp-update" ${bpPick.rules||bpPick.template?'':'disabled'}>Update Blueprint</button><button class="ghost" id="bp-revert" ${st?.canRevert?'':'disabled'} title="${st?.revertTo?`Go back to ${esc(st.revertTo)}`:'Nothing to revert yet'}">Revert to Previous Version</button></div>
  ${ch?`<div class="bp-changes"><h5>${bpLast.what==='reverted'?'Reverted':'Updated'}: what changed</h5><p class="bp-sum">${esc(bpSummary(ch))}</p>${list('Fields added',ch.fieldsAdded)}${list('Fields removed (hidden, not deleted)',ch.fieldsRemoved)}${list('Week plan changes',ch.planChanges)}${list('Tabs added',ch.tabsAdded)}${list('Tabs removed (written cards are archived, not deleted)',ch.tabsRemoved)}${list('Card types added',ch.typesAdded)}${list('Card types removed',ch.typesRemoved)}${list('Approved tags added',ch.tagsAdded)}${list('Approved tags removed',ch.tagsRemoved)}${bpLogHtml(ch)}<div class="button-row"><button type="button" class="ghost sm" id="bp-copylog">Copy change log</button></div>
    ${bpLast.filled?`<p class="micro">${bpLast.filled} new field${bpLast.filled>1?'s were':' was'} filled on existing cards from what they already knew. The rest show as "Needs writing".</p>`:''}
    ${(ch.sectionsChanged.length||ch.sectionsAdded.length||ch.sectionsRemoved.length)?'<p class="micro bp-warn">Changed rule sections update the rule text in the app. A series you add to the files appears in the Rewrite Card series choice, with its rules. The week plan above (days, daily themes, how many of each series, the Scenario 2 and 3 mix, the NTR rotation) is read from your rulebook each time, so the next week you generate follows it. A series the app has no story writer for becomes an empty slot marked Needs writing.</p>':''}</div>`:''}`;
  bindPlanPanel(host,()=>{renderBlueprintSettings();});
  { const cb=$('bp-copylog'); if(cb)cb.onclick=async()=>{try{await navigator.clipboard.writeText(bpLogText(bpLast.changes,bpLast.what==='reverted'?'Reverted':'Updated'));toast('Change log copied.');}catch(e){toast('Could not copy: '+e.message,true);}}; }
  host.querySelectorAll('[data-sched]').forEach(btn=>{btn.onclick=async()=>{const n=+btn.dataset.sched;if(sch&&sch.bundled===n){toast(`Already on ${n} bots per day.`);return;}
    const own=sch&&sch.own&&sch.own[n];
    if(!confirm(`Switch the Weekly Blueprint to ${n} bots per day?\n\nThis loads ${own?`your ${n===3?'Kill Switch':'2-bots-per-day'} files (${own.rulesName} + ${own.templateName})`:`the ${n}-bots-per-day rulebook and card template that came with the app`} (it replaces the rulebook and template in use now; Revert to Previous Version brings them back). The NTR tab and the cards already in this week are not changed. Press Generate Week afterwards to build a week on the new schedule.`))return;
    try{busy(true,`Switching to ${n} bots per day...`,'Reading the rulebook and card template for that schedule.');const r=await window.juicyApp.scheduleSet(n);if(r.unchanged){toast(`Already on ${n} bots per day.`);return;}bpLast=r;state=r.state;BP=await window.juicyApp.blueprintGet();renderAll();toast(`Now on ${n} bots per day. Press Rebuild Day Tabs Only to change this week's day tabs and keep the NTR tabs, or Generate Week for a whole new week.`);}catch(e){toast(e.message,true);}finally{busy(false);renderBlueprintSettings();}};});
  if($('ks-rules')){$('ks-rules').onclick=async()=>{const r=await window.juicyApp.blueprintChoose('rules');if(r){ksPick.rules=r;renderBlueprintSettings();}};
    $('ks-template').onclick=async()=>{const r=await window.juicyApp.blueprintChoose('template');if(r){ksPick.template=r;renderBlueprintSettings();}};
    $('ks-save').onclick=async()=>{try{busy(true,'Saving the Kill Switch files...','Checking that they make 3 cards a day.');await window.juicyApp.scheduleSaveFiles(3,ksPick.rules?ksPick.rules.path:null,ksPick.template?ksPick.template.path:null);ksPick={rules:null,template:null};toast(sch&&sch.perDay===3?'Kill Switch files saved. Press 3 bots/day to load them now.':'Kill Switch files saved. Press 3 bots/day whenever you want to switch.');}catch(e){toast(e.message,true);}finally{busy(false);renderBlueprintSettings();}};}
  $('bp-rules').onclick=async()=>{const r=await window.juicyApp.blueprintChoose('rules');if(r){bpPick.rules=r;renderBlueprintSettings();}};
  $('bp-template').onclick=async()=>{const r=await window.juicyApp.blueprintChoose('template');if(r){bpPick.template=r;renderBlueprintSettings();}};
  $('bp-update').onclick=async()=>{try{busy(true,'Updating the Weekly Blueprint...',bpPick.rules&&bpPick.template?'Reading your rulebook and card template.':bpPick.rules?'Reading your rulebook (the card template stays as it is).':'Reading your card template (the rulebook stays as it is).');const r=await window.juicyApp.blueprintUpdate(bpPick.rules?bpPick.rules.path:null,bpPick.template?bpPick.template.path:null);bpLast=r;bpPick={rules:null,template:null};state=r.state;BP=await window.juicyApp.blueprintGet();renderAll();toast(`Blueprint updated to ${r.status.current.label}.${(r.staleFixed||[]).length?` Your rulebook now fixes ${r.staleFixed.map(x=>x.day+' = '+x.theme).join(', ')}, but this week was built before that. Press Generate Week to get it.`:''}${r.lanes&&r.lanes.modesUpdated?` ${r.lanes.modesUpdated} Preventable NTR card${r.lanes.modesUpdated>1?'s were':' was'} rewritten for the rulebook's modes.`:''}`);}catch(e){toast(e.message,true);}finally{busy(false);renderBlueprintSettings();}};
  $('bp-revert').onclick=async()=>{if(!confirm(`Revert to ${st?.revertTo||'the previous version'}?`))return;try{const r=await window.juicyApp.blueprintRevert();bpLast=r;state=r.state;BP=await window.juicyApp.blueprintGet();renderAll();toast(`Reverted. Now using ${r.status.current?.label||'no blueprint'}.`);}catch(e){toast(e.message,true);}finally{renderBlueprintSettings();}};
}
// ---- Blocked tags (Settings): edited here, applied by Save Settings
let blockedDraft=null,blockTagCache={key:'',tags:[]};
const blockNorm=t=>String(t==null?'':t).toLowerCase().replace(/^#+/,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
function blockedNow(){return blockedDraft||((state&&state.settings&&state.settings.blockedTags)||[]);}
// tags that are really sentences, emoji or symbols are left out of the pick list (they can still be typed and blocked)
const blockOdd=n=>/[\p{Extended_Pictographic}\p{So}‍️]/u.test(n)||n.length>60||n.trim().split(/\s+/).length>8;
function setBlockTags(tags){blockTagCache.tags=(tags||[]).filter(t=>t&&t.name&&!blockOdd(t.name)).map(t=>({name:t.name,count:t.count||0,n:blockNorm(t.name)}));}
async function loadBlockTags(force){
  const st=state||{},key=(st.datasets&&st.datasets.lastCollectedAt||'')+'|'+(st.juicyTagsAt||'');
  if(!force&&blockTagCache.key===key&&blockTagCache.tags.length)return;
  try{const r=await window.juicyApp.tagsList();blockTagCache.key=key;setBlockTags(r.tags||[]);}catch(e){blockTagCache.key=key;blockTagCache.tags=[];}
  renderBlockPick();
}
function renderBlockChips(){
  const box=$('block-chips');if(!box)return;
  const list=blockedNow();
  box.innerHTML=list.length?list.map(t=>`<span class="block-chip">${esc(t)}<button type="button" class="block-x" data-tag="${esc(t)}" title="Unblock ${esc(t)}">×</button></span>`).join(''):'<span class="micro">No tags blocked.</span>';
}
// the pick list shows every matching tag (all the tags read from JuicyChat), and only the pick list is redrawn while typing
function renderBlockPick(){
  const pick=$('block-pick');if(!pick)return;
  const have=new Set(blockedNow().map(blockNorm)),q=blockNorm(($('block-input')||{}).value||'');
  const all=blockTagCache.tags,shown=[];
  if(q){
    for(const t of all){if(t.n.startsWith(q)&&!have.has(t.n))shown.push(t);}
    for(const t of all){if(!t.n.startsWith(q)&&t.n.includes(q)&&!have.has(t.n))shown.push(t);}
  }else for(const t of all){if(!have.has(t.n))shown.push(t);}
  pick.innerHTML=shown.map(t=>`<button type="button" class="block-pick-b" data-tag="${esc(t.name)}">${esc(t.name)}${t.count?`<em>${t.count}</em>`:''}</button>`).join('')||(all.length?'<span class="micro">No other tag matches. Press Block to block what you typed.</span>':'<span class="micro">No tags yet. Collect Recent + Trending, or press Read tags from JuicyChat.</span>');
}
function renderBlocked(skipLoad){
  renderBlockChips();renderBlockPick();
  if(!skipLoad)loadBlockTags(false);
}
function blockTag(name){
  const label=String(name||'').replace(/^[^\p{L}\p{N}]+/u,'').replace(/\s+/g,' ').trim().slice(0,60);if(!label)return;
  const cur=[...blockedNow()];if(cur.some(x=>blockNorm(x)===blockNorm(label)))return;
  blockedDraft=[...cur,label];if(window.__settingsDirty)window.__settingsDirty(true);$('block-input').value='';renderBlocked(true);
}
function bindBlocked(){
  const panel=$('block-panel');if(!panel||panel.dataset.bound)return;panel.dataset.bound='1';
  panel.addEventListener('click',e=>{
    const x=e.target.closest('.block-x'),b=e.target.closest('.block-pick-b');
    if(x){blockedDraft=blockedNow().filter(t=>t!==x.dataset.tag);if(window.__settingsDirty)window.__settingsDirty(true);renderBlocked(true);}
    else if(b)blockTag(b.dataset.tag);
  });
  $('block-add').onclick=()=>blockTag($('block-input').value);
  $('block-input').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();blockTag($('block-input').value);}});
  let bt=null;$('block-input').addEventListener('input',()=>{clearTimeout(bt);bt=setTimeout(renderBlockPick,120);});
  $('block-fetch').onclick=async()=>{const btn=$('block-fetch');btn.disabled=true;$('block-note').textContent='Reading tags from JuicyChat...';
    try{const r=await window.juicyApp.tagsFetch();$('block-note').textContent=`Read ${r.count} tags from JuicyChat.`;await loadBlockTags(true);}
    catch(e){$('block-note').textContent=e.message;}finally{btn.disabled=false;}};
}
function renderSettings(){renderPolicySettings();bindBlocked();renderBlocked();renderBlueprintSettings();renderImageLockSettings();renderUpdateSettings();renderAiSettings();const s=state.settings;$('auto-collect').checked=s.autoCollect!==false;$('auto-performance').checked=s.autoPerformance!==false;$('open-at-login').checked=!!s.openAtLogin;$('pull-timezone').value=s.pullTimeZone==='computer'?'computer':'est';$('collect-time').value=s.collectTime||'20:00';$('perf-time').value=s.perfTime||'20:00';$('auto-morning').checked=s.autoMorning===true;$('morning-time').value=s.morningTime||'08:00';$('lounge-main').value=s.loungeMain||'';$('lounge-ntr').value=s.loungeNtr||'';$('target-recent').value=s.targetRecent;$('target-trending').value=s.targetTrending;$('gender-filter').value=s.gender||'Female';$('juicy-home-url').value=s.juicyHomeUrl||'https://www.juicychat.ai';refreshPullNotes();}
function renderDiscarded(){
  const el=$('block-discarded');if(!el)return;
  const d=state&&state.discardedBots;
  if(!d||!(d.items||[]).length){el.innerHTML=d?'<p class="micro">No bots were discarded in the last collection because of blocked tags.</p>':'';return;}
  const tagsHit=[...new Set(d.items.flatMap(x=>x.blocked||[]).map(t=>t))];
  const when=d.at?new Date(d.at).toLocaleString():'';
  el.innerHTML=`<div class="bd-box"><h4>These bots were discarded from your data because of the following blocked tags</h4>
    <p class="bd-sub">${d.items.length} bot${d.items.length===1?'':'s'} left out of the last collection${when?` (${esc(when)})`:''}. They did not count toward the pull, so the scan kept going to reach your target. Blocked: ${tagsHit.map(t=>esc(t)).join(', ')||'-'}.</p>
    <div class="bd-list">${d.items.map(x=>{const hit=new Set((x.blocked||[]).map(blockNorm));const tags=[...(x.blocked||[]),...(x.tags||[]).filter(t=>!hit.has(blockNorm(t)))];
      return `<div class="bd-row"><span class="bd-name">${x.url?`<a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(x.name)}</a>`:esc(x.name)}</span><span class="bd-sec">${esc((x.sections||[]).join(' + '))}</span><span class="bd-tags">${tags.map(t=>`<span class="bd-tag${hit.has(blockNorm(t))?' hit':''}">${esc(t)}</span>`).join('')}</span></div>`;}).join('')}</div></div>`;
}
function renderBlockReminder(){
  const el=$('block-reminder');if(!el)return;
  const list=(state&&state.settings&&state.settings.blockedTags)||[];
  el.innerHTML=list.length
    ?`<span class="br-label">Blocked tags (${list.length}), skipped when collecting:</span>${list.map(t=>`<span class="block-chip">${esc(t)}</span>`).join('')}<a class="br-change">Change</a>`
    :`<span class="br-label">Blocked tags: none.</span><a class="br-change">Block tags</a>`;
  const a=el.querySelector('.br-change');if(a)a.onclick=()=>{const b=document.querySelector('.nav-btn[data-view="settings"]');if(b)b.click();setTimeout(()=>{const p=$('block-panel');if(p)p.scrollIntoView({block:'center'});},120);};
}
function renderAll(){window.__eventRB=(state.event&&state.event.active&&state.event.rulebook)||null;window.__eventName=(state.event&&state.event.parsed&&(state.event.parsed.name||state.event.parsed.eventTag))||'';window.eventForCard=eventForCardId;if(!state)return;renderEventPill();renderDashboard();renderAnalysis();renderEngines();renderWeek();renderBonusView();renderEvent();renderPerformance();renderAutoStatus();renderBlockReminder();renderDiscarded();renderDashUpdate();renderCollectAs();renderSettings();weekSub();}
function weekSub(){try{if(IS_SHARE)return;const e=document.getElementById('wk-sub'),tabs=(BP&&Array.isArray(BP.tabs)?BP.tabs:[]).filter(t=>t.kind==='day');if(e&&tabs.length)e.textContent=`${tabs.reduce((n,t)=>n+(t.cards||0),0)} core day scenarios (${Math.max(...tabs.map(t=>t.cards||0))} a day) + 7 Likeable NTR scenarios. Refresh one card or rebuild the entire week.`;}catch{}}
let bonusDraft={brief:'',title:'',name:'',series:'Auto',archetype:'Auto',relationship:'',setting:'',hook:'',tags:'',futa:false},bonusCheckResult=null;
let BONUS_SERIES=['Auto','Standalone','Bully Series','ANTI-NTR Series','Dommy Mommy Series','Stepmom Series','Stepsister Series','Gentle Giant Series','Tomboy Series','Yandere Series','Bakadere Series','Likeable NTR'];
const BONUS_ARCH=['Auto','Brat','Bully','Bimbo','Submissive','Seductive','Flirty','Affectionate','Stoic','Serious','Sadistic','Maid','Tomboy','Villain','Hero','Royalty','Celebrity','Goth','Mafia/Gang','Bakadere','Dandere','Deredere','Himedere','Hinedere','Kuudere','Kamidere','Mayadere','Tsundere','Yandere','Undere'];
function bonusFormHtml(){if(IS_SHARE){BONUS_SERIES.length=0;BONUS_SERIES.push('Auto','Standalone');}const d=bonusDraft,inp=(k,ph)=>`<input class="bonus-in" data-k="${k}" value="${esc(d[k])}" placeholder="${esc(ph)}">`,sel=(k,opts)=>`<select class="bonus-in" data-k="${k}">${opts.map(o=>`<option ${o===d[k]?'selected':''}>${esc(o)}</option>`).join('')}</select>`;
  const ds=state.datasets||{},n=(ds.recent?.length||0)+(ds.trending?.length||0);
  return `<div class="panel bonus-form"><div class="panel-head"><div><h3>New bonus idea</h3><p>Describe the bot in a sentence or two. The app builds the full scenario card (same fields as the weekly ones) and estimates its success from ${n?`the ${n} collected bots and ${state.engineAnalysis?.engines?.length||0} measured engines`:'the idea alone until you collect Recent + Trending'}.</p></div></div>
  <textarea class="bonus-in bonus-brief" data-k="brief" rows="3" placeholder="e.g. My ex shows up at my door after three years asking to stay the night, and she's hiding why she left.">${esc(d.brief)}</textarea>
  <div id="bonus-detect" class="bonus-detect" style="display:none"></div>
  <details class="bonus-more"><summary>More details (optional)</summary><div class="bonus-grid">
    <label>Scene name ${inp('title','Auto-detect from paste, or generate')}</label><label>Character name ${inp('name','Leave blank to generate')}</label>
    <label>Series ${sel('series',BONUS_SERIES)}</label><label>Archetype ${sel('archetype',BONUS_ARCH)}</label>
    <label>Relationship to you ${inp('relationship',"e.g. your ex-girlfriend")}</label><label>Setting ${inp('setting','e.g. a snowed-in mountain cabin')}</label>
    <label class="wide">Opening moment (the hook) ${inp('hook','What is happening when the chat starts? Leave blank to generate')}</label>
    <label>Extra tags ${inp('tags','comma separated, e.g. Fantasy, Magic')}</label><label class="bonus-check"><input type="checkbox" class="bonus-in" data-k="futa" ${d.futa?'checked':''}> Futanari character</label>
    <div class="wide bonus-cast"><h5>Other characters <small>(up to 2 more, for 3 in total${IS_SHARE?'':'. ANTI-NTR gets an antagonist automatically if you leave this empty'})</small></h5>
      ${[1,2].map(i=>`<div class="bonus-cast-row"><input class="bonus-in" data-k="c${i}name" value="${esc(d['c'+i+'name']||'')}" placeholder="Name"><select class="bonus-in" data-k="c${i}role">${['Secondary','Antagonist','Love Rival','Friend','Family','Other'].map(r=>`<option ${r===(d['c'+i+'role']||'Secondary')?'selected':''}>${r}</option>`).join('')}</select><input class="bonus-in" data-k="c${i}age" value="${esc(d['c'+i+'age']||'')}" placeholder="Age"><input class="bonus-in wide-in" data-k="c${i}about" value="${esc(d['c'+i+'about']||'')}" placeholder="Who they are, e.g. her ex who keeps showing up"></div>`).join('')}
    </div>
  </div></details>
  <p class="micro bonus-paste-tip">Tip: you can paste a full scenario card here (for example from your Weekly Blueprint HTML's Copy button, or "Label: value" lines). Your scene name is detected automatically. Characters, tags and written fields are kept; the app fills missing fields. A Scene name entered in More details overrides the detected title.</p>
  <div class="button-row"><button id="bonus-check" class="secondary">Check success estimate</button>${(()=>{const evs=evpActive();if(!evs.length)return '';const v=bonusDraft.event!==undefined&&(bonusDraft.event==='none'||evs.some(e=>e.id===bonusDraft.event))?bonusDraft.event:evs[0].id;return `<label class="bonus-day" title="Which event this idea is entered in. It stays with the idea when it is built, moved or regenerated.">Event <select id="bonus-event">${evpOpts(evs,v)}</select></label>`;})()}<label class="bonus-day">Release day <select id="bonus-day">${releaseDayOptions(bonusDraft.day||'Bonus')}</select></label><button id="bonus-add" class="primary">＋ Add ${!bonusDraft.day||bonusDraft.day==='Bonus'?'to Bonus':(bonusDraft.day==='NTR'?'to NTR':'to '+esc(bonusDraft.day))}</button></div>
  <div id="bonus-result">${bonusCheckResult?assessHtml(bonusCheckResult,true):''}</div></div>`;}
function bonusIdea(){const d=bonusDraft;const cast=[];if(d.name)cast.push({name:d.name,role:'Primary'});for(const i of [1,2])if((d['c'+i+'name']||'').trim())cast.push({name:d['c'+i+'name'],role:d['c'+i+'role']||'Secondary',age:d['c'+i+'age']||'',about:d['c'+i+'about']||''});
  return{brief:d.brief,title:d.title,name:d.name,relationship:d.relationship,setting:d.setting,hook:d.hook,futa:d.futa,series:d.series==='Auto'?'':d.series,archetype:d.archetype==='Auto'?'':d.archetype,tags:String(d.tags||'').split(',').map(x=>x.trim()).filter(Boolean),cast:cast.length>1?cast:[],eventId:d.event||''};}
const assessmentOpen = new Set();
try { for (const key of JSON.parse(localStorage.getItem('jbs-assessment-open') || '[]')) assessmentOpen.add(key); } catch {}
function assessmentIsOpen(key) { return assessmentOpen.has(String(key)); }
document.addEventListener('toggle', ev => {
  const el = ev.target;
  if (!el.matches?.('details.assess[data-assess]')) return;
  const key = el.dataset.assess;
  if (el.open) assessmentOpen.add(key); else assessmentOpen.delete(key);
  try { localStorage.setItem('jbs-assessment-open', JSON.stringify([...assessmentOpen].slice(-600))); } catch {}
}, true);
function assessHtml(a,preview=false,key='preview'){if(!a)return'';const cls=a.score>=75?'strong':a.score>=60?'good':a.score>=45?'mid':'weak';
  return `<details class="assess ${cls}" data-assess="${esc(key)}" ${assessmentIsOpen(key)?'open':''}><summary class="assess-top" title="Expand or collapse success estimate"><div class="assess-ring"><strong>${esc(a.score)}</strong><small>/100</small></div><div class="assess-head"><div class="eyebrow" ${tip('successEstimate')}>${preview?'SUCCESS ESTIMATE* (NOT SAVED YET)':'SUCCESS ESTIMATE*'} ${tipI('successEstimate')}</div><h4><span ${tip('band')}>${esc(a.band)}</span> · <span ${tip('confidence')}>${esc(a.confidence)} confidence</span></h4><p>${a.sample?.recent||a.sample?.trending?`Compared with ${esc(a.sample.recent)} Recent + ${esc(a.sample.trending)} Trending bots${a.bestEngine?` · closest engine: <b>${esc(a.bestEngine.name)}</b> (${esc(a.bestEngine.fit)}% fit)`:''}.`:esc(a.note||'')}</p><p class="micro assess-foot">*The Success Estimate is based on the data the tool has pulled from Recent and Trending.</p></div><span class="assess-chevron" aria-hidden="true"></span></summary>
  <div class="assess-cols"><div><h5 ${tip('moved')}>What moved the score</h5><ul class="assess-breakdown">${(a.breakdown||[]).map(b=>`<li class="${b.delta>0?'up':b.delta<0?'down':''}"><span class="delta">${b.delta>0?'+':''}${esc(b.delta)}</span><div><b ${tip(b.label)}>${esc(b.label)}</b><br>${esc(b.detail)}</div></li>`).join('')}</ul></div>
  <div>${a.suggestions?.length?`<h5 ${tip('raise')}>How to raise it</h5><ul class="assess-tips">${a.suggestions.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}
  ${a.similar?.length?`<h5 ${tip('similarBots')}>Most similar collected bots</h5><div class="assess-similar">${a.similar.slice(0,8).map(x=>`${botChip(x)}<span class="sim-meta">${esc(x.percentile)}th pct · ${esc(x.similarity)}% similar</span>`).join('')}</div>`:''}</div></div>
  <p class="micro assess-note">A relative estimate from the collected sample, not a guarantee. It gets sharper as you collect more data and log real results in Performance.</p></details>`;}
let bonusLastAdded=null;
function renderBonusView(){const host=$('bonus-view');if(!host)return;const added=bonusLastAdded&&bonusCards().find(b=>b.id===bonusLastAdded);
  host.innerHTML=bonusFormHtml()+(added?`<div class="panel bonus-added"><div class="bonus-added-head"><div><div class="eyebrow">ADDED TO BONUS</div><h3>${esc(added.sceneName)} <small>· ${esc(added.primaryCharacter)}</small></h3></div><div class="button-row"><button class="secondary" data-open-bonus>View in Weekly Blueprint › Bonus</button><button class="ghost to-builder" data-id="${esc(added.id)}">✎ Build bot</button></div></div>${assessHtml(added.bonusAssessment,false,added.id)}</div>`:'')+bonusListHtml();
  bindBonus();bindPolicy();
  qsa('#bonus-view .bl-improve').forEach(b=>b.onclick=()=>openSuggest(b.dataset.id,'bonus'));
  bindSuggest('#bonus-view',renderBonusView);
  qsa('#bonus-view .bl-move').forEach(sel=>sel.onchange=async()=>{try{const st=await window.juicyApp.bonusMove(sel.dataset.id,sel.value);state=st;renderAll();toast(`Moved to ${st.__placed||sel.value}.`);}catch(e){toast(e.message,true);}});
  {const ev=$('bonus-event');if(ev){bonusDraft.event=ev.value;ev.onchange=()=>{bonusDraft.event=ev.value;};}}
  qsa('#bonus-view .event-pick').forEach(el=>el.onchange=async()=>{try{const id=el.dataset.id,before=currentWeekAll().find(x=>x.id===id),name=before?before.sceneName:'This idea';state=await window.juicyApp.cardSetEvent(id,el.value!=='none',el.value);renderAll();const e=evList().find(x=>x.id===el.value);toast(el.value==='none'?`${name} is not in any event.`:`${name} is entered in ${e?evName(e,evList().indexOf(e)):'the event'}.`);}catch(e){renderAll();toast(e.message,true);}});
  {const d=$('bonus-day');if(d)d.onchange=()=>{bonusDraft.day=d.value;const b=$('bonus-add');if(b)b.textContent='＋ Add '+(d.value==='Bonus'?'to Bonus':'to '+d.value);};}
  qsa('#bonus-view .bl-edit').forEach(b=>b.onclick=()=>{editingBonus=b.dataset.id;activeDay='Bonus';switchView('weekly');renderWeek();setTimeout(()=>{const el=document.querySelector(`.bonus-edit[data-id="${CSS.escape(b.dataset.id)}"]`);if(el)el.closest('.scenario-card')?.scrollIntoView({block:'start',behavior:'smooth'});},60);});qsa('#bonus-view .to-builder').forEach(b=>b.onclick=()=>{switchView('builder');if(window.builderPreselect)window.builderPreselect(b.dataset.id);});}
// every bonus idea, each with an Edit button that opens its card's editor
const RELEASE_DAYS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
function releaseDayOptions(sel){return [['Bonus','Bonus tab'],...RELEASE_DAYS.map(d=>[d,d]),...(IS_SHARE?[]:[['NTR','NTR']])].map(([v,l])=>`<option value="${v}" ${v===sel?'selected':''}>${l}</option>`).join('');}
// every card that came from a Bonus idea, wherever it sits
function bonusCards(){const w=state.week||{};return [...(w.bonus||[]),...(w.scenarios||[]).filter(c=>c.bonusIdea),...(w.ntr||[]).filter(c=>c.bonusIdea)];}
// Delete on the Bonus ideas list: the card leaves the week (a linked bot keeps its frozen score and archived card)
// one listener for every Delete button in the Bonus ideas view, so it works however the list or a panel in it was drawn

// ---- Paste scenario: paste a whole scenario into one scene card; the app reads it, shows what it found, and fills the card only after you confirm
function pasteScenarioDialog(id){
  const card=currentWeekAll().find(x=>x.id===id);if(!card)return;
  if(document.getElementById('paste-scenario-modal'))return;
  const root=document.createElement('div');root.className='upd-modal sr-modal';root.id='paste-scenario-modal';
  let step='edit',text='',pv=null;
  const close=()=>{root.remove();};
  const chip=(k,v,cls='')=>v?`<span class="ps-chip ${cls}"><b>${esc(k)}</b> ${esc(v)}</span>`:`<span class="ps-chip ps-miss"><b>${esc(k)}</b> not found</span>`;
  const draw=()=>{
    if(step==='edit'){
      root.innerHTML=`<section class="upd-box ps-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>Paste a scenario into "${esc(card.sceneName||'this card')}"</h3><p class="upd-sub">Paste the whole scenario. The app reads the character's name, age and race, the scene name, series, tags, setup, personality and every other section, whatever layout it is in (bold labels, headings, plain "Label:" lines, or even no labels). Nothing changes until you confirm on the next screen. No AI is used.</p></header>
        <textarea id="ps-text" class="ps-text" rows="16" spellcheck="false" placeholder="Scene Name: ...&#10;Series Assignment: ...&#10;The Setup: ...&#10;Character's Personality: ...&#10;Tags: ...">${esc(text)}</textarea>
        <p class="ps-err" id="ps-err" role="alert"></p>
        <footer><span class="micro">This replaces the card's text. The old card is archived with its scores.</span><div class="button-row"><button type="button" class="ghost" id="ps-cancel">Cancel</button><button type="button" class="primary" id="ps-read">Read it</button></div></footer></section>`;
      const ta=root.querySelector('#ps-text'),err=root.querySelector('#ps-err');ta.focus();
      root.querySelector('#ps-cancel').onclick=close;
      root.querySelector('#ps-read').onclick=async()=>{text=ta.value;err.textContent='';const b=root.querySelector('#ps-read');b.disabled=true;
        try{pv=await window.juicyApp.pastePreview(id,text);step='review';draw();}catch(e){err.textContent=(e&&e.message||String(e)).replace(/^Error invoking remote method '[^']+': (Error: )?/,'');b.disabled=false;}};
    }else{
      const f=pv.found,minor=(pv.minors||[]).length;
      root.innerHTML=`<section class="upd-box ps-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>Here is what the app found</h3><p class="upd-sub">Check it, then fill the card. It will replace "${esc(pv.replaces||'the card')}".</p></header>
        <div class="ps-found">${chip('Scene name',f.sceneName)}${chip('Character',f.character)}${chip('Age',f.age)}${f.race?chip('Race',f.race+(f.raceKnown?'':' (guess)'),f.raceKnown?'':'ps-guess'):chip('Race','')}${chip('Series',f.series)}${chip('Archetype',f.archetype)}</div>
        <div class="ps-tags"><b>Tags</b> ${(f.tags||[]).length?f.tags.map(t=>`<span class="ps-tag">${esc(t)}</span>`).join(''):'<span class="ps-miss">none found</span>'}</div>
        ${minor?`<p class="ps-bad" role="alert"><b>Mentions a minor or a school setting</b> (${esc(pv.minors.slice(0,4).join(', '))}). Everyone in a story must be 18 or older. You can still fill the card, then rewrite those parts.</p>`:''}
        ${(pv.notes||[]).map(n=>`<p class="ps-note">${esc(n)}</p>`).join('')}
        <h4 class="ps-h">Sections read (${pv.fields.length})</h4>
        <div class="ps-fields">${pv.fields.map(x=>`<div class="ps-row"><span class="ps-lab">${esc(x.label)}</span><span class="ps-chars">${x.chars.toLocaleString()} chars</span><span class="ps-prev">${esc(x.preview)}${x.chars>110?'…':''}</span></div>`).join('')}</div>
        <p class="ps-err" id="ps-err" role="alert"></p>
        <footer><span class="micro">A section that is not listed here was not in the text. Add it later with Edit.</span><div class="button-row"><button type="button" class="ghost" id="ps-back">Back to the text</button><button type="button" class="ghost" id="ps-cancel">Cancel</button><button type="button" class="primary" id="ps-apply">Fill this card</button></div></footer></section>`;
      root.querySelector('#ps-back').onclick=()=>{step='edit';draw();};
      root.querySelector('#ps-cancel').onclick=close;
      root.querySelector('#ps-apply').onclick=async()=>{const b=root.querySelector('#ps-apply');b.disabled=true;
        try{state=await window.juicyApp.pasteApply(id);close();renderAll();toast(`"${pv.found.sceneName||'The scenario'}" is now in the card.`);}catch(e){root.querySelector('#ps-err').textContent=(e&&e.message||String(e)).replace(/^Error invoking remote method '[^']+': (Error: )?/,'');b.disabled=false;}};
    }
  };
  document.body.appendChild(root);draw();
  root.addEventListener('keydown',e=>{if(e.key==='Escape')close();});
}

// ---- Move a card to another tab (Monday to Sunday, Bonus). It goes to the top of that tab. A card in one of its day's own slots leaves a spot behind: you choose to reset it (kept empty) or delete it.
function moveCardDialog(id){
  const card=currentWeekAll().find(x=>x.id===id);if(!card||document.getElementById('move-card-modal'))return;
  const here=card.slot==='Bonus'||card.day==='Bonus'?'Bonus':card.day, extra=!!(card.addedBonus||(card.bonusIdea&&card.day&&card.day!=='Bonus'&&card.slot!=='Bonus')), core=here!=='Bonus'&&!extra;
  const dests=[...MOVE_TABS,'Bonus'].filter(d=>d!==here), name=card.sceneName&&card.sceneName!=='Untitled'?card.sceneName:'This card';
  const m=document.createElement('div');m.className='upd-modal';m.id='move-card-modal';m.setAttribute('role','dialog');m.setAttribute('aria-modal','true');m.setAttribute('aria-labelledby','mv-h');
  m.innerHTML=`<div class="upd-box"><h3 id="mv-h">Move this card</h3><p class="upd-sub"><b>${esc(name)}</b> is in ${esc(here)}${core?` (${esc(card.slot||'')})`:''}.</p>
    <label class="micro">Move it to <select id="mv-dest">${dests.map(d=>`<option value="${esc(d)}">${esc(d)}</option>`).join('')}</select></label>
    <p class="micro">It goes to the <b>top</b> of that tab and keeps its text, its Built tick, its score and its linked bot.</p>
    ${core?`<p class="micro"><b>What should happen to its old spot in ${esc(here)}?</b><br><b>Reset</b> keeps the spot, empty, ready to fill again (like Clear &amp; Reset Tab).<br><b>Delete</b> removes the spot, so ${esc(here)} has one card fewer (Regenerate Tab brings it back).</p>`:''}
    <div class="button-row" style="margin-top:12px">${core?`<button type="button" class="primary" data-mv="reset">Move and reset the old spot</button><button type="button" class="ghost" style="color:#ff9a9a;border-color:#7a3a3a" data-mv="delete">Move and delete the old spot</button>`:`<button type="button" class="primary" data-mv="go">Move</button>`}<button type="button" class="ghost" data-mv="cancel">Cancel</button></div></div>`;
  document.body.appendChild(m);
  const close=()=>m.remove();
  m.addEventListener('click',async e=>{
    if(e.target===m){close();return;}
    const b=e.target.closest&&e.target.closest('[data-mv]');if(!b)return;
    if(b.dataset.mv==='cancel'){close();return;}
    const dest=m.querySelector('#mv-dest').value;
    try{const st=await window.juicyApp.cardMove(id,dest,core?b.dataset.mv:'',core?bpType(card):'');state=st;close();renderAll();toast(`Moved "${name}" to ${st.__placed||dest}.`);}catch(err){toast(err.message,true);}
  });
  m.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();close();}});
  m.querySelector('#mv-dest').focus();
}
document.addEventListener('click',e=>{const b=e.target&&e.target.closest?e.target.closest('.card-move'):null;if(b)moveCardDialog(b.dataset.id);});
document.addEventListener('click',e=>{const b=e.target&&e.target.closest?e.target.closest('.card-paste'):null;if(b)pasteScenarioDialog(b.dataset.id);});
document.addEventListener('click',e=>{const b=e.target&&e.target.closest?e.target.closest('#bonus-view .card-del'):null;if(b)deleteBonusCard(b.dataset.id);});
async function deleteBonusCard(id){const c=bonusCards().find(x=>x.id===id);if(!c)return;
  if(!confirm(`Delete "${c.sceneName}"${c.day&&c.day!=='Bonus'?` (${c.day} ${c.slot||''})`:''}? The card leaves the week. A linked bot keeps its frozen score and archived card.`))return;
  try{state=await window.juicyApp.cardDelete(c.id);if(sugWeekOpen===c.id)sugWeekOpen=null;if(sugBonusOpen===c.id)sugBonusOpen=null;renderAll();toast(`Deleted "${c.sceneName}".`);}catch(e){toast(e.message,true);}}
function bonusListHtml(){const list=bonusCards();if(!list.length)return'';
  return `<div class="panel bonus-list"><div class="panel-head"><div><h3>Your bonus ideas</h3><p>${list.length} idea${list.length>1?'s':''}. Edit changes the card itself: scene name, characters, tags and every field.</p></div></div>
  ${list.map(b=>{const sc=b.prediction?.score;return `<div class="bl-row-wrap"><div class="bl-row"><div><b>${esc(b.sceneName||'Untitled')}</b><span>${esc(b.primaryCharacter||'')} · <b class="bl-day">${b.day&&b.day!=='Bonus'?`${esc(b.day)} · ${esc(b.slot||'')}`:'Bonus tab'}</b>${normStatus(state.week.statuses?.[b.id])==='Built'?' · <em class="bl-built">Built</em>':''}</span></div><div class="button-row">${evList().some(e=>e.parsed||e.raw)?eventPickHtml(b):''}<select class="bl-move" data-id="${esc(b.id)}" title="Move this card to another release day">${releaseDayOptions(b.day&&b.day!=='Bonus'?b.day:'Bonus')}</select>${policyToggle(b)}<span class="imp-score ${scoreCls(sc)} bl-score">${sc??'–'}<small>/100</small></span><button class="ghost card-paste" data-id="${esc(b.id)}" title="Paste a whole scenario into this card">📋 Paste scenario</button><button class="ghost bl-improve" data-id="${esc(b.id)}" title="Ideas to consider adding or tweaking, read from this scenario">${sugBonusOpen===b.id?'Close':'💡 Suggestions'}</button><button class="secondary bl-edit" data-id="${esc(b.id)}">✎ Edit</button><button class="ghost card-del" data-id="${esc(b.id)}" title="Delete this card">🗑 Delete</button><button class="ghost to-builder" data-id="${esc(b.id)}">✎ Build bot</button></div></div>${sugBonusOpen===b.id?suggestHtml(b.id):''}${policyPanel(b)}${trackerPanel(b)}</div>`;}).join('')}</div>`;}
// the same help the ChatGPT import gives, for one Bonus card
// ---- Suggestions: ideas to consider adding or tweaking, read from the card itself. Nothing is changed, nothing is scored.
// The creator picks what to use: edit the card, put it in the Write with AI details, or give the list to ChatGPT.
let sugBonusOpen=null,sugWeekOpen=null,sug=null,sugFixTicks={};      // sug: {id, items, fixes, busy, error, ticked:Set}
const SUG_KIND={add:'Consider adding',tweak:'Consider tweaking'};
function sugText(){if(!sug)return'';const pick=sug.items.filter((x,i)=>sug.ticked.has(i)),list=pick.length?pick:sug.items;
  const card=currentWeekAll().find(c=>c.id===sug.id)||{sceneName:''};
  const group=(k)=>{const l=list.filter(x=>x.kind===k);return l.length?`${SUG_KIND[k].toUpperCase()}\n${l.map(x=>`- ${x.title}${x.where?` (${x.where})`:''}\n  ${x.idea}${x.why?`\n  Builds on: ${x.why}`:''}`).join('\n')}`:'';};
  return [`Suggestions for "${card.sceneName||'this scenario'}"`,group('add'),group('tweak')].filter(Boolean).join('\n\n');}
function suggestHtml(id){
  const S=sug&&sug.id===id?sug:null;
  const fixes=S&&S.fixes||[];
  const items=S?S.items:[];
  return `<div class="bl-imp sug"><div class="sug-head"><h5>Suggestions</h5><p class="micro">Ideas for this scenario, read from the scenario itself. Nothing is changed and there is no score. Take what helps: edit the card, use an idea in the <b>Rewrite Card</b> details, or copy the list into ChatGPT.</p></div>
    <div class="button-row"><button class="primary sug-local" data-id="${esc(id)}" title="The app reads the card and suggests ideas itself: free, instant, no AI needed.">${items.length&&S.source==='local'?'💡 Get different suggestions':'💡 Get suggestions'}</button>${AI.on?`<button class="secondary sug-ai" data-id="${esc(id)}" ${S&&S.busy?'disabled':''} title="The AI reads the whole scenario and writes ideas that fit it closely. Uses your AI allowance.">${S&&S.busy?'Reading the scenario…':items.length&&S.source==='ai'?'✦ Get new AI suggestions':'✦ Get AI suggestions'}</button>`:''}<button class="secondary sug-req" data-id="${esc(id)}" title="Copies the request, with this scenario in it, to paste into ChatGPT. Works without the AI connection.">⧉ Copy request for ChatGPT</button></div>
    ${items.length&&S.source==='local'?'<p class="micro">These came from the app reading your card, so they are patterns: bend them to fit. '+(AI.on?'Get AI suggestions for ideas written around your exact story.':'Copy the request for ChatGPT for ideas written around your exact story.')+'</p>':''}
    ${S&&S.error?`<p class="ai-msg bad">${esc(S.error)}</p>`:''}
    ${items.length?['add','tweak'].map(k=>{const l=items.map((x,i)=>[x,i]).filter(([x])=>x.kind===k);return l.length?`<h6>${SUG_KIND[k]}</h6>${l.map(([x,i])=>`<label class="sug-item"><input type="checkbox" class="sug-tick" data-i="${i}" ${S.ticked.has(i)?'checked':''}><span><b>${esc(x.title)}</b>${x.where?` <em class="sug-where">${esc(x.where)}</em>`:''}<span class="sug-idea">${esc(x.idea)}</span>${x.why?`<small class="sug-why">Builds on: ${esc(x.why)}</small>`:''}</span></label>`).join('')}`:'';}).join('')+`<div class="button-row"><button class="secondary sug-copy">⧉ Copy ${S.ticked.size?`${S.ticked.size} ticked`:'all'}</button></div>`:''}
    ${fixes.length?`<h6>Quick fixes the app can make</h6><p class="micro">Small, safe changes to tags and event marking. Each one is yours to approve.</p>${fixes.map(f=>`<label class="imp-chg"><input type="checkbox" class="sug-fix" data-label="${esc(f.label)}" ${(sugFixTicks[id]||[]).includes(f.label)?'checked':''}><span><b>${esc(f.label)}</b>${(f.diff||[]).map(d=>`<span class="imp-diff"><i>${esc(d.field)}</i><del>${esc(d.from||'(empty)')}</del><ins>${esc(d.to)}</ins></span>`).join('')}</span></label>`).join('')}<button class="secondary sug-fix-go" data-id="${esc(id)}">${(sugFixTicks[id]||[]).length?`Apply ${(sugFixTicks[id]||[]).length} ticked`:fixes.length>1?`Apply all ${fixes.length} quick fixes`:'Apply this quick fix'}</button>`:''}
  </div>`;}
function bindSuggest(scope,rerender){
  const root=document.querySelector(scope);if(!root)return;
  const lc=root.querySelector('.sug-local');if(lc)lc.onclick=async()=>{const id=lc.dataset.id;try{const seed=((sug&&sug.id===id&&sug.seed)||0)+1;const r=await window.juicyApp.cardSuggestLocal(id,seed-1);sug={...(sug&&sug.id===id?sug:{id,fixes:[]}),id,items:r.suggestions||[],ticked:new Set(),busy:false,error:'',source:'local',seed};if(!sug.items.length)sug.error='The app found nothing to suggest from this card. Try the AI, or copy the request for ChatGPT.';}catch(e){sug={...(sug&&sug.id===id?sug:{id,items:[],fixes:[],ticked:new Set()}),id,error:e.message||String(e)};}rerender();};
  const ai=root.querySelector('.sug-ai');if(ai)ai.onclick=async()=>{const id=ai.dataset.id;sug={...(sug&&sug.id===id?sug:{id,items:[],fixes:[],ticked:new Set()}),id,busy:true,error:''};rerender();
    try{const r=await aiRun(()=>window.juicyApp.aiSuggestCard(id),'Reading the scenario for suggestions');if(r&&r.suggestions)sug={...sug,items:r.suggestions,ticked:new Set(),busy:false,error:'',source:'ai'};else sug={...sug,busy:false};}catch(e){sug={...sug,busy:false,error:e.message||String(e)};}rerender();};
  const rq=root.querySelector('.sug-req');if(rq)rq.onclick=async()=>{try{const t=await window.juicyApp.cardSuggestRequest(rq.dataset.id);await copyText(t);toast('Request copied. Paste it into ChatGPT to get ideas for this scenario.');}catch(e){toast(e.message,true);}};
  root.querySelectorAll('.sug-tick').forEach(c=>c.onchange=()=>{if(!sug)return;const i=+c.dataset.i;c.checked?sug.ticked.add(i):sug.ticked.delete(i);const b=root.querySelector('.sug-copy');if(b)b.textContent=`⧉ Copy ${sug.ticked.size?sug.ticked.size+' ticked':'all'}`;});
  const cp=root.querySelector('.sug-copy');if(cp)cp.onclick=async()=>{await copyText(sugText());toast('Suggestions copied.');};
  const boxes=[...root.querySelectorAll('.sug-fix')],go=root.querySelector('.sug-fix-go');
  if(go){const label=()=>{const on=boxes.filter(c=>c.checked).map(c=>c.dataset.label);sugFixTicks[go.dataset.id]=on;go.textContent=on.length?`Apply ${on.length} ticked`:boxes.length>1?`Apply all ${boxes.length} quick fixes`:'Apply this quick fix';};
    boxes.forEach(c=>c.onchange=label);
    go.onclick=async()=>{const ticked=boxes.filter(c=>c.checked).map(c=>c.dataset.label),labels=ticked.length?ticked:boxes.map(c=>c.dataset.label);
      try{const r=await window.juicyApp.bonusApplyTidy(go.dataset.id,labels);sugFixTicks[go.dataset.id]=[];state=r.state;if(sug&&sug.id===go.dataset.id)sug.fixes=r.fixes?r.fixes.fixes:[];renderAll();toast(`Applied ${labels.length} quick fix${labels.length>1?'es':''}.`);}catch(e){toast(e.message,true);}};}
}
// open or close the panel on a card; the quick fixes are read when it opens, the suggestions only when asked for
async function openSuggest(id,which){const cur=which==='week'?sugWeekOpen:sugBonusOpen,next=cur===id?null:id;if(which==='week')sugWeekOpen=next;else sugBonusOpen=next;
  sug=next?{id,items:[],fixes:[],ticked:new Set(),busy:false,error:''}:null;which==='week'?renderWeek():renderBonusView();if(!next)return;
  try{const q=await window.juicyApp.cardQuickFixes(id);if(sug&&sug.id===id)sug.fixes=q.fixes||[];}catch{}
  which==='week'?renderWeek():renderBonusView();const el=document.querySelector(which==='week'?'.week-imp':'.bl-imp');if(el)el.scrollIntoView({block:'nearest'});}
function openWeeklyBonus(){activeDay='Bonus';switchView('weekly');renderWeek();}
function bindBonusList(){const re=$('bonus-recheck');if(re)re.onclick=()=>runBusy('Re-checking bonus ideas against the latest data...',async()=>window.juicyApp.bonusRecheck());qsa('[data-go-bonus]').forEach(b=>b.onclick=()=>switchView('bonus'));}
let bonusParseT=null;
function showDetect(r){const el=$('bonus-detect');if(!el)return;if(!r||!r.full){el.style.display='none';el.innerHTML='';return;}
  el.style.display='';el.innerHTML=`<div class="bd-head">✓ Full scenario detected${bonusDraft.title.trim() ? ', using your scene-name override' : ', keeping the detected scene name'}</div><div class="bd-body"><b>${esc(bonusDraft.title.trim() || r.sceneName || '(no Scene Name found)')}</b>${r.series?` · ${esc(r.series)}`:''}${r.archetype?` · ${esc(r.archetype)}`:''}</div>
  <div class="bd-cast">${r.cast.length?r.cast.map(c=>`<span class="cast-chip role-${esc(c.role.toLowerCase())}"><small>${esc(c.role)}</small>${esc(c.name)}${c.age?` <em>${esc(c.age)}</em>`:''}</span>`).join(''):'<span class="bd-warn">No Primary Character found. The app will create one.</span>'}</div>
  ${(r.more||[]).length?`<div class="bd-warn">A card holds 3 characters. Also named in the text, not kept: ${esc(r.more.join(', '))}.</div>`:''}
  <div class="bd-meta">${r.fields} fields · ${r.tags.length} tags. The scene name is detected automatically. A Scene name entered in More details overrides it.</div>`;}
function detectPaste(){clearTimeout(bonusParseT);bonusParseT=setTimeout(async()=>{const text=bonusDraft.brief||'';try{const r=await window.juicyApp.bonusParse(text);if(text===(bonusDraft.brief||''))showDetect(r);}catch{if(text===(bonusDraft.brief||''))showDetect(null);}},250);}
function bindBonus(){qsa('[data-open-bonus]').forEach(b=>b.onclick=openWeeklyBonus);const br=document.querySelector('.bonus-brief');if(br){br.addEventListener('input',detectPaste);if(bonusDraft.brief)detectPaste();}qsa('.bonus-in').forEach(el=>{const ev=el.type==='checkbox'||el.tagName==='SELECT'?'change':'input';el.addEventListener(ev,()=>{bonusDraft[el.dataset.k]=el.type==='checkbox'?el.checked:el.value;if(el.dataset.k==='title')detectPaste();});});
  const chk=$('bonus-check');if(chk)chk.onclick=async()=>{try{bonusCheckResult=await window.juicyApp.bonusCheck(bonusIdea());$('bonus-result').innerHTML=assessHtml(bonusCheckResult,true);}catch(e){toast(e.message,true);}};
  const add=$('bonus-add');if(add)add.onclick=()=>runBusy('Building the bonus scenario and checking it against the collected data...',async()=>{const day=($('bonus-day')||{}).value||'Bonus';const before=new Set(bonusCards().map(b=>b.id));const st=await window.juicyApp.bonusAdd(bonusIdea(),day);state=st;const fresh=bonusCards().find(b=>!before.has(b.id));bonusLastAdded=fresh?.id||null;bonusDraft={brief:'',title:'',name:'',series:'Auto',archetype:'Auto',relationship:'',setting:'',hook:'',tags:'',futa:false,day,event:bonusDraft.event};bonusCheckResult=null;const where=st.__placed||'the Bonus tab';if(fresh&&fresh.pasted)toast(`Added "${fresh.sceneName}" to ${where}, with your scene name and ${fresh.cast.length} character${fresh.cast.length>1?'s':''} kept.`);else if(fresh)toast(`Added "${fresh.sceneName}" to ${where}.`);return st;});}
function bindScenarioButtons(){qsa('.pv-mode').forEach(sel=>sel.onchange=async()=>{const n=+sel.value,mm=((BP&&BP.modes)||[]).find(m=>m.no===n);if(mm&&mm.creatorOnly&&!confirm(`Mode ${n} (${mm.name}) is marked creator selection only in your rulebook. Use it for this card?`)){sel.value=String((state.week&&Object.values(state.week).flat().find?.(c=>c&&c.id===sel.dataset.id)?.modeNo)||1);return;}try{busy(true,'Rewriting this card for the selected mode...','');state=await window.juicyApp.setPreventableMode(sel.dataset.id,n);renderAll();toast('Mode switched. The card was rewritten for it.');}catch(err){toast(err.message||String(err));}finally{busy(false);}});
  qsa('.week-improve').forEach(b=>b.onclick=()=>openSuggest(b.dataset.id,'week'));
  bindSuggest('#week-content',renderWeek);
  qsa('.ai-fill').forEach(b=>b.onclick=()=>{const id=b.dataset.id,label=b.dataset.label||null,c=tabCardsAll().find(x=>x.id===id);if(!c)return;const nm=c.sceneName||'this card';
    if(!confirm(label?`Fill the blank "${label}" of "${nm}" with AI? The whole card is sent so it fits the story, and only this section is written. Nothing already written is changed.`:`Fill every blank section of "${nm}" with AI? The whole card is sent so the new text fits the story, and only the blank sections are written. Nothing already written is changed.`))return;
    aiRun(()=>window.juicyApp.aiFillCard(id,label?[label]:null),label?`Filling "${label}" with AI`:`Filling the blank sections of "${nm}" with AI`);});
  qsa('.scp-num').forEach(b=>b.onclick=async()=>{const id=b.dataset.id,c=currentWeekAll().find(x=>x.id===id);const cur=c&&/^SCP[- ]?0*(\d+)/i.exec(String(c.primaryCharacter||c.sceneName||''));
    const v=await askText({title:'SCP number',message:'The SCP number for this card (a whole number, for example 22). Only the main character\'s name and the Scene Name prefix change; nothing is rewritten and no AI is used.',value:cur?String(Number(cur[1])):'',placeholder:'for example 22',okLabel:'Change'});if(v===null)return;
    try{const r=await window.juicyApp.scpRename(id,v);state=r.state;renderAll();toast(`This card is now ${r.designation}.`);}catch(err){toast(err.message||String(err),true);}});
  qsa('.ai-card').forEach(b=>b.onclick=()=>{const id=b.dataset.id,c=tabCardsAll().find(x=>x.id===id);if(!c)return;const nm=c.sceneName||'this card',built=normStatus(state.week.statuses?.[id])==='Built';
    aiWriteOrContinue(j=>j.kind==='week'&&j.scope==='card:'+id,'card write',`Write "${nm}" with AI? Only this card is scrapped and written again from scratch (new characters, new story, nothing carried over), in its own request, and saved as soon as it is finished. The old version is archived with its score${built?', and the card is marked Built, so it goes back to Idea':''}. Every other card stays as it is.`,async focus=>{if(focus&&focus.eventId!==undefined)await window.juicyApp.weekSetEvents({[id]:focus.eventId},{adapt:false});return window.juicyApp.aiWriteCard(id,focus);},`Writing "${nm}" with AI`,()=>aiCardSeriesPick(id,nm,built),['card',id]);});
  qsa('.open-saved').forEach(b=>b.onclick=async()=>{const list=window.builderSavedFor(b.dataset.id);if(!list.length)return;const key=list[0].key;try{const bot=await window.juicyApp.builderLoadSavedBot(key);switchView('builder');setTimeout(()=>{if(window.builderLoadDraft)window.builderLoadDraft(bot.templateId,bot.values);const sel=document.getElementById('bb-saved');if(sel)sel.value=key;},120);}catch(e){toast(e.message,true);}});
  qsa('.edit-bonus').forEach(b=>b.onclick=()=>{editingBonus=editingBonus===b.dataset.id?null:b.dataset.id;renderWeek();const f=document.querySelector(`.bonus-edit[data-id="${CSS.escape(b.dataset.id)}"]`);if(f)f.scrollIntoView({block:'center'});});
  qsa('.be-cancel').forEach(b=>b.onclick=()=>{editingBonus=null;renderWeek();});
  qsa('.be-save').forEach(b=>b.onclick=async()=>{const box=b.closest('.bonus-edit'),id=b.dataset.id;
    const patch={sceneName:box.querySelector('[data-k=sceneName]').value.trim(),tags:box.querySelector('[data-k=tags]').value.split(',').map(x=>x.trim()).filter(Boolean),fields:{},cast:[]};
    box.querySelectorAll('.be-fld').forEach(t=>patch.fields[t.dataset.k]=t.value);
    for(let i=0;i<3;i++){const g=f=>box.querySelector(`.be-cast-in[data-i="${i}"][data-f="${f}"]`).value.trim();if(g('name'))patch.cast.push({name:g('name'),role:g('role'),age:g('age'),about:g('about')});}
    if(!patch.sceneName)return toast('Give the scene a name first.',true);if(!patch.cast.length)return toast('Keep at least the main character.',true);
    try{state=await window.juicyApp.cardUpdate(id,patch);editingBonus=null;renderAll();toast('Card updated.');}catch(e){toast(e.message,true);}});qsa('.remove-bonus').forEach(b=>b.onclick=async()=>{if(!confirm('Remove this bonus idea? A linked bot keeps its score and an archived copy of the card.'))return;try{state=await window.juicyApp.bonusRemove(b.dataset.id);renderAll();}catch(e){toast(e.message,true);}});qsa('.card-del').filter(b=>!b.closest('#bonus-view')).forEach(b=>b.onclick=async()=>{const c=[...(state.week?.scenarios||[]),...(state.week?.ntr||[]),...(state.week?.bonus||[])].find(x=>x.id===b.dataset.id);if(!c)return;if(!confirm(`Delete "${c.sceneName}"${c.day&&c.day!=='Bonus'?` (${c.day} ${c.slot||''})`:''}? The card leaves the week. A linked bot keeps its frozen score and archived card.`))return;try{state=await window.juicyApp.cardDelete(c.id);if(sugWeekOpen===c.id)sugWeekOpen=null;if(sugBonusOpen===c.id)sugBonusOpen=null;renderAll();toast(`Deleted "${c.sceneName}".`);}catch(e){toast(e.message,true);}});qsa('.to-builder').forEach(b=>b.onclick=()=>{switchView('builder');if(window.builderPreselect)window.builderPreselect(b.dataset.id);});
  bindPolicy();
  qsa('.build-bot').forEach(b=>b.onclick=()=>{if(!AI.on)return toast('Build Bot writes the bot with AI. Set up the AI writer in AI settings first.',true);if(window.builderBuildWithAI)window.builderBuildWithAI(b.dataset.id);else toast('The Bot Builder did not load. Restart the app.',true);});qsa('.event-pick').forEach(el=>el.onchange=async()=>{try{const id=el.dataset.id,before=currentWeekAll().find(x=>x.id===id),name=before?before.sceneName:'This card';state=await window.juicyApp.cardSetEvent(id,el.value!=='none',el.value);renderAll();const e=evList().find(x=>x.id===el.value);toast(el.value==='none'?`${name} is not in any event: no Event tag, and Adapt to Event skips it.`:`${name} is entered in ${e?evName(e,evList().indexOf(e)):'the event'}.`);}catch(e){renderAll();toast(e.message,true);}});
  qsa('.event-check').forEach(el=>el.onchange=async()=>{try{const id=el.dataset.id,before=currentWeekAll().find(x=>x.id===id),name=before?before.sceneName:'This card';state=await window.juicyApp.cardSetEvent(id,el.checked);renderAll();toast(el.checked?`${name} is an event card again.${state.event?.active?' Click Adapt to Event to add the event tag and fields.':' Its Event tag is back.'}`:`${name} is not an event card: no Event tag, and Adapt to Event skips it.`);}catch(e){renderAll();toast(e.message,true);}});qsa('.built-check').forEach(el=>el.onchange=async()=>{state=await window.juicyApp.setStatus(el.dataset.id,el.checked?'Built':'Idea');renderAll();try{window.__builtSync&&window.__builtSync();}catch{}toast(el.checked?'Marked Built. Its score is now frozen for accuracy tracking.':'Unmarked.');});qsa('.copy-scenario').forEach(b=>b.onclick=async()=>{const s=currentWeekAll().find(x=>x.id===b.dataset.id);if(!s)return;await copyText(scenarioText(s));b.classList.add('copied');b.textContent='✓ Copied';setTimeout(()=>{b.classList.remove('copied');b.textContent='⧉ Copy';},1600);toast('Scenario copied.');});qsa('.regen-scenario').forEach(b=>b.onclick=async()=>{const c=currentWeekAll().find(x=>x.id===b.dataset.id),pk=await aiCardEventPick(b.dataset.id,c?c.sceneName||'this card':'this card','Regenerate');if(pk===null)return;
    runBusy('Regenerating scenario locally...',async()=>{if(pk)await window.juicyApp.weekSetEvents(pk,{adapt:false});return window.juicyApp.regenerateScenario(b.dataset.id,'regenerate');});});qsa('.adapt-event').forEach(b=>b.onclick=async()=>{try{
    const c=currentWeekAll().find(x=>x.id===b.dataset.id),aiOn=AI.on&&window.juicyApp.aiAdaptEvent;
    // which event to adapt this card to (any event that is on); the card is entered in it first
    const pk=await aiCardEventPick(b.dataset.id,c?c.sceneName||'this card':'this card','Adapt to Event',{adapt:true,intro:aiOn?'Choose the event to adapt this scenario to. The app adds that event\'s tag, opportunity tags and event fields itself. Then the AI makes small, surgical edits so the story, the character\'s personality and the character\'s appearance all fit the event. Everything that already works stays word for word, and the card is saved as soon as it is done.':'Choose the event to adapt this scenario to. The app adds that event\'s tag, opportunity tags and event fields. The story is not changed.'});
    if(pk===null)return;
    if(pk){state=await window.juicyApp.weekSetEvents(pk,{adapt:false});renderAll();}
    if(aiOn){
      if(!pk&&!confirm(`Adapt "${c?c.sceneName:'this card'}" to the event with the AI?`))return;
      aiRun(()=>window.juicyApp.aiAdaptEvent([b.dataset.id]),'Adapting to the event with AI');return;}
    const r=await window.juicyApp.adaptEvent(b.dataset.id);state=r.state;renderAll();const x=r.report[0]||{changes:[],missingFit:[]};toast((x.changes.length?`Adapted: ${x.changes.join(' · ')}.${x.missingFit.length?` The story doesn't feature ${x.missingFit.join(', ')} yet, so add a small detail for the event's relevance review.`:''}`:'Already adapted to the event. Nothing changed.')+themeNote(),!!x.missingFit.length);}catch(e){toast(e.message,true);}});}
function defaultMonday(){const d=new Date(),day=d.getDay(),diff=(day===0?-6:1-day);d.setDate(d.getDate()+diff);return d.toISOString().slice(0,10);}
function bindStatic(){
  qsa('.nav-btn').forEach(b=>b.onclick=()=>switchView(b.dataset.view));qsa('[data-jump]').forEach(b=>b.onclick=()=>switchView(b.dataset.jump));
  $('open-login').onclick=async()=>{try{const link=$('magic-link').value.trim();if(!link)return toast('Paste a fresh JuicyChat magic link first.',true);renderAuthStatus({signedIn:null,status:'checking',message:'Signing in in the background...'});const r=await window.juicyApp.openLogin(link);renderAuthStatus(r.auth);if(r.ok){$('magic-link').value='';toast('Signed in. The session is saved and ready for collection.');}else toast(r.auth?.message||'The sign-in was not confirmed. Use a fresh magic link.',true);}catch(e){renderAuthStatus({signedIn:false,status:'signed-out',message:e.message||String(e)});toast(e.message,true);}};
  $('finish-login').onclick=async()=>{try{renderAuthStatus({signedIn:null,status:'checking',message:'Saving the JuicyChat browser profile...'});const status=await window.juicyApp.finishLogin();renderAuthStatus(status);if(status.signedIn===true){$('magic-link').value='';toast('JuicyChat sign-in saved. The same browser profile is ready for collection.');}else toast(status.message||'The JuicyChat session was not confirmed. Use a fresh magic link and try again.',true);}catch(e){renderAuthStatus({signedIn:null,status:'unknown',message:e.message||String(e)});toast(e.message,true);}};
  $('check-session').onclick=()=>checkSession(true);
  $('reset-session').onclick=async()=>{if(!confirm('Clear the saved JuicyChat login from this app? You will need a fresh magic link to sign in again.'))return;try{const status=await window.juicyApp.resetLogin();renderAuthStatus(status);$('magic-link').value='';toast('Saved JuicyChat login cleared.');}catch(e){toast(e.message,true);}};
  $('collect-recent').onclick=()=>runBusy('Collecting Recent bots...',async()=>window.juicyApp.collect('Recent'),'collector');
  $('collect-trending').onclick=()=>runBusy('Collecting Trending bots...',async()=>window.juicyApp.collect('Trending'),'collector');
  $('collect-both').onclick=()=>runBusy('Collecting Recent + Trending bots...',async()=>window.juicyApp.collect('both'),'collector');
  $('collect-as').onchange=async e=>{try{state=await window.juicyApp.saveSettings({collectAs:e.target.value});renderAll();toast(e.target.value==='tool'?'Recent/Trending will be collected with the tool account.':'Recent/Trending will be collected with that signed-in account.');}catch(err){toast(err.message,true);}};
  $('adapt-all').onclick=async()=>{
    // which event each card is adapted to: the same slot dialog as writing the week (a card set to No event is skipped)
    const pl=await aiWeekEventPick({title:'Adapt the week to events',intro:'Choose which event each scenario is adapted to, or No event to leave it out. Use a column or row menu, or the day buttons, to fill many at once. Built cards are skipped.',goLabel:AI.on&&window.juicyApp.aiAdaptEvent?'Adapt with the AI':'Adapt the week'});
    if(pl===null)return;
    if(pl){state=await window.juicyApp.weekApplyEventPlan(pl);renderAll();}
    if(AI.on&&window.juicyApp.aiAdaptEvent){const ids=currentWeekAll().filter(c=>String(state.week?.statuses?.[c.id]||'')!=='Built'&&c.eventCard!==false).map(c=>c.id);
      if(!ids.length)return toast('Every card this week is marked Built, so nothing was adapted.',true);
      if(!pl&&!confirm(`Adapt ${ids.length} card${ids.length===1?'':'s'} to the event with the AI? Built cards are skipped.\n\nEach card goes to the AI in its own request, and is saved as soon as it is done. The app adds the event tag, opportunity tags and event fields itself; the AI makes small, surgical edits so the story, the personality and the appearance fit the event. Scene names, characters and engines are never changed.`))return;
      aiRun(()=>window.juicyApp.aiAdaptEvent(ids),'Adapting the week to the event with AI');return;}
    if(!pl&&!confirm('Adapt every card this week to the event? Only the event tag, opportunity tags and event fields are added. Scene names, stories, hooks and engines are not changed. Built cards are skipped.'))return;
    try{const r=await window.juicyApp.adaptAllEvent();state=r.state;renderAll();const changed=r.report.filter(x=>x.changes.length).length,need=r.report.filter(x=>x.missingFit.length);
      toast(`Adapted ${changed} card${changed===1?'':'s'}${r.skippedBuilt||r.skippedNotEvent?` (${[r.skippedBuilt?`${r.skippedBuilt} Built`:'',r.skippedNotEvent?`${r.skippedNotEvent} not event card${r.skippedNotEvent===1?'':'s'}`:''].filter(Boolean).join(', ')} skipped)`:''}.${need.length?` ${need.length} still need a small story detail for the event: ${need.slice(0,4).map(x=>x.sceneName).join(', ')}${need.length>4?'…':''}.`:''}${themeNote()}`,!!need.length);}catch(e){toast(e.message,true);}};
  {const aw=$('ai-week');if(aw)aw.onclick=()=>{const ws=($('week-start')||{}).value||'';aiWriteOrContinue(j=>j.kind==='week'&&j.scope==='week','week write','Write a whole new week with AI? The app plans the series, slots and engines as usual, the AI writes every card, and you review everything before anything replaces your current week.',plan=>window.juicyApp.aiWriteWeek(ws,plan&&typeof plan==='object'?plan:undefined),'Writing the week with AI',aiWeekEventPick,['week','']);};}
  $('import-week').onclick=async()=>{try{const f=await window.juicyApp.importChoose();if(!f)return;busy(true,'Reading the week...','Scoring every card against your collected data.');IMP=await window.juicyApp.importPreview(f.path);impAccept={};impOpen=(IMP.items.find(i=>(i.score??0)<80)||{}).id||null;renderImportPanel();$('import-panel').scrollIntoView({block:'start'});}catch(e){toast(e.message,true);}finally{busy(false);}};
  if(window.juicyApp.onAiProgress)window.juicyApp.onAiProgress(p=>{
    if(!AI.job)AI.job={};
    if(p.saved&&p.saved.length&&(p.kind==='week'||p.kind==='adapt')){window.juicyApp.getState().then(st=>{state=st;renderAll();}).catch(()=>{});}
    if(p.title!=null)AI.job.title=p.title;if(p.steps)AI.job.steps=p.steps;if(p.cost!=null)AI.job.cost=p.cost;
    if(Object.prototype.hasOwnProperty.call(p,'live'))AI.job.live=p.live;
    if(Object.prototype.hasOwnProperty.call(p,'request'))AI.job.requestSeenAt=Date.now();
    AI.job.last={...(AI.job.last||{}),...p,live:AI.job.live||''};
    if(p.done||p.error)AI.job.last={...p,request:null,live:AI.job.live||''};
    aiModal(AI.job.last);
  });
  window.aiReady=aiCheck();
  window.addEventListener('saved-bots-changed',()=>{try{renderWeek();}catch{}});
  window.addEventListener('card-status-changed',e=>{try{if(e.detail&&e.detail.state){state=e.detail.state;renderAll();}}catch{}});
  if(window.juicyApp.onUpdateAvailable)window.juicyApp.onUpdateAvailable(r=>{if(r.skipped){const b=$('upd-badge');if(b){b.style.display='';UPD=r;}renderDashUpdate();}else showUpdate(r);});
  {const b=$('upd-badge');if(b)b.onclick=e=>{e.preventDefault();UPD&&UPD.available?showUpdate({...UPD,stage:null}):checkForUpdates(true);};}
  $('perf-pull').onclick=()=>runBusy('Reading both lounges from JuicyChat...',async()=>window.juicyApp.performancePull(),'collector');
  window.juicyApp.onAutoRun&&window.juicyApp.onAutoRun(r=>{bgOnAuto(r);if(r.state){state=r.state;setTimeout(renderAll,60);}
    if(r.stage==='start')toast(r.kind==='am'?'Morning pull: pulling your bot stats...':r.kind==='collect'?'8 PM run: collecting Recent + Trending...':'8 PM run: pulling your bot stats...');
    else if(r.stage==='done')toast(r.kind==='am'?'Morning pull: your bot stats are updated.':r.kind==='collect'?'8 PM run: collection and analysis updated.':'8 PM run: your bot stats are updated.');
    else if(r.stage==='error')toast(`${r.kind==='am'?'Morning pull':'8 PM run'} could not finish: ${r.message}. It will try again in 45 minutes.`,true);});

  const cancelBtn=$('cancel-collection');
  if(cancelBtn)cancelBtn.onclick=async()=>{if(!collectorUi.active)return;cancelBtn.disabled=true;cancelBtn.textContent='Cancelling...';setCollectorStatus('CANCELLING','stalled');collectorLog('Cancel requested. Stopping the transplanted Market Scan and keeping captured records...','warn');try{await window.juicyApp.cancelCollect();}catch(e){collectorLog(e.message||String(e),'warn');}};

  $('analyze-engines').onclick=()=>runBusy('Measuring success engines locally...',async()=>window.juicyApp.analyzeEngines());
  $('parse-event').onclick=async()=>{const raw=$('event-text').value.trim();if(!raw)return toast('Paste an event announcement first.',true);try{const cur=curEvent(),before=new Set(evList().map(e=>e.id));state=await window.juicyApp.parseEvent(raw,cur?cur.id:undefined);if(!cur){const fresh=evList().find(e=>!before.has(e.id));evSel=fresh?fresh.id:null;}evShown=null;renderAll();toast('Event read. Its checklist is below.');}catch(e){toast(e.message,true);}};$('clear-event-text').onclick=()=>{$('event-text').value='';};
  $('event-active').onchange=async()=>{const cur=curEvent();state=await window.juicyApp.setEventActive($('event-active').checked,(cur&&cur.applyMode)||'new-only',cur?cur.id:undefined);renderAll();};
  $('event-new-only').onclick=async()=>{const cur=curEvent();state=await window.juicyApp.setEventActive(true,'new-only',cur?cur.id:undefined);renderAll();toast('Event Mode active for new/regenerated scenarios.');};
  $('event-rebuild-week').onclick=()=>{if(!state.week.weekStart)return toast('Generate a week first, or choose a week start date.',true);runBusy('Rebuilding the week locally for the active event...',async()=>{const cur=curEvent();await window.juicyApp.setEventActive(true,'whole-week',cur?cur.id:undefined);return window.juicyApp.generateWeek(state.week.weekStart);});};
  $('generate-week').onclick=async()=>{const d=$('week-start').value||defaultMonday();const pl=await aiWeekEventPick({title:'Build the week',intro:'The app builds the week locally from your rule library. First choose which event each scenario is entered in, or no event at all. Use a column or row menu, or the day buttons, to fill many at once.',goLabel:'Build the week'});if(pl===null)return;runBusy('Building weekly blueprint locally...',async()=>window.juicyApp.generateWeek(d,pl||undefined));};
  $('reset-week').onclick=async()=>{
    const w=state?.week||{};
    const count=(w.scenarios||[]).length+(w.ntr||[]).length+Object.keys(w).filter(k=>k.startsWith('lane:')&&Array.isArray(w[k])).reduce((n,k)=>n+w[k].length,0);
    if(!count){toast('The weekly and NTR tabs are already empty. Bonus Ideas have not been changed.');return;}
    if(!confirm(`Reset the entire week?\n\nThis removes all ${count} cards across Monday–Sunday, the NTR tab, and any extra weekly tabs, INCLUDING cards marked Built.\n\nBonus Ideas are not changed. This action cannot be undone.`))return;
    try{busy(true,'Resetting the week...','Bonus Ideas will be preserved.');const r=await window.juicyApp.resetWeek();state=r.state;activeDay='Monday';renderAll();toast(`Reset Week: ${r.cleared} cards removed. ${r.bonusKept} Bonus Ideas preserved.`);}catch(e){toast(e.message||String(e),true);}finally{busy(false);}
  };
  $('regenerate-week').onclick=async()=>{const d=$('week-start').value||state.week.weekStart||defaultMonday();const pl=await aiWeekEventPick({title:'Regenerate the week',intro:'The app rebuilds the whole week locally. Choose which event each scenario is entered in, or no event at all. The choices start from what the week has now.',goLabel:'Regenerate the week'});if(pl===null)return;runBusy('Regenerating the entire week locally...',async()=>window.juicyApp.generateWeek(d,pl||undefined));};
  $('rebuild-days').onclick=()=>{const d=$('week-start').value||state.week.weekStart||defaultMonday();const per=Math.max(1,...((BP&&BP.tabs)||[]).filter(t=>t.kind==='day').map(t=>t.cards||0));if(!confirm(`Rebuild the day tabs (Monday to Sunday) from the schedule in use${per?`: ${per} cards a day`:''}?\n\nThe NTR, Preventable NTR, Post-NTR and Bonus tabs are not touched. The current day cards, Built ones included, go to the archive, so nothing is lost.`))return;runBusy('Rebuilding the day tabs...',async()=>window.juicyApp.generateDays(d));};
  $('export-week').onclick=async()=>{try{const r=await window.juicyApp.exportWeekHtml();if(!r.canceled)toast('Weekly Blueprint exported.');}catch(e){toast(e.message,true);}};
  ['pull-timezone','collect-time','perf-time','morning-time','auto-morning'].forEach(id=>{const el=$(id);if(el&&!el.dataset.bound){el.dataset.bound='1';el.addEventListener('input',refreshPullNotes);el.addEventListener('change',refreshPullNotes);}});{const dirty=on=>{const n=$('save-note');if(!n)return;n.textContent=on?'\u25CF You have unsaved changes':'These settings are saved when you press Save Settings';n.classList.toggle('dirty',on);};window.__settingsDirty=dirty;['target-recent','target-trending','gender-filter','juicy-home-url','auto-collect','auto-performance','open-at-login','pull-timezone','collect-time','perf-time','auto-morning','morning-time','lounge-main','lounge-ntr'].forEach(id=>{const el=$(id);if(el&&!el.dataset.dirty){el.dataset.dirty='1';el.addEventListener('input',()=>dirty(true));el.addEventListener('change',()=>dirty(true));}});}
  $('save-settings').onclick=async()=>{try{state=await window.juicyApp.saveSettings({targetRecent:$('target-recent').value,targetTrending:$('target-trending').value,gender:$('gender-filter').value,juicyHomeUrl:$('juicy-home-url').value,autoCollect:$('auto-collect').checked,autoPerformance:$('auto-performance').checked,openAtLogin:$('open-at-login').checked,pullTimeZone:$('pull-timezone').value,collectTime:$('collect-time').value,perfTime:$('perf-time').value,autoMorning:$('auto-morning').checked,morningTime:$('morning-time').value,loungeMain:$('lounge-main').value,loungeNtr:$('lounge-ntr').value,blockedTags:blockedNow()});blockedDraft=null;renderAll();window.__settingsDirty&&window.__settingsDirty(false);toast('Settings saved.');}catch(e){toast(e.message,true);}};
  $('week-tabs').addEventListener('click',async e=>{if(!e.target.closest('#upload-tab'))return;const tab=activeDay,name=tab.startsWith('lane:')?tabInfo(tab).label:tab;
    try{const f=await window.juicyApp.uploadChoose();if(!f)return;busy(true,`Reading ${f.name}...`,`Putting your cards into the ${name} tab for review.`);IMP=await window.juicyApp.uploadPreview(f.path,tab);impAccept={};impOpen=(IMP.items.find(i=>(i.score??0)<80)||{}).id||null;renderImportPanel();$('import-panel').scrollIntoView({block:'start'});}catch(err){toast(err.message,true);}finally{busy(false);}});
  $('week-tabs').addEventListener('click',e=>{if(!e.target.closest('#ai-tab'))return;const tab=activeDay,name=tab.startsWith('lane:')?tabInfo(tab).label:tab;aiWriteOrContinue(j=>j.kind==='week'&&j.scope===tab&&j.weekStart===(state.week||{}).weekStart,`${name} tab write`,`Write the ${name} tab with AI? Each card is written in its own request and saved the moment it is finished, so an error never loses the cards already written. Only this tab's cards are scrapped and written again from scratch (new characters, new stories; cards marked Built are kept, replaced cards are archived with their scores) and every other tab stays as it is.`,async plan=>{if(plan&&typeof plan==='object')await evApplyPlan(plan,false);return window.juicyApp.aiWriteTab(tab);},`Writing ${name} with AI`,()=>aiTabEventPick(tab,'Write'),['tab',tab]);});
  $('week-tabs').addEventListener('click',async e=>{if(!e.target.closest('#clear-tab'))return;const tab=activeDay,name=tab.startsWith('lane:')?tabInfo(tab).label:tab;
    // a tab whose cards are all Built (a finished tab, ready for the next week) used to fail with an error: ask whether to clear the Built cards too
    const cards=tabCards(tab),isAdd=c=>!!(c&&(c.addedBonus||(c.bonusIdea&&c.day&&c.day!=='Bonus'&&c.slot!=='Bonus'))),open=cards.filter(c=>!isAdd(c)&&normStatus(state.week.statuses?.[c.id])!=='Built'),allBuilt=cards.some(c=>!isAdd(c))&&!open.length;
    if(allBuilt){if(!confirm(`Every card in the ${name} tab is marked Built.\n\nClear and reset them anyway? Each card goes back to an empty slot (its day, slot, series and event stay) and is marked Idea again. The cards are archived with their scores, not deleted, but their link to the bot you posted is removed. Bonus ideas you placed on a day stay.`))return;}
    else if(!confirm(`Clear and reset the ${name} tab?\n\nEvery card that is not marked Built goes back to an empty slot (its day, slot, series and event stay). The cleared cards are archived with their scores, not deleted. Built cards are kept.`))return;
    try{busy(true,`Clearing ${name}...`,'');const r=await window.juicyApp.clearTab(tab,allBuilt);state=r.state;renderAll();toast(`${r.cleared} card${r.cleared>1?'s':''} cleared${r.kept?`, ${r.kept} kept`:''}. Fill them with Write with AI, Upload my cards, Regenerate Tab, or by hand.`);}catch(err){toast(err.message||String(err),true);}finally{busy(false);}});
  $('week-tabs').addEventListener('click',async e=>{if(!e.target.closest('#regen-tab'))return;const tab=activeDay,label=tab==='NTR'?'the NTR tab':tab==='Bonus'?'the Bonus tab (each card is rebuilt from its original idea or pasted card)':tab.startsWith('lane:')?'the '+((weekTabs().find(t=>t.id===tab)||{}).label||'extra')+' tab':tab;
    const evPlan=await aiTabEventPick(tab,'Regenerate');if(evPlan===null)return;
    if(evPlan===false&&!confirm(`Regenerate every card in ${label}? Cards marked Built are kept.`))return;
    try{if(evPlan)await evApplyPlan(evPlan,false);busy(true,`Regenerating ${tab}...`,'Please keep this window open.');const r=await window.juicyApp.regenerateTab(tab);state=r.state;renderAll();toast(`${r.regenerated} card${r.regenerated>1?'s':''} regenerated${r.kept?`, ${r.kept} Built card${r.kept>1?'s':''} kept`:''}.`);}catch(err){toast(err.message||String(err),true);}finally{busy(false);}});
  $('week-tabs').onclick=e=>{const b=e.target.closest('.tab');if(!b)return;activeDay=b.dataset.day;renderWeek();const t=$('week-tabs'),c=$('week-content');if(t&&c&&t.classList.contains('stuck')){const y=c.getBoundingClientRect().top+window.scrollY-t.offsetHeight-8;window.scrollTo(0,Math.max(0,y));}};
  window.juicyApp.onBgStep&&window.juicyApp.onBgStep(bgOnStep);
  window.juicyApp.onCloseAsk&&window.juicyApp.onCloseAsk(closeAskShow);window.juicyApp.onCloseAskCancel&&window.juicyApp.onCloseAskCancel(closeAskHide);window.juicyApp.onWebpAbortAsk&&window.juicyApp.onWebpAbortAsk(closeWebpAbortShow);
  window.juicyApp.onCollectorProgress(p=>{bgOnCollect(p);const current=Number(p.overallCurrent??p.current)||0,target=Math.max(1,Number(p.overallTarget??p.target)||1),pct=Math.round(current/target*100);const detail=[p.sortName||p.source,p.current!=null&&p.target!=null?`${p.current}/${p.target}`:'',p.pass?`scan ${p.pass}`:'',p.pageCards!=null?`${p.pageCards} page cards`:'',p.networkRecords!=null?`${p.networkRecords} API records`:''].filter(Boolean).join(' · ');$('collector-message').textContent=p.message||detail||'Collecting...';$('collector-progress').style.width=Math.max(0,Math.min(100,pct))+'%';updateCollectorLive(p);});
  window.juicyApp.onNeedLogin&&window.juicyApp.onNeedLogin(d=>askMagicLink(d||{}));
  window.juicyApp.onAuthStatus(status=>renderAuthStatus(status));window.juicyApp.onAnalysisProgress(p=>{bgOnAnalysis(p);const m=p.message||'Analyzing...',fin=!!p.done||/updated|complete/i.test(m);$('busy-text').textContent=m;
    if(collectorUi.active&&!collectorUi.pull){ // analysis is the last step of a collection: show it in the window, not only in the caption
      $('busy-title').textContent=p.skipped?'Collection finished':fin?'Collection and analysis finished':'Analyzing the collected bots...';
      setCollectorStatus(fin?'DONE':'ANALYZING',fin?'done':'');
      if($('collector-live-source'))$('collector-live-source').textContent='Engine analysis';
      if($('collector-live-count'))$('collector-live-count').textContent=fin?'Done':'Analyzing';
      if($('collector-source-bar'))$('collector-source-bar').style.width='100%';if($('collector-source-percent'))$('collector-source-percent').textContent='100%';
      if($('collector-stall-label'))$('collector-stall-label').textContent=fin?'Finished':'Analyzing';
      collectorLog(m,fin?'good':'');collectorUi.analysisSeen=true;if(fin)collectorUi.analysisDone=true;}
  });window.juicyApp.onWeekProgress(p=>{$('week-progress-message').textContent=p.message||'';$('busy-text').textContent=p.message||'Building...';});
}
// ---- automatic runs: the progress box at the bottom right (what is being pulled, how far, how long)
const bgPull={on:false,t0:0,tick:null,hide:null,hidden:false,title:'',account:''};
function bgShow(patch){const el=$('bg-pull');if(!el)return;
  if(bgPull.hidden&&!patch.force)return;
  el.classList.remove('hidden');document.body.classList.add('bg-on');
  if(patch.title!=null)$('bg-pull-title').textContent=patch.title;
  if(patch.what!=null)$('bg-pull-what').textContent=patch.what;
  if(patch.msg!=null)$('bg-pull-msg').textContent=patch.msg;
  if(patch.pct!=null){el.classList.remove('indet');$('bg-pull-fill').style.width=Math.max(0,Math.min(100,patch.pct))+'%';}
  else if(patch.indet){el.classList.add('indet');}
  el.classList.toggle('done',!!patch.done);el.classList.toggle('err',!!patch.err);}
function bgClose(ms){clearTimeout(bgPull.hide);bgPull.hide=setTimeout(()=>{const el=$('bg-pull');if(el)el.classList.add('hidden');document.body.classList.remove('bg-on');bgPull.hidden=false;},ms);}
function bgOnAuto(r){const el=$('bg-pull');if(!el)return;
  if(!el.dataset.bound){el.dataset.bound='1';$('bg-pull-x').onclick=()=>{bgPull.hidden=true;el.classList.add('hidden');document.body.classList.remove('bg-on');};}
  if(r.stage==='start'){clearTimeout(bgPull.hide);bgPull.on=true;bgPull.hidden=false;bgPull.t0=Date.now();bgPull.title=r.title||'Automatic run';bgPull.account='';
    el.classList.remove('done','err');$('bg-pull-fill').style.width='0%';
    bgShow({title:bgPull.title,what:'Starting...',msg:'This runs in the background. You can keep using the app.',indet:true,force:true});
    clearInterval(bgPull.tick);bgPull.tick=setInterval(()=>{const t=$('bg-pull-time');if(t){const s=Math.round((Date.now()-bgPull.t0)/1000);t.textContent=`${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;}},1000);}
  else if(r.stage==='done'||r.stage==='error'){bgPull.on=false;clearInterval(bgPull.tick);
    if(r.stage==='done'){bgShow({what:'Finished',msg:'Everything is saved.',pct:100,done:true});bgClose(6000);}
    else{bgShow({what:'Could not finish',msg:r.message||'',pct:100,err:true});bgClose(15000);}}}
function bgAccount(name){if(name&&name!==bgPull.account){bgPull.account=name;bgShow({title:`${bgPull.title} · ${name}`});}}
function bgOnStep(p){if(!bgPull.on)return;bgAccount(p.account);
  const hasPct=!p.indeterminate&&p.current!=null&&p.target;
  bgShow({what:p.message||'Working...',msg:'',...(hasPct?{pct:Math.round(p.current/p.target*100)}:{indet:true})});}
function bgOnCollect(p){if(!bgPull.on||!p)return;if(p.pull&&p.account)bgAccount(p.account);
  const label=p.pull?(p.account||p.sortName):(p.sortName||p.source||'');
  const cur=Number(p.overallCurrent??p.current),tg=Number(p.overallTarget??p.target);
  const counted=Number.isFinite(cur)&&Number.isFinite(tg)&&tg>0;
  const what=p.pull?(p.message||`Reading ${label}...`):(label?`${label}${p.current!=null&&p.target!=null?` · ${p.current} of ${p.target} bots`:''}`:(p.message||'Collecting...'));
  bgShow({what,msg:p.pull?'':(p.message||''),...(counted&&!p.pull?{pct:Math.round(cur/tg*100)}:{indet:true})});}
function bgOnAnalysis(p){if(!bgPull.on||!p)return;bgShow({what:p.message||'Analyzing...',msg:'',indet:true});}
window.addEventListener('scroll',()=>{const t=document.getElementById('week-tabs');if(t)t.classList.toggle('stuck',t.getBoundingClientRect().top<=0.5&&window.scrollY>0);},{passive:true});
(async()=>{try{const v=await window.juicyApp.appVersion();const el=document.getElementById('app-version');if(el&&typeof v==='string'&&/^\d+\.\d+/.test(v))el.textContent=`v${v.replace(/\.0$/,'')}`;}catch{}})();
function applyEdition(){document.body.classList.toggle('edition-share',IS_SHARE);if(!IS_SHARE)return;
  const set=(sel,txt)=>{const el=document.querySelector(sel);if(el)el.textContent=txt;};
  set('#perf-pull','↻ Pull now');
  for(const el of document.querySelectorAll('p'))el.innerHTML=el.innerHTML.replace('Build progress across core and NTR scenarios.','Build progress across this week\'s scenarios.').replace('21 core day scenarios + 7 Likeable NTR scenarios. Refresh one card or rebuild the entire week.','Your scenarios for the week, by release day. Add a Bonus idea to a day from the Bonus Ideas tab.').replace('21 core day scenarios + 7 Likeable NTR scenarios.','Your scenarios for the week, by release day.').replace('Each account is read from its lounge link, or directly when you sign it in with its magic link,','Your bots are read from the account signed in on the JuicyChat Analysis tab');
  const lm=document.getElementById('lounge-main');if(lm&&lm.parentElement)lm.parentElement.style.display='none';
  const ln=document.getElementById('lounge-ntr');if(ln&&ln.parentElement)ln.parentElement.style.display='none';
  const ca=document.querySelector('.collect-as');if(ca)ca.style.display='none';
  const ap=document.getElementById('auto-performance');if(ap&&ap.parentElement)ap.parentElement.lastChild.textContent=' Pull my bots for the Performance tab every day';
}
function applyEditionUi(){if(!IS_SHARE)return;document.body.classList.add('edition-share');
  const pv=[...document.querySelectorAll('.event-rule')].find(e=>/PRIVACY/.test(e.textContent));
  if(pv){const d=pv.querySelector('div');if(d)d.innerHTML=d.innerHTML.replace('✦ Write week, ','');}   // this edition has no Write week
  if(pv&&!pv.querySelector('.share-note'))pv.querySelector('div')?.insertAdjacentHTML('beforeend',' <span class="share-note">The shared AI service records, for each computer, its approximate location (country and region), spending and number of requests, so the person who runs it can manage the monthly limits.</span>');}
(async function init(){try{BP=await window.juicyApp.blueprintGet?.();}catch{}try{IS_SHARE=(await window.juicyApp.appEdition?.())==='share';}catch{}applyEditionUi();window.IS_SHARE=IS_SHARE;applyEdition();bindStatic();$('week-start').value=defaultMonday();state=await window.juicyApp.getState();renderAll();renderAuthStatus(authStatus);checkSession(false);const bi=()=>window.initBuilder&&window.initBuilder().catch(e=>toast('Bot Builder: '+e.message,true));if(window.initBuilder)bi();else window.addEventListener('load',bi);})();

// ---- PolicyWeights: the weights panel on a scenario card, and the per-series defaults in Settings
const PWX=()=>window.PolicyWeights&&window.PolicyWeights.enabled?window.PolicyWeights:null;
const pwOpen=new Set();
function policyCopyText(s){const P=PWX();if(!P||!s||!s.policy||!P.isOn(s,state)||!s.policy.weights)return'';const nm=(s.cast&&s.cast[0]&&s.cast[0].name)||s.primaryCharacter||'Character';return`PolicyWeights:\n${P.blockText({...s.policy,on:true,rules:P.lockFor(s).rules},nm)}`;}
function policyToggle(s){const P=PWX();if(!P||!s)return'';const on=P.isOn(s,state),own=s.policy&&typeof s.policy.on==='boolean';return`<label class="built-toggle pw-toggle ${on?'on':'off'}" title="${on?'PolicyWeights are included in this card\'s bot.':'PolicyWeights are not included in this card\'s bot.'} ${own?'This card has its own choice.':'Following the series default in Settings.'} Tick or untick to set it for this card only."><input type="checkbox" class="pw-check" data-id="${esc(s.id)}" ${on?'checked':''}><span class="bt-box">${on?'✓':''}</span><span>PolicyWeights</span></label>`;}
function policyPanel(s){const P=PWX();if(!P||!s)return'';const pol=s.policy||{},on=P.isOn(s,state),mode=typeof pol.on==='boolean'?(pol.on?'on':'off'):'default',def=!!((state.policyDefaults||{})[P.seriesKey(s)]);
  const nm=(s.cast&&s.cast[0]&&s.cast[0].name)||s.primaryCharacter||'Name',chk=pol.weights?P.check(pol,s):null;
  const guard=on&&pol.weights&&chk&&!chk.errors.length?P.guardText({...pol,on:true,rules:P.lockFor(s).rules},nm):'';
  return`<details class="pw-panel" data-id="${esc(s.id)}" ${pwOpen.has(s.id)?'open':''}><summary><b>PolicyWeights</b> <span class="pw-badge ${on?'on':'off'}">${on?'On':'Off'}</span>${pol.weights?`<span class="pw-sum">${esc(pol.weights)}</span>`:'<span class="pw-sum">none yet</span>'}</summary>
  <div class="pw-body">
    <label class="pw-row">Use on this card <select class="pw-on"><option value="default" ${mode==='default'?'selected':''}>Series default (${def?'On':'Off'})</option><option value="on" ${mode==='on'?'selected':''}>On</option><option value="off" ${mode==='off'?'selected':''}>Off</option></select></label>
    <p class="micro">Off writes the bot exactly as before. On: the AI writes the bot from these weights, and the app puts them into the bot's Scenario, in this order: PolicyWeights, Tracker (only if the card has one, set in its own Tracker section below), System Rules with its guardrails. Any bot can use PolicyWeights.</p>
    <label class="stack">Weights <small>Name: 0.5; Name: 0.3 (5 to 8 of them, 0 to 0.8). Edit freely; the app checks them below.</small><input class="pw-weights" value="${esc(pol.weights||'')}" placeholder="Written by the AI, or type your own"></label>
    <label class="stack">Extra guardrails <small>Optional. One or two short sentences for this card.</small><textarea class="pw-extra" rows="2">${esc(pol.extra||'')}</textarea></label>
    ${guard?`<div class="pw-guard"><b>Guardrail line the app adds to the Scenario:</b> ${esc(guard)}</div>`:''}
    ${chk?chk.errors.map(e=>`<div class="pw-err">${esc(e)}</div>`).join('')+chk.warnings.map(e=>`<div class="pw-warn">${esc(e)}</div>`).join(''):''}
    ${pol.note?`<div class="pw-note">${esc(pol.note)}</div>`:''}
    <div class="pw-btns"><button class="primary pw-save" data-id="${esc(s.id)}">Save</button><button class="secondary pw-write ai-only" data-id="${esc(s.id)}" style="${AI.on?'':'display:none'}" title="The AI picks the weights and the extra guardrails for this card from the author's lists.">✦ Write weights with AI</button></div>
  </div></details>`;}
function trackerPanel(s){const P=PWX();if(!P||!s)return'';const pol=s.policy||{},has=!!String(pol.tracker||'').trim(),on=P.trackerActive(pol),mode=typeof pol.trackerOn==='boolean'?(pol.trackerOn?'on':'off'):'auto',key='t:'+s.id;
  const first=has?String(pol.tracker).split('\n')[0].replace(/^\[Tracker:\s*([^\]]*)\].*$/,'$1'):'';
  return`<details class="pw-panel tr-panel" data-id="${esc(s.id)}" ${pwOpen.has(key)?'open':''}><summary><b>Tracker</b> <span class="pw-badge ${on?'on':'off'}">${on?'On':'Off'}</span><span class="pw-sum">${has?esc(first):'none (optional)'}</span></summary>
  <div class="pw-body">
    <label class="pw-row">Use on this card <select class="tr-on"><option value="auto" ${mode==='auto'?'selected':''}>Automatic (On when there is a tracker)</option><option value="on" ${mode==='on'?'selected':''}>On</option><option value="off" ${mode==='off'?'selected':''}>Off</option></select></label>
    <p class="micro">Separate from PolicyWeights, and optional: most bots don't need one. A hidden score with stages, such as Trust or Remorse. It goes into the Scenario right after the PolicyWeights line (or on its own when PolicyWeights are off). Bully cards need one.</p>
    <label class="stack">What should it track? <small>Tell the AI what this tracker measures, in your own words (for example: how much she trusts him, or how jealous she gets). Leave empty and the AI picks what fits the card.</small><input class="tr-want" value="${esc(pol.trackerWant||'')}" placeholder="e.g. Trust: how safe she feels letting him in"></label>
    <label class="stack">Tracker <small>Starts with [Tracker: Name]. Write your own, or press the button.</small><textarea class="tr-text" rows="4">${esc(pol.tracker||'')}</textarea></label>
    <div class="pw-btns"><button class="primary tr-save" data-id="${esc(s.id)}">Save</button><button class="secondary tr-write ai-only" data-id="${esc(s.id)}" style="${AI.on?'':'display:none'}" title="The AI writes a tracker for this card from what you typed in &quot;What should it track?&quot; and replaces the Tracker above. It never touches the PolicyWeights.">✦ Write tracker with AI</button></div>
  </div></details>`;}
function bindPolicy(){qsa('.pw-check').forEach(el=>el.onchange=async()=>{try{state=await window.juicyApp.policySet(el.dataset.id,{on:el.checked});renderAll();toast(el.checked?'PolicyWeights on for this card.':'PolicyWeights off for this card.');}catch(e){toast(e.message,true);renderAll();}});
  qsa('.pw-panel:not(.tr-panel)').forEach(d=>{const id=d.dataset.id,g=c=>d.querySelector(c);
  d.addEventListener('toggle',()=>{d.open?pwOpen.add(id):pwOpen.delete(id);});
  g('.pw-save').onclick=async()=>{const m=g('.pw-on').value;try{pwOpen.add(id);state=await window.juicyApp.policySet(id,{on:m==='default'?null:m==='on',weights:g('.pw-weights').value,extra:g('.pw-extra').value});renderAll();toast('PolicyWeights saved.');}catch(e){toast(e.message,true);}};
  g('.pw-write').onclick=async()=>{if(!AI.on)return toast('Set up the AI writer in AI settings first.',true);const c=tabCardsAll().find(x=>x.id===id);pwOpen.add(id);await aiRun(()=>window.juicyApp.policyWrite(id),`Writing PolicyWeights for "${(c&&c.sceneName)||'this card'}"`);try{state=await window.juicyApp.getState();renderAll();}catch{}};});
  qsa('.tr-panel').forEach(d=>{const id=d.dataset.id,key='t:'+id,g=c=>d.querySelector(c);
    d.addEventListener('toggle',()=>{d.open?pwOpen.add(key):pwOpen.delete(key);});
    const patch=()=>{const m=g('.tr-on').value;return{trackerOn:m==='auto'?null:m==='on',tracker:g('.tr-text').value,trackerWant:g('.tr-want').value};};
    g('.tr-save').onclick=async()=>{try{pwOpen.add(key);state=await window.juicyApp.policySet(id,patch());renderAll();toast('Tracker saved.');}catch(e){toast(e.message,true);}};
    g('.tr-write').onclick=async()=>{if(!AI.on)return toast('Set up the AI writer in AI settings first.',true);const c=tabCardsAll().find(x=>x.id===id);pwOpen.add(key);await aiRun(()=>window.juicyApp.policyWriteTracker(id,g('.tr-want').value),`Writing the Tracker for "${(c&&c.sceneName)||'this card'}"`);try{state=await window.juicyApp.getState();renderAll();}catch{}};});
}
function renderPolicySettings(){const host=$('pw-settings');if(!host)return;const P=PWX(),panel=host.closest('.panel');if(!P){if(panel)panel.style.display='none';return;}
  const built=['Bully Series','ANTI-NTR Series','Dommy Mommy Series','Stepmom Series','Gentle Giant Series','Stepsister Series','Tomboy Series','Yandere Series','Bakadere Series','Futa Friday Series'];
  if(window.__allSeriesFor!==BP){window.__allSeriesFor=BP;window.__allSeries=null;}
  if(!window.__allSeries&&!window.__allSeriesAsking&&window.juicyApp.seriesList){window.__allSeriesAsking=true;window.juicyApp.seriesList().then(l=>{window.__allSeries=Array.isArray(l)?l:[];window.__allSeriesAsking=false;renderPolicySettings();}).catch(()=>{window.__allSeries=[];window.__allSeriesAsking=false;});}
  const names=[...new Set([...(IS_SHARE?[]:built),'Standalone',...(window.__allSeries||[]),...tabCardsAll().map(c=>P.seriesKey(c)),...Object.keys(state.policyDefaults||{})])],D=state.policyDefaults||{};
  host.innerHTML=`<p class="micro">Hidden steering numbers (the community author's PolicyWeights) that the AI writes into a bot's Scenario. They are <b>off</b> unless you turn them on. Tick a series to have new bots in it get PolicyWeights by default. Any card can override this in its own PolicyWeights panel.</p>
  <div class="pw-defaults">${names.map(n=>`<label class="pw-def"><input type="checkbox" class="pw-default" data-series="${esc(n)}" ${D[n]?'checked':''}> ${esc(n)}</label>`).join('')}</div>`;
  qsa('.pw-default').forEach(el=>el.onchange=async()=>{try{state=await window.juicyApp.policyDefault(el.dataset.series,el.checked);renderAll();}catch(e){toast(e.message,true);el.checked=!el.checked;}});}
