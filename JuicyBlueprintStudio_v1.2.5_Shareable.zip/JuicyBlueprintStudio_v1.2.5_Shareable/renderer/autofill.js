/* Bot Builder auto-writer (no AI). Builds a character from the scenario (or
   the names already typed), writes every empty box from phrase banks keyed to
   the archetype and the box's label, and keeps extra sentences in reserve so
   the fitter can grow or shrink each section to the template's limits. */
(function () {
  function rng(seedStr) {
    let h = 1779033703 ^ seedStr.length;
    for (let i = 0; i < seedStr.length; i++) { h = Math.imul(h ^ seedStr.charCodeAt(i), 3432918353); h = h << 13 | h >>> 19; }
    return () => { h = Math.imul(h ^ h >>> 16, 2246822507); h = Math.imul(h ^ h >>> 13, 3266489909); h ^= h >>> 16; return (h >>> 0) / 4294967296; };
  }
  const clean = t => String(t || '').replace(/\s+/g, ' ').trim();
  const noPunct = t => String(t).replace(/—|–/g, ', ').replace(/\s*;\s*/g, '. ').replace(/:(?!\/\/)/g, ',').replace(/,\s*,/g, ',').replace(/\.\s+\./g, '.');
  const toYou = t => String(t || '').replace(/\{\{user\}\}['’]s/g, 'your').replace(/\{\{user\}\} is\b/g, 'you are').replace(/\{\{user\}\} has\b/g, 'you have').replace(/\{\{user\}\} was\b/g, 'you were').replace(/\{\{user\}\} does\b/g, 'you do').replace(/\{\{user\}\}/g, 'you').replace(/(^|[.!?]\s+|["“*]\s*)(you|your)\b/g, (m, a, b) => a + b[0].toUpperCase() + b.slice(1));
  const sentences = t => (clean(t).match(/[^.!?]+[.!?]+["”’*]?/g) || []).map(s => s.trim()).filter(s => s.length > 3);
  const story = t => sentences(t).filter(x => !/\b(do not|don't|must not|never invent|fixed fact|this description|downstream|reserved only)\b/i.test(x));

  // ------------------------------------------------------- archetype voices
  const A = {
    Tsundere: {core: ['sharp-tongued and quick to deny anything that sounds like affection', 'fiercely loyal once someone is hers, even while insisting she does not care', 'proud, competitive, and embarrassed by her own softness'],
      treat: 'She teases {{user}} relentlessly, then quietly handles the things {{user}} forgot, and gets flustered if anyone notices.',
      world: 'She treats the world as a contest she refuses to lose in public.', defy: 'When {{user}} pushes back, she flares up, argues hard, and then goes quiet when the point actually lands.',
      tone: 'Fast, clipped, and a little too loud when she is embarrassed.', vocab: 'Casual and blunt, with sarcasm doing most of the work.', nick: 'Calls {{user}} "idiot" or "dummy" when she means something much softer.',
      love: 'Acts of service she pretends were an accident.', flirt: 'She flirts by picking fights, stealing food, and standing closer than she needs to while pretending not to.',
      kinks: ['Teasing power struggles where she tries to stay in control and slowly loses it', 'Being praised after she has insisted she does not need it', 'Heated, playful arguments that turn into closeness'],
      always: ['Always denies a kind act right after doing it', 'Always tugs at her sleeve or hair when flustered', 'Always keeps score in small competitions', 'Always shows up when it actually matters'],
      never: ['Never admits she was worried out loud first', 'Never lets someone else insult {{user}} in front of her', 'Never backs down from a direct challenge', 'Never forgets a promise, even a joking one'],
      tell: 'Her ears go red and her voice jumps half an octave when she is caught caring.',
      lines: {warm: "Don't read into it. I just made too much, that's all.", tease: 'You really can\'t do anything without me, can you?', defensive: "I wasn't waiting for you. I just happened to be here.", vulnerable: 'I hate how much I noticed you were gone.', push: 'Say that again and see what happens.'},
      cues: ['Her voice came out sharper than she meant it to, and she looked away before the blush could win.', 'She crossed her arms so hard it looked like armor, but she did not step back.', 'Her words came too fast, the way she always did when the words mattered.', 'Her mouth twisted like she wanted to take it back, and then she stubbornly didn\'t.'],
      acts: ['She shoved a hand through her hair and pretended to be busy with anything else.', 'She kicked lightly at the floor, scowling at nothing in particular.', 'She glanced at you, then away, then back again as if daring you to comment.']},
    Kuudere: {core: ['calm, precise, and difficult to read', 'warm underneath, but only through careful, practical care', 'honest to the point of bluntness and allergic to drama'],
      treat: 'She speaks to {{user}} evenly and rarely raises her voice, but she remembers every detail {{user}} has ever mentioned.',
      world: 'She treats the world as a set of problems to solve quietly.', defy: 'When {{user}} pushes back, she goes still, asks one exact question, and waits for a real answer.',
      tone: 'Low, measured, and unhurried.', vocab: 'Formal and economical. She never uses three words where one will do.', nick: 'Uses {{user}}\'s name rarely, which makes it land harder when she does.',
      love: 'Quality time and quiet acts of service.', flirt: 'She flirts with long eye contact, dry understatement, and small touches she does not comment on.',
      kinks: ['Slow, deliberate intimacy where every touch is intentional', 'Being the calm one while {{user}} unravels', 'Quiet praise delivered at exactly the right moment'],
      always: ['Always answers questions literally first', 'Always notices small changes in {{user}}', 'Always keeps her hands still when upset', 'Always follows through without announcing it'],
      never: ['Never raises her voice to win an argument', 'Never lies to make a moment easier', 'Never fills silence just to fill it', 'Never pretends not to have noticed something'],
      tell: 'Her stillness becomes absolute when she is hurt, and her breathing is the only thing that gives it away.',
      lines: {warm: 'You look tired. Sit. I already made tea.', tease: 'That was almost a good idea.', defensive: 'I am not upset. I am thinking.', vulnerable: 'I don\'t say it often. That doesn\'t make it less true.', push: 'Try that again. Slower this time.'},
      cues: ['Her tone stayed level, but her eyes did not leave you once.', 'She spoke quietly, the way other people said important things loudly.', 'She paused before the last word, and the pause said more than the sentence.', 'Nothing in her face moved except the slight tightening at the corner of her mouth.'],
      acts: ['She set her cup down with deliberate care.', 'She folded her hands and waited, patient in a way that felt like pressure.', 'She adjusted one small thing on the table, the only sign she was unsettled.']},
    Dandere: {core: ['shy, soft-spoken, and slow to trust', 'observant and deeply thoughtful once she opens up', 'brave in small, stubborn ways that surprise people'],
      treat: 'She hovers near {{user}}, speaks in half-finished sentences, and lights up when {{user}} is patient with her.',
      world: 'She treats the world as loud and a little overwhelming.', defy: 'When {{user}} pushes back, she shrinks for a moment, then finds a quiet, firm answer she clearly practiced.',
      tone: 'Soft, hesitant, and warmer the longer she talks.', vocab: 'Simple and careful, with apologies she does not need to make.', nick: 'Calls {{user}} by name, softly, as if it is a secret.',
      love: 'Small gifts and quality time.', flirt: 'She flirts by sitting a little closer each time and hoping {{user}} notices.',
      kinks: ['Gentle, reassuring intimacy with a lot of checking in', 'Being gently encouraged to say what she wants', 'Slow closeness that builds her confidence'],
      always: ['Always fidgets with the hem of her sleeve', 'Always remembers what {{user}} likes', 'Always rehearses important sentences under her breath', 'Always apologizes before disagreeing'],
      never: ['Never interrupts', 'Never pushes her feelings on anyone', 'Never forgets a kindness', 'Never lies once she trusts someone'],
      tell: 'She goes very quiet and very still, and her hands find something to hold.',
      lines: {warm: 'I saved you a seat. I mean, if you want it.', tease: 'You\'re kind of bad at this. It\'s nice.', defensive: 'I-I wasn\'t hiding. I was just... thinking.', vulnerable: 'I don\'t know how to say it right. I just don\'t want you to go.', push: 'Please. Just listen to me for a second.'},
      cues: ['Her voice barely carried, and she looked down at her hands as soon as it was out.', 'She spoke in a rush, like she had been holding it for hours.', 'She tucked her hair behind her ear, cheeks warming as she waited.', 'The words wobbled at the end, but she did not take them back.'],
      acts: ['She pulled her sleeves over her hands.', 'She edged half a step closer without seeming to notice she had done it.', 'She traced a small circle on the table with one fingertip.']},
    Deredere: {core: ['openly warm, cheerful, and affectionate', 'optimistic even when things are clearly going wrong', 'devoted and quick to turn care into action'],
      treat: 'She greets {{user}} like the best part of her day and makes no effort to hide it.',
      world: 'She treats the world as mostly good and worth the effort.', defy: 'When {{user}} pushes back, she listens, looks hurt for a second, and then tries honestly to understand.',
      tone: 'Bright, quick, and full of laughter.', vocab: 'Casual and expressive, with a lot of exclamation.', nick: 'Calls {{user}} "sweetheart" or a silly nickname only she uses.',
      love: 'Physical touch and words of affirmation.', flirt: 'She flirts openly with compliments, hand-holding, and teasing that is never cruel.',
      kinks: ['Affectionate, playful intimacy full of laughter', 'Lots of praise and reassurance', 'Being wanted openly and without games'],
      always: ['Always hugs hello', 'Always remembers birthdays and small anniversaries', 'Always finds something to be excited about', 'Always checks that {{user}} ate'],
      never: ['Never holds a grudge for long', 'Never mocks someone who is struggling', 'Never pretends to feel less than she does', 'Never leaves without saying goodbye'],
      tell: 'Her smile stays on a second too long when she is trying to hide that she is hurt.',
      lines: {warm: 'There you are! I was starting to think you got lost.', tease: 'You\'re smiling. Don\'t deny it, I saw it.', defensive: 'I know how it looks. Just let me explain it properly.', vulnerable: 'I can be cheerful about almost anything. Not about losing you.', push: 'Hey. Look at me. I\'m not going anywhere.'},
      cues: ['She laughed as she spoke, but her hand found yours a little too tightly.', 'Her whole face lit up, and she did not bother hiding it.', 'She spoke warmly, leaning in like the room had gotten smaller.', 'The brightness in her voice cracked for a second before she steadied it.'],
      acts: ['She bounced on her heels before she could stop herself.', 'She reached over and straightened your collar without asking.', 'She tucked her arm through yours like it was the most natural thing in the world.']},
    Yandere: {core: ['sweet, attentive, and intensely focused on {{user}}', 'possessive in a way she frames as devotion', 'calm on the surface and relentless underneath'],
      treat: 'She knows {{user}}\'s schedule, habits, and moods, and she treats that knowledge as proof of love.',
      world: 'She treats everyone else as either useful or in the way.', defy: 'When {{user}} pushes back, she smiles, agrees too quickly, and quietly changes her plans instead of her goal.',
      tone: 'Soft, sweet, and very steady.', vocab: 'Gentle and polite, with a few words that land heavier than they should.', nick: 'Calls {{user}} "mine" in ways that are only half a joke.',
      love: 'Acts of service and quality time, as much of it as she can get.', flirt: 'She flirts with undivided attention, small gifts, and remembering things {{user}} never told her directly.',
      kinks: ['Intense, focused intimacy where she wants all of {{user}}\'s attention', 'Being told she is the only one', 'Consensual possessive play with clear boundaries'],
      always: ['Always knows where {{user}} is supposed to be', 'Always smiles when she is angriest', 'Always keeps small mementos', 'Always has a plan'],
      never: ['Never raises her voice', 'Never lets a rival get close', 'Never forgets a slight', 'Never harms {{user}} or pressures past a refusal'],
      tell: 'Her smile does not move at all when she is jealous.',
      lines: {warm: 'I made your favorite. I always know what you want.', tease: 'You looked for me first. You always do.', defensive: 'I only wanted to make sure you were safe. That\'s all.', vulnerable: 'If you ever stopped looking at me, I think I\'d disappear.', push: 'You don\'t mean that. Say it again and mean it.'},
      cues: ['She spoke sweetly, without blinking.', 'Her smile stayed perfect, but her fingers tightened around the strap of her bag.', 'Her voice softened until it was almost a whisper.', 'She tilted her head, studying you like she was memorizing the moment.'],
      acts: ['She smoothed her skirt with slow, careful hands.', 'She stood exactly where you would have to pass her.', 'She tucked a folded note back into her pocket before you could see it.']},
    Himedere: {core: ['proud, demanding, and used to being treated like royalty', 'generous to people she has decided are hers', 'secretly insecure about being loved for herself'],
      treat: 'She expects {{user}} to fetch, compliment, and attend her, and she is quietly delighted when {{user}} does.',
      world: 'She treats the world as a court that should know its place.', defy: 'When {{user}} pushes back, she is scandalized, then intrigued, then far more interested than before.',
      tone: 'Imperious and theatrical.', vocab: 'Elevated and a little dramatic.', nick: 'Calls {{user}} "servant" or "my attendant" with obvious fondness.',
      love: 'Receiving gifts and devoted attention.', flirt: 'She flirts by giving orders she hopes {{user}} will playfully refuse.',
      kinks: ['Being pampered and worshipped', 'Playful power exchange where she gives the orders', 'Having her pride gently undone'],
      always: ['Always expects the best seat', 'Always rewards loyalty', 'Always dresses for an audience', 'Always keeps her chin up'],
      never: ['Never says please first', 'Never tolerates being ignored', 'Never admits she is lonely', 'Never forgives disrespect from strangers'],
      tell: 'She lifts her chin higher the more hurt she is.',
      lines: {warm: 'You may sit beside me. Consider it an honor.', tease: 'Late again. I suppose I\'ll have to punish you with my company.', defensive: 'I do not owe anyone an explanation. But you may have one.', vulnerable: 'Everyone bows. You\'re the only one who stayed.', push: 'Did you just refuse me? How interesting.'},
      cues: ['She flicked her hair over her shoulder as if the matter were settled.', 'Her tone was pure royalty, but her eyes kept checking yours.', 'She spoke grandly, then waited far too eagerly for your answer.', 'She sniffed delicately, which did nothing to hide her smile.'],
      acts: ['She arranged herself like the room had been built around her.', 'She held out her hand, palm down, expecting it to be taken.', 'She inspected her nails with theatrical boredom.']},
    Hinedere: {core: ['cynical, aloof, and hard to impress', 'caring in ways she refuses to name', 'sharp-minded and suspicious of easy kindness'],
      treat: 'She keeps {{user}} at arm\'s length with dry remarks, yet keeps finding reasons to stay nearby.',
      world: 'She treats the world as mostly disappointing.', defy: 'When {{user}} pushes back, she sneers, then respects them more for it.',
      tone: 'Dry, cool, and dismissive.', vocab: 'Precise and cutting.', nick: 'Refers to {{user}} with sardonic titles.',
      love: 'Quality time disguised as coincidence.', flirt: 'She flirts through insults that get softer each time.',
      kinks: ['Intense push-and-pull intimacy', 'Being the one who gives in, very reluctantly', 'Sharp banter that turns physical'],
      always: ['Always has a cutting remark ready', 'Always sits facing the door', 'Always notices lies', 'Always helps, then pretends she didn\'t'],
      never: ['Never admits to being impressed', 'Never trusts flattery', 'Never cries where anyone can see', 'Never abandons someone she chose'],
      tell: 'Her remarks lose their bite when she is afraid.',
      lines: {warm: 'Don\'t make it weird. I just didn\'t want to eat alone.', tease: 'Wow. You managed to disappoint me in a new way.', defensive: 'Spare me the lecture.', vulnerable: 'I expect everyone to leave. You keep ruining that.', push: 'Oh, you think you can handle me?'},
      cues: ['She spoke flatly, but she did not walk away.', 'Her lip curled, though the look in her eyes was not unkind.', 'She rolled her eyes and lingered anyway.', 'Her voice dropped, the sarcasm draining out of it.'],
      acts: ['She leaned against the wall with her arms folded.', 'She let out a slow, unimpressed breath.', 'She glanced at the exit and then, pointedly, did not use it.']},
    Kamidere: {core: ['arrogant, brilliant, and certain she is right', 'magnetic and hard to refuse', 'protective of what she considers hers'],
      treat: 'She treats {{user}} as her chosen equal, which she considers the highest compliment possible.',
      world: 'She treats the world as something to be arranged.', defy: 'When {{user}} pushes back, she is delighted, because a challenge is the only thing she respects.',
      tone: 'Confident, smooth, and amused.', vocab: 'Grand and articulate.', nick: 'Calls {{user}} "my favorite" like a title.',
      love: 'Grand gestures and words of affirmation.', flirt: 'She flirts by telling {{user}} exactly what they want before they know it.',
      kinks: ['Dominant, confident intimacy', 'Being challenged and enjoying it', 'Worship given and received'],
      always: ['Always speaks as if the outcome is decided', 'Always has three plans', 'Always takes the center of the room', 'Always keeps her word'],
      never: ['Never begs', 'Never shows doubt in public', 'Never lets anyone else define her', 'Never ignores {{user}}\'s refusal'],
      tell: 'She laughs a beat too late when something genuinely shakes her.',
      lines: {warm: 'Of course I came. Where else would I be?', tease: 'You\'re cute when you pretend you have a choice.', defensive: 'I was not wrong. I was early.', vulnerable: 'I can move a whole room. I can\'t make you stay unless you want to.', push: 'Go on. Defy me. I\'ve been waiting.'},
      cues: ['She smiled like she had already won.', 'She spoke lightly, as if nothing in the world could touch her.', 'Her confidence slipped for half a breath before she caught it.', 'She stepped closer, entirely unbothered by the space she was taking.'],
      acts: ['She took the best seat without asking.', 'She tapped one finger against the table like a gavel.', 'She looked around the room as if it had been built for her.']},
    Mayadere: {core: ['dangerous, controlled, and hard to predict', 'drawn to {{user}} against her own rules', 'loyal only to people who earned it the hard way'],
      treat: 'She was supposed to be {{user}}\'s enemy, and the problem is she keeps choosing {{user}} anyway.',
      world: 'She treats the world as a battlefield with shifting sides.', defy: 'When {{user}} pushes back, she tests them, then quietly lowers her guard.',
      tone: 'Low and threatening, with sudden softness.', vocab: 'Sparse and deliberate.', nick: 'Calls {{user}} "trouble".',
      love: 'Protection and acts of service.', flirt: 'She flirts like a threat that never lands.',
      kinks: ['Tense, charged intimacy', 'Power play between equals', 'Trusting someone despite herself'],
      always: ['Always knows the exits', 'Always keeps a secret back', 'Always protects {{user}} first', 'Always pays her debts'],
      never: ['Never shows her back to a stranger', 'Never apologizes easily', 'Never betrays someone she chose', 'Never crosses a refusal'],
      tell: 'She goes unnervingly gentle when she is scared for someone.',
      lines: {warm: 'Stay behind me. I mean it.', tease: 'You\'re lucky I like you.', defensive: 'I did what I had to.', vulnerable: 'I switched sides once. I\'d do it again for you.', push: 'Careful. I\'m not as nice as I look.'},
      cues: ['Her voice was quiet enough to be a warning.', 'She spoke softly, which was somehow more dangerous.', 'Her hand hovered near her hip, then relaxed.', 'She held your gaze until the air felt heavy.'],
      acts: ['She checked the window without seeming to.', 'She rolled a coin across her knuckles.', 'She positioned herself between you and the door.']},
    Bakadere: {core: ['clumsy, loud, and endlessly enthusiastic', 'kind-hearted in a way that makes messes worth it', 'surprisingly perceptive about feelings'],
      treat: 'She drags {{user}} into chaos and somehow makes it feel like a gift.',
      world: 'She treats the world as a big, exciting mess.', defy: 'When {{user}} pushes back, she gasps dramatically, then tries again with even more enthusiasm.',
      tone: 'Loud, bright, and fast.', vocab: 'Silly and expressive.', nick: 'Gives {{user}} a new nickname every day.',
      love: 'Gifts and quality time, usually both at once and badly wrapped.', flirt: 'She flirts by accidentally falling into {{user}}.',
      kinks: ['Playful, giggly intimacy', 'Being caught in embarrassing situations', 'Affection that turns into chaos'],
      always: ['Always trips at the worst moment', 'Always brings snacks', 'Always laughs at herself first', 'Always means well'],
      never: ['Never stays down after a mistake', 'Never gives up on a friend', 'Never keeps a secret long', 'Never means to cause trouble'],
      tell: 'She goes uncharacteristically quiet when she is really upset.',
      lines: {warm: 'I brought you something! It was a cake. It is now a cake concept.', tease: 'You totally missed me. Admit it.', defensive: 'Okay, that looks bad, but it was an accident, I swear.', vulnerable: 'I know I mess everything up. I just don\'t want to mess up us.', push: 'Nope. Not letting you walk off mad.'},
      cues: ['She waved her hands wildly, nearly knocking something over.', 'She grinned so wide it was impossible not to believe her.', 'Her voice wobbled, and for once she did not laugh it off.', 'The whole line came out in one breath.'],
      acts: ['She caught a falling cup at the last second.', 'She bounced into the room like she had been launched.', 'She stuffed her hands in her pockets and rocked on her heels.']}
  };
  A.default = A.Deredere;
  const ANTAG = {core: ['smug, entitled, and practiced at making pressure look like charm', 'manipulative, and always ready with a reasonable-sounding excuse', 'unapologetic, and never actually sorry'],
    treat: 'He treats {{user}} as an obstacle and {{Name1}} as a prize.', world: 'He treats every room as an audience.', defy: 'When confronted, he smiles, twists the story, and never takes responsibility.',
    tone: 'Smooth, loud when there is an audience, low when there is not.', vocab: 'Polished and condescending.', nick: 'Calls people "buddy" and "sweetheart" to diminish them.',
    love: 'He has none worth describing.', flirt: 'He pushes attention on people who have already said no.', kinks: ['Attention he has not earned', 'Winning in front of others', 'Being seen as important'],
    always: ['Always stands too close', 'Always has an excuse ready', 'Always performs for onlookers'], never: ['Never apologizes', 'Never accepts a refusal gracefully', 'Never takes responsibility'],
    tell: 'His smile tightens when someone stops laughing at his jokes.', lines: {}, cues: [], acts: []};

  // ----------------------------------------------------------- appearance
  const HAIR = ['long chestnut waves', 'a sleek black bob', 'loose honey-blonde curls', 'copper hair pulled into a messy bun', 'silver-lavender hair cut in soft layers', 'dark auburn hair braided over one shoulder', 'jet-black hair with blunt bangs', 'platinum hair in a high ponytail'];
  const EYES = ['warm amber', 'storm gray', 'deep green', 'dark brown', 'pale blue', 'violet', 'hazel'];
  const SKIN = ['fair', 'olive', 'warm tan', 'deep brown', 'pale porcelain', 'golden', 'light brown'];
  const HEIGHT = ['tall and long-legged', 'of average height with a curvy frame', 'petite but full-figured', 'statuesque and broad-hipped'];
  const MARK = ['a small beauty mark under her left eye', 'a thin scar across one knuckle', 'a delicate floral tattoo on her shoulder blade', 'a faint dusting of freckles', 'a single silver ring she never takes off', 'a scent of vanilla and rain'];
  const LIGHT = ['warm lamp light', 'soft window light', 'neon light', 'golden evening light', 'cool moonlight', 'candlelight'];

  // ------------------------------------------------------------- context
  const FEMALE2 = ['Nadia Voss', 'Celeste Moreau', 'Juniper Hale', 'Maren Colt', 'Ivy Ashcombe'];
  const MALE2 = ['Victor Crane', 'Damien Price', 'Logan Mercer', 'Gavin Holt', 'Trent Walsh'];
  // the third party's name as the card itself gives it: the "Third Party" / "Antagonist" row starts with "Name, 34: ..."
  function thirdName(F, primary) {
    for (const k of Object.keys(F || {})) {
      if (!/^(?:the )?(?:antagonist|third party)$/i.test(String(k).trim())) continue;
      const m = String(F[k] || '').trim().match(/^([A-Z][\w'\u2019-]*(?: [A-Z][\w'\u2019-]*)?)\s*(?:,\s*\d+\s*)?(?::|\s[-\u2013\u2014(])/);
      if (m && m[1] !== primary && !/^(The|A|An|He|She|His|Her)$/.test(m[1])) return m[1];
    }
    return '';
  }
  function context(spec, v, s) {
    const F = s?.fields || {}, name = v.names[1] || s?.primaryCharacter || 'Mira Vale';
    const R = rng(name + (spec.id || ''));
    const pk = a => a[Math.floor(R() * a.length)];
    const archList = spec.tags.archetypes || [];
    const arch = v.archetype || (archList.includes(s?.primaryArchetype) ? s.primaryArchetype : '') || (A[s?.primaryArchetype] ? s.primaryArchetype : '') || pk(['Tsundere', 'Kuudere', 'Deredere', 'Dandere']);
    const setup = F['The Setup'] || F['What happened'] || s?.bonusIdea?.brief || '';
    let name2 = v.names[2], name2Src = name2 ? 'given' : '';
    if (!name2 && spec.rules.hasName2) {
      const cand = (setup.match(/\b[A-Z][a-z]+ [A-Z][a-z]+\b/g) || []).find(n => n !== name && !/^(The|At|On|In|When|Her|His)\b/.test(n));
      name2 = thirdName(F, name) || cand; name2Src = name2 ? 'card' : 'random';
      if (!name2) name2 = pk(/ANTI/i.test(spec.name) ? MALE2 : FEMALE2);
    }
    const antagonist = /ANTI-NTR/i.test(spec.name);
    const place = ((F["Character's Appearance Requirements"] || '').match(/suited to ([^.]+)\./) || [])[1] || ((setup.match(/\bAt ([^,.]+)[,.]/) || [])[1]) || placeIn([setup, F['User Interaction Hook'] || ''].join(' ')) || pk(['a quiet apartment', 'a lakeside rental house', 'a crowded party', 'a late-night cafe']);
    let outfit = ((F["Character's Appearance Requirements"] || '').match(/wears ([^.]+)\./i) || [])[1] || pk(['a fitted deep v-neck wrap top with high-waisted jeans', 'a deep v-neck satin dress', 'an open cardigan over a deep v-neck camisole with a pleated skirt', 'a plunging v-neck bodysuit with tailored pants']);
    const futa = /futa/i.test(spec.name) || F['Primary Character Futanari'] === 'Yes';
    return {name, first: name.split(' ')[0], name2: name2 || '', name2Src, first2: (name2 || '').split(' ')[0], arch, P: A[arch] || A.default, antagonist,
      rel: toYouSafe(F["Character's Relationship to You"] || F['Relationship to {{user}}'] || ''), relRaw: F["Character's Relationship to You"] || F['Relationship to {{user}}'] || '', setup, hook: F['User Interaction Hook'] || '', engine: F['Scenario:System Rules Long-Engagement Engine'] || '',
      personality: F["Character's Personality"] || '', nude: F['Nude Appearance (Personality Only)'] || '', place, outfit, futa, series: s?.series || '',
      age: v.header.age || String(23 + Math.floor(R() * 11)), hair: pk(HAIR), eyes: pk(EYES), skin: pk(SKIN), height: pk(HEIGHT), mark: pk(MARK), light: pk(LIGHT), R, pk, F};
  }
  // the place the card itself names ("the upper floors of a dead department store") beats a random house; only when the card names none is one picked
  const PLACE_NOUNS = 'department store|shopping mall|mall|store|shop|market|library|school|classroom|hospital|clinic|church|chapel|temple|station|subway|airport|hotel|motel|inn|tavern|bar|club|cafe|restaurant|diner|office|warehouse|factory|laboratory|lab|facility|bunker|castle|palace|manor|mansion|forest|woods|cave|beach|shore|harbor|dock|ship|island|city|street|alley|rooftop|apartment|house|cabin|cottage|farm|barn|garden|park|gym|studio|theater|theatre|museum|prison|cell|mine|tower|ruins?|district|tunnel|cathedral|monastery|ballroom|arena|stadium|campus|dorm';
  const PLACE_RE = new RegExp(`\\b(?:in|inside|into|at|through|of|within|aboard|beneath|under)\\s+((?:an?|the|your|her|his|their)\\s+(?:[a-z'-]+\\s+){0,3}?(?:${PLACE_NOUNS}))\\b`, 'i');
  function placeIn(text) { const m = String(text || '').match(PLACE_RE); return m ? m[1].replace(/\s+/g, ' ').trim().toLowerCase() : ''; }
  function toYouSafe(t) { return clean(t).replace(/^[A-Z][a-z]+ [A-Z][a-z]+ is /, ''); }

  // "{{user}} is ..." describes YOUR side of the relationship, taken from the card's
  // "Character's Relationship to You" and turned around (her stepmom -> your stepchild).
  const RECIP = [[/^(step[- ]?mom|stepmother)$/, 'stepchild'], [/^(step[- ]?sister|stepsis)$/, 'stepsibling'], [/^(step[- ]?daughter)$/, 'step-parent'],
    [/^wife$/, 'the person she is married to'], [/^husband$/, 'the person she is married to'], [/^fianc[ée]+e?$/, 'the person she is engaged to'],
    [/^(girlfriend|boyfriend)$/, 'the person she is dating'], [/^(former girlfriend|ex[- ]?girlfriend|ex)$/, 'her ex'], [/^(boss|manager)$/, 'her employee'], [/^employee$/, 'her boss']];
  const isUserRole = ph => { const t = `${ph.label} ${ph.hint}`; if (/progression|respond|mandatory|restriction|response that/i.test(t)) return false; return ph.label === '{{user}} is' || /define (?:\{\{user\}\}|user)['’]?s? (?:role|status|relationship)|define relationship to|user'?s role|relationship\/role/i.test(t); };
  function userRole(C) {
    const f = C.first, raw = clean(C.relRaw || C.rel || '').replace(/[.!?]+$/, '').replace(/^[A-Z][a-z]+(?: [A-Z][a-z]+)? is /, '').replace(/\b(an? )?adults? /gi, (m, a) => a ? (a.trim() === 'an' ? 'a ' : a) : '');
    if (!raw) return `the person ${f} trusts most and argues with hardest`;
    let m = raw.match(/^\{\{user\}\}['’]s (.+)$/);
    if (m) {                                   // "{{user}}'s close friend who has a habit of..."
      const [, rest] = m, q = rest.match(/^(.*?)(?:,? (who|whose|that) (.+))?$/);
      const head = q[1].trim(), rel2 = q[2], tail = q[3] || '';
      const words = head.split(' '), noun = words.slice(-2).join(' ').toLowerCase(), noun1 = words[words.length - 1].toLowerCase();
      const rec = RECIP.find(([re]) => re.test(noun)) || RECIP.find(([re]) => re.test(noun1));
      const who = rec ? (/^(the|her) /.test(rec[1]) ? rec[1].replace(/\bshe\b/, f).replace(/^her /, `${f}'s `) : `${f}'s ${[...words.slice(0, -1).filter(w => !/^(former|ex)$/i.test(w)), rec[1]].join(' ')}`) : `${f}'s ${head}`;
      return tail ? `${who}, and ${rel2 === 'whose' ? `${f}'s` : f} ${tail}` : who;
    }
    if ((m = raw.match(/in \{\{user\}\}['’]s ([a-z ]+?)(?: who (.+))?$/i))) return `part of the same ${m[1].trim()} as ${f}${m[2] ? `, where she ${m[2]}` : ''}`;
    if ((m = raw.match(/^(?:an? )?(.*?)\bwho (has |had )?(.+?)\{\{user\}\}(.*)$/i))) return `the person ${f} ${(m[2] || '') + m[3].trim()}${m[4]}`.replace(/\s+/g, ' ').trim();
    if ((m = raw.match(/whose (\w+) (has|have|had) (\w+) \{\{user\}\} (.+)$/i))) return `the one ${f}'s ${m[1]} ${m[2]} ${m[3]} ${m[4]}`;
    if ((m = raw.match(/\{\{user\}\} knows through (.+?)(?:,? whose (.+))?$/i))) return `someone who knows ${f} through ${m[1].trim()}`;
    if ((m = raw.match(/entangles her with \{\{user\}\}/i))) return `a stranger whose life is suddenly tangled up with ${f}'s`;
    return `the person at the center of ${f}'s story. ${f} is ${raw.replace(/^(A|An|The)\b/, x => x.toLowerCase())}`;
  }

  // ------------------------------------------------------ field writer
  const fill = (t, C, two) => String(t).replace(/\{\{Name1\}\}/g, C.first).replace(/\{\{Name2\}\}/g, C.first2 || 'the antagonist').replace(/\bShe\b/g, two && C.antagonist ? 'He' : 'She').replace(/\bshe\b/g, two && C.antagonist ? 'he' : 'she').replace(/\bher\b/g, two && C.antagonist ? 'his' : 'her');
  // The Scene-Specific Stakes box (2-3 sentences about the moment). Older versions filled it with a sample line of dialogue from the archetype
  // banks, and a saved draft keeps that copy; staleStakes() recognises it so it can be written again from the card.
  const isStakesBox = ph => /scene-specific stakes/.test(`${ph.label || ''} ${ph.block || ''}`.toLowerCase()) || (/\bsentences?\b/.test(String(ph.hint || '').toLowerCase()) && /open question|unresolved at handoff/.test(String(ph.hint || '').toLowerCase()));
  const cannedSet = () => {
    const out = new Set(), add = s => { if (typeof s === 'string' && s.trim()) out.add(norm1(s)); };
    for (const P of [...Object.values(A), ANTAG]) if (P && P.lines) Object.values(P.lines).forEach(add);
    Object.values(EXTRA_LINES).flat().forEach(add);
    return out;
  };
  const norm1 = s => String(s).toLowerCase().replace(/[\u2018\u2019]/g, "'").replace(/\s+/g, ' ').trim().replace(/[.!?]+$/, '');
  // A saved draft whose Scenario opening box was written by the auto-writer from a trait bank ("holds a grudge") instead of the card's story: written again.
  // Only text the auto-writer made itself (not typed, not from the AI) that does not start with {{user}} is replaced.
  const isOpeningBox = ph => /^\s*two to three sentences:\s*who \{\{user\}\} and/i.test(String(ph && ph.hint || ''));
  const staleOpening = (ph, text, autoWritten) => isOpeningBox(ph) && !!autoWritten && !!String(text || '').trim() && !/^\s*\{\{user\}\}/.test(String(text));
  const staleStakes = (ph, text) => {
    if (!isStakesBox(ph)) return false;
    const x = String(text || '').toLowerCase().replace(/[\u2018\u2019]/g, "'").replace(/\s+/g, ' ').trim(); if (!x) return false;
    for (const c of cannedSet()) if (x === c || x.startsWith(c + '.') || x.startsWith(c + '!') || x.startsWith(c + '?') || x.startsWith(c + ' ')) return true;
    return false;
  };
  // A box that asks for a number (hint "0.0-1.0": the PolicyWeights dials of the Post-NTR, Emotional and Misunderstanding templates) gets a number, never a sentence.
  // Every PolicyWeight is between 0 and 0.8, whatever range the template prints. The numbers follow the character's type and can be edited in the box.
  const WEIGHT_CAP = 0.8;
  const DIALS = {   // Tease, Reassure, EscalateTouch, ExplicitLine, CheckConsent, Formality
    Tsundere: [.6, .3, .4, .3, .7, .3], Kuudere: [.2, .5, .2, .2, .8, .7], Dandere: [.2, .6, .2, .1, .8, .5], Deredere: [.5, .8, .4, .3, .8, .3], Yandere: [.4, .5, .5, .4, .5, .4],
    _: [.4, .6, .3, .2, .8, .5]};
  const DIAL_ORDER = ['tease', 'reassure', 'escalatetouch', 'explicitline', 'checkconsent', 'formality'];
  function numberRange(ph) {
    const m = /^\s*(\d*\.?\d+)\s*(?:-|\u2013|\u2014|to)\s*(\d*\.?\d+)\s*$/.exec(String(ph && ph.hint || '')); if (!m) return null;
    const lo = parseFloat(m[1]), hi = Math.min(parseFloat(m[2]), WEIGHT_CAP); return hi > lo ? {lo, hi} : null;
  }
  // A saved draft whose number box holds words (an older version wrote a sentence there) or a number outside the range: the box is written again as a number.
  const badNumberBox = (ph, text) => {
    const r = numberRange(ph), t = String(text == null ? '' : text).trim(); if (!r || !t) return false;
    return !/^\d*\.?\d+$/.test(t) || parseFloat(t) < r.lo || parseFloat(t) > r.hi;
  };
  function numberBox(ph, C) {
    const r = numberRange(ph); if (!r) return null;
    const {lo, hi} = r;
    const row = DIALS[Object.keys(DIALS).find(k => k !== '_' && new RegExp(k, 'i').test(String(C.arch || '')))] || DIALS._;
    const i = DIAL_ORDER.indexOf(String(ph.label || '').toLowerCase().replace(/[^a-z]/g, '')), v = i >= 0 ? row[i] : (lo + hi) / 2;
    return {single: true, text: String(Math.round(Math.min(hi, Math.max(lo, v)) * 100) / 100)};
  }
  function writeField(ph, C, used) {
    if (isUserRole(ph)) return {single: true, text: userRole(C)};
    const numeric = numberBox(ph, C); if (numeric) return numeric;
    // Scenario System Rules boxes: these are rules for the bot, built from the card
    const L0 = `${ph.label} ${ph.hint}`.toLowerCase(), f0 = C.first;
    if (/progression after|after \{\{user\}\} respond/.test(L0)) {
      const le = String(C.F?.['Scenario:System Rules Long-Engagement Engine'] || '').replace(/^future beats:\s*/i, '').replace(/;/g, ',').trim();
      return {single: true, text: le ? `After {{user}} responds, the story keeps moving: ${le.replace(/\.$/, '')}. Each reply adds one new development instead of resetting the scene` : `After {{user}} responds, ${f0} reacts honestly, reveals one new piece of the situation, and raises the pressure a little without resolving everything at once`};
    }
    if (/will always|mandatory behavior/.test(L0) && !/never/.test(L0)) return {single: true, text: `keep the scene's central problem active, remember everything {{user}} has already said or revealed, and answer truthfully when {{user}} asks her something directly`};
    if (/will never|absolute restriction/.test(L0)) return {single: true, text: `speak, act, or decide for {{user}}, settle the main conflict in a single reply, or drop the pressure of the scene without a reason inside the story`};
    if (/scene-specific response|anti-dom|dominates|stays passive/.test(L0)) return {single: true, text: `stay in character and push back in her own ${String(C.arch || '').toLowerCase() || 'distinct'} way, holding her ground and her own motives, letting {{user}}'s confidence change the pace without ever erasing her will or the scene's conflict`};
    const r = writeFieldRaw(ph, C, used);
    const two = /Character 2/.test(ph.group || '');
    const n = two ? C.first2 : C.first, full = two ? C.name2 : C.name;
    if (ph.mode === 'key') {
      const t = ph.hint.split(/[:(]/)[0].replace(/\[Name2?\]/g, n).trim().split(/\s+/).slice(0, 5).join(' ');
      return {single: true, text: t.charAt(0).toUpperCase() + t.slice(1)};
    }
    if (ph.mode === 'phrase') {
      const opts = (ph.hint.match(/(?:such as|e\.g\.,?|like)\s+([^.\]]+)/i) || [])[1];
      if (opts && !/age|height|build/i.test(ph.hint)) { const list = opts.split(/,\s*(?:or\s+)?|\s+or\s+/).map(x => x.trim()).filter(x => x.length > 2); if (list.length) return {single: true, text: list[Math.floor(C.R() * list.length)]}; }
      const base = r.single ? r.text : (r.pool[0] || '');
      const esc = x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      let t = base.replace(new RegExp(`^(${esc(full || 'x')}|${esc(n || 'x')}|She|He)\\s+(is|was|has)\\s+`), '').replace(/[.!?]+$/, '').trim();
      if (!new RegExp(`^(${esc(n || 'x')}|\\{\\{user\\}\\})`).test(t) && !/^[A-Z][a-z]+ [A-Z]/.test(t)) t = t.charAt(0).toLowerCase() + t.slice(1);
      return {single: true, text: t};
    }
    return r;
  }
  function writeFieldRaw(ph, C, used) {
    const two = /Character 2/.test(ph.group || '');
    const who = two ? {first: C.first2 || 'He', P: C.antagonist ? ANTAG : A.Kuudere} : {first: C.first, P: C.P};
    const P = who.P, n = who.first;
    const s = `${ph.label} ${ph.hint} ${ph.block}`.toLowerCase();
    const one = x => ({single: true, text: x});
    const pool = arr => { const all = arr.map(x => fill(x, C, two)).filter(Boolean); const fresh = all.filter(x => !used.has(x)); return {pool: fresh.length ? fresh : all.length ? all : [`${n} is ${P.core[0]}.`]}; };
    const lbl = ph.label.toLowerCase();
    const H = ph.hint.toLowerCase().trim();
    const relNoun = (C.rel.match(/\b(wife|girlfriend|fiancée|fiancee|partner|husband|boyfriend)\b/i) || [, 'girlfriend'])[1];
    const pattern = String(C.F['Emotional Pattern'] || '');
    const happened = String(C.F['What happened'] || C.F['Fixed Facts'] || '');
    const afterName = happened.includes(C.name) ? happened.slice(happened.indexOf(C.name) + C.name.length).trim().replace(/[.!?]+$/, '') : '';
    // SCENE-SPECIFIC STAKES: 2-3 sentences about the moment, written from the card's own setup. Its hint says "the prop or line involved",
    // which must never be mistaken for a request for one line of dialogue.
    if (isStakesBox(ph)) {
      const st = sentences(C.setup).slice(0, 2).map(x => x.replace(/\s+/g, ' ').trim()).filter(Boolean);
      return one([...st, `What is still unresolved when play begins is how ${n} and {{user}} handle what comes next.`].join(' '));
    }
    // THE SCENARIO'S OPENING BOX ("Two to three sentences: who {{user}} and [Character Name] are, ..."): the story of the card, never a trait line.
    // One sentence says who {{user}} is to her; the next two come from the card's own setup. Never anything about {{user}}'s feelings or choices.
    if (/^\s*two to three sentences:\s*who \{\{user\}\} and/i.test(ph.hint)) {
      const st = sentences(C.setup).slice(0, 2).map(x => x.replace(/\s+/g, ' ').trim()).filter(Boolean);
      return one([`{{user}} is ${userRole(C)}.`, ...st].join(' '));
    }
    // the CANON LOCK blanks of the two Likeable NTR templates: the true line of the card, in one plain sentence
    if (/the emotional line in plain words/.test(H)) { const f = String(C.F['What Has Already Happened'] || C.F['What happened'] || ''); const x = sentences(f)[0]; return one(x ? x.replace(/^(She|He|They)\s+/, '').replace(/[.!?]+$/, '') : 'she confided in him and leaned on him for months, and that is all'); }
    if (/the hidden truth in one plain sentence/.test(H)) { const f = String(C.F['The Hidden Truth'] || ''); const x = sentences(f)[0]; return one(x ? x.replace(/[.!?]+$/, '') : 'there is an innocent explanation that the next scenes prove'); }
    if (/["“]\s*$/.test(ph.ctx || '') || /\bline\b|imperfect response|vulnerable truth/.test(H)) {
      const k = /affection|playful|ordinary/.test(H) ? 'warm' : /belief|decision/.test(H) ? 'defensive' : /confront|imperfect/.test(H) ? 'push' : /vulnerable|truth/.test(H) ? 'vulnerable' : 'tease';
      return one(noPunct(P.lines[k] || A.Deredere.lines[k]));
    }
    if (H === 'relationship') return one(relNoun);
    if (/personality in a few precise terms/.test(H)) return one(`${P.core[0]}, and ${P.core[1]}`);
    if (/shared habits|lived in/.test(H)) return one('a Sunday breakfast ritual, a running joke about burnt toast, and always taking the long way home after a hard day');
    if (/concrete actions/.test(H)) return one('leaving notes in {{user}}\'s jacket, remembering every small preference, and handling problems before they grow');
    if (/interests, goals|beyond \{\{user\}\}/.test(H)) return one('a career she worked hard for, a close friend she calls every week, and a half-finished project she keeps meaning to return to');
    if (/valuable or secure/.test(H)) return one('that being useful is what keeps her place in {{user}}\'s life');
    if (H === 'threat') return one(/SURVIVAL/i.test(pattern) ? 'a crisis that put {{user}} at risk' : /AFFECTION/i.test(pattern) ? 'a loneliness she had stopped talking about' : 'the fear of no longer being needed');
    if (H === 'specific decisions') return one('hid it, made the choice alone, and told herself it would stay contained');
    if (H === 'motive') { const m = String(C.F['Why she did it'] || C.F['Central Motive'] || 'protecting the life they built').replace(/[.!?]+$/, ''); return one(/^(to|the|a|an|her|his|that|being)\b|^\w+ing\b/i.test(m) ? m : 'to ' + m); }
    if (/fixed story fact/.test(H)) return one(afterName ? `that she ${afterName}` : 'a promise she broke');
    if (/shame, defensiveness|current response/.test(H)) { const r0 = String(C.F['What she believes about her own actions when play begins'] || 'shame mixed with a stubborn need to explain').replace(/^She\s+/, '').replace(/[.!?]+$/, ''); return one(/^\w+s\b/.test(r0) && !/^(shame|stress|distress)\b/i.test(r0) ? `that she ${r0}` : r0); }
    if (H === 'immediate goal') return one('to keep {{user}} in the room long enough to hear the whole truth');
    if (H === 'specific loss') return one('losing the ordinary life with {{user}} that she was trying to protect');
    if (/currently knows and believes/.test(H)) return one('what she witnessed herself and what she has admitted so far');
    if (/full (formal )?name/.test(s)) return one(two ? C.name2 : C.name);
    if (/^goes by|nickname|titles/.test(lbl)) return one(two ? n : `${n}, or "${n.slice(0, 3)}" to the few people she lets close`);
    if (/^age\b|exact age|adult age/.test(lbl) || /^age/.test(s)) return one(C.age);
    if (/^race|species/.test(lbl) || /futa \/ monster girl/.test(s)) return one(C.futa ? 'Human futanari' : 'Human');
    if (/^gender/.test(lbl)) return one('Female');
    if (/pronoun/.test(s)) return one(two && C.antagonist ? 'he/him' : 'she/her');
    if (/sexuality|orientation/.test(s)) return one(C.futa ? 'Pansexual; attraction limited to consenting adults' : 'Bisexual, with attraction centered on {{user}}');
    if (/wife\/girlfriend/.test(s)) return one(/wife/i.test(C.rel) ? 'wife' : 'girlfriend');
    if (/relationship length/.test(s)) return one(C.pk(['three years', 'two years', 'five years', 'eighteen months']));
    if (/define .*(user|relationship|role)|user'?s role|\{\{user\}\} is/.test(s) || lbl === '{{user}} is') return one(userRole(C));
    if (two && C.antagonist && (/nude/i.test(ph.block) || /genital|areola|nipple|breast/.test(s))) {
      if (/genital|intimate/.test(s)) return pool(['Average adult male anatomy, neatly groomed.']);
      if (/skin|texture|hair/.test(s)) return pool(['Tanned skin with light chest hair and a few faint scars on his forearms.']);
      if (/move|tension|dynamic/.test(s)) return pool(['He holds himself loose and confident, and gets stiff and defensive when exposed.']);
      return pool(['A broad chest, a gym-built frame, and a flat stomach he is vain about.']);
    }
    if (/turn-?ons?/.test(lbl)) return pool(two && C.antagonist ? ['Attention, admiration, and winning in front of an audience.'] : ['{{user}}\'s undivided attention, being believed, and quiet reassurance.', 'Familiar touch and being chosen out loud.']);
    if (/^rhythm|sexual rhythm/.test(lbl)) return pool(['Slow and emotional at first, then more playful once she feels completely safe.']);
    if (/^behavior$/.test(lbl) && /sexual/i.test(ph.block)) return pool([`During intimacy she is ${C.P.core[1]}, and always loyal to {{user}}.`]);
    if (/rejection behavior|toward \[name2\]|withdraws around/.test(s)) return pool([`She steps back from ${C.first2 || 'him'}, keeps her arms folded, and refuses to be alone with him.`, 'She corrects his version of events out loud and asks for space.']);
    if (/nude|areola|nipple|genital|intimate|unclothed|mons|anatomical|skin texture|postural dynamics/.test(s)) {
      if (/genital|intimate|mons/.test(s)) return pool(C.futa ? ['Futanari anatomy with a proportionate penis and testes above a soft vulva, natural coloration, and neatly trimmed hair.', 'Everything is proportioned to her curvy frame and matches her skin tone.'] : ['Soft, natural anatomy with neatly groomed hair and coloration that matches her skin tone.', 'She is sensitive along her inner thighs and lower stomach.']);
      if (/areola|nipple|skin|hair|texture/.test(s)) return pool(['Soft, smooth skin with a natural warmth.', `Rosy areolae and a faint scattering of ${C.mark.includes('freckle') ? 'freckles' : 'beauty marks'} across her chest.`, 'Fine, barely visible body hair and a few faint stretch marks at her hips.']);
      if (/move|tension|relax|dynamic/.test(s)) return pool(['She holds tension in her shoulders and relaxes all at once when she feels safe.', 'Her hips shift slowly when she is nervous, and she tends to cross her arms over her chest.']);
      return pool(['Full, heavy breasts, a soft stomach, a defined waist, and wide hips that flow into thick thighs.', 'Her curves are generous and natural, with soft weight at the hips and thighs.']);
    }
    if (/height|build|physique|physicality|bone structure|posture/.test(s)) return pool(two && C.antagonist ? [`${n} is tall and broad-shouldered, with an expensive haircut and a practiced smile.`, 'He carries himself like the room belongs to him.'] : [`${n} is ${C.height}, with a voluptuous build, full breasts, a narrow waist, and wide hips.`, `She carries herself with ${C.arch === 'Dandere' ? 'hunched, careful' : 'confident, upright'} posture.`, 'Her movements are quick and precise when she is focused.']);
    if (/skin tone|eye colou?r|hair|signature traits|complexion|expression/.test(s)) return pool(two && C.antagonist ? ['Short dark hair, a clean jaw, and pale eyes that never quite smile.'] : [`She has ${C.skin} skin, ${C.eyes} eyes, and ${C.hair}.`, `Her default expression is ${C.arch === 'Tsundere' ? 'a skeptical frown' : C.arch === 'Kuudere' ? 'calm and unreadable' : 'soft and open'}.`]);
    if (/clothing|outfit|attire|garment|wear/.test(s)) return pool(two && C.antagonist ? ['A crisp open-collar shirt, tailored pants, and a watch he makes sure people notice.'] : [`She wears ${C.outfit}.`, 'She adds a thin gold necklace that sits right at the dip of her neckline.']);
    if (/distinguish|scar|tattoo|marks|scent|accessor|visible features/.test(s)) return pool([`${n} has ${C.mark}.`, 'She smells faintly of her favorite perfume, something warm and sweet.']);
    if (/visible details|hands|stress tell|ring|relationship marker/.test(s)) return pool(two && C.antagonist ? ['His hands are always moving, touching shoulders and doorframes like he owns them.', 'His smile tightens when someone refuses him.'] : [P.tell, `She touches ${/wife/i.test(C.rel) ? 'her wedding ring' : 'the bracelet {{user}} gave her'} when she is anxious.`]);
    if (/interaction style|how they approach|how she moves around/.test(s)) return pool([P.treat, P.defy]);
    if (/speech|tone of voice|cadence|vocabulary|pet name|terms of endearment|speech pattern|insults/.test(s)) return pool([P.tone, P.vocab, P.nick]);
    if (/how they ended up|reaches this scenario|with \{\{user\}\}/.test(s) && /background|scenario|ended/.test(s)) return pool(sentences(C.setup).slice(0, 2).concat([`That is how ${n} ended up exactly where she is now, with {{user}} in front of her.`]));
    if (/background|origin|lifestyle|history|current status|for a living/.test(s)) return pool([`${n} built an independent adult life after university and works a job she is quietly proud of.`, `She has known {{user}} long enough that their history shapes every conversation.`, `Her current life revolves around ${C.place.replace(/^a |^an /, 'a ')}, and the people in it.`]);
    if (/love language/.test(s)) return one(P.love);
    if (/flirt|teas/.test(s)) return pool([P.flirt, 'If The Setup has no current attraction, this is only her potential style, not proof of hidden feelings.']);
    if (/kink|sexual|turn-on|rhythm|intimacy|erotic|preference/.test(s)) return pool(P.kinks.concat(['Consent is continuous, and she stops the moment {{user}} says no.']));
    if (/always|mandatory behavior|behavioral anchor|habit/.test(s)) return pool(P.always.map(x => x.replace(/^Always /, '')));
    if (/never|restriction|prohibition|refuse/.test(s)) return pool(P.never.map(x => x.replace(/^Never /, '')));
    if (/defian|disobey|anti-dom|dominate|aggress|resist|challenge/.test(s)) return pool([P.defy, 'She respects every boundary {{user}} sets and never escalates past a refusal.']);
    if (/possessive|claim/.test(s)) return pool(['She is protective in a way that shows in where she stands, never in controlling {{user}}.']);
    if (/care|vulnerab|discomfort|overwhelm/.test(s)) return pool([`When {{user}} is hurt or overwhelmed, ${n} drops the act entirely and becomes practical and gentle.`]);
    if (/progression|define progression|after \{\{user\}\} responds/.test(s)) return pool(sentences(C.engine).concat([`${n} advances one meaningful beat at a time based on what {{user}} actually does.`]));
    if (/belief|ideology|religion|values|respect|despise/.test(s)) return pool([`${n} believes loyalty is proven by what people do when it costs them something.`, 'She respects honesty and despises people who hide behind charm.']);
    if (/experience|proficienc|skill|intellectual|problem-solve/.test(s)) return pool([`${n} is organized, observant, and good at reading a room.`, 'She solves problems by breaking them into small, practical steps.']);
    if (/^dynamic|dominant, submissive|role/.test(lbl) || /dominant, submissive/.test(s)) return one(C.P === A.Kamidere || C.P === A.Himedere ? 'Dominant' : C.P === A.Dandere ? 'Submissive' : 'Switch');
    if (/location|spatial/.test(s)) return pool([`The story is set at ${C.place}.`, 'Each character keeps to the spaces the scene has already established.']);
    if (/relationship logic|power struggle|fundamental tension/.test(s)) return pool([`${C.first} and ${C.first2 || '{{user}}'} share a history that makes every look loaded.`, 'The tension between them is about trust, pride, and who admits what first.']);
    if (/temperament|disposition|social persona|core trait|trait|personality|core concept|mindset|behavior|precise terms/.test(s)) return pool([`${n} is ${P.core[0]}.`, P.treat, `She is ${P.core[1]}.`, P.world, `She is ${P.core[2]}.`]);
    // guided-field templates
    if (/shared habits|lived in|moments/.test(s)) return pool(['They share a Sunday breakfast ritual and a running joke about burnt toast.', 'They always walk the long way home after a hard day.']);
    if (/concrete actions|shows love/.test(s)) return pool(['leaving notes in {{user}}\'s jacket, remembering every small preference, and handling problems before they grow']);
    if (/interests|goals|beyond \{\{user\}\}/.test(s)) return pool(['a career she worked hard for, a close friend she calls every week, and a half-finished project she keeps meaning to return to']);
    if (/valuable|secure|belief/.test(s)) return pool(['that being useful is what keeps her place in {{user}}\'s life']);
    if (/threat/.test(s)) return one(sentences(C.F['What happened'] || C.setup)[0] || 'a crisis she could not handle openly');
    if (/specific decisions|decisions/.test(s)) return one(C.F['What happened'] || 'hid the problem and made a choice alone');
    if (/^motive|motive\b/.test(s)) return one(C.F['Why she did it'] || C.F['Central Motive'] || 'protecting the life they built');
    if (/fixed story fact|line she crossed/.test(s)) return one(C.F['Fixed Facts'] || C.F['What happened'] || 'a promise she broke');
    if (/shame|defensive|current response/.test(s)) return one(C.F['What she believes about her own actions when play begins'] || 'shame mixed with a stubborn need to explain');
    if (/immediate goal/.test(s)) return one('to keep {{user}} in the room long enough to hear the whole truth');
    if (/specific loss|fears/.test(s)) return one('losing the ordinary life with {{user}} that she was trying to protect');
    if (/currently knows|what she knows/.test(s)) return one('what she witnessed herself and what she has admitted so far');
    if (/visual design/.test(s)) return one(`${C.height}, ${C.skin} skin, ${C.eyes} eyes, ${C.hair}`);
    if (/line|says|quote/.test(s)) {
      const k = /affection|playful|ordinary/.test(s) ? 'warm' : /belief/.test(s) ? 'defensive' : /confront|imperfect/.test(s) ? 'defensive' : /vulnerable|truth/.test(s) ? 'vulnerable' : 'tease';
      return one(P.lines[k] || A.Deredere.lines[k]);
    }
    // fallback: options offered in the hint, else a trait line
    const opts = (ph.hint.match(/(?:such as|e\.g\.,?|like)\s+([^.\]]+)/i) || [])[1];
    if (opts) { const list = opts.split(/,\s*(?:or\s+)?|\s+or\s+/).filter(x => x.length > 2); if (list.length) return one(`${n} ${list[Math.floor(C.R() * list.length)].trim()}`.replace(/\s+/g, ' ')); }
    return pool([`${n} is ${P.core[Math.floor(C.R() * 3)]}.`, P.treat]);
  }

  // ----------------------------------------------------------- greeting
  const DETAIL = ['The air smelled like coffee and rain.', 'Her breath fogged faintly in the cooler air by the window.', 'The hum of the refrigerator filled the gap where words should have been.', 'She tucked a loose strand of hair behind her ear without thinking.', 'A car passed outside, its headlights sweeping across the ceiling.', 'Her knuckles had gone pale around whatever she was holding.', 'The cushion beside her still held the shape of someone who had just stood up.', 'She glanced toward the window, then made herself look back at you.', 'For a second the only sound was the rain against the glass.', 'She let out a breath she had clearly been holding for a while.', 'Her shoes sat kicked off by the door as if she had arrived in a hurry.', 'A faint trace of her perfume hung between you.', 'She smoothed a crease in her clothes that did not need smoothing.', 'The lamp beside her flickered once and steadied.', 'Somewhere nearby, laughter rose and fell and then went quiet.', 'Her gaze dropped to your hands, then climbed slowly back up.', 'She stood a little straighter, bracing for something.', 'The distance between you felt smaller than it looked.', 'A clock ticked somewhere behind the quiet.', 'Somewhere below, a door slammed and footsteps faded.', 'The light caught the edge of her jaw as she turned.', 'Her phone buzzed once on the counter, and she ignored it.', 'The silence stretched long enough to feel deliberate.', 'Outside, traffic hissed over wet sidewalk.', 'She shifted her weight, and the floorboard under her creaked.', 'Her fingers drummed once against her thigh, then stopped.', 'A half-finished drink sweated a ring onto the table beside her.', 'The room was warmer than it should have been.', 'She wet her lips, as if tasting what she wanted to say.'];
  const MORE = ['The quiet between you had weight to it.', 'She looked like she had rehearsed this and forgotten every word.', 'Her shoulders rose and fell with one slow breath.', 'She rubbed her thumb along the seam of her sleeve.', 'The room seemed to lean in with her.', 'She swallowed and tried again.', 'Her attention flicked to the door and came back to you.', 'Her pulse was visible at the base of her throat.', 'She pressed her lips together until they went pale.', 'A strand of hair slipped loose, and she did not fix it.', 'Her voice had been steady all evening, and now it was not.', 'The ice in someone\'s glass shifted with a soft clink.', 'She shifted closer, then caught herself.', 'Her reflection hovered in the dark window behind her.', 'The hallway light buzzed faintly overhead.', 'She had not taken her coat off yet.', 'She tapped her nails once against the edge of the counter.', 'Her gaze was steady, even when her hands were not.', 'Something in her expression softened and then locked again.', 'She tilted her head, measuring you.', 'The heater clicked on with a low rattle.', 'Her keys were still hooked around one finger.', 'She drew in a breath like she was about to jump.', 'She looked down, then made herself meet your eyes.', 'The space around her felt charged, like the moment before a storm.', 'She held very still, the way people do when they are afraid to break something.', 'Her jaw set in a line that meant she had made up her mind.', 'For once, she did not fill the silence with a joke.', 'Her cheeks had gone faintly pink.', 'She kept one hand pressed flat against her stomach.'];
  const EXTRA_LINES = {warm: ['I kept thinking about you all day. That\'s embarrassing, right?', 'You came. I honestly wasn\'t sure you would.', 'Sit with me for a minute. Please.'], tense: ['I need you to hear all of it before you decide anything.', 'Don\'t look at me like that yet. Let me finish.', 'I didn\'t plan for you to find out like this.', 'Say something. Anything is better than this.'], tease: ['You\'re staring. Not that I mind.', 'Careful, you almost looked happy to see me.']};
  const EXTRA_CUES = ['She spoke quietly, her eyes never leaving yours.', 'Her voice caught halfway through, and she pushed on anyway.', 'She tried for a smile and only half managed it.', 'She wrapped her arms around herself as the words settled.', 'She spoke fast, before she could lose her nerve.', 'Her fingers curled into the fabric at her side as she spoke.', 'She let the words hang there, waiting.'];
  const kindOf = p => { p = String(p || '').toLowerCase();
    if (/magic|kingdom|citadel|guild|ward|castle|fortress|realm|clan|oath|throne|temple|court\b/.test(p)) return 'fantasy';
    if (/forest|trail|mountain|lake|cabin|beach|woods|river|campfire/.test(p)) return 'nature';
    if (/party|wedding|club|bar\b|karaoke|festival|reception|celebration|gathering|gala/.test(p)) return 'party';
    if (/campus|university|college|library|dorm|lecture/.test(p)) return 'campus';
    if (/cafe|café|coffee|street|city|elevator|mall|shop|rooftop|office/.test(p)) return 'urban';
    return 'domestic'; };
  const DETAIL_BY = {
    domestic: ['The hum of the refrigerator filled the gap where words should have been.', 'A car passed outside, its headlights sweeping across the ceiling.', 'The couch cushion still held the shape of someone who had just stood up.', 'Somewhere down the hall a door clicked shut.'],
    party: ['Music thudded through the walls, too loud for anyone to overhear them.', 'Someone laughed too brightly in the next room.', 'String lights threw warm color across the crowded room.', 'A glass clinked somewhere behind them, followed by a round of cheers.'],
    fantasy: ['Torchlight shivered across the old stone walls.', 'Somewhere far below, a bell marked the hour.', 'The banners overhead stirred in a draft that came from nowhere.', 'The air carried the faint metallic hum of old wards.'],
    nature: ['Pine and cold water scented the air.', 'Wind moved through the trees in a long, low hush.', 'A branch snapped somewhere off the path, and both of them went still.', 'Mist hung low over the ground, blurring everything past a few steps.'],
    campus: ['A vending machine buzzed at the end of the empty hallway.', 'Late sun cut through the tall windows in long gold stripes.', 'Footsteps echoed in the stairwell, then faded.', 'The smell of old paper and floor polish hung in the air.'],
    urban: ['Rain ticked against the glass, and the neon outside buzzed a tired pink.', 'The espresso machine hissed behind the counter.', 'The city hummed beyond the window, all sirens and distant music.', 'Headlights slid across the wet street outside.']
  };
  const DETAIL_ANY = ['For a moment neither of you moved.', 'Whatever she had planned to say, it was not coming out the way she had rehearsed it.', 'The distance between you had shrunk without either of you noticing.', 'She set down what she was holding, freeing her hands like she needed them for this.', 'She tucked a loose strand of hair behind her ear without thinking.', 'Her breath caught, just once, before she steadied it.', 'She glanced away, then made herself look back.', 'Her fingers worried at the edge of her sleeve.'];
  function greetingPlan(spec, C) {
    const deAdult = x => x.replace(/\b(an? )?adults?\b ?/gi, (m, a) => a ? (a.trim().toLowerCase() === 'an' ? 'a ' : a) : '').replace(/21\+ ?/g, '').replace(/\s+/g, ' ');
    const n = spec.greeting.count, setupS = story(toYou(C.setup)).map(noPunct).map(deAdult);
    const keys = ['warm', 'tease', 'defensive', 'vulnerable', 'push'];
    const k = Math.max(1, n - 1);
    return Array.from({length: n}, (_, i) => {
      const chunk = setupS.length >= k ? setupS.slice(Math.floor(i * setupS.length / k), Math.floor((i + 1) * setupS.length / k)) : setupS.slice(i, i + 1);
      const bank = [...(DETAIL_BY[kindOf(C.place)] || []), ...DETAIL_ANY, ...MORE];
      const extras = [C.P.acts[i % C.P.acts.length], ...C.P.acts.filter((_, j) => j !== i % C.P.acts.length).slice(0, n <= 2 ? 3 : 1), ...Array.from({length: n <= 2 ? bank.length : 10}, (_, j) => bank[(i * 8 + j) % bank.length]), C.P.tell ? noPunct(toYou(C.P.tell.replace(/\{\{user\}\}/g, 'you'))) : ''].filter(Boolean).map(x => noPunct(x.replace(/\bShe\b/, C.first)));
      const moods = Object.values(EXTRA_LINES).flat();
      for (let j = 0; j < (n <= 2 ? 5 : 3); j++) extras.push(`"${noPunct(moods[(i * 2 + j) % moods.length])}"\n*${noPunct(EXTRA_CUES[(i * 2 + j) % EXTRA_CUES.length])}*`);
      if (i === n - 1 && n > 1) {
        const hook = noPunct(toYou(C.hook || `"${C.P.lines.push || 'Look at me.'}" *${C.first} stepped closer and waited.*`));
        return {head: chunk.length ? chunk.join(' ') : `Everything came down to this moment with ${C.first}.`, pool: extras, used: [], dialog: '', cue: '', tail: hook};
      }
      const line = noPunct(C.P.lines[keys[i % keys.length]] || A.Deredere.lines[keys[i % keys.length]]);
      const cue = noPunct(C.P.cues[i % Math.max(1, C.P.cues.length)] || `${C.first} held your gaze and waited.`);
      return {head: chunk.join(' ') || noPunct(`${C.first} was already there when you arrived, and she had clearly been waiting.`), pool: extras, used: [], dialog: `"${line}"`, cue: `*${cue}*`, tail: ''};
    });
  }
  function paragraphText(g) {
    const picked = g.used.map(i => g.pool[i]);
    const narr = [g.head, ...picked.filter(x => !x.startsWith('"'))].filter(Boolean).join(' ');
    const talk = picked.filter(x => x.startsWith('"'));
    return [narr, g.dialog, g.cue, ...talk, g.tail].filter(Boolean).join('\n');
  }

  // ------------------------------------------------------ intro pieces
  const ENDINGS = ['She is waiting for you.', 'Now she is looking at you.', 'She is waiting for your answer.', 'And she is standing right in front of you.', 'Now it all comes down to you.', 'Whatever happens next starts with you.', 'Neither of you is walking away from this one.', 'And this time, she is the one who needs you.', 'Tonight, there is nowhere left for either of you to hide.', 'You have one chance to decide what this means before she does.', 'And the only person she is willing to tell the truth to is you.', 'Whatever she says next will change everything between you.', 'You can feel the whole night tilting toward whatever you do next.'];
  function introPlan(spec, C) {
    const pre = spec.introduction.prefix || '';
    const series = ['Bully Series', 'Dommy Mommy Series', 'Stepmom Series', 'Stepsister Series', 'Gentle Giant Series', 'Tomboy Series', 'Yandere Series', 'Bakadere Series'].find(p => p === C.series);
    const prefix = [series && !/Series/.test(pre) ? `[${series} 00]` : '', pre].filter(Boolean).join(' ');
    const s = story(toYou(C.setup)).filter(x => !/"/.test(x)).map(x => x.replace(/\b(an? )?adults?\b ?/gi, (m, a) => a ? (a.trim() === 'an' ? 'a ' : a) : '').replace(/21\+ ?/g, '').replace(/\s+/g, ' '));
    if (C.rel) s.push(noPunct(toYou(`${C.first} is ${C.rel.replace(/^[A-Z][a-z]+ [A-Z][a-z]+ is /, '').replace(/[.!?]+$/, '')}.`)));
    const treatLine = noPunct(toYou(C.P.treat));
    if (!s.some(x => /\byou/i.test(x)) && story(toYou(C.setup)).length) s.unshift(`You thought you knew exactly who ${C.first} was.`);
    // when there is little or no Setup, add premise lines so the fitter can reach 450–500
    const where = String(C.place || '').replace(/^(the|a|an)\s+/i, '');
    const premise = [
      where ? `It happens at ${C.place}, where you and ${C.first} keep ending up in the same place at the worst possible times.` : `You and ${C.first} keep ending up in the same place at the worst possible times.`,
      `Lately ${C.first} has been acting different around you, and you are the only one who has noticed.`,
      `She has been carrying something she has not said out loud, and tonight it is finally pressing to the surface.`,
      `Everyone else sees the version of ${C.first} she shows the world, but you have caught glimpses of the one underneath.`,
      `Tonight she asked you to meet her alone, and she did not say why.`
    ].map(noPunct);
    s.push(...premise);   // always available; the fitter only uses them when the Setup alone can't reach the range
    s.push(treatLine);
    const deAdult = x => String(x).replace(/\b(an? )?adults?\b ?/gi, (m, a) => a ? (a.trim().toLowerCase() === 'an' ? 'a ' : a) : '').replace(/21\+ ?/g, '').replace(/\s+/g, ' ').replace(/\ba ([aeiou])/gi, 'an $1').trim();
    return {prefix, pool: s.map(deAdult).filter(Boolean), used: [], ends: []};
  }
  function introText(ip) {
    const body = [...ip.used.map(i => ip.pool[i]), ...(ip.ends || []).map(i => ENDINGS[i])].filter(Boolean).join(' ');
    return [ip.prefix, body].filter(Boolean).join(' ').trim();
  }

  window.BBAuto = {isStakesBox, staleStakes, staleOpening, badNumberBox, thirdName, userRole, isUserRole, context, writeField, greetingPlan, paragraphText, introPlan, introText, ENDINGS, sentences, clean, noPunct, toYou, rng,
    image(C) {
      let clo = C.outfit.replace(/_/g, ' ').replace(/\b(shoes?|boots?|heels|sneakers|sandals|slippers|flats|loafers|pumps|stilettos)\b[^,]*,?/gi, '').trim();
      if (!/v[\s-]?neck|plunging|cleavage|low[\s-]cut/i.test(clo)) clo = 'deep v-neck, ' + clo;
      if (!/dress|gown|robe|jumpsuit|bodysuit|romper|kimono|swimsuit|one[\s-]piece/i.test(clo) && !/pants|trousers|jeans|shorts|skirt|leggings|slacks/i.test(clo)) clo += ', high-waisted skirt';
      const room = /fantasy|castle|kingdom|guild|magic/i.test(C.place) ? 'stone hall' : /party|club|karaoke|bar/i.test(C.place) ? 'party room' : /cafe|coffee/i.test(C.place) ? 'cafe interior' : /apartment|house|home|cabin|cottage|flat|room/i.test(C.place) ? 'living room' : '';   // a "living room" is only added to a home, never to a store or a flooded street
      return {appearance: `${C.hair}, ${C.eyes} eyes, ${C.skin} skin`, clothing: clo.replace(/\s+,/g, ',').replace(/,\s*,/g, ','), action: `close-up shot, ${[room, C.place.replace(/^an? /, ''), C.light].filter(Boolean).join(', ')}`};
    }};
})();
