// Automatic backup UI: a first-run pop-up (when no backup folder is set) and a Backup block in Settings.
(function () {
  const api = window.juicyApp || {};
  if (!api.backupGet) return;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const say = (m, bad) => { try { toast(m, !!bad); } catch {} };
  const ago = t => { if (!t) return 'never'; const m = Math.round((Date.now() - t) / 60000); if (m < 1) return 'just now'; if (m < 60) return m + ' min ago'; const h = Math.round(m / 60); if (h < 24) return h + ' h ago'; const d = Math.round(h / 24); return d + (d === 1 ? ' day ago' : ' days ago'); };
  let st = null, askedThisSession = false;

  async function load() { try { st = await api.backupGet(); } catch (e) { st = {ok: false, error: String(e && e.message || e)}; } return st; }

  // the online backup: ONE box for the URL of your Google backup script (no sign-in, no Client ID). The script itself is copied from the button.
  function googleBlock() {
    const url = (st.gd && st.gd.url) || st.defaultUrl || '';
    return `<div class="gd-block" style="margin-top:12px;padding-top:10px;border-top:1px solid #33273c">
      <p class="micro"><b>Back up online to Google Drive</b> (one URL, no sign-in)</p>
      <div class="block-add" style="flex-wrap:wrap;gap:8px"><input id="gd-url" type="url" style="flex:1;min-width:220px" placeholder="Paste your backup URL (https://script.google.com/macros/s/…/exec)" value="${esc(url)}" autocomplete="off"><button class="ghost sm" type="button" data-bk="gdrive">Use this URL</button></div>
      <details id="gd-setup"><summary class="micro" style="cursor:pointer">Where do I get the URL? / Backup ID</summary>
        <ol class="micro" style="margin:6px 0 6px 18px;padding:0">
          <li>Press <b>Copy the Google script</b> below.</li>
          <li>Open <b>script.google.com</b> (signed in to the Google account whose Drive should hold the backups) &gt; <b>New project</b>, delete what is there and paste.</li>
          <li><b>Deploy &gt; New deployment &gt; Web app</b>: Execute as <b>Me</b>, Who has access <b>Anyone</b> &gt; Deploy, allow it when Google asks, and copy the <b>Web app URL</b>.</li>
          <li>Paste that URL above. Anyone who has the URL can store and read backups, so keep it private.</li></ol>
        <div class="block-add" style="flex-wrap:wrap;gap:8px"><button class="ghost sm" type="button" data-bk="copyscript">Copy the Google script</button></div>
        <p class="micro" style="margin-top:8px">Backup ID of this PC: <code>${esc(st.installId || '')}</code> (backups are kept under this name; to reach another PC's backups, type its ID here before pressing Use this URL):</p>
        <div class="block-add"><input id="gd-box" type="text" style="min-width:200px" placeholder="${esc(st.installId || 'Backup ID')}" value="${esc(st.gd && st.gd.box || '')}" autocomplete="off"></div>
      </details>
    </div>`;
  }

  function paint() {
    const el = $('backup-box'); if (!el) return;
    if (!st || st.ok === false) { el.innerHTML = '<p class="micro">' + esc(st && st.error || 'Backup is not available here.') + '</p>'; return; }
    const on = st.enabled;
    el.innerHTML =
      (on ? `<p class="micro"><b>Automatic backup is on.</b></p>
         <p class="micro">Folder: <code>${esc(st.root)}</code></p>
         <p class="micro">Last backup: <b>${esc(ago(st.lastAt))}</b>${st.count ? ' · ' + st.count + ' saved' : ''}</p>
         ${st.lastRestore ? (st.lastRestore.error ? `<p class="micro" style="color:#ff8a8a">The last restore did not work: ${esc(st.lastRestore.error)}</p>` : `<p class="micro">Restored on ${esc(fmt(st.lastRestore.at))} from backup ${esc(st.lastRestore.name)}. Your data from before is kept in <code>${esc(st.lastRestore.safety)}</code></p>`) : ''}
         ${st.lastError ? `<p class="micro" style="color:#ff8a8a">Last problem: ${esc(st.lastError)}</p>` : ''}`
        : `<p class="micro">Automatic backup is <b>off</b>. Your scrape history, saved bots and settings are only on this PC.</p>`) +
      `<div class="block-add" style="flex-wrap:wrap;gap:8px">
         ${on ? '<button class="ghost sm" type="button" data-bk="now">Back up now</button><button class="ghost sm" type="button" data-bk="restore">Restore from a backup…</button><button class="ghost sm" type="button" data-bk="choose">Change folder…</button><button class="ghost sm" type="button" data-bk="open">Open folder</button><button class="ghost sm" type="button" data-bk="off">Turn off</button>'
              : '<button class="ghost sm" type="button" data-bk="choose">Choose a folder…</button>' + (st.detected && st.detected[0] ? '<button class="ghost sm" type="button" data-bk="drive">Use my Google Drive folder</button>' : '') + '<button class="ghost sm" type="button" data-bk="restore">Restore from a backup…</button>'}
       </div>
       ${googleBlock()}
       <p class="micro">Best place without a link: a folder inside <b>Google Drive for Desktop</b> (usually <code>My Drive</code>), so the backup syncs to your Drive. It saves when the app starts (if the last one is over 20 hours old), about every 3 hours while the app is open, and when you close it. The last 4 plus one per day for 2 weeks are kept. Browser sign-ins are not included. To restore, see the README.txt inside the backup folder.</p>`;
  }

  const fmt = t => { try { return new Date(t).toLocaleString([], {weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit'}); } catch { return String(t); } };
  const mb = n => n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB';

  function restoreDialog(list, fresh) {
    let m = $('backup-modal2');
    if (!m) { m = document.createElement('div'); m.id = 'backup-modal2'; m.className = 'upd-modal'; document.body.appendChild(m); }
    m.style.display = 'flex';
    if (!list || !list.length) {
      m.innerHTML = '<div class="upd-box"><h3>Restore from a backup</h3><p class="upd-sub">There are no backups in the backup folder yet.</p><div style="display:flex;gap:8px;margin-top:12px"><button class="ghost" type="button" data-br="close">Close</button></div></div>';
    } else {
      m.innerHTML = `<div class="upd-box"><h3>${fresh ? 'Backups found in this folder' : 'Restore from a backup'}</h3>
        <p class="upd-sub">${fresh ? 'This folder already holds backups. Restore your data from one of them, or keep the data on this PC.' : 'Pick the backup to go back to.'} The app first keeps a safety copy of your current data next to its data folder, then restarts with the backup's data.</p>
        <div class="upd-notes" id="br-list" style="max-height:40vh;overflow:auto">${list.map((x, i) => `<label class="check-row" style="display:flex;gap:8px;padding:6px 2px"><input type="radio" name="br" value="${esc(x.name)}" ${i === 0 ? 'checked' : ''}> <span>${esc(fmt(x.at))} <span class="micro">· ${esc(mb(x.size))}${i === 0 ? ' · newest' : ''}</span></span></label>`).join('')}</div>
        <p class="micro" id="br-msg"></p>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px"><button class="primary" type="button" data-br="go">Restore this backup</button>${fresh ? '<button class="ghost" type="button" data-br="keep">Keep my current data</button>' : '<button class="ghost" type="button" data-br="close">Cancel</button>'}</div></div>`;
    }
    m.onclick = async ev => {
      const b = ev.target.closest('[data-br]'); if (!b) return; const w = b.dataset.br;
      if (w === 'close') { m.style.display = 'none'; return; }
      if (w === 'keep') { m.style.display = 'none'; await act('now'); return; }
      if (w === 'go') {
        const pick = m.querySelector('input[name=br]:checked'); if (!pick) return;
        if (!confirm('Restore the backup from ' + fmt((list.find(x => x.name === pick.value) || {}).at) + '?\n\nThe app will close and open again. Your current data is saved as a safety copy first.')) return;
        $('br-msg').textContent = 'Restoring… the app restarts in a moment.';
        const r = await api.backupRestore(pick.value).catch(e => ({ok: false, error: String(e && e.message || e)}));
        if (!r || r.ok === false) $('br-msg').textContent = 'Could not restore: ' + (r && r.error || 'unknown problem');
      }
    };
  }

  async function act(what, dir) {
    let r;
    try {
      if (what === 'choose') r = await api.backupChoose();
      else if (what === 'drive') r = await api.backupUseDetected(dir || (st.detected || [])[0]);
      else if (what === 'now') r = await api.backupNow();
      else if (what === 'open') r = await api.backupOpen();
      else if (what === 'off') r = await api.backupDisable(false);
      else if (what === 'copyscript') { r = await api.backupCopyScript(); if (r && r.ok) say('Script copied. Paste it into script.google.com.'); }
      else if (what === 'gdrive') { const url = (dir && /^https?:/.test(dir) ? dir : '') || ($('gd-url') || {}).value || ''; if (!url.trim()) { say('Paste your backup URL first.', true); return {ok: false}; } say('Checking the URL…'); r = await api.backupGdrive(url, ($('gd-box') || {}).value || ''); }
      else if (what === 'restore') { const l = st && st.dir ? await api.backupList() : null; if (!l) { r = await api.backupChoose(); if (r && r.canceled) return r; } else { restoreDialog(l.snapshots || [], false); return l; } }
    } catch (e) { r = {ok: false, error: String(e && e.message || e)}; }
    if (r && r.canceled) return r;
    if (r && r.ok && r.existing) { await load(); paint(); const md = $('backup-modal'); if (md) md.style.display = 'none'; restoreDialog(r.existing, true); return r; }
    if (what === 'restore' && r && r.ok && !r.existing) { say('No backups were found in that folder. Automatic backup is now on there.'); await load(); paint(); return r; }
    if (r && r.ok === false && r.error) say('Backup: ' + r.error, true);
    else if (what === 'now' || what === 'choose' || what === 'drive' || what === 'gdrive') { if (r && r.unchanged) say('Backup is up to date.'); }   // the progress card (bottom right) already shows start, progress and done
    else if (what === 'off') say('Automatic backup turned off.');
    await load(); paint(); return r;
  }

  function ensureBlock() {
    if ($('backup-panel')) return;
    const col = document.querySelector('#view-settings .set-col'); if (!col) return;
    const p = document.createElement('div'); p.className = 'panel'; p.id = 'backup-panel';
    p.innerHTML = '<div class="panel-head"><div><h3>Backup</h3><p>Keeps a copy of your data in a folder you choose, such as Google Drive.</p></div></div><div id="backup-box"></div>';
    col.insertBefore(p, col.firstChild);
    p.addEventListener('click', ev => { const b = ev.target.closest('[data-bk]'); if (b) { ev.preventDefault(); act(b.dataset.bk); } });
  }

  function popup() {
    if (askedThisSession) return; askedThisSession = true;
    let m = $('backup-modal');
    if (!m) { m = document.createElement('div'); m.id = 'backup-modal'; m.className = 'upd-modal'; document.body.appendChild(m); }
    const d = (st.detected || [])[0];
    m.style.display = 'flex';
    m.innerHTML = `<div class="upd-box"><h3>Back up your data?</h3>
      <p class="upd-sub">Your scrape history, saved bots and settings live only on this PC. Pick a folder and the app will keep backups there automatically. If the folder is inside <b>Google Drive for Desktop</b>, the backups sync to your Drive.</p>
      ${d ? `<p class="upd-sub">Google Drive folder found: <code>${esc(d)}</code></p>` : '<p class="upd-sub">No Google Drive folder was found on this PC. You can still pick any folder (for example one on a USB drive), or install Google Drive for Desktop first.</p>'}
      <p class="upd-sub" style="margin-top:10px">Or back up online to Google Drive: paste your backup URL (one URL, no sign-in).</p>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><input id="bm-url" type="url" style="flex:1;min-width:220px" placeholder="https://script.google.com/macros/s/…/exec" value="${esc(st.defaultUrl || '')}" autocomplete="off"><button class="ghost" type="button" data-bm="gdrive">Use this URL</button></div>
      <p class="micro" id="bm-msg"></p>
      <div class="upd-actions" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:12px">
        ${d ? '<button class="primary" type="button" data-bm="drive">Use my Google Drive folder</button>' : ''}
        <button class="${d ? 'ghost' : 'primary'}" type="button" data-bm="choose">Choose a folder…</button>
        <button class="ghost" type="button" data-bm="later">Not now</button>
        <button class="ghost" type="button" data-bm="never">Don't ask again</button>
      </div></div>`;
    m.onclick = async ev => {
      const b = ev.target.closest('[data-bm]'); if (!b) return;
      const w = b.dataset.bm;
      if (w === 'later') { m.style.display = 'none'; return; }
      if (w === 'never') { try { await api.backupDisable(true); } catch {} m.style.display = 'none'; await load(); paint(); say('OK. You can turn backup on any time in Settings.'); return; }
      if (w === 'gdrive') {
        const url = ($('bm-url') || {}).value || ''; if (!url.trim()) { $('bm-msg').textContent = 'Paste the backup URL first.'; return; }
        $('bm-msg').textContent = 'Checking the URL…';
        const r = await act('gdrive', url.trim());
        if (r && r.ok) m.style.display = 'none'; else $('bm-msg').textContent = (r && r.error) || 'Could not use that link.';
        return;
      }
      const r = await act(w, d);
      if (r && r.ok) m.style.display = 'none';
    };
  }


  // ---- progress card, bottom right: started > in progress > complete (or failed)
  (function progressCard() {
    if (!api.onBackupProgress) return;
    const css = document.createElement('style');
    css.textContent = '#bk-card{position:fixed;right:20px;bottom:88px;z-index:99999;width:290px;background:#1b1422;border:1px solid #4a3a58;border-radius:10px;padding:12px 14px;box-shadow:0 6px 22px rgba(0,0,0,.45);color:#eee;font-size:13px;display:none}' +
      '#bk-card .bk-t{display:flex;justify-content:space-between;gap:8px;font-weight:600}#bk-card .bk-s{margin-top:2px;color:#b9aac6;font-size:12px}' +
      '#bk-card .bk-bar{margin-top:9px;height:7px;border-radius:5px;background:#2e2338;overflow:hidden}#bk-card .bk-fill{height:100%;width:0;border-radius:5px;background:linear-gradient(90deg,#a14bdb,#e2599f);transition:width .35s ease}' +
      '#bk-card.done .bk-fill{background:#3fb97a}#bk-card.err .bk-fill{background:#e35d5d}';
    document.head.appendChild(css);
    const card = document.createElement('div'); card.id = 'bk-card'; card.setAttribute('role', 'status'); card.setAttribute('aria-live', 'polite');
    card.innerHTML = '<div class="bk-t"><span class="bk-h">Backup</span><span class="bk-p"></span></div><div class="bk-s"></div><div class="bk-bar"><div class="bk-fill"></div></div>';
    document.body.appendChild(card);
    const q = s => card.querySelector(s);
    let hideT = null, creepT = null, shown = 0;
    const setPct = p => { shown = p; q('.bk-fill').style.width = p + '%'; q('.bk-p').textContent = Math.round(p) + '%'; };
    const stopCreep = () => { if (creepT) { clearInterval(creepT); creepT = null; } };
    api.onBackupProgress(ev => {
      if (!ev) return;
      clearTimeout(hideT); card.style.display = 'block';
      const where = ev.where === 'Google Drive' ? ' for Google Drive' : '';
      if (ev.phase === 'start') { stopCreep(); card.className = ''; q('.bk-h').textContent = 'Backup started'; q('.bk-s').textContent = 'Getting your data ready' + where + '…'; setPct(0); return; }
      if (ev.phase === 'progress') {
        stopCreep(); card.className = ''; q('.bk-h').textContent = 'Backing up…'; q('.bk-s').textContent = (ev.text || 'Working') + '…'; setPct(Math.max(shown, ev.pct || 0));
        if (ev.creepTo) creepT = setInterval(() => { if (shown < ev.creepTo) setPct(shown + (ev.creepTo - shown) * 0.04 + 0.2); }, 700);   // one upload has no real percentage: ease toward the end while Google answers
        return;
      }
      stopCreep();
      if (ev.phase === 'done') { card.className = 'done'; q('.bk-h').textContent = 'Backup complete ✓'; q('.bk-s').textContent = (ev.where === 'Google Drive' ? 'Saved to your Google Drive' : 'Saved to your backup folder') + (ev.name ? ' (' + ev.name + ')' : ''); setPct(100); hideT = setTimeout(() => { card.style.display = 'none'; }, 6000); try { load().then(paint); } catch {} return; }
      if (ev.phase === 'error') { card.className = 'err'; q('.bk-h').textContent = 'Backup did not finish'; q('.bk-s').textContent = ev.text || 'Something went wrong.'; q('.bk-fill').style.width = '100%'; q('.bk-p').textContent = ''; hideT = setTimeout(() => { card.style.display = 'none'; }, 12000); try { load().then(paint); } catch {} }
    });
  })();

  async function init() {
    ensureBlock(); await load(); paint();
    if (st && st.ok !== false && st.needsPrompt) setTimeout(() => { try { popup(); } catch {} }, 2500);
  }
  window.JBSBackup = {refresh: async () => { await load(); paint(); }};
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  document.addEventListener('click', ev => { const t = ev.target.closest && ev.target.closest('[data-view="settings"], [data-tab="settings"]'); if (t) setTimeout(() => window.JBSBackup.refresh(), 50); });
})();
