/* Bot Builder: fill a bot template by hand (no AI). The template file decides
   the structure; this screen gives one box per [placeholder], keeps the fixed
   rules word-for-word, and checks the template's own limits as you type. */
const halfTag = x => String(x).toLowerCase().split('/').map(y => y.trim()).filter(Boolean);
const repeatsEventTag = (t, evTags) => !(evTags || []).includes(t) && (evTags || []).some(o => String(o).includes('/') && halfTag(o).includes(String(t).toLowerCase().trim()));   // "Mafia" next to the event's "Mafia/Gang" is the same tag twice
(function () {
  const B = {templates: [], spec: null, v: null, saveT: null, pair: null, variant: 'main', editingOver: {}, fieldView: {}};
  // Save and Return places the actual generated HTML directly into the
  // Introduction field of the active Studio bot. Preserve the full editable
  // design as part of its existing draft (including paired variants).
  if (window.juicyApp?.onIntroductionDesignerSaved) window.juicyApp.onIntroductionDesignerSaved(result=>{
    if(!B.spec||!B.v||!result?.html)return;
    const context=result.context;
    if(context&&(context.templateId!==B.spec.id||context.sourceId!==String(B.v.sourceId||'')||context.variant!==String(B.v.botVariant||''))){
      toast('The active bot changed while you were designing. The generated Introduction was not applied to a different bot. Your design is still saved in Introduction Designer.',true);return;
    }
    if(result.html.length>15000){toast("Introduction exceeds JuicyChat's 15,000-character limit.",true);return;}
    // The Introduction box stays the plain text (the words typed in the Designer); the design goes into the Introduction style as its template version
    // ({{intro}}, {{name}}, {{scene}} where the bot's words go), so View as text / View as HTML, the preview and Copy Introduction all work as usual.
    const plain=String(result.design?.fields?.intro??'').trim();
    if(plain&&!htmlIntro(plain)){B.v.intro=plain;if(typeof B.v.over?.introduction==='string')B.v.over.introduction=plain;}
    else if(B.v.over&&htmlIntro(B.v.over.introduction))delete B.v.over.introduction;
    B.v.introDesign=result.design;
    B.v.introDesignHtml=result.html;
    delete B.v.introHtml;
    B.v.iAuto=null;
    B.v.touched=B.v.touched||{};B.v.touched.intro=true;
    save();build();
    const section=document.querySelector('#bb-form .bb-sec[data-sec="introduction"]');
    if(section)section.open=true;
    const tpl=String(result.templateHtml||'').trim(),LP=window.LivePreview;
    let styled=false;
    if(tpl&&LP&&LP.applyStyle){
      try{
        LP.mount();
        const first=introPayload(compose(B.spec,B.v));LP.update('introduction',first);
        styled=LP.applyStyle('Designer · '+(B.v.header.scene||B.v.names[1]||'Introduction'),tpl);
        LP.update('introduction',introPayload(compose(B.spec,B.v)));syncIvw(true);
      }catch{styled=false;}
    }
    if(htmlIntro(B.v.intro))toast('The Introduction box still holds HTML because the Designer had no plain text for it. Open the Introduction Designer, check the Introduction text, and Save and Return again.',true);
    else toast(styled?'Introduction Designer saved. The text stays in the Introduction box, and the design is now the Introduction style "Designer · '+(B.v.header.scene||B.v.names[1]||'Introduction')+'". Copy Introduction copies the finished HTML.':'Introduction Designer saved. The text stays in the Introduction box. The design could not be saved as an Introduction style; open Introduction style and paste your HTML there.',!styled);
  });
  async function openIntroductionDesigner(){
    if(!B.spec||!B.v)return toast('Choose a bot template before opening Introduction Designer.',true);
    const html=String(B.v.intro||'');
    const own=htmlIntro(html),edited=String(B.v.introHtml||'');       // own: an older save left HTML in the Introduction box; edited: HTML you changed by hand under View as HTML
    const design=B.v.introDesign&&((own&&B.v.introDesignHtml===html)||(!own&&!edited))?clone(B.v.introDesign):null;
    if(design?.fields){design.fields.scene=B.v.header.scene;design.fields.name=B.v.names[1];if(!own)design.fields.intro=html;}
    const payload={
      fields:{scene:B.v.header.scene||'',name:B.v.names[1]||'',intro:own?'':html,extra:''},
      ...(design?{design}:{sourceHtml:own?html:edited}),
      context:{templateId:B.spec.id,sourceId:String(B.v.sourceId||''),variant:String(B.v.botVariant||'')}
    };
    try{await window.juicyApp.introductionDesignerOpen(payload);}
    catch(err){toast('Could not open Introduction Designer: '+err.message,true);}
  }

  const Identity = window.CardIdentity;
  const clone = value => JSON.parse(JSON.stringify(value));
  const q = id => document.getElementById(id);
  const e = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
  const SEC_TITLE = {header: 'Basics', introduction: 'Introduction', personality: 'Personality', scenario: 'Scenario',
    greeting: 'Greeting', image: 'Image Generation', tags: 'Tags', scene: 'Scene Breakdown'};
  const SERIES_PREFIX = ['Bully Series', 'Dommy Mommy Series', 'Stepmom Series', 'Stepsister Series', 'Gentle Giant Series', 'Tomboy Series', 'Yandere Series', 'Bakadere Series'];

  function blank(spec) {
    return {templateId: spec.id, header: {scene: '', age: ''}, names: {1: '', 2: '', 3: ''}, include3: false,
      intro: spec.introduction.prefix ? spec.introduction.prefix + ' ' : '', f: {},
      greet: Array(spec.greeting.count).fill(''), autoFormat: true, greetFmt: greetFmtDefault(), greetBreak: greetBreakDefault(),
      img: {appearance: '', clothing: '', action: (window.ImageStyle && window.ImageStyle.rulesOn === false) ? '' : 'close-up shot, '}, tags: [], archetype: '', wife: false,
      scenes: Array.from({length: spec.greeting.count}, () => ({name: '', shot: spec.scene.shotPrefix, setting: '', action: ''})),
      over: {}, auto: {}, gAuto: [], fit: {}};
  }

  // ---------------------------------------------------------------- archetype: one from the template's list
  // the card's own archetype if it's listed; otherwise the closest listed one (never a silent default)
  const ARCH_NEAR = {undere: 'Deredere', 'yes-girl': 'Deredere', sweet: 'Deredere', affectionate: 'Deredere', cheerful: 'Deredere', bubbly: 'Deredere', brat: 'Tsundere', bully: 'Tsundere', tomboy: 'Tsundere', prickly: 'Tsundere',
    shy: 'Dandere', quiet: 'Dandere', timid: 'Dandere', cold: 'Kuudere', stoic: 'Kuudere', aloof: 'Kuudere', calm: 'Kuudere', princess: 'Himedere', spoiled: 'Himedere', haughty: 'Himedere', proud: 'Himedere',
    clumsy: 'Bakadere', airhead: 'Bakadere', ditzy: 'Bakadere', obsessive: 'Yandere', possessive: 'Yandere', jealous: 'Yandere', dangerous: 'Mayadere', villain: 'Mayadere', femme: 'Mayadere', arrogant: 'Kamidere', godlike: 'Kamidere', superior: 'Kamidere', cynical: 'Hinedere', sarcastic: 'Hinedere', bitter: 'Hinedere'};
  // the card's own archetype, exactly as written, or nothing: never a guessed "close" one
  function closestArchetype(list, arch, card) {
    list = list || []; const a = String(arch || '').trim();
    if (!list.length) return a;
    return list.find(x => x.toLowerCase() === a.toLowerCase()) || '';
  }
  window.__closestArchetype = closestArchetype;

  // ---------------------------------------------------------------- reader: "you/your" or {{user}}
  function applyPov(spec, v) {
    if (!window.Pov) return; const L = window.Pov.locks(spec), m = v.pov === 'user' ? 'user' : 'you';
    if (!htmlIntro(v.intro)) v.intro = window.Pov.convert(v.intro || '', L.intro ? 'you' : m); v.greet = v.greet.map(p => window.Pov.convert(p || '', L.greet ? 'you' : m));
    if (window.TemplateContract?.userCallRequired(spec)) v.greet = window.Pov.ensureUserLine(v.greet);
  }
  function povUi() {
    const box = q('bb-pov'); if (!box || !B.spec || !window.Pov) return;
    const L = window.Pov.locks(B.spec), m = B.v.pov === 'user' ? 'user' : 'you';
    box.querySelectorAll('button').forEach(b => { b.classList.toggle('on', b.dataset.pov === m); });
    const ub = box.querySelector('[data-pov=user]'); ub.disabled = !!(L.intro && L.greet); ub.title = [L.intro, L.greet].filter(Boolean).join(' ') || 'Refer to the reader as {{user}} in the narration';
  }
  // ----------------------------------------------------- local narration tense
  // These controls are optional in the headless builder used by the AI runner.
  // No renderer dependency is added to its load order, and no AI API is called.
  const TENSE_PARTS = [{scope: 'intro', label: 'Introduction'}, {scope: 'greet', label: 'Greeting'}];
  function renderTense() {
    const host = q('bb-tense'); if (!host) return;
    host.hidden = !B.spec || !B.v;
    if (host.hidden) return;
    const T = window.NarrativeTense;
    if (!host.querySelector('[data-tense]')) {
      host.innerHTML = `<div class="bb-tense-top"><strong>Narration tense</strong><span class="bb-local-badge">Local | No AI</span></div>
        ${TENSE_PARTS.map(p => `<div class="bb-tense-row" data-tense-row="${p.scope}"><span class="bb-tense-part">${p.label}</span><div class="bb-tense-buttons" role="group" aria-label="${p.label} narration tense">
          <button type="button" data-tense="past" data-scope="${p.scope}" aria-pressed="false">Past</button><button type="button" data-tense="present" data-scope="${p.scope}" aria-pressed="false">Present</button></div>
          <button type="button" class="ghost bb-tense-undo" data-tense-undo="${p.scope}" disabled>Undo</button><span class="bb-tense-status" data-tense-status="${p.scope}" role="status" aria-live="polite"></span></div>`).join('')}
        <p class="bb-tense-help">Pick the Introduction and the Greeting tense separately. Quoted dialogue, image links and formatting stay unchanged. Rule-based conversion: review complex or mixed-time sentences.</p>`;
      host.querySelectorAll('[data-tense]').forEach(button => button.onclick = () => changeTense(button.dataset.tense, button.dataset.scope));
      host.querySelectorAll('[data-tense-undo]').forEach(button => button.onclick = () => changeTense('undo', button.dataset.tenseUndo));
    }
    const labels = {past: 'Past tense', present: 'Present tense', mixed: 'Mixed narration', unknown: 'Not set'};
    for (const part of TENSE_PARTS) {
      const S = T ? T.status(B.v, part.scope) : {mode: 'unknown', canUndo: false};
      host.querySelectorAll(`[data-tense][data-scope="${part.scope}"]`).forEach(button => {
        button.disabled = !T;
        button.classList.toggle('on', S.mode === button.dataset.tense);
        button.setAttribute('aria-pressed', String(S.mode === button.dataset.tense));
      });
      host.querySelector(`[data-tense-undo="${part.scope}"]`).disabled = !S.canUndo;
      host.querySelector(`[data-tense-status="${part.scope}"]`).textContent = T ? (labels[S.mode] || labels.unknown) : 'The local converter could not load. Your text has not been changed.';
    }
  }
  function changeTense(target, scope) {
    if (!B.v || !B.spec || !window.NarrativeTense || !['intro', 'greet'].includes(scope)) return;
    const name = scope === 'intro' ? 'Introduction' : 'Greeting';
    try {
      let result;
      if (target === 'undo') {
        if (!window.NarrativeTense.undo(B.v, scope)) return toast(`There is no unchanged tense conversion to undo for the ${name}. Your current edits are kept.`, true);
      } else result = window.NarrativeTense.apply(B.v, target, scope);
      // Update only the affected controls. Keep open sections and scroll position.
      document.querySelectorAll('#bb-form .bb-in[data-k]').forEach(el => {
        const k = el.dataset.k;
        if (scope === 'intro' && k === 'intro') el.value = B.v.intro;
        else if (scope === 'greet' && /^g\.\d+$/.test(k)) el.value = B.v.greet[+k.slice(2)];
        else if (scope === 'intro' && k === 'over.introduction') el.value = typeof B.v.over.introduction === 'string' ? B.v.over.introduction : compose(B.spec, B.v).sec.introduction.body;
        else if (scope === 'greet' && k === 'over.greeting') el.value = typeof B.v.over.greeting === 'string' ? B.v.over.greeting : compose(B.spec, B.v).sec.greeting.body;      // the markdown box shows the finished Greeting when it has no edited copy of its own (never "undefined")
        else return;
        if (el.tagName === 'TEXTAREA') { grow(el); el.dispatchEvent(new Event('bbrepaint')); }      // the Greeting markdown box shows a painted copy of its text: repaint it, or it keeps showing the old tense
      });
      refresh(); renderEvent(); save();
      toast(target === 'undo' ? `Restored the exact ${name} text from before the last tense conversion.` : result.changed ? `${name} switched to ${target} tense locally. Review the result before publishing.` : `No recognized narration verbs needed changing in the ${name} for ${target} tense. No AI was used.`);
    } catch (err) { console.error(err); toast('Tense conversion failed: ' + err.message, true); }
  }
  // What the AI writer is told: one tense for both parts, or one per part.
  function tenseForAi(v) {
    const c = window.NarrativeTense && window.NarrativeTense.chosen ? window.NarrativeTense.chosen(v) : {intro: '', greeting: ''};
    if (!c.intro && !c.greeting) return undefined;
    return Object.assign({}, c.intro && c.intro === c.greeting ? {mode: c.intro} : {}, c.intro ? {intro: c.intro} : {}, c.greeting ? {greeting: c.greeting} : {});
  }

  async function loadSaved(selectKey) {
    const sel = q('bb-saved'); if (!sel) return; let list = [];
    try { list = await window.juicyApp.builderSavedBots(); } catch {}
    sel.innerHTML = `<option value="">${list.length ? `Load a saved bot… (${list.length})` : 'No saved bots yet'}</option>` + list.map(b => `<option value="${e(b.key)}" ${b.key === selectKey ? 'selected' : ''}>${e(b.sceneName)} · ${e(b.templateName)}${b.day && b.day !== 'Bonus' ? ` · ${e(b.day)}` : ''}</option>`).join('');
    const del = q('bb-saved-del'); if (del) del.style.display = sel.value ? '' : 'none';
  }
  window.builderSavedFor = id => (B.savedIndex || []).filter(b => b.cardId === id);

  // ---------------------------------------------------------------- character limits: from the template, or asked from you
  const SEC_NAME = {introduction: 'Introduction', personality: 'Personality', scenario: 'Scenario', greeting: 'Greeting'};
  function renderLimits() {
    const host = q('bb-limits'); if (!host || !B.spec) return;
    const missing = B.spec.missingLimits || [], f = L => L ? `${L.min.toLocaleString()}–${L.max.toLocaleString()}` : '';
    const total = B.spec.rules && B.spec.rules.total;
    host.className = 'bb-limits' + (missing.length ? ' need' : '');
    host.innerHTML = `<div class="bb-lim-row">${Object.keys(SEC_NAME).map(sec => { const L = B.spec[sec] && B.spec[sec].limit;
        if (B.spec[sec] && B.spec[sec].absent) return `<span class="bb-lim"><b>${SEC_NAME[sec]}</b>—<small>not in this template</small></span>`;
        return `<span class="bb-lim ${L ? (L.fromUser ? 'mine' : '') : 'none'}"><b>${SEC_NAME[sec]}</b>${L ? `${f(L)}<small>${L.fromUser ? 'set by you' : 'from template'}</small>` : '<small>no limit in template</small>'}</span>`; }).join('')}
      ${total ? `<span class="bb-lim"><b>Combined</b>${f(total)}<small>${total.softMin || total.softMax ? 'approximate' : 'from template'}</small></span>` : ''}</div>
      ${B.spec.limitConflict ? `<div class="bb-lim-ask"><p><b>These limits contradict each other.</b> ${e(B.spec.limitConflict)} Change one of them in the template so a bot can meet both.</p></div>` : ''}
      ${missing.length ? `<div class="bb-lim-ask"><p><b>This template doesn't set a character limit for the ${missing.map(x => SEC_NAME[x]).join(', ')}.</b> Set ${missing.length > 1 ? 'them' : 'it'} so the bot (and the AI) know how long to write. Saved for this template; if the template gets its own limit later, the template's wins.</p>
        ${missing.map(sec => `<label>${SEC_NAME[sec]} <input type="number" min="1" step="10" class="bb-lim-in" data-sec="${sec}" data-k="min" placeholder="minimum"> to <input type="number" min="1" step="10" class="bb-lim-in" data-sec="${sec}" data-k="max" placeholder="maximum"> characters</label>`).join('')}
        <div class="button-row"><button class="primary" id="bb-lim-save">Save limits</button></div></div>` : ''}`;
    const sv = q('bb-lim-save'); if (sv) sv.onclick = async () => {
      const lim = {}; for (const inp of host.querySelectorAll('.bb-lim-in')) { (lim[inp.dataset.sec] = lim[inp.dataset.sec] || {})[inp.dataset.k] = +inp.value; }
      for (const sec of missing) { const L = lim[sec] || {}; if (!(L.min > 0) || !(L.max >= L.min)) return toast(`Enter a minimum and a maximum for the ${SEC_NAME[sec]} (the maximum at least as large as the minimum).`, true); }
      try { B.templates = await window.juicyApp.builderSetLimits(B.spec.id, lim); selectTemplate(B.spec.id); toast(`Limits saved for ${B.spec.name}.`); } catch (e) { toast(e.message, true); }
    };
  }
  window.builderMissingLimits = () => (B.spec && B.spec.missingLimits) || [];

  // ---------------------------------------------------------------- the active event's checklist
  // the checklist is the one of the event the source card is entered in; a card that is in no event has no event checklist
  function cardEvent(v) {
    v = v || B.v;
    if (!v || !v.sourceId || typeof window.eventForCard !== 'function') return undefined;
    return window.eventForCard(v.sourceId);             // undefined: no such card (a blank bot) -> the default event
  }
  // is this bot really entered in an event? (its event box is ticked AND its card is in an active event, or it is a blank bot while an event is active)
  function eventActiveFor(v) {
    v = v || B.v;
    if (typeof window === 'undefined' || !v || v.eventOn === false) return false;
    const ce = cardEvent(v), rb = ce === undefined ? window.__eventRB : (ce && ce.rulebook) || null;
    return !!rb;
  }
  const isEventTag = t => /^event$/i.test(String(t).trim());
  const NO_EVENT_FILL = ['OC', 'Story/Scene', 'Drama', 'Romance', 'Slow Burn', 'Slice of Life', 'Fictional', 'Serious', 'Comedy', 'Fantasy', 'Mystery', 'Angst'];
  // a bot that is in no event does not carry the template's "Event" tag: the next approved tag takes that slot so the count stays
  function reconcileEventSlot(spec, v) {
    if (!spec || !v || !spec.tags) return;
    const state = eventActiveFor(v) ? 'on' : 'off';
    if (v.evSlot === state) return;
    v.evSlot = state;
    if (state === 'on') return;
    v.tags = (v.tags || []).filter(t => !isEventTag(t));
    const T = spec.tags; if (!T.total) return;
    const have = () => tagList(spec, v);
    for (const t of NO_EVENT_FILL) {
      if (have().length >= T.total) break;
      if (T.approved.includes(t) && !isEventTag(t) && !have().includes(t) && !(T.archetypes || []).includes(t) && t !== 'Wife') v.tags.push(t);
    }
  }
  // the tags the active event asks for (its own tag and its opportunity tags), exactly as JuicyChat's announcement writes them: they are allowed on the bot whether or not the rulebook's approved list has them
  function eventTagNames() {
    if (typeof window === 'undefined' || !B.v || B.v.eventOn === false) return [];
    const ce = cardEvent(), rb = ce === undefined ? window.__eventRB : (ce && ce.rulebook) || null; if (!rb) return [];
    return [...new Set((rb.rules || []).filter(r => r.part === 'tags' && r.source === 'text').flatMap(r => r.signs || []).filter(t => t && !/^event$/i.test(t)))];
  }
  // the active event's own tag (for example "Dangerous Attraction"): it takes the place of the template's "Event" tag slot while the event is on
  function eventTagName() {
    if (typeof window === 'undefined' || !B.v || B.v.eventOn === false) return '';
    const ce = cardEvent(), rb = ce === undefined ? window.__eventRB : (ce && ce.rulebook) || null; if (!rb) return '';
    const P = ce && ce.parsed; if (P && P.eventTag && !/^event$/i.test(String(P.eventTag).trim())) return String(P.eventTag).trim();
    for (const r of (rb.rules || [])) { const m = r.part === 'tags' && r.source === 'text' && /^Use the event tag "(.+?)"/.exec(r.requirement || ''); if (m && !/^event$/i.test(m[1].trim())) return m[1].trim(); }
    return '';
  }
  const slotTags = (list, name) => name ? list.map(t => /^event$/i.test(String(t).trim()) ? name : t) : list;
  function eventState() {
    const ce = cardEvent(), rb = ce === undefined ? window.__eventRB : (ce && ce.rulebook) || null; if (!rb || !window.EventRules || !B.spec) return null;
    if (B.v.eventOn === undefined) B.v.eventOn = true;          // while an event is on, every bot is checked against it (untick to leave one out)
    if (!B.v.eventOn) return {rb, on: false, res: [], failing: []};
    const res = window.EventRules.check(rb, B.spec, B.v, compose(B.spec, B.v));
    return {rb, on: true, res, failing: res.filter(x => !x.ok)};
  }
  function renderEvent() {
    const host = q('bb-event'); if (!host) return; const E = eventState();
    if (!E) { host.style.display = 'none'; try { syncChecks(); } catch { /* ignore */ } return; }
    host.style.display = '';
    // Keep the user's disclosure state when another editor action redraws this panel.
    const publishingOpen = host.querySelector('.bb-publishing-checks')?.open === true;
    const mainOpen = host.querySelector('.bb-ev-main')?.open === true;                // the whole box is collapsed until opened
    const PL = {personality: 'Personality', scenario: 'Scenario', greeting: 'Greeting', image: 'Image Generation', tags: 'Tags', publishing: 'Publishing'};
    const content = E.res.filter(x => !x.reminder), later = E.res.filter(x => x.reminder);
    const todo = later.filter(x => !x.ok).length, needsContent = content.some(x => !x.ok);
    const tick = x => `<label class="er"><input type="checkbox" class="bb-ev-tick" data-id="${e(x.rule.id)}" ${x.ok ? 'checked' : ''}> <span>${e(x.rule.requirement)}<small>${PL[x.rule.part] || 'Review'}: tick when actually done</small></span></label>`;
    const nBad = content.filter(x => !x.ok).length, evState = !E.on ? 'off' : needsContent ? 'bad' : todo ? 'warn' : 'ok';       // red: something to fix, yellow: only publishing reminders left, green: all good
    const evNote = !E.on ? 'not checked' : needsContent ? `${nBad} to fix` : todo ? `${todo} reminder${todo > 1 ? 's' : ''} left` : '\u2713 all good';
    host.className = 'bb-event ev-' + evState;
    host.innerHTML = `<details class="bb-ev-main"${mainOpen ? ' open' : ''}><summary><h4>Event: ${e((cardEvent() ? (cardEvent().label || (cardEvent().parsed && (cardEvent().parsed.name || cardEvent().parsed.eventTag))) : '') || window.__eventName || E.rb.event || 'Event')}</h4><span class="bb-ev-st">${evNote}</span></summary>
      <label class="er"><input type="checkbox" id="bb-ev-on" ${E.on ? 'checked' : ''}> This bot is for the event</label>
      <p class="micro">Save and build drafts now. Event warnings and JuicyChat publishing reminders never block local saves, copies or exports.</p>
      ${E.on ? content.map(x => `<div class="er ${x.ok ? 'ok' : 'bad'}"><span>${x.ok ? '\u2713' : '!'}</span><span>${e(x.rule.requirement)}<small>${PL[x.rule.part]}${!x.ok && (x.missing || []).length ? ` \u00b7 needs something like: ${e(x.missing.slice(0,4).join(', '))}` : ''}</small></span></div>`).join('')
      + (needsContent ? '<div class="button-row"><button class="primary" id="bb-ev-fix">Fix for event</button></div>' : '<p class="micro">Content checks pass. Review the publishing checklist separately.</p>')
      + (later.length ? `<details class="bb-publishing-checks"${publishingOpen ? ' open' : ''}><summary>JuicyChat publishing checklist <span>${todo} remaining</span></summary><p class="micro">Complete these when you publish on JuicyChat, not when saving a draft here. Saving does not check them off.</p>${later.map(tick).join('')}</details>` : '') : '<p class="micro">Not checked against the event.</p>'}</details>`;
    q('bb-ev-on').onchange = ev => { B.v.eventOn = ev.target.checked; save(); renderEvent(); refresh(); };
    host.querySelectorAll('.bb-ev-tick').forEach(c => c.onchange = () => {
      B.v.eventTicks = B.v.eventTicks || {}; B.v.eventTicks[c.dataset.id] = c.checked;
      // A publishing tick changes only its value and the remaining count. Keep
      // the existing controls so the checklist, keyboard focus and scroll stay put.
      const counter = host.querySelector('.bb-publishing-checks summary span');
      if (counter) counter.textContent = `${host.querySelectorAll('.bb-ev-tick:not(:checked)').length} remaining`;
      save();
    });
    const fx = q('bb-ev-fix'); if (fx) fx.onclick = () => fixForEvent(content.filter(x => !x.ok));
    try { syncChecks(); } catch { /* ignore */ }
  }
  async function fixForEvent(failing) {
    const content = failing.filter(x => !x.reminder);
    if (!content.length) return toast('Only reminders are left: tick them once you have done them.', true);
    if (window.AI_ON && window.aiRun) {             // with AI: rewrite only what's missing
      const r = await window.aiRun(() => window.juicyApp.aiFixEvent(B.spec.id, B.v, content.map(x => ({rule: x.rule}))), 'Fixing the bot for the event');
      if (r && r.values) { const keep = {savedKey: B.v.savedKey, eventOn: true, eventTicks: B.v.eventTicks}; B.v = Object.assign(r.values, keep); if(B.pair?.[B.variant])B.pair[B.variant].v=B.v; save(); build(); await offerKeywords('The AI wrote the image prompt for the event as sentences.'); offerAge('The AI changed the bot for the event.'); }
      return;
    }
    // without AI: add what can be added safely (tags, image details); prose needs a writer
    const {left} = window.EventRules.safeFix(content, B.v);
    save(); build();
    toast(left.length ? `Added the tags and image details. ${content.some(x => x.rule.aiOnly) ? 'The appearance keywords for the theme need the AI writer: connect it in Settings, then press Fix for event. ' : ''}Still to write by hand: ${left.join(' · ')}` : 'Added what was missing for the event.', !!left.length);
  }

  // ---------------------------------------------------------------- Image Generation keywords
  // The app writes the appearance keywords itself. When it can't (they come out empty or broken), the AI writes them. A prompt that reads
  // like sentences is offered back as keywords, and the person decides: use the keywords, or keep the sentence-like prompts.
  const appearanceUsable = t => { const x = String(t || '').trim(); return x.length >= 6 && !/\b(undefined|null|NaN)\b|\[object/i.test(x) && x.split(/[,;]/).filter(w => w.trim().length > 1).length >= 2; };
  const IMG_RULES = () => !(window.ImageStyle && window.ImageStyle.rulesOn === false);       // false in the Shareable edition: no Image Generation rules, checks or defaults of the app
  const imageTools = v => `<div class="bb-kw-row">${!IMG_RULES() || appearanceUsable((v.img || {}).appearance) ? '' : `<p class="bb-warnrow"><b>The appearance keywords could not be generated from this card.</b> ${window.AI_ON ? 'The AI writer is asked to write them.' : 'Connect the AI writer in Settings, then press "Write appearance with AI": it writes them.'}</p>`}${IMG_RULES() ? '<button type="button" class="ghost bb-kw" title="If the image prompt reads like sentences, turn it into keywords (you decide whether to use them)">⇄ Check keywords</button> ' : ''}<button type="button" class="ghost ai-only bb-ai-look" style="${window.AI_ON ? '' : 'display:none'}" title="Have the AI write only the Appearance keywords for this character">✦ Write appearance with AI</button></div>`;
  async function aiAppearance(auto) {
    if (!B.v || !B.spec || B.imgBusy) return;
    if (!window.AI_ON || !window.juicyApp.aiImageKeywords) { if (!auto) toast('Connect the AI writer in Settings first: it writes the appearance keywords the app could not generate.', true); return; }
    if (!auto && appearanceUsable(B.v.img.appearance) && !confirm('Replace the current Appearance keywords with ones the AI writes? Clothing and Action & Background are not changed.')) return;
    B.imgBusy = true;
    try {
      const spec = B.spec, sourceId = B.v.sourceId, variant = B.v.botVariant, E = eventState();
      const rules = E && E.on ? (E.res || []).filter(x => x.rule.part === 'image' && !x.reminder).map(x => ({rule: x.rule})) : [];
      const r = await window.aiRun(() => window.juicyApp.aiImageKeywords(spec.id, clone(B.v), rules), 'Writing the appearance keywords');
      if (!r || !r.appearance) return;
      const modal = q('ai-modal'); if (modal) modal.style.display = 'none';
      if (B.spec.id !== spec.id || B.v.sourceId !== sourceId || B.v.botVariant !== variant) return toast('The selected bot changed while the AI was writing, so nothing was applied.', true);
      if (auto && appearanceUsable(B.v.img.appearance)) return;                       // the person filled it in meanwhile: theirs stays
      B.v.img.appearance = r.appearance; if (B.pair?.[B.variant]) B.pair[B.variant].v = B.v;
      save(); build(); toast('The AI wrote the Appearance keywords. Clothing and Action & Background are unchanged.');
      offerKeywords('The AI wrote the appearance in a sentence-like way.');
    } catch (err) { console.error(err); toast(err.message || 'The appearance keywords could not be written.', true); }
    finally { B.imgBusy = false; }
  }
  // after a fill or a load: if the appearance came out empty or broken, the AI is asked once for that bot
  async function checkAppearance() {
    if (!IMG_RULES()) return;                                                       // Shareable: the app does not decide what a usable Appearance is
    if (!B.v || !B.spec || !B.v.img || !(B.spec.order || []).includes('image') || appearanceUsable(B.v.img.appearance)) return;
    try { await window.aiReady; } catch {}                                          // the AI writer's status may still be loading: wait for it before deciding it is not connected
    if (!B.v || !B.spec || !B.v.img || appearanceUsable(B.v.img.appearance)) return;
    if (!B.v.sourceId && !Object.keys(B.v.f || {}).length) return;                  // a blank bot has no card to write keywords from: say nothing
    const key = `${B.spec.id}|${B.v.sourceId || ''}|${B.v.botVariant || ''}`; B.appearanceTried = B.appearanceTried || {};
    if (B.appearanceTried[key]) return; B.appearanceTried[key] = 1;
    if (window.AI_ON && window.juicyApp.aiImageKeywords && B.v.sourceId) aiAppearance(true);
    else if (window.AI_ON) toast('The appearance keywords could not be generated from this card. Open Image Generation and press "Write appearance with AI".', true);
    else toast('The appearance keywords could not be generated from this card. Connect the AI writer in Settings, then open Image Generation and press "Write appearance with AI".', true);
  }
  const IMG_TITLES = {appearance: 'Appearance', clothing: 'Clothing and Accessories', action: 'Action & Background'};
  function keywordChanges() {
    const IS = window.ImageStyle, out = {}; if (!IS || !B.v || !B.v.img) return out;
    for (const k of ['appearance', 'clothing', 'action']) {
      const raw = String(B.v.img[k] || ''), lead = k === 'action' ? (raw.match(/^close-up shot,\s*/i) || [''])[0] : '', body = raw.slice(lead.length);
      if (!IS.issues(body, k).length) continue;
      const r = IS.convert(body, k); if (r.text && r.text !== body) out[k] = {from: raw, to: lead + r.text, dropped: r.dropped};
    }
    return out;
  }
  function askKeywords(change, why) {
    return new Promise(resolve => {
      const root = document.createElement('div'); root.className = 'upd-modal sr-modal'; root.id = 'bb-kw-modal';
      const rows = Object.entries(change).map(([k, c]) => `<div class="bb-kw-item"><h4>${e(IMG_TITLES[k])}</h4><p class="micro">Now (reads like sentences)</p><pre>${e(c.from)}</pre><p class="micro">As keywords</p><pre>${e(c.to)}</pre>${c.dropped.length ? `<p class="micro">Left out because it only makes sense as a sentence: ${e(c.dropped.join(' · '))}</p>` : ''}</div>`).join('');
      root.innerHTML = `<section class="upd-box sr-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>This image prompt reads like sentences</h3><p>${e(why)} Image models work best with short keywords. Here is the same prompt as keywords. Do they make sense?</p></header><div class="sr-body">${rows}</div><footer><span class="micro">Nothing changes until you choose.</span><div class="button-row"><button type="button" class="ghost" id="bb-kw-keep">Keep the sentence-like prompts</button><button type="button" class="primary" id="bb-kw-use">Use the keywords</button></div></footer></section>`;
      document.body.appendChild(root);
      const done = v => { root.remove(); resolve(v); };
      root.querySelector('#bb-kw-keep').onclick = () => done('keep'); root.querySelector('#bb-kw-use').onclick = () => done('keywords');
      root.addEventListener('keydown', ev => { if (ev.key === 'Escape') done('keep'); }); root.querySelector('.sr-box').focus();
    });
  }
  async function offerKeywords(why, manual) {
    if (!IMG_RULES()) return;
    if (!B.v || !B.spec || document.getElementById('bb-kw-modal')) return;
    const change = keywordChanges();
    if (!Object.keys(change).length) { if (manual) toast('The image prompt is already short keywords.'); return; }
    const sig = JSON.stringify(Object.values(change).map(c => c.from));
    if (!manual && B.v.imgKeepSentences === sig) return;                                // these exact sentence-like prompts were kept on purpose
    const pick = await askKeywords(change, why);
    if (pick === 'keywords') { for (const [k, c] of Object.entries(change)) B.v.img[k] = c.to; if (B.pair?.[B.variant]) B.pair[B.variant].v = B.v; delete B.v.imgKeepSentences; save(); build(); toast('The image prompt is now keywords.'); }
    else { B.v.imgKeepSentences = sig; save(); toast('Kept the sentence-like prompts as they are.'); }
  }

  // ---------------------------------------------------------------- the character's age in the Introduction / Greeting
  // The age belongs in the Age field. When the Introduction or the Greeting also writes it out ("a 28-year-old", "Mia, 28,"),
  // the person is asked whether to take it out. Nothing changes until they choose; "keep" is remembered for those exact mentions.
  function ageSources() {
    const v = B.v, out = [], direct = k => v.over && typeof v.over[k] === 'string', many = !direct('greeting') && (v.greet || []).length > 1;
    if (direct('introduction')) out.push({label: 'Introduction', get: () => v.over.introduction, set: t => { v.over.introduction = t; }});
    else out.push({label: 'Introduction', get: () => v.intro || '', set: t => { v.intro = t; (v.touched = v.touched || {}).intro = true; v.iAuto = null; }});
    if (direct('greeting')) out.push({label: 'Greeting', get: () => v.over.greeting, set: t => { v.over.greeting = t; }});
    else (v.greet || []).forEach((_, i) => out.push({label: many ? `Greeting, passage ${i + 1}` : 'Greeting', get: () => v.greet[i] || '', set: t => { v.greet[i] = t; (v.touched = v.touched || {})['g' + i] = true; if (v.gAuto) v.gAuto[i] = null; }}));
    return out;
  }
  function ageFindings() {
    const AM = window.AgeMention; if (!AM || !B.v) return [];
    const want = parseInt(B.v.header && B.v.header.age, 10), items = [];
    // the archetype and the race are Personality facts too: the Introduction and the Greeting do not state them
    let race = ''; try { const pb = String((compose(B.spec, B.v).sec.personality || {}).body || ''); race = (pb.match(/^[ \t*-]*Race\s*:\s*(.+)$/im) || [, ''])[1].trim(); } catch (_) {}
    const metaCtx = {archetype: B.v.archetype || '', race};
    ageSources().forEach((src, si) => {
      const text = String(src.get() || '');
      if (htmlIntro(text)) return;          // HTML (colours like rgba(214, 134, 72, 0.7), sizes, links) is code, not the character's age: it is never scanned
      AM.find(text, B.v.header && B.v.header.age).concat(AM.findMeta ? AM.findMeta(text, metaCtx) : []).sort((a, b) => a.start - b.start).forEach(hit => {
        const pv = AM.preview(text, hit);
        items.push({id: `${si}:${hit.start}`, si, src, text, hit, pv, tick: !hit.manual && (hit.mine || (hit.explicit && (isNaN(want) || isNaN(hit.age)))), other: !hit.mine && !isNaN(hit.age) && !isNaN(want)});
      });
    });
    return items;
  }
  const ageSig = items => JSON.stringify(items.map(x => [x.src.label, x.hit.text, x.pv.before]));
  function askAge(items, why) {
    return new Promise(resolve => {
      const root = document.createElement('div'); root.className = 'upd-modal sr-modal'; root.id = 'bb-age-modal';
      const age = String((B.v.header && B.v.header.age) || '').trim();
      const rows = items.map(x => `<div class="bb-kw-item bb-age-item"><label class="bb-check"><input type="checkbox" data-id="${e(x.id)}" ${x.tick ? 'checked' : ''} ${x.hit.manual ? 'disabled' : ''}> <b>${e(x.src.label)}</b>${x.other ? ` <span class="micro">a different age (${e(String(x.hit.age))}) than the character's, so probably someone else: not ticked</span>` : ''}</label>
        <p class="micro">Now</p><pre>${e(x.pv.before)}</pre>${x.hit.manual ? '<p class="micro">This one can\'t be taken out without breaking the sentence. Edit it by hand.</p>' : `<p class="micro">Without it</p><pre>${e(x.pv.after)}</pre>`}</div>`).join('');
      root.innerHTML = `<section class="upd-box sr-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>${items.some(x => x.hit.kind) ? 'Age, archetype or race is written in the text' : "The character's age is written in the text"}</h3><p>${e(why)} ${items.some(x => x.hit.kind) ? 'The age, the archetype and the race belong in the Personality (and the Age field), so the Introduction and the Greeting should not state them. Remove them?' : `${age ? `The age (${e(age)}) already has its own field, so the ` : 'The age has its own field, so the '}Introduction and the Greeting do not need to say it. Remove it?`}</p></header><div class="sr-body">${rows}</div><footer><span class="micro">Nothing changes until you choose. Only the ticked ones are taken out; the rest of the text is not touched.</span><div class="button-row"><button type="button" class="ghost" id="bb-age-keep">Keep it</button><button type="button" class="primary" id="bb-age-use">Remove the ticked ones</button></div></footer></section>`;
      document.body.appendChild(root);
      const done = v => { root.remove(); resolve(v); };
      root.querySelector('#bb-age-keep').onclick = () => done(null);
      root.querySelector('#bb-age-use').onclick = () => done([...root.querySelectorAll('input[type=checkbox]:checked')].map(c => c.dataset.id));
      root.addEventListener('keydown', ev => { if (ev.key === 'Escape') done(null); }); root.querySelector('.sr-box').focus();
    });
  }
  async function offerAge(why, manual) {
    if (!B.v || !B.spec || !window.AgeMention || document.getElementById('bb-age-modal')) return;
    const items = ageFindings();
    if (!items.length) { if (manual) toast('No age, archetype or race is written in the Introduction or the Greeting.'); return; }
    const sig = ageSig(items);
    if (!manual && B.v.ageKeep === sig) return;                                         // these exact mentions were kept on purpose
    const v0 = B.v, pick = await askAge(items, why);
    if (B.v !== v0) return;                                                             // another bot was opened meanwhile
    if (!pick || !pick.length) { B.v.ageKeep = sig; save(); toast('Kept the text as it is.'); return; }
    const bySrc = new Map();
    for (const x of items) if (pick.includes(x.id) && !x.hit.manual) { if (!bySrc.has(x.si)) bySrc.set(x.si, {src: x.src, text: x.text, hits: []}); bySrc.get(x.si).hits.push(x.hit); }
    for (const g of bySrc.values()) g.src.set(window.AgeMention.apply(g.text, g.hits));
    if (B.pair?.[B.variant]) B.pair[B.variant].v = B.v;
    const rest = ageFindings(); if (rest.length) B.v.ageKeep = ageSig(rest); else delete B.v.ageKeep;
    save(); build();
    const n = [...bySrc.values()].reduce((a, g) => a + g.hits.length, 0);
    toast(`Took ${n} mention${n === 1 ? '' : 's'} (age, archetype or race) out of the text.${rest.length ? ' The rest stays as it is.' : ''}`);
  }

  // click a check to copy its text (nothing happens when the creator is selecting part of it with the mouse)
  async function copyCheck(el, text) {
    try { const sel = window.getSelection && window.getSelection(); if (sel && String(sel).trim() && el.contains(sel.anchorNode)) return; } catch (_) { /* ignore */ }
    const t = String(text || '').trim(); if (!t) return;
    try { await window.copyText(t); el.classList.add('copied'); setTimeout(() => el.classList.remove('copied'), 1200); toast('Copied: ' + (t.length > 70 ? t.slice(0, 67) + '\u2026' : t)); } catch (_) { toast('Could not copy.', true); }
  }
  // ---------------------------------------------------------------- spelling, grammar and wording (checked here on this computer: no AI, no credits)
  const WORD_KIND = {spelling: 'Spelling', grammar: 'Grammar', wording: 'Wording'};
  function wordNames() { const v = B.v || {}; return [...Object.values(v.names || {}), v.header && v.header.name, v.header && v.header.scene].filter(x => typeof x === 'string' && x); }
  // every piece of text the check reads: the Introduction, the Greeting and the written boxes of the Personality and the Scenario (each one can be fixed from the window)
  function wordSources() {
    const v = B.v, spec = B.spec, out = ageSources().map(src => ({key: /^Intro/.test(src.label) ? 'introduction' : 'greeting', label: src.label, src}));
    for (const sec of ['personality', 'scenario']) {
      if (!spec[sec] || !spec[sec].lines || (v.over && typeof v.over[sec] === 'string')) continue;     // the whole section typed as one text is left alone
      const seen = new Set();
      for (const l of spec[sec].lines) for (const s of l.segs) {
        if (s.t !== 'ph' || (l.opt3 && !v.include3) || seen.has(s.key)) continue; seen.add(s.key);
        if (!String((v.f || {})[s.key] || '').trim()) continue;
        out.push({key: sec, label: `${SEC_TITLE[sec] || sec}: ${s.label}`, src: {get: () => (v.f || {})[s.key] || '', set: t => setPath('f.' + s.key, t)}});
      }
    }
    return out;
  }
  function wordItems() {
    const TC = window.TextCheck; if (!TC || !B.v || !B.spec) return [];
    const names = wordNames(), items = [], cache = B.wordCache || (B.wordCache = new Map());
    if (cache.size > 80) cache.clear();
    wordSources().forEach((s, si) => {
      const text = String(s.src.get() || '');
      if (!text || htmlIntro(text)) return;
      const key = names.join('|') + '\u0000' + text; let hits = cache.get(key); if (!hits) { hits = TC.check(text, {names}); cache.set(key, hits); }
      hits.forEach(hit => items.push({id: `${si}:${hit.start}:${hit.kind}`, si, s, text, hit}));
    });
    return items;
  }
  const wordCtx = (text, h) => `${e(text.slice(Math.max(0, h.start - 50), h.start).replace(/^\S*\s/, '…'))}<mark>${e(text.slice(h.start, h.end) || '·')}</mark>${e(text.slice(h.end, h.end + 50).replace(/\s\S*$/, '…'))}`;
  { let ltT = 0; window.addEventListener('jbs-lt-update', () => { clearTimeout(ltT); ltT = setTimeout(() => { if (!B.v || document.querySelector('#bb-word-close')) return; B.wordCache = null; try { refresh(); } catch (_) { /* the Checks list catches up on the next change */ } }, 250); }); }
  function addWordingNotes(res) {
    if (!window.TextCheck || !B.v || !B.spec) return;
    const items = wordItems(), by = {};
    for (const x of items) (by[x.s.key] = by[x.s.key] || []).push(x);
    for (const k of Object.keys(by)) {
      const list = by[k], n = list.length, show = list.slice(0, 2).map(x => `“${x.text.slice(x.hit.start, x.hit.end).trim().slice(0, 40)}”`).join(', ');
      (res[k] = res[k] || []).push(['warn', `Spelling and wording: ${n} thing${n > 1 ? 's' : ''} to look at (${show}${n > 2 ? ', …' : ''}). Open Checks > Spelling & wording to go through ${n > 1 ? 'them' : 'it'}.`]);
    }
    B.wordCount = items.length;
    const b = q('bb-spell'); if (b) b.textContent = items.length ? `Spelling & wording (${items.length})` : 'Spelling & wording ✓';
  }
  function sentenceRange(t, h) {
    let a = h.start; while (a > 0 && !/[.!?\n]/.test(t[a - 1])) a--;
    while (a < h.start && /\s/.test(t[a])) a++;
    let z = h.end; while (z < t.length && !/[.!?\n]/.test(t[z])) z++;
    while (z < t.length && /[.!?"”*]/.test(t[z])) z++;
    return [a, z];
  }
  function askWording(items) {
    return new Promise(resolve => {
      const root = document.createElement('div'); root.className = 'upd-modal sr-modal'; root.id = 'bb-word-modal';
      const addBtn = x => `<button type="button" class="ghost sm" data-addword="${e(x.id)}" data-word="${e(x.text.slice(x.hit.start, x.hit.end))}">Add to dictionary</button>`;
      // wording and grammar notes can be dismissed for good ("gonna", a phrase you like): a single word goes into the dictionary, a phrase is ignored
      const ignBtn = (x, h) => { const w = x.text.slice(h.start, h.end).trim(); if (!w) return ''; return /^[A-Za-z'’-]+$/.test(w) ? `<button type="button" class="ghost sm" data-addword="${e(x.id)}" data-word="${e(w)}" title="Stop flagging this word">Add to dictionary</button>` : `<button type="button" class="ghost sm" data-ignore="${e(x.id)}" data-word="${e(w)}" title="Stop flagging this wording">Ignore this</button>`; };
      const rowsData = [];
      for (const x of items) {
        const h = x.hit, manual = h.fix == null && !(h.suggest && h.suggest.length);
        if (h.kind === 'wording' && manual) {         // a wording problem is fixed by rewriting its sentence: hits in the same sentence share one box
          const sr = sentenceRange(x.text, h), key = `${x.si}:${sr[0]}`; let g = rowsData.find(r => r.key === key);
          if (!g) rowsData.push(g = {key, sent: true, x, sr, hits: []}); g.hits.push(h);
        } else rowsData.push({key: x.id, x});
      }
      const rows = rowsData.map(r => {
        const x = r.x, h = x.hit;
        if (r.sent) {
          const sent = x.text.slice(r.sr[0], r.sr[1]);
          return `<div class="bb-kw-item bb-word-item" data-row="${e(r.key)}"><p class="bb-word-h"><b>Wording</b> · ${e(x.s.label)}</p>${r.hits.map(k => `<p class="bb-word-msg">${e(k.msg)} ${ignBtn(x, k)}</p>`).join('')}<label class="micro">Rewrite the sentence here, or leave it as it is</label><textarea class="bb-in bb-word-edit" rows="${Math.min(6, Math.max(2, Math.ceil(sent.length / 80)))}" data-sent="${e(r.key)}" data-si="${x.si}" data-a="${r.sr[0]}" data-z="${r.sr[1]}" spellcheck="false">${e(sent)}</textarea></div>`;
        }
        const act = h.suggest && h.suggest.length ? `<label class="micro">Change to <select data-pick="${e(x.id)}"><option value="">Leave it</option>${h.suggest.map((sg, i) => `<option value="${e(sg)}"${i === 0 ? ' selected' : ''}>${e(sg)}</option>`).join('')}</select></label> ${addBtn(x)}`
          : h.fix != null ? `<label class="bb-check"><input type="checkbox" data-id="${e(x.id)}"${h.src === 'languagetool' && h.kind === 'wording' ? '' : ' checked'}> ${h.kind === 'wording' ? 'Change it to' : 'Fix'}: ${e(h.fix.trim() === '' ? 'one space' : '“' + h.fix.trim() + '”')}</label> ${h.kind === 'spelling' ? '' : ignBtn(x, h)}`
          : h.kind === 'spelling' ? `<p class="micro">No close match. Fix it by hand, or ${addBtn(x)} if it is a name or a real word.</p>`
          : `<p class="micro">Edit this one by hand, or ${ignBtn(x, h)}</p>`;
        return `<div class="bb-kw-item bb-word-item" data-row="${e(x.id)}"><p class="bb-word-h"><b>${e(WORD_KIND[h.kind])}</b> · ${e(x.s.label)}</p><p class="bb-word-msg">${e(h.msg)}</p><pre>${wordCtx(x.text, h)}</pre>${act}</div>`;
      }).join('');
      root.innerHTML = `<section class="upd-box sr-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>Spelling, grammar and wording</h3><p>${items.length} thing${items.length > 1 ? 's' : ''} found by the app's own checker, on this computer: no AI, no credits. Tick what you want fixed, or rewrite a sentence in its box. Anything you leave alone stays exactly as it is.</p></header><div class="sr-body">${rows}</div><footer><span class="micro">Nothing changes until you press the button.</span><div class="button-row"><button type="button" class="ghost" id="bb-word-close">Close</button><button type="button" class="primary" id="bb-word-use">Apply my changes</button></div></footer></section>`;
      document.body.appendChild(root);
      const done = v => { root.remove(); resolve(v); };
      root.querySelector('#bb-word-close').onclick = () => done(null);
      root.querySelector('#bb-word-use').onclick = () => done({
        ids: [...root.querySelectorAll('input[type=checkbox]:checked')].map(c => c.dataset.id),
        picks: Object.fromEntries([...root.querySelectorAll('select[data-pick]')].filter(s => s.value).map(s => [s.dataset.pick, s.value])),
        sents: [...root.querySelectorAll('textarea[data-sent]')].map(t => ({si: +t.dataset.si, start: +t.dataset.a, end: +t.dataset.z, value: t.value, orig: t.defaultValue})).filter(t => t.value !== t.orig && t.value.trim())});
      root.addEventListener('click', ev => { const b = ev.target.closest('[data-addword],[data-ignore]'); if (!b) return; const adding = b.hasAttribute('data-addword'); if (adding ? window.TextCheck.addWord(b.dataset.word) : window.TextCheck.ignorePhrase(b.dataset.word)) { B.wordCache = null; try { refresh(); } catch (_) { /* the Checks list follows the new dictionary at once */ } const msg = b.closest('.bb-word-msg'), row = b.closest('.bb-word-item'); if (msg) msg.remove(); if (row && !row.querySelector('.bb-word-msg') || (row && !msg)) row.remove(); toast(adding ? `“${b.dataset.word}” added to your dictionary.` : `“${b.dataset.word}” will not be flagged again.`); try { refresh(); } catch (_) { /* ignore */ } } });
      root.addEventListener('keydown', ev => { if (ev.key === 'Escape') done(null); }); root.querySelector('.sr-box').focus();
    });
  }
  async function offerWording(manual) {
    if (!window.TextCheck || !B.v || !B.spec || document.getElementById('bb-word-modal')) return;
    const items = wordItems();
    if (!items.length) { B.wordCache = null; try { refresh(); } catch (_) { /* bring the Checks list up to date */ } if (manual) toast('No spelling, grammar or wording problems found.'); return; }
    const v0 = B.v, r = await askWording(items);
    if (B.v === v0) { B.wordCache = null; try { refresh(); } catch (_) { /* the list matches what is on screen again */ } }
    if (!r || B.v !== v0) return;
    const by = new Map(); let n = 0;
    const group = (x) => { if (!by.has(x.si)) by.set(x.si, {s: x.s, text: x.text, picks: []}); return by.get(x.si); };
    for (const x of items) {
      const rep = r.picks[x.id] != null ? r.picks[x.id] : (r.ids.includes(x.id) && x.hit.fix != null ? x.hit.fix : null);
      if (rep == null || r.sents.some(t => t.si === x.si && x.hit.start >= t.start && x.hit.end <= t.end)) continue;     // a sentence you rewrote by hand replaces any small fix inside it
      group(x).picks.push({start: x.hit.start, end: x.hit.end, replacement: rep});
    }
    for (const t of r.sents) { const x = items.find(i => i.si === t.si); if (x) group(x).picks.push({start: t.start, end: t.end, replacement: t.value.replace(/\s*\n\s*/g, ' ').trim()}); }
    for (const g of by.values()) { g.s.src.set(window.TextCheck.apply(g.text, g.picks)); n += g.picks.length; }
    if (!n) return toast('Nothing was changed.');
    if (B.pair?.[B.variant]) B.pair[B.variant].v = B.v;
    save(); build();
    toast(`Changed ${n} thing${n > 1 ? 's' : ''}.`);
  }

  // ---------------------------------------------------------------- compose
  function nameOf(v, tok) {
    const n = tok[1], upper = tok.endsWith('U');
    if (tok === 'N3?') return v.include3 ? (v.names[3] || '[Name3]') : '\u0003?';
    if (n === '3' && !v.include3) return '\u0003';
    const val = v.names[n] || (n === '1' ? '[Name]' : `[Name${n}]`);
    return upper ? val.toUpperCase() : val;
  }
  function renderLines(lines, v, missing) {
    const out = [];
    for (const l of lines) {
      if (l.opt3 && !v.include3) continue;
      out.push(l.segs.map((s, index) => {
        if (s.t === 'lit') return s.v.replace(/\u0001(N[123]\??U?)\u0002/g, (_, t) => nameOf(v, t));
        let val = (v.f[s.key] || '').trim();
        if (!val) { missing.push(s.label); return s.orig; }
        if (window.Dialogue?.speechSlot && /["\u201c]\s*$/.test(l.segs[index - 1]?.v || '') && /^\s*["\u201d]/.test(l.segs[index + 1]?.v || '')) val = window.Dialogue.speechSlot(val, Object.values(v.names || {}));
        if (s.endsSentence || s.mode === 'key') val = val.replace(/[.!?]+["”]?$/, m => m.includes('"') || m.includes('”') ? m.replace(/[.!?]+/, '') : '');
        return val;
      }).join(''));
    }
    // a line that is only about a third character (e.g. "*💭 [Name3]'s Thoughts ... if Name3 is used*") goes when there isn't one
    const n12 = [v.names[1], v.names[2]].filter(Boolean);
    const kept = v.include3 ? out : out.filter(line => !(line.includes('\u0003') && !n12.some(n => line.includes(n))));
    let t = kept.join('\n');
    if (!v.include3) t = t.replace(/;\s*\u0003\??/g, '').replace(/,?\s*plus \u0003(?:'s)? when (?:\u0003 is )?used/g, '')
      .replace(/,?\s*and \u0003 when used/g, '').replace(/,?\s*including \u0003 only when used/g, '')
      .replace(/,?\s*plus \u0003(?:'s)?/g, '').replace(/\u0003\??/g, '');
    return t.replace(/\n{3,}/g, '\n\n').trim();
  }
  function autoFormat(p) {
    const parts = [];
    for (const line of p.split('\n')) {
      const t = line.trim(); if (!t) { if (parts.length && parts[parts.length-1].s) parts.push({d:false,s:''}); continue; }
      if (/^!\[\]\(image\d+\)$/.test(t)) continue;
      const re = /"[^"\n]+"|“[^”\n]+”/g; let last = 0, m;
      const push = s => { s = s.trim().replace(/^\*+|\*+$/g, '').trim(); if (s) parts.push({d: false, s: `*${s}*`}); };
      while ((m = re.exec(t))) { push(t.slice(last, m.index)); parts.push({d: true, s: '"' + m[0].slice(1, -1).trim() + '"'}); last = m.index + m[0].length; }
      push(t.slice(last));
    }
    return parts.map((x, i) => (i && x.d && parts[i-1].s ? '\n' : '') + x.s).join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  // ---- Your Greeting format (Personal edition only): no blank lines; a *ㅤ* line (italic invisible filler) where a blank line was; pictures straight after the text and the text straight after the picture.
  // A dialogue line stays directly above the narration line that follows it. Only layout changes: not one word of the Greeting is touched, and the character count (which leaves this layout out) is unchanged.
  const GREET_FMT = false;   // build_share.py switches this off: the Shareable edition does not have it
  const GREET_SPACER = '*\u3164*';
  const greetFmtDefault = () => { try { return localStorage.getItem('jbs.greetFmt') === '1'; } catch { return false; } };
  const greetFmtOn = v => !!(GREET_FMT && v && v.greetFmt && !(typeof IS_SHARE !== 'undefined' && IS_SHARE));
  const greetFmtAvail = () => !!(GREET_FMT && !(typeof IS_SHARE !== 'undefined' && IS_SHARE));
  function compactGreeting(text) {
    const isBound = l => /^[ \t]*!\[[^\]]*\]\([^)\s]*\)[ \t]*$/.test(l) || /^[ \t]*(?:-{3,}|\*{3,})[ \t]*$/.test(l);
    const out = []; let gap = false;
    for (const raw of String(text || '').replace(/\r/g, '').split('\n')) {
      const l = raw.replace(/[ \t]+$/, '');
      if (!l.trim()) { gap = true; continue; }
      if (isBound(l)) { out.push(/^[ \t]*(?:-{3,}|\*{3,})[ \t]*$/.test(l) ? '***' : l.trim()); gap = false; continue; }   // the --- line between passages becomes ***: --- makes JuicyChat shrink the pictures
      if (gap && out.length && !isBound(out[out.length - 1])) out.push(GREET_SPACER);
      gap = false; out.push(l);
    }
    return out.join('\n');
  }
  // Break long narration into short lines like yours: a narration line of more than 3 sentences or about 250 characters is split at sentence ends into even blocks (at most 3 sentences each);
  // each block becomes its own line, with a spacer between. A line already within that (like the lines you broke yourself) is left exactly as it is. A dialogue's own narration line keeps its first block attached to the quote.
  const greetBreakDefault = () => { try { return localStorage.getItem('jbs.greetBreak') !== '0'; } catch { return true; } };
  const BRK_MAX_S = 3, BRK_MAX_C = 250, ABBR = /(?:\b(?:Mr|Mrs|Ms|Dr|St|Jr|Sr|Mt|Prof|Capt|Lt|Col|Gen|Sgt|vs|etc|No)|\b[A-Z])\.$/;
  function splitSentences(s) {
    const raw = String(s).trim().split(/(?<=[.!?\u2026]["'\u201d\u2019)\]]*)\s+(?=["'\u201c\u2018(\[]?[A-Z0-9])/), out = [];
    for (const x of raw) { if (out.length && ABBR.test(out[out.length - 1])) out[out.length - 1] += ' ' + x; else out.push(x); }
    return out.filter(Boolean);
  }
  function breakNarration(inner) {
    const ss = splitSentences(inner), total = ss.reduce((a, x) => a + x.length, 0) + Math.max(0, ss.length - 1);
    const k = Math.max(Math.ceil(ss.length / BRK_MAX_S), Math.ceil(total / BRK_MAX_C));
    if (ss.length < 2 || k < 2) return [inner.trim()];
    const blocks = Array.from({length: k}, () => []); let before = 0;
    for (const x of ss) { blocks[Math.min(k - 1, Math.floor((before + x.length / 2) / total * k))].push(x); before += x.length + 1; }
    return blocks.filter(b => b.length).map(b => b.join(' '));
  }
  function breakGreeting(text) {
    const out = [];
    for (const raw of String(text || '').split('\n')) {
      const l = raw.trim();
      if (/^\*[^*].*\*$/.test(l) && l.replace(/^\*|\*$/g, '').trim() !== '\u3164') {
        const bl = breakNarration(l.replace(/^\*|\*$/g, ''));
        bl.forEach((b, i) => { if (i) out.push(''); out.push('*' + b + '*'); });
      } else out.push(raw);
    }
    return out.join('\n');
  }
  const greetFmtLabel = v => greetFmtAvail() ? `<label class="bb-check bb-greetfmt"><input type="checkbox" data-k="greetFmt" ${v.greetFmt ? 'checked' : ''}> Your Greeting format: no blank lines, a *ㅤ* line between the narration blocks, pictures straight after the text (layout only; the words and the character count are not changed)</label>${v.greetFmt ? `<label class="bb-check bb-greetfmt bb-greetbrk"><input type="checkbox" data-k="greetBreak" ${v.greetBreak !== false ? 'checked' : ''}> Break long narration into short lines (up to 3 sentences each, split where a sentence ends; lines you already broke stay as they are)</label>` : ''}` : '';
  function paragraphs(v) { return v.greet.map(p => v.autoFormat ? autoFormat(p || '') : (p || '').trim()); }
  function tagList(spec, v) {
    const active = eventActiveFor(v);
    const m = slotTags(spec.tags.mandatory.filter(t => active || !isEventTag(t)), v === B.v ? eventTagName() : '');
    if (v.archetype) m.push(v.archetype === 'Mafia' ? 'Mafia/Gang' : v.archetype);                       // the one archetype is always one of the tags
    if (spec.tags.wifeRule && v.wife) m.push('Wife');
    const evn = v === B.v ? eventTagName() : '';
    const all = [...new Set([...m, ...((evn || !active) ? (v.tags || []).filter(t => !isEventTag(t)) : v.tags)])];
    return spec.tags.total ? all.slice(0, Math.max(spec.tags.total, m.length)) : all;   // mandatory tags and the archetype first, then the rest up to the template's total
  }

  // ---------------------------------------------------------------- Futa bots and their female version
  const isFuta = spec => !!spec && /\bfuta(nari)?\b/i.test(spec.name || '');
  function variantOf(spec, v) { return isFuta(spec) ? 'futa' : v?.botVariant === 'female' ? 'female' : ''; }
  function variantSpec(spec, variant) {
    return variant ? {...spec, introduction: {...spec.introduction, prefix: Identity.PREFIX[variant]}} : spec;
  }
  function normalizeIdentity(spec, v) {
    const variant = variantOf(spec, v); if (!variant) return;
    v.botVariant = variant;
    v.header.scene = Identity.sceneName(v.header.scene, variant);
    v.intro = Identity.introduction(v.intro, variant);
    if (typeof v.over?.introduction === 'string') v.over.introduction = Identity.introduction(v.over.introduction, variant);
  }
  function plainVariant(v) {
    const out = clone(v); delete out.femaleVersion; delete out.pairedOrigin; delete out.activeVariant;
    return out;
  }
  function variantHash(v) {
    const pv = plainVariant(v); delete pv.policy; delete pv.policyAuto; delete pv.policyKey; delete pv.policyTrim; delete pv.policyShort;      // the PolicyWeights copy follows the card; it is not an edit
    const text = JSON.stringify(pv); let hash = 2166136261;
    for (let i = 0; i < text.length; i++) hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return (hash >>> 0).toString(16);
  }
  function rememberActive() {
    if (!B.pair) return;
    if (B.variant === 'main' && B.pair.main.v !== B.v) B.pair.female = null; // new source or Clear
    B.pair[B.variant] = {...B.pair[B.variant], spec: B.spec, v: B.v};
  }
  function saveValues() {
    normalizeIdentity(B.spec, B.v); rememberActive();
    const values = plainVariant(B.v);
    if (B.pair && B.variant === 'female') values.pairedOrigin = {templateId: B.pair.main.spec.id, values: plainVariant(B.pair.main.v)};
    else if (B.pair?.female) values.femaleVersion = {templateId: B.pair.female.spec.id, values: plainVariant(B.pair.female.v), sourceHash: B.pair.female.sourceHash, baselineHash: B.pair.female.baselineHash};
    return values;
  }
  function renderVariant() {
    const host = q('bb-variant'); if (!host) return;
    host.style.display = B.pair ? '' : 'none';
    if (!B.pair) { host.innerHTML = ''; return; }
    const female = B.variant === 'female', available = !!femaleSpecFor(B.pair.main.spec);
    host.innerHTML = `<span class="bb-var-label">Bot version</span><div class="bb-var-tabs" role="tablist" aria-label="Bot version">
      <button type="button" role="tab" aria-selected="${!female}" aria-controls="bb-form" class="${female ? '' : 'on'}" data-var="main">Futa Bot</button>
      <button type="button" role="tab" aria-selected="${female}" aria-controls="bb-form" class="${female ? 'on' : ''}" data-var="female" ${available ? '' : 'disabled'}>Female version</button></div>
      <p class="micro">${available ? `Editing the <b>${female ? 'Female Bot' : 'Futa Bot'}</b>. Fields, checks, copies and saves use this version. Your edits are kept separately.` : 'Add a matching non-Futa template to enable the Female version.'}</p>`;
    host.querySelectorAll('[data-var]').forEach(button => button.onclick = () => switchVariant(button.dataset.var));
    host.querySelector('.bb-var-tabs').onkeydown = ev => {
      if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(ev.key) || !available) return;
      ev.preventDefault(); const next = ev.key === 'Home' ? 'main' : ev.key === 'End' ? 'female' : female ? 'main' : 'female';
      switchVariant(next); host.querySelector(`[data-var="${next}"]`)?.focus();
    };
  }
  function switchVariant(next) {
    if (!B.pair || !['main', 'female'].includes(next) || next === B.variant) return;
    save(); rememberActive();
    if (next === 'female') {
      const main = B.pair.main, old = B.pair.female, sourceHash = variantHash(main.v);
      // Refresh a derived version only while it is untouched. Never throw away female edits.
      if (!old || (old.sourceHash !== sourceHash && old.baselineHash === variantHash(old.v))) {
        let generated; try { generated = buildFemale(main.spec, main.v); } catch (err) { console.error(err); toast('Could not create the Female version: ' + err.message, true); return; }
        if (!generated) return toast('Add a matching non-Futa template first.', true);
        B.pair.female = {...generated, sourceHash, baselineHash: variantHash(generated.v)};
      }
    }
    const active = B.pair[next]; B.variant = next; B.spec = active.spec; B.v = active.v;
    normalizeIdentity(B.spec, B.v); q('bb-template').value = B.spec.id;
    build(); save(); if (window.__bbTplInfo) window.__bbTplInfo();
  }
  function futaLead(v) {
    const first = String((v.names || {})[1] || '').trim().split(/\s+/)[0] || '[Character First Name]';
    return '```\nPlease answer the following in your first message:\nGender:\nPronouns:\nOnce you answer this, ' + first + ' will address you correctly.\n```\n***\n\n';
  }
  // what describes futa anatomy (a sentence or a keyword containing any of these is left out of the female version)
  const FUTA_RE = /\b(futa\w*|futanari|cock\w*|dick\w*|penis\w*|shaft\w*|balls|testic\w*|scrot\w*|erection\w*|hard-?ons?|girl-?(?:cock|dick)\w*|pre-?cum\w*|foreskin\w*|glans|bulg\w*|throbb\w*|cum\w*|precome)\b/i;
  function deFutaProse(text) {
    return String(text || '').replace(/Female\s+Futa(nari)?/gi, 'Female').split('\n').map(line => {
      const m = line.match(/^(\s*)(\*|["“])?([\s\S]*?)(\*|["”])?(\s*)$/), open = m[2] || '', close = m[4] || '', inner = m[3];
      if (!FUTA_RE.test(inner)) return line;
      const kept = inner.split(/(?<=[.!?…])\s+/).filter(x => !FUTA_RE.test(x)).join(' ').trim();
      return kept ? `${m[1]}${open}${kept}${close}${m[5]}` : null;
    }).filter(l => l !== null).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  const deFutaList = t => String(t || '').split(/,\s*/).filter(x => x.trim() && !FUTA_RE.test(x)).join(', ');
  // in a Greeting, a removed narration line that followed dialogue leaves a short neutral beat, so every quote keeps its cue
  const BEATS = ['She lets the words hang there for a moment.', 'She watches your face, waiting.', 'She holds your gaze a beat longer than she means to.',
    'She tucks a loose strand of hair behind her ear.', 'She glances away, then back at you.', 'Her voice softens on the last word.', 'She leaves the rest unsaid.'];
  function deFutaGreeting(text, seed = 0) {
    const out = [], lines = String(text || '').replace(/Female\s+Futa(nari)?/gi, 'Female').split('\n'); let n = seed;
    for (const line of lines) {
      const kept = deFutaProse(line), prev = out.length ? out[out.length - 1].trim() : '';
      if (kept) { out.push(kept); continue; }
      if (/^["“]/.test(prev)) out.push(`*${BEATS[n++ % BEATS.length]}*`);       // the quote above keeps a narration line under it
    }
    return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
  }
  // the regular template that matches a Futa one: "Gemini Template Futa 8K" -> "Gemini Template 8K"; otherwise any 8K that isn't Futa or NTR
  function femaleSpecFor(spec) {
    if (!isFuta(spec)) return null; const norm = n => String(n || '').toLowerCase().replace(/\bfuta(nari)?\b/g, '').replace(/\s+/g, ' ').trim();
    const ok = t => t && !t.error && t.id !== spec.id && !isFuta(t);
    return B.templates.find(t => ok(t) && !t.unlisted && norm(t.name) === norm(spec.name)) || B.templates.find(t => ok(t) && !t.unlisted && /\b8k\b/i.test(t.name) && !/ntr/i.test(t.name)) || B.templates.find(t => ok(t) && norm(t.name) === norm(spec.name)) || null;
  }
  function femaleCard(card) {
    const clean = x => typeof x === 'string' ? deFutaProse(x) : Array.isArray(x) ? x.map(clean) : x && typeof x === 'object' ? Object.fromEntries(Object.entries(x).map(([k, v]) => [k, clean(v)])) : x;
    const out = clean(card); out.id = card.id; out.futa = false; out.sceneName = Identity.stripSuffix(card.sceneName);
    out.tags = (card.tags || []).filter(t => !FUTA_RE.test(t));
    if (out.fields) { out.fields['Primary Character Futanari'] = 'No'; delete out.fields['Futanari Marker']; out.fields['Scene Name'] = out.sceneName; }
    return out;
  }
  // the female version: same Introduction and Greeting without futa wording; Personality and Scenario in the regular template's boxes
  function buildFemale(sourceSpec = B.spec, sourceV = B.v) {
    const baseSpec = femaleSpecFor(sourceSpec); if (!baseSpec) return null;
    const fs = variantSpec(baseSpec, 'female');
    const card0 = (typeof currentWeekAll === 'function' ? currentWeekAll() : []).find(x => x.id === sourceV.sourceId) || null;
    const cleanAny = x => typeof x === 'string' ? deFutaProse(x) : Array.isArray(x) ? x.map(cleanAny).filter(y => !(typeof y === 'string' && FUTA_RE.test(y))) : x && typeof x === 'object' ? Object.fromEntries(Object.entries(x).map(([k, y]) => [k, cleanAny(y)])) : x;
    const card = card0 ? {...cleanAny(card0), id: card0.id, sceneName: Identity.stripSuffix(card0.sceneName), futa: false, tags: (card0.tags || []).filter(t => !FUTA_RE.test(t))} : null;
    const v2 = card ? prefill(fs, card) : blank(fs); v2.touched = {};
    v2.botVariant = 'female';
    Object.assign(v2, {pov: sourceV.pov, sourceId: sourceV.sourceId, include3: sourceV.include3, names: {...sourceV.names}, header: {...sourceV.header}});
    normalizeIdentity(fs, v2);
    if ((fs.tags.archetypes || []).includes(sourceV.archetype)) v2.archetype = sourceV.archetype;
    // the Introduction's leading [tags]: the series tag stays, a futa tag ("[ANY POV | FUTA]") is replaced by the regular template's own prefix
    let intro = String(sourceV.intro || '').trim(); const tagRun = (intro.match(/^((?:\[[^\]]*\]\s*)+)/) || [''])[0];
    const tags = (tagRun.match(/\[[^\]]*\]/g) || []).filter(t => !FUTA_RE.test(t)); intro = intro.slice(tagRun.length).trim();
    const fsPre = (fs.introduction.prefix || '').trim();
    v2.intro = htmlIntro(sourceV.intro) ? String(sourceV.intro).trim() : [...tags, ...(fsPre && !tags.includes(fsPre) ? [fsPre] : []), deFutaProse(intro)].filter(Boolean).join(' ').trim(); v2.touched.intro = true;
    const g = sourceV.greet.map((p, i) => deFutaGreeting(p, i * 2)), n = fs.greeting.count || g.length;
    v2.greet = Array.from({length: n}, (_, i) => g.length === n ? g[i] : g.slice(Math.floor(i * g.length / n), Math.floor((i + 1) * g.length / n)).join('\n\n') || '');
    v2.greet.forEach((_, i) => { v2.touched['g' + i] = true; });
    v2.img = {appearance: deFutaList(sourceV.img.appearance), clothing: deFutaList(sourceV.img.clothing), action: deFutaList(sourceV.img.action)};
    v2.scenes = (sourceV.scenes || []).map(x => ({...x, setting: deFutaProse(x.setting), action: deFutaProse(x.action)}));
    // boxes matched by meaning: the regular box takes the text of the Futa box whose name shares the most words with it
    const STOP = new Set('and or of the a an to in on at for with any if is are her his their other plus incl including'.split(' '));
    const words = t => new Set(String(t || '').toLowerCase().split(/[^a-z]+/).filter(w => w.length > 2 && !STOP.has(w)));
    const boxesOf = sp => ['personality', 'scenario'].flatMap(sec => sp[sec].lines.flatMap(l => l.segs.filter(x => x.t === 'ph').map(x => ({sec, key: x.key, label: x.label}))));
    const src = boxesOf(sourceSpec).filter(b => (sourceV.f[b.key] || '').trim()), used = new Set();
    for (const d of boxesOf(fs)) {
      if (/^gender$/i.test(d.label.trim())) { v2.f[d.key] = 'Female'; v2.touched[d.key] = true; continue; }
      if (/^pronouns?$/i.test(d.label.trim())) { v2.f[d.key] = 'she/her'; v2.touched[d.key] = true; continue; }
      const dw = words(d.label); let best = null, top = 0;
      for (const b of src) { if (b.sec !== d.sec || used.has(b.key)) continue; const bw = words(b.label); let n2 = 0; for (const w of dw) if (bw.has(w)) n2++; const sc = n2 / Math.max(1, Math.min(dw.size, bw.size)); if (sc > top) { top = sc; best = b; } }
      if (best && top >= 0.34) { const t = deFutaProse(sourceV.f[best.key]); if (t) { v2.f[d.key] = t; v2.touched[d.key] = true; used.add(best.key); } }
    }
    // the Futa bot's own traits that no regular box matched by name (core concept, dominance, care...) go into the regular
    // template's trait and behaviour boxes, so the female version keeps the same character
    const ANAT = /anatom|genital|nude|breast|chest|nipple|areola|crotch/i;
    const spare = src.filter(b => b.sec === 'personality' && !used.has(b.key) && !ANAT.test(b.label) && deFutaProse(sourceV.f[b.key]));
    for (const d of boxesOf(fs).filter(d => d.sec === 'personality' && !(v2.f[d.key] || '').trim() && /trait|personality|behavio|quirk|habit|motivat|reaction|flirt|care|tease|defian|dominan|possess|core/i.test(d.label))) {
      const b = spare.shift(); if (!b) break; v2.f[d.key] = deFutaProse(sourceV.f[b.key]); v2.touched[d.key] = true; used.add(b.key);
    }
    v2.tags = (sourceV.tags || []).filter(t => !FUTA_RE.test(t) && (fs.tags.approved || []).includes(t));
    autoComplete(fs, v2, card);
    // boxes nothing could fill: a plain default instead of leaving them empty
    for (const d of boxesOf(fs)) if (!(v2.f[d.key] || '').trim()) {
      let val = '';
      if (/^race$|species/i.test(d.label.trim())) val = (card && (card.species || (card.fields || {}).Species)) || 'Human';
      else if (/genital|anatomy/i.test(d.label)) val = 'Natural female anatomy, neatly groomed';
      if (val) { v2.f[d.key] = val; v2.touched[d.key] = true; if (v2.auto) delete v2.auto[d.key]; }   // set, so the length fitting keeps it
    }
    fitAll(fs, v2);                                             // fills only what's still empty, and fits the limits
    // the Introduction stays the Futa one without its futa sentences; if that leaves it short, it's topped up from The Setup
    const IL = fs.introduction.limit;
    if (IL && !htmlIntro(v2.intro) && v2.intro.length < IL.min && card) {
      const pool = String(toYou((card.fields || {})['The Setup'] || '')).split(/(?<=[.!?])\s+/).map(x => x.trim()).filter(x => x && !v2.intro.includes(x) && !FUTA_RE.test(x));
      for (const x of pool) { if (v2.intro.length >= IL.min) break; if ((v2.intro + ' ' + x).length <= IL.max) v2.intro = `${v2.intro} ${x}`.trim(); }
    }
    // a last safety pass: Auto-complete knows a Friday card is a futa card and can write futa text into boxes (Race, anatomy)
    for (const k of Object.keys(v2.f || {})) if (FUTA_RE.test(v2.f[k] || '')) { v2.f[k] = deFutaProse(v2.f[k]); v2.touched[k] = true; if (v2.auto) delete v2.auto[k]; }
    for (const k of ['appearance', 'clothing', 'action']) v2.img[k] = deFutaList(v2.img[k]); v2.tags = (v2.tags || []).filter(t => !FUTA_RE.test(t));
    for (const d of boxesOf(fs)) if (!(v2.f[d.key] || '').trim()) {                // whatever that emptied gets a plain default
      const val = /^race$|species/i.test(d.label.trim()) ? ((card && (card.species || (card.fields || {}).Species)) || 'Human') : /genital|anatomy/i.test(d.label) ? 'Natural female anatomy, neatly groomed' : '';
      if (val) { v2.f[d.key] = val; v2.touched[d.key] = true; if (v2.auto) delete v2.auto[d.key]; }
    }
    // the cleanup shortened things, so fit the limits again (only boxes the app filled itself grow), and make sure nothing futa came back
    fitAll(fs, v2);
    for (const k of Object.keys(v2.f || {})) if (FUTA_RE.test(v2.f[k] || '')) { v2.f[k] = deFutaProse(v2.f[k]) || v2.f[k].replace(FUTA_RE, '').trim(); v2.touched[k] = true; if (v2.auto) delete v2.auto[k]; }
    // the Greeting: if removing futa sentences left it short, each shortened paragraph is topped up from the (clean) card's own story
    const GL = fs.greeting.limit, glen = () => compose(fs, v2).sec.greeting.prose.length;
    if (GL && glen() < GL.min && card) {
      const scratch = prefill(fs, card); scratch.greet = scratch.greet.map(() => ''); autoComplete(fs, scratch, card);
      const pool = scratch.greet.map(p => String(p || '').split('\n').filter(l => /^\s*\*/.test(l) && !FUTA_RE.test(l)));   // narration lines only
      for (let i = 0; i < v2.greet.length && glen() < GL.min; i++) for (const line of (pool[i] || [])) {
        if (glen() >= GL.min) break; if (v2.greet[i].includes(line)) continue;
        if (glen() + line.length + 1 > GL.max) break; v2.greet[i] = `${v2.greet[i]}\n${line}`.trim();
      }
    }
    // still a few characters short: a neutral narration line goes into the shortest paragraph (never repeating within a paragraph)
    const FILL = ['*The quiet stretches between you, comfortable and not quite.*', '*Somewhere outside, a car passes and its headlights sweep the wall.*', '*She shifts her weight, then seems to decide something.*',
      '*The room feels smaller than it did a minute ago.*', '*She studies you as if she is trying to read the answer before you give it.*', '*A clock ticks somewhere behind her, too loud in the pause.*'];
    for (let k = 0; GL && glen() < GL.min && k < 12; k++) {
      const i = v2.greet.reduce((m, p, j) => p.length < v2.greet[m].length ? j : m, 0), line = FILL.find(f => !v2.greet[i].includes(f));
      if (!line || glen() + line.length + 1 > GL.max) break; v2.greet[i] = `${v2.greet[i]}\n${line}`.trim();
    }
    // last: every quote in the Greeting keeps a narration line directly under it (your template's format rule)
    let beat = 3; v2.greet = v2.greet.map(p => { const L = String(p || '').split('\n'), out = [];
      L.forEach((l, i) => { out.push(l); const nx = (L.slice(i + 1).find(x => x.trim()) || '').trim(); if (/^\s*["“]/.test(l) && !/^\*/.test(nx)) out.push(`*${BEATS[beat++ % BEATS.length]}*`); });
      return out.join('\n'); });
    const c = compose(fs, v2);
    return {spec: fs, v: v2, c, res: check(fs, v2, c)};
  }

  // Name 2 in a template is the card's Third Party (the Antagonist on an ANTI-NTR card). Text that is already in the builder (a saved bot, a loaded draft,
  // AI-written or hand-edited sections) can still carry a raw [Name2]: give Name 2 its name from the card, then put it into every stored text.
  const N2_RE = /\[Name ?2\]|\{\{Name ?2\}\}/g;
  function cardFor(v) {
    const id = (v && v.sourceId) || (typeof q === 'function' && q('bb-from') && q('bb-from').value) || '';
    if (!id) return null;
    const all = typeof currentWeekAll === 'function' ? currentWeekAll() : [];
    const arch = (typeof state !== 'undefined' && state && state.cardArchive) || [];
    return all.find(x => x.id === id) || arch.find(x => x.id === id) || null;
  }
  function settleName2(spec, v) {
    if (!v || !v.names) return;
    if (!v.names[2] || !String(v.names[2]).trim()) {
      const sc = cardFor(v);
      if (sc) {
        const cast = (sc.cast || []).filter(c => c && c.name), others = cast.filter(c => c.role !== 'Primary');
        const ant = others.find(c => c.role === 'Antagonist' || c.role === 'Third Party');
        const nm = (ant && ant.name) || (window.BBAuto && window.BBAuto.thirdName && window.BBAuto.thirdName(sc.fields || {}, v.names[1] || sc.primaryCharacter || '')) || '';
        if (nm) v.names[2] = nm;
      }
    }
    const n2 = v.names[2] && String(v.names[2]).trim(); if (!n2) return;
    const fill = x => typeof x === 'string' ? x.replace(N2_RE, n2) : x;
    for (const k of Object.keys(v.over || {})) v.over[k] = fill(v.over[k]);
    for (const k of Object.keys(v.f || {})) v.f[k] = fill(v.f[k]);
    if (typeof v.intro === 'string') v.intro = fill(v.intro);
    if (Array.isArray(v.greet)) v.greet = v.greet.map(fill);
  }

  // PolicyWeights on the linked scenario card go into the Scenario of the bot built here too (the AI writer already does this). A copy that came from the AI writer is left alone;
  // a template with its own PolicyWeights section keeps its own. The copy follows the card until the bot is cut to fit (then it stays as cut, until the card changes).
  // A template's own PolicyWeights line: every number at 0.8 or less and the guardrail line in (see PolicyWeights.settleOwn). The lane rules come from the linked card.
  function settleOwnPolicy(body, v) {
    try {
      const PWX = window.PolicyWeights; if (!PWX || !PWX.enabled || !PWX.settleOwn || !PWX.has(body)) return body;
      const sid = v && (v.sourceId || (typeof B !== 'undefined' && B.pair && B.pair.main && B.pair.main.v && B.pair.main.v.sourceId)) || '';
      const sc = sid ? cardFor({sourceId: sid}) : null;
      return PWX.settleOwn(body, v && v.names && v.names[1], sc ? PWX.lockFor(sc).rules : []);
    } catch { return body; }
  }
  function syncPolicy(spec, v) {
    try {
      const PWX = window.PolicyWeights; if (!PWX || !PWX.enabled || !v || !spec || typeof B === 'undefined' || v !== B.v) return;
      const usable = pol => !!(pol && pol.on && (PWX.parseWeights(pol.weights).items.length || String(pol.tracker || '').trim()));
      if (v.policy && !v.policyAuto && usable(v.policy) && v.botVariant !== 'female') return;      // a block the AI writer put here is kept; an empty or switched-off one gives way to the card's
      const owns = !!(spec.scenario && (spec.scenario.lines || []).some(l => (l.segs || []).some(x => x.t === 'lit' && /PolicyWeights\s*\{/.test(String(x.v || '')))));
      const sid = v.sourceId || (B.pair && B.pair.main && B.pair.main.v && B.pair.main.v.sourceId) || '';      // the Female version belongs to the same card as the Futa one
      const sc = sid ? cardFor({sourceId: sid}) : null;
      const eff = sc && !owns ? PWX.effective(sc, typeof state !== 'undefined' ? state : null) : null;
      if (!eff) { if (v.policyAuto || (v.policy && !usable(v.policy))) { delete v.policy; delete v.policyAuto; delete v.policyKey; delete v.policyTrim; delete v.policyShort; } return; }
      const key = JSON.stringify(eff);
      if (v.policyKey !== key || !v.policy) { v.policy = {...JSON.parse(key), compact: true}; v.policyAuto = true; v.policyKey = key; delete v.policyTrim; delete v.policyShort; }
    } catch { /* PolicyWeights are optional: the bot still builds without them */ }
  }
  function compose(spec, v) {
    if (v === B.v) reconcileEventSlot(spec, v);
    syncPolicy(spec, v);
    normalizeIdentity(spec, v);
    if (spec.rules && spec.rules.hasName2) settleName2(spec, v);
    const sec = {};
    const miss = {personality: [], scenario: []};
    const h = spec.header.map(x => {
      const val = x.key === 'scene' ? v.header.scene : x.key === 'name' ? v.names[1] : v.header.age;
      return x.nextLine ? `${x.label}:\n${val}` : `${x.label}: ${val}`;
    });
    sec.header = {body: h.join(spec.header.some(x => x.nextLine) ? '\n\n' : '\n'), bare: true};
    sec.introduction = {body: v.intro.trim()};
    sec.personality = {body: renderLines(spec.personality.lines, v, miss.personality)};
    sec.scenario = {body: renderLines(spec.scenario.lines, v, miss.scenario)};
    if (v.policy && window.PolicyWeights && window.PolicyWeights.enabled) sec.scenario.body = window.PolicyWeights.insert(sec.scenario.body, v.policy, v.names && v.names[1]);   // PolicyWeights: before the length fit, so the fit counts them
    sec.scenario.body = settleOwnPolicy(sec.scenario.body, v);   // a template's own PolicyWeights line: 0.8 cap and guardrails, before the length fit too
    for (const k of ['personality', 'scenario']) {
      const lim = spec[k].limit;
      if (false && v.fit?.[k] && lim && sec[k].body.length > withTol(lim).max) { const r = compressFixed(sec[k].body, lim.max - 25, v); sec[k].body = r.text; sec[k].shortened = r.cut; }
    }
    const ps = paragraphs(v);
    const lead = isFuta(spec) ? futaLead(v) : '';                     // Futa bots ask the reader's gender and pronouns first (not counted)
    sec.greeting = {body: lead + ps.map((p, i) => `${p}\n\n![](image${i + 1})`).join(spec.greeting.separator ? '\n\n---\n\n' : '\n\n'), prose: ps.join('\n\n'), lead};
    sec.image = {body: [`Appearance:\n${[spec.image.quality, v.img.appearance.trim()].filter(Boolean).join(', ')}`,
      `Clothing and Accessories:\n${v.img.clothing.trim()}`, `Action & Background:\n${v.img.action.trim()}`,
      `Negative Prompt:\n${spec.image.negative}`].join('\n\n'), title: 'Image Generation'};
    sec.tags = {body: tagList(spec, v).join('\n')};
    sec.scene = {body: v.scenes.map((s, i) => `Scene ${i + 1}: ${s.name.trim()}\nShot Angle: ${s.shot.trim()}\nSetting: ${s.setting.trim()}\nAction: ${s.action.trim()}`).join('\n\n')};
    for (const k of Object.keys(v.over || {})) if (sec[k] && typeof v.over[k] === 'string') { if (/\[START INSTRUCTIONS/.test(v.over[k])) v.over[k] = v.over[k].replace(/[ \t]*\[START INSTRUCTIONS[^\]]*\][\s\S]*?\[END INSTRUCTIONS[^\]]*\][ \t]*\r?\n?/g, '').replace(/^[ \t]*\[(?:START|END) INSTRUCTIONS[^\]]*\][ \t]*\r?\n?/gm, '').replace(/\n{3,}/g, '\n\n').trim();   /* the template's writer-only regions are never part of the bot */
      if (k === 'personality' || k === 'scenario') v.over[k] = v.over[k].replace(/^\s*(?:Personality|Scenario)\s*:[ \t]*(?:\r?\n|$)\s*/i, '');   /* the copy adds the section's own heading: a finished block that starts with it must not carry a second one */
      sec[k].body = v.names && v.names[2] && /personality|scenario/.test(k) ? v.over[k].replace(/\[Name ?2\]/g, v.names[2]) : v.over[k]; sec[k].overridden = true; if (k === 'greeting') sec[k].prose = v.over[k].replace(/^[ \t]*!\[[^\]]*\]\([^)\s]*\)[ \t]*$/gm, '').replace(/^---$/gm, '').replace(/^\*\*\*$/gm, '').replace(/^[ \t]*\*\u3164\*[ \t]*$/gm, ''); }
    if (v.policy && sec.scenario && sec.scenario.overridden && window.PolicyWeights && window.PolicyWeights.enabled) sec.scenario.body = window.PolicyWeights.insert(sec.scenario.body, v.policy, v.names && v.names[1]);   // a hand-edited or whole-written Scenario gets them too (never twice)
    if (sec.scenario) sec.scenario.body = settleOwnPolicy(sec.scenario.body, v);   // the same for a Scenario that was edited by hand or written whole
    if (spec.rules && spec.rules.hasName2 && v.names[2]) for (const k of ['personality', 'scenario']) if (sec[k]) sec[k].body = sec[k].body.replace(N2_RE, v.names[2]);
    if (window.Dialogue?.personalityText) sec.personality.body = window.Dialogue.personalityText(sec.personality.body);
    if (greetFmtOn(v) && sec.greeting) { const b = sec.greeting.body, ld = sec.greeting.lead && b.startsWith(sec.greeting.lead) ? sec.greeting.lead : ''; sec.greeting.body = ld + compactGreeting(v.greetBreak !== false ? breakGreeting(b.slice(ld.length)) : b.slice(ld.length)); }   // Your Greeting format: layout only, applied to what you copy and see
    if (sec.greeting && v.imgUrls && v.imgUrls.some(Boolean)) sec.greeting.body = sec.greeting.body.replace(/^([ \t]*)!\[\]\(image(\d+)\)/gm, (m, ind, n) => v.imgUrls[n - 1] ? `${ind}![](${v.imgUrls[n - 1]})` : m);   // pictures uploaded to your image site: their links replace the markers
    const full = spec.order.filter(k => sec[k]).map(k => sec[k].bare ? sec[k].body : `${sec[k].title || SEC_TITLE[k]}:\n${sec[k].body}`).join('\n\n') + '\n';
    return {sec, full, miss};
  }

  // Shorten the template's own rule text (not your fields) until it fits:
  // repeated sentences go first, then each rule keeps at least its first sentence.
  // The protected User Agency rules and anything containing your text are never touched.
  function compressFixed(text, target, v) {
    const mine = Object.values(v.f || {}).map(x => String(x || '').trim()).filter(x => x.length > 12);
    const paras = text.split(/\n\s*\n/);
    const hasMine = t => mine.some(m => t.includes(m) || (m.length > 40 && t.includes(m.slice(0, 40))));
    const locked = p => /Never narrate or decide \{\{user\}\}|has absolute agency|USER AGENCY HARD LOCK|^\s*\[CANON LOCK\]|PolicyWeights\s*\{|^\s*\[Tracker|^\s*\[POLICYWEIGHT GUARDRAILS\]/.test(p) || p.trim().length < 90 || /\n/.test(p.trim()) && p.trim().split('\n').every(l => l.trim().length < 200) || /^[^\n]*\{\s*$/.test(p.trim()) || /^\}\s*$/.test(p.trim());
    const split = p => (p.replace(/(^|\n)(\d+)\.(?=\s)/g, '$1$2\u0001').match(/[^.!?]+[.!?]+["”’)\]]*\s*|[^.!?]+$/g) || [p]).map(x => x.replace(/\u0001/g, '.'));   // a list number ("1.") is not the end of a sentence
    let cur = paras.map(p => ({p, s: locked(p) ? null : split(p)}));
    const len = () => cur.map(x => x.s ? x.s.join('').trim() : x.p).join('\n\n').length;
    const before = len(); const seen = new Set();
    for (const x of cur) if (x.s) x.s = x.s.filter(t => { const k = t.trim().toLowerCase(); if (seen.has(k) && x.s.length > 1) return false; seen.add(k); return true; });
    let guard = 0, total = len();
    for (const x of cur) if (x.s) { x.mine = x.s.map(hasMine); x.len = x.s.join('').length; }
    while (total > target && guard++ < 2000) {
      const cand = cur.filter(x => x.s && x.s.filter((t, i) => !x.mine[i]).length > (x.mine.some(Boolean) ? 0 : 1)).sort((a, b) => b.len - a.len)[0];
      if (!cand) break;
      let at = -1; for (let i = cand.s.length - 1; i >= 0; i--) if (!cand.mine[i] && !(i === 0 && !cand.mine.some(Boolean))) { at = i; break; }
      if (at < 0) break;
      total -= cand.s[at].length; cand.len -= cand.s[at].length; cand.s.splice(at, 1); cand.mine.splice(at, 1);
    }
    total = len();
    // long "a, b, c, d, or e" lists keep their first two items and the last
    for (const x of cur) { if (total <= target) break; if (x.s) { x.s = x.s.map(t => t.replace(/((?:[^,.]+,){2})(?:[^,.]+,){2,}\s*((?:or|and) [^,.]+[.!?])/g, '$1 $2').replace(/\s+,/g, ',')); total = len(); } }
    // unlabeled explanation paragraphs go last, longest first; every [LABELED] rule survives
    while (total > target && guard++ < 4000) {
      const cand = cur.filter(x => x.s && !x.s.some(hasMine) && !/^\s*\[/.test(x.s[0] || '') && !/^\s*[-*•]/.test(x.s[0] || '')).sort((a, b) => b.s.join('').length - a.s.join('').length)[0];
      if (!cand) break; cur = cur.filter(x => x !== cand); total = len();
    }
    const out = cur.map(x => x.s ? x.s.join('').trim() : x.p).join('\n\n');
    return {text: out, cut: before - out.length};
  }

  // ------------------------------------------------------------------ checks
  const len = s => (s || '').length;
  // copy one section's finished text. The Introduction is copied as the finished HTML when a saved Introduction style (or your edited HTML) is applied
  async function copySection(key) {
    if (!B.spec || !B.v) return false;
    const sec = compose(B.spec, B.v).sec[key]; if (!sec) return false;
    let out = sec.body, asHtml = false;
    if (key === 'introduction' && window.LivePreview && window.LivePreview.finalHtml) { try { const h = window.LivePreview.finalHtml(introPayload(compose(B.spec, B.v))); if (h) { out = h; asHtml = true; } } catch {} }
    if(key==='introduction'&&out.length>15000){toast(`Introduction is ${out.length.toLocaleString()} characters including HTML. JuicyChat allows 15,000.`,true);return false;}
    await window.copyText(out);
    toast(asHtml ? 'Introduction copied as HTML code.' : `${SEC_TITLE[key] || 'Section'} copied.`);
    return true;
  }
  // "View as text / View as HTML" above the Introduction box. HTML view shows the finished HTML (the preview's code) and you can edit it, for example to change the series number.
  // What you change there is kept with this bot as its Introduction HTML: Copy Introduction copies it and the Live preview shows it. The Introduction text itself (the plain text the AI writes, its limit and the full-bot copy) is not touched.
  function syncIvw(fill) {
    const bar = document.querySelector('#bb-form [data-ivw-bar]'); if (!bar) return;
    const ownHtml = htmlIntro(B.v.intro);                                    // the Introduction box already holds HTML: nothing to switch
    bar.hidden = ownHtml; if (ownHtml) B.ivw = 'text';
    const mode = B.ivw === 'html' ? 'html' : 'text', tx = document.querySelector('#bb-form [data-ivw-text]'), hx = document.querySelector('#bb-form [data-ivw-html]'), ta = document.querySelector('#bb-form [data-ihtml]');
    if (!tx || !hx || !ta) return;
    bar.querySelectorAll('[data-ivw]').forEach(b => { const on = b.dataset.ivw === mode; b.classList.toggle('on', on); b.setAttribute('aria-pressed', on ? 'true' : 'false'); });
    tx.hidden = mode === 'html'; hx.hidden = mode !== 'html';
    { let fz = tx.querySelector('[data-ivw-frozen]');            // HTML you edited by hand freezes the preview and Copy: say so where the text is, with a way back
      if (!fz) { fz = document.createElement('div'); fz.className = 'bb-ivw-frozen'; fz.setAttribute('data-ivw-frozen', ''); fz.setAttribute('role', 'note'); fz.innerHTML = '<span><b>The preview and Copy Introduction show HTML you edited by hand,</b> so they do not follow this text (the series number included). Press <b>Rebuild from the text</b> (next to View as HTML) to go back to automatic.</span>'; tx.insertBefore(fz, tx.firstChild); }
      fz.hidden = !B.v.introHtml || ownHtml; const rb0 = bar.parentNode.querySelector('[data-ivw-rebuild]'); if (rb0) rb0.hidden = !B.v.introHtml || ownHtml; }
    if (mode !== 'html') return;
    const note = hx.querySelector('[data-ihtml-note]'), edited = !!B.v.introHtml;
    if (note) note.textContent = edited ? 'You edited this HTML. It no longer follows the Introduction text. Copy Introduction copies it as written. Press "Rebuild from the text" to start again from the text.' : 'This is the finished Introduction as HTML code, as the preview shows it. The series number follows the tag in the Introduction text by itself. If you change anything here, your change is kept and Copy Introduction copies it, but the preview then stops following the text until you press Rebuild from the text.';
    hx.querySelector('[data-ihtml-reset]').style.display = edited ? '' : 'none';
    if ((fill || !edited) && document.activeElement !== ta) {
      let base = ''; try { base = window.LivePreview && window.LivePreview.baseHtml ? window.LivePreview.baseHtml(Object.assign(introPayload(compose(B.spec, B.v)), {html: ''})) : ''; } catch {}
      const val = B.v.introHtml || base; if (ta.value !== val) { ta.value = val; try { grow(ta); } catch {} }
    }
  }
  function wireIvw() {
    const f = document.getElementById('bb-form'); if (!f) return;
    f.querySelectorAll('[data-ivw]').forEach(b => b.onclick = () => { B.ivw = b.dataset.ivw; syncIvw(true); });
    const ta = f.querySelector('[data-ihtml]'); if (!ta) return;
    let tm = null;
    ta.oninput = () => { try { grow(ta); } catch {} B.v.introHtml = ta.value.trim() ? ta.value : ''; clearTimeout(tm); tm = setTimeout(() => { try { window.LivePreview && window.LivePreview.update('introduction', introPayload(compose(B.spec, B.v))); syncIvw(false); save(); } catch {} }, 250); };
    const rs = f.querySelector('[data-ihtml-reset]'); if (rs) rs.onclick = () => { delete B.v.introHtml; syncIvw(true); try { window.LivePreview && window.LivePreview.update('introduction', introPayload(compose(B.spec, B.v))); save(); } catch {} };
    const rb = f.querySelector('[data-ivw-rebuild]'); if (rb) rb.onclick = () => { delete B.v.introHtml; syncIvw(true); try { window.LivePreview && window.LivePreview.update('introduction', introPayload(compose(B.spec, B.v))); save(); } catch {} };
    syncIvw(true);
  }
  // what the Live preview needs to draw (and Copy Introduction needs to build) the styled Introduction
  const introPayload = c => { const sc = B.v.sourceId && typeof currentWeekAll === 'function' ? currentWeekAll().find(x => x.id === B.v.sourceId) : null; return {variant: variantOf(B.spec, B.v) || '', tag: Identity.PREFIX[variantOf(B.spec, B.v)] || '', text: c.sec.introduction.body, name: B.v.names && B.v.names[1], scene: B.v.header && B.v.header.scene, series: sc ? String(sc.series || sc.slot || '') : '', html: B.v.introHtml || ''}; };
  const htmlIntro = t => !!(window.LivePreview && window.LivePreview.hasHtml && window.LivePreview.hasHtml(t));   // the Introduction is the user's own HTML: nothing is added in front of it or changed in it
  const introVis = t => (window.LivePreview && window.LivePreview.visibleText) ? window.LivePreview.visibleText(t) : (t || '');   // HTML in the Introduction box: only the words you can read count
  // every character limit has a 10% allowance each way: inside it the section passes (the AI is still told the template's own range to aim for)
  const LIMIT_TOL = 0.10;
  const withTol = L => L && ({min: Math.floor(L.min * (1 - LIMIT_TOL)), max: Math.ceil(L.max * (1 + LIMIT_TOL))});
  // the PolicyWeights block inside the Scenario (0 when off): it is outside the Scenario's own limit, and counts only in the combined total
  const policyAdd = v => { try { const P = window.PolicyWeights; return v && v.policy && v.policy.on && P && P.enabled && P.blockLength ? P.blockLength(v.policy, v.names && v.names[1]) : 0; } catch { return 0; } };
  function range(out, label, n, lim) {
    if (!lim) return;
    const W = withTol(lim);
    if (n < W.min) out.push(['bad', `${label} is ${n.toLocaleString()} characters. Needs ${lim.min.toLocaleString()}–${lim.max.toLocaleString()} (${(lim.min - n).toLocaleString()} short; ${LIMIT_TOL * 100}% allowance = ${W.min.toLocaleString()}–${W.max.toLocaleString()}).`]);
    else if (n > W.max) out.push(['bad', `${label} is ${n.toLocaleString()} characters. Needs ${lim.min.toLocaleString()}–${lim.max.toLocaleString()} (${(n - lim.max).toLocaleString()} over; ${LIMIT_TOL * 100}% allowance = ${W.min.toLocaleString()}–${W.max.toLocaleString()}).`]);
    else if (n < lim.min || n > lim.max) out.push(['ok', `${label}: ${n.toLocaleString()} characters, inside the ${LIMIT_TOL * 100}% allowance around ${lim.min.toLocaleString()}–${lim.max.toLocaleString()}.`]);
    else out.push(['ok', `${label}: ${n.toLocaleString()} characters (limit ${lim.min.toLocaleString()}–${lim.max.toLocaleString()}).`]);
  }
  function common(out, t, spec) {
    { const cal = window.CalendarNames && window.CalendarNames.problem(t); if (cal) out.push(['bad', `This text ${cal}`]); }
    { const plc = window.PlaceNames && window.PlaceNames.problem(t); if (plc) out.push(['bad', `This text ${plc}`]); }
    if (/high[\s-]?school|\bchildhood\b|\bminor\b|\bteen(ager|age)?\b|\b1[0-7][\s-]?years?[\s-]?old\b/i.test(t)) out.push(['bad', 'Mentions a school, childhood, minor or under-18 age. The templates forbid this.']);
  }
  function check(spec, v, c) {
    const R = spec.rules, S = c.sec, res = {};
    // basics
    let o = res.header = [];
    if (!Identity.stripSuffix(v.header.scene)) o.push(['bad', 'Scene name is empty.']);
    const variant = variantOf(spec, v);
    if (variant && v.header.scene.length > 30) o.push(['bad', 'Scene name must be at most 30 characters, including its version suffix.']);
    { const sc = v.sourceId && typeof currentWeekAll === 'function' ? currentWeekAll().find(x => x.id === v.sourceId) : null, want = cardNtrType(sc), have = templateNtrType(spec);
      if (want && have && want !== have) o.push(['bad', `This is ${/^(?:[EAIOU]|NTR)/.test(NTR_TYPE_NAME[want]) ? 'an' : 'a'} ${NTR_TYPE_NAME[want]} card, but the template is the ${NTR_TYPE_NAME[have]} one. Switch to the ${NTR_TYPE_NAME[want]} template (${(NC0.TEMPLATE_NO || {})[want] || ''}).`]); }
    if (!v.names[1].trim()) o.push(['bad', 'Character name is empty.']);
    const age = parseInt(v.header.age, 10);
    if (!v.header.age.trim()) o.push(['bad', 'Age is empty.']); else if (!(age >= 21)) o.push(['bad', 'Age must be 21 or older.']);
    if (R.hasName2 && !v.names[2].trim()) o.push(['bad', 'Name 2 is empty.']);
    if (v.include3 && !v.names[3].trim()) o.push(['bad', 'Name 3 is switched on but empty.']);
    // introduction
    o = res.introduction = []; const it = introVis(S.introduction.body);
    range(o, 'Introduction', len(it), spec.introduction.limit);
    if(S.introduction.body.length>15000)o.push(['bad',`Introduction HTML is ${S.introduction.body.length.toLocaleString()} characters; JuicyChat allows a maximum of 15,000 including styling.`]);
    if (window.TemplateContract) for (const issue of window.TemplateContract.introductionIssues(spec, it)) o.push(['bad', issue]);
    // an NTR bot (never ANTI-NTR) starts with its topic: [Emotional NTR], [NTR], [Light NTR], [Preventable NTR], [Post-NTR]...
    const srcCard = v.sourceId && typeof currentWeekAll === 'function' ? currentWeekAll().find(x => x.id === v.sourceId) : null, topicPre = !variant && srcCard && window.NtrCanon ? window.NtrCanon.topicTag(srcCard) : '';
    const requiredPrefix = variant ? Identity.PREFIX[variant] : topicPre || spec.introduction.prefix;
    if (requiredPrefix && !htmlIntro(S.introduction.body) && !it.startsWith(requiredPrefix) && (variant || topicPre || !SERIES_PREFIX.some(p => it.startsWith(`[${p}`)))) o.push(['bad', `Must start with ${requiredPrefix}`]);
    if (R.introEnding && it && (!/[.!?]["”’)\]*]*$/.test(it) || /(\.\.\.|…)["”’)\]*]*$/.test(it))) o.push(['bad', 'Must end with a finished sentence (period, ? or !), not "..." or a cut-off line.']);
    if (R.secondPerson && it && !/\byou(r|rs|rself)?\b/i.test(it)) o.push(['bad', 'Must be in second person (you/your).']);
    if (R.noAdultWord && /\badults?\b|21\+/i.test(it)) o.push(['bad', 'Remove "adult" / "21+". The Introduction must not include age reassurance.']);
    common(o, it, spec);
    // personality & scenario
    for (const k of ['personality', 'scenario']) {
      o = res[k] = [];
      // PolicyWeights are hidden steering numbers added to the Scenario: they do not count against the Scenario's own limit (the combined total still counts them)
      { const PWb = window.PolicyWeights, add = (k === 'scenario' && v.policy && v.policy.on && PWb && PWb.blockLength) ? PWb.blockLength(v.policy, v.names && v.names[1]) : 0;
        if (add && spec.scenario.limit) { const n = len(S[k].body), W0 = withTol(spec.scenario.limit);
          if (n - add >= W0.min && n - add <= W0.max) o.push(['ok', `The base characters are still within the accepted range with ${add.toLocaleString()} characters added from the PolicyWeights, bringing it up to ${n.toLocaleString()} characters.`]);
          else if (n >= W0.min && n <= W0.max) o.push(['ok', `The Scenario is ${n.toLocaleString()} characters with the ${add.toLocaleString()} from the PolicyWeights included, inside the accepted range (the text without them is ${(n - add).toLocaleString()}).`]);
          else { range(o, 'Scenario without PolicyWeights', n - add, spec.scenario.limit); o.push(['ok', `PolicyWeights add ${add.toLocaleString()} characters (the Scenario is ${n.toLocaleString()} with them). They count in the combined total, not in the Scenario's own limit.`]); } }
        else range(o, SEC_TITLE[k], len(S[k].body), spec[k].limit); }
      const left = S[k].overridden ? (S[k].body.match(/\[[a-z][^\]\n]*\]/g) || []).length : c.miss[k].length;
      if (left) o.push(['bad', `${left} field${left > 1 ? 's' : ''} still empty${S[k].overridden ? '' : `: ${c.miss[k].slice(0, 4).join(', ')}${left > 4 ? '…' : ''}`}.`]);
      else o.push(['ok', 'All fields filled.']);
      if (S[k].shortened > 0) o.push(['warn', `This is the template's own rule text cut down by ${S[k].shortened.toLocaleString()} characters (rules reduced to their first sentences, User Agency rules untouched). It was NOT written by the AI for this bot. Use Write with AI or Rewrite section so the AI writes the ${SEC_TITLE[k]} from the template's instructions, or untick "Shorten the template's rule text" to keep it word-for-word.`]);
      if (/\[Name[123]?\]/.test(S[k].body)) o.push(['bad', 'A character name is missing (fill the names at the top).']);
      const mine = S[k].overridden ? S[k].body : spec[k].lines.flatMap(l => l.segs).filter(x => x.t === 'ph').map(x => v.f[x.key] || '').join('\n');
      if (R.relationshipSpecific && /\b(spouse|significant other|lover)\b|\bpartner\b(?!\/)/i.test(mine.replace(/Spouse\/Partner/g, ''))) o.push(['warn', 'Say "wife" or "girlfriend" instead of partner/spouse/lover.']);
      common(o, mine, spec);
    }
    if (/Never narrate or decide \{\{user\}\}’s dialogue/.test(spec.scenario.lines.map(l => l.segs.map(s => s.v || '').join('')).join('\n')) &&
        !/Never narrate or decide \{\{user\}\}’s dialogue, thoughts, feelings, reactions, consent, interpretations, or voluntary actions\./.test(S.scenario.body))
      res.scenario.push(['bad', 'The protected User Agency rule was changed. It must stay word-for-word.']);
    // greeting
    o = res.greeting = []; const g = spec.greeting, ps = S.greeting.overridden ? null : paragraphs(v), prose = S.greeting.prose;
    range(o, 'Greeting (without image markers)', len(prose), g.limit);
    if (window.TemplateContract?.greetingIssues) for (const issue of window.TemplateContract.greetingIssues(spec, v)) o.push(['bad', issue]);
    if (window.TemplateContract?.greetingNotes) for (const note of window.TemplateContract.greetingNotes(spec, v)) o.push(['warn', note]);
    // The Setup's concrete details should all be in the Greeting
    if (window.SetupFacts && v.sourceId && typeof currentWeekAll === 'function') { const sc = currentWeekAll().find(x => x.id === v.sourceId), F = (sc && sc.fields) || {};
      const planned = window.GreetingPlan && window.GreetingPlan.forCard(sc, v.greetingPlan);
      const source = planned ? window.GreetingPlan.factInputs(sc, planned) : {setup: F['The Setup'] || F['What happened'] || '', hook: F['User Interaction Hook'] || ''};
      const miss = window.SetupFacts.missing(window.SetupFacts.facts(source.setup, source.hook), prose);
      if (miss.some(f => f.kind === 'name') || miss.length >= 2) o.push(['warn', `The Greeting leaves out ${miss.length} detail${miss.length > 1 ? 's' : ''} from ${planned ? 'your selected Greeting beats' : 'The Setup'}: ${miss.slice(0, 5).map(f => f.text).join(', ')}${miss.length > 5 ? '…' : ''}.`]); }

    if (ps) {
      const empty = ps.filter(p => !p).length;
      if (empty) o.push(['bad', `${empty} of ${g.count} paragraphs are empty.`]);

    }
    const markers = (S.greeting.body.match(/^[ \t]*!\[[^\]]*\]\([^)\s]*\)[ \t]*$/gm) || []).length;
    o.push([markers === g.count ? 'ok' : 'bad', `${markers} image markers (needs exactly ${g.count}).`]);
    if (g.banColonSemi && /[:;]/.test(prose)) o.push(['bad', 'Contains a colon (:) or semicolon (;). The Greeting bans both.']);
    if (g.banEmDash && /—/.test(prose)) o.push(['bad', 'Contains an em dash (—). Use a comma or period.']);
    { const narr = prose.replace(/"[^"\n]*"|“[^”\n]*”/g, '');          // narration only: the one line of dialogue may say {{user}}
      if (g.banUserToken && /\{\{user\}\}/.test(narr)) o.push(['bad', 'The narration uses {{user}}. Write "you" in the Greeting\'s narration instead.']); }
    // Dialogue slots and formatting are checked against the selected template
    // by TemplateContract above. Do not add generic dialogue requirements here.
    if (R.cannedBanter && /you owe me|that'?ll cost you|put it on (?:your|my) tab|charging you|consider that payment/i.test(prose)) o.push(['bad', 'Uses "you owe me / that\'ll cost you" style banter, which the template bans.']);
    const lastP = ps ? ps[ps.length - 1] : prose.split('\n\n').pop();
    if (R.imDone && /\bI(?:'m| am) done \w+ing\b/i.test(lastP || '')) o.push(['bad', 'The final hook uses "I\'m done [doing]". The template bans that line shape.']);
    if (/never[^\n]*what do you do|do not[^\n]*what do you do/i.test(spec.greeting.raw || '') && /what do you do\??/i.test(lastP || '')) o.push(['bad', 'The final hook ends on "what do you do". Use a live action or line instead.']);
    if (R.noAdultWord && /\badults?\b|21\+/i.test(prose)) o.push(['bad', 'Remove "adult" / "21+" from the Greeting.']);
    common(o, prose, spec);
    // image
    o = res.image = []; const im = v.img, all = `${im.appearance} ${im.clothing} ${im.action}`;
    if (!IMG_RULES()) o.push(['ok', 'Image Generation follows your own template and rules; the app adds none.']);
    else {
    if (window.ImageStyle) for (const k of ['appearance', 'clothing', 'action']) { const iss = window.ImageStyle.issues(String(im[k] || '').replace(/^close-up shot,\s*/i, ''), k); if (iss.length) o.push(['warn', `Image ${k} reads like sentences, not keywords: "${iss[0].item.slice(0, 60)}" (${iss[0].why}). Use short comma-separated keywords.`]); }
    if (!im.appearance.trim()) o.push(['bad', 'Appearance is empty (hair, eyes, skin).']);
    if (!im.clothing.trim()) o.push(['bad', 'Clothing is empty.']);
    if (/_/.test(all)) o.push(['bad', 'Remove underscores. Use spaced phrases.']);
    if (/hourglass figure/i.test(all)) o.push(['bad', '"hourglass figure" is banned.']);
    if (im.clothing.trim()) {
      if (!/v[\s-]?neck|plunging|deep v|open v|cleavage|low[\s-]cut|sweetheart neckline/i.test(im.clothing)) o.push(['bad', 'Clothing needs a visible V-neckline or cleavage (e.g. "deep v-neck").']);
      if (/turtleneck|crew neck|high[\s-]neck|closed collar|fully buttoned|straight[\s-]across neckline/i.test(im.clothing)) o.push(['bad', 'Remove the high/closed neckline. The template requires an open V.']);
      if (!/dress|gown|robe|jumpsuit|bodysuit|romper|leotard|kimono|yukata|swimsuit|one[\s-]piece|playsuit|catsuit/i.test(im.clothing) && !/pants|trousers|jeans|shorts|skirt|leggings|slacks|hakama|sarong|joggers|sweatpants|culottes/i.test(im.clothing)) o.push(['bad', 'Add the lower-body garment (pants, skirt, shorts, etc.) or use a one-piece outfit.']);
      if (/\b(shoes?|boots?|heels|sneakers|sandals|slippers|footwear|loafers|pumps|stilettos|flats|socks?|gloves?|mittens?)\b/i.test(im.clothing)) o.push(['bad', 'Remove shoes, socks, footwear and gloves from Clothing.']);
    }
    if (!/close[\s-]?up/i.test(im.action)) o.push(['bad', 'Action & Background must use a close-up shot.']);
    if (!o.some(x => x[0] === 'bad')) o.push(['ok', 'Image prompt passes the template locks.']);
    }
    // tags
    o = res.tags = []; const tl = tagList(spec, v), T = spec.tags;
    o.push([tl.length === T.total ? 'ok' : 'bad', `${tl.length} of ${T.total} tags.`]);
    if (T.archetypeRequired && !v.archetype) {
      const src = (window.__srcArchetype && window.__srcArchetype()) || '';
      o.push(['bad', src ? `The card's archetype "${src}" isn't on this template's approved list. Change it on the card (✎ Edit) to one of: ${T.archetypes.join(', ')}.` : "No archetype: the card's Primary Archetypal Personality is empty. Set it on the card (✎ Edit); the app never picks one for you."]);
    }
    const evTags = eventTagNames(), unknown = tl.filter(t => !T.mandatory.includes(t) && !T.approved.includes(t) && t !== 'Wife' && !evTags.includes(t));
    if (unknown.length) o.push(['bad', `Not on the approved list: ${unknown.join(', ')}`]);
    // scene breakdown
    o = res.scene = [];
    const sc = v.scenes; if (sc.length !== g.count) o.push(['bad', `${sc.length} scenes but ${g.count} image markers.`]);
    sc.forEach((s, i) => {
      const gaps = ['name', 'setting', 'action'].filter(k => !s[k].trim());
      if (gaps.length) o.push(['bad', `Scene ${i + 1}: ${gaps.join(', ')} empty.`]);
      if (spec.scene.shotPrefix && !s.shot.startsWith(spec.scene.shotPrefix.trim())) o.push(['bad', `Scene ${i + 1}: Shot Angle must start with "${spec.scene.shotPrefix.trim()}".`]);
      if (spec.scene.noPOV && /\bPOV\b/i.test(s.shot)) o.push(['bad', `Scene ${i + 1}: this template bans POV labels. Use camera-facing shots.`]);
      if (/_/.test(`${s.shot}${s.setting}${s.action}`)) o.push(['bad', `Scene ${i + 1}: remove underscores.`]);
    });
    if (!o.length) o.push(['ok', `${sc.length} scenes match the ${g.count} image markers.`]);
    // overall total
    if (R.total) { const n = len(S.personality.body) + len(S.scenario.body) + len(prose); res.total = [];
      const TW = withTol(R.total), low = n < TW.min, high = n > TW.max, soft = (low && R.total.softMin) || (high && R.total.softMax);
      if ((low || high) && soft) res.total.push(['warn', `Personality + Scenario + Greeting is ${n.toLocaleString()} characters. Your template asks for approximately ${R.total.min.toLocaleString()}–${R.total.max.toLocaleString()} (${low ? `${(R.total.min - n).toLocaleString()} short` : `${(n - R.total.max).toLocaleString()} over`}); every section is inside its own limit.`]);
      else range(res.total, 'Personality + Scenario + Greeting', n, R.total); }
    // everyone in a story is 18 or older: flag any child, teenager or school setting anywhere in the bot
    { const M = (typeof window !== 'undefined' && window.Minors) || null;
      if (M) { const parts = [['introduction', 'Introduction', S.introduction.body], ['personality', 'Personality', S.personality && S.personality.body], ['scenario', 'Scenario', S.scenario && S.scenario.body], ['greeting', 'Greeting', S.greeting && S.greeting.prose], ['scene', 'Scene breakdown', (v.scenes || []).map(x => `${x.name} ${x.setting} ${x.action}`).join(' ')]];
        for (const [sec, label, text] of parts) { const hits = text ? M.find(text) : []; if (hits.length) (res[sec] = res[sec] || []).unshift(['bad', `${label} ${M.problem(hits)}`]); } } }
    // an NTR-tab bot (Emotional, Misunderstanding, Light or Emotional Post-NTR): the relationship in the present tense, no wording that reads as more than happened, and a Scenario that states the fixed facts
    { const NC = (typeof window !== 'undefined' && window.NtrCanon) || null, type = NC && NC.templateType ? NC.templateType(spec && spec.raw) : '';
      if (NC && type) {
        const parts = [['introduction', 'Introduction', S.introduction.body, 'prose'], ['personality', 'Personality', S.personality && S.personality.body, 'prose'], ['scenario', 'Scenario', S.scenario && S.scenario.body, 'scenario'], ['greeting', 'Greeting', S.greeting && S.greeting.prose, 'prose']];
        for (const [sec, label, text, where] of parts) { const p = text ? NC.problem(text, type, where) : null; if (p) (res[sec] = res[sec] || []).push(['bad', `${label} ${p}`]); } } }
    return res;
  }

  // ---------------------------------------------------------------- prefill
  function toYou(t) {
    return t.replace(/\{\{user\}\}'s|\{\{user\}\}’s/g, 'your').replace(/\{\{user\}\}/g, 'you')
      .replace(/(^|[.!?]\s+)(you|your)\b/g, (m, a, b) => a + b[0].toUpperCase() + b.slice(1));
  }
  const sentences = t => (String(t || '').match(/[^.!?]+[.!?]+["”’]?/g) || []).map(s => s.trim());
  function prefill(spec, s) {
    const v = blank(spec), F = s.fields || {}, name = s.primaryCharacter || '';
    v.header.scene = s.sceneName || ''; v.names[1] = name;
    if (s.eventCard === false) v.eventOn = false;               // not an event card: the bot starts with the event check off (tick it to enter this bot anyway)
    // cast: Name 2 / Name 3 in the templates come from the card's other characters
    const cast = (s.cast || []).filter(c => c && c.name);
    const prim = cast.find(c => c.role === 'Primary'); if (prim?.age && parseInt(prim.age, 10) >= 21) v.header.age = String(prim.age);
    const others = cast.filter(c => c.role !== 'Primary');
    const ant = others.find(c => c.role === 'Antagonist' || c.role === 'Third Party'), rest = others.filter(c => c !== ant);
    const second = ant || rest[0];                                  // Name 2 is the card's Third Party (the Antagonist on an ANTI-NTR card); another character only when the card has none
    if (second && spec.rules.hasName2) v.names[2] = second.name;
    else if (spec.rules.hasName2) v.names[2] = window.BBAuto?.thirdName?.(F, name) || '';   // no one in the cast: the name the card's Third Party row gives
    const third = others.find(c => c !== second);
    if (third && spec.rules.hasName3) { v.names[3] = third.name; v.include3 = true; }
    v.castNote = others.length && !spec.rules.hasName2 ? `This card has ${cast.length} characters, but this template has room for one. ${window.IS_SHARE ? 'Pick a template with room for more characters to keep them all.' : `The Multi-Character${others.some(c => c.role === 'Antagonist') ? ' or ANTI-NTR' : ''} template keeps them all.`}` : '';
    v.archetype = closestArchetype(spec.tags.archetypes, s.primaryArchetype, s);
    const setup = F['The Setup'] || '', hook = F['User Interaction Hook'] || '';
    const series = !window.IS_SHARE && SERIES_PREFIX.find(p => s.series === p);
    const topic = window.NtrCanon ? window.NtrCanon.topicTag(s) : '';      // an NTR card's bot starts with its topic instead of the template's own label
    const pre = topic || [series && !/Series/.test(spec.introduction.prefix) ? `[${series} 00]` : '', spec.introduction.prefix].filter(Boolean).join(' ');
    const ss = sentences(toYou(setup)).filter(x => !/[A-Z][a-z]+ Blueprint|^The Setup/.test(x));
    let intro = pre ? pre + ' ' : '';
    for (const x of ss) { if ((intro + x).length > (spec.introduction.limit?.max || 500)) break; intro += x + ' '; }
    v.intro = intro.trim();
    const n = spec.greeting.count, body = sentences(toYou(setup)), k = Math.max(1, n - 1);
    v.greet = Array.from({length: n}, (_, i) => i === n - 1 ? toYou(hook) : (body.length >= k ? body.slice(Math.floor(i * body.length / k), Math.floor((i + 1) * body.length / k)) : body.slice(i, i + 1)).join(' '));
    const approved = new Set(spec.tags.approved);
    const room = spec.tags.total - spec.tags.mandatory.filter(t => !isEventTag(t) || eventActiveFor(v)).length - (spec.tags.archetypeRequired ? 1 : 0);
    const oppTags = (s.opportunityTags || []).map(String);      // the event's own tags stay as the announcement writes them, even when the approved list has no such tag
    v.tags = [...new Set([...oppTags, ...(s.tags || [])])]
      .filter(t => !repeatsEventTag(t, oppTags)).filter(t => (approved.has(t) || oppTags.includes(t)) && !spec.tags.mandatory.includes(t) && t !== v.archetype && t !== 'Event' && !(spec.tags.archetypeRequired && spec.tags.archetypes.includes(t)))
      .slice(0, Math.max(0, room));
    const wear = (F["Character's Appearance Requirements"] || '').match(/wears ([^.]+)\./i);
    if (wear) v.img.clothing = wear[1].replace(/_/g, ' ');
    const rel = F["Character's Relationship to You"] || '', pers = F["Character's Personality"] || '';
    const map = [[/^full name$|^name$/i, name], [/^goes by$/i, name.split(' ')[0]], [/^gender/i, 'Female'], [/^pronouns$/i, 'she/her'],
      [/core trait 1|core temperament|core concept/i, pers],
      [/progression/i, F['Scenario:System Rules Long-Engagement Engine'] || ''], [/brief origin|origin story|background/i, rel]];
    const nude = F['Nude Appearance (Personality Only)'] || '', look = F["Character's Appearance Requirements"] || '';
    const used = new Set();
    // Scenario fields named like the template's own labels go straight in (e.g. NTR "What happened").
    const norm = t => String(t || '').toLowerCase().replace(/\{\{user\}\}|\{\{char\}\}/g, '').replace(/[’']s\b/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
    const byKey = {}; for (const [k, val] of Object.entries(F)) if (typeof val === 'string' && val.trim()) byKey[norm(k)] = val.trim();
    for (const sec of ['personality', 'scenario']) for (const l of spec[sec].lines) for (const x of l.segs) {
      if (x.t !== 'ph' || l.opt3) continue;
      const direct = byKey[norm(x.label)] || byKey[norm(x.ctx)];
      if (direct && !used.has('k:' + x.key)) { v.f[x.key] = direct.replace(/\.$/, ''); used.add('k:' + x.key); (v.prefilled = v.prefilled || []).push(x.key); continue; }
      const hit = map.find(([re]) => re.test(x.label) && !used.has(re.source));
      if (hit && hit[1]) { v.f[x.key] = hit[1]; used.add(hit[0].source); (v.prefilled = v.prefilled || []).push(x.key); continue; }
      if (/nude/i.test(x.block) && nude && !used.has('nude') && !/Character 2/.test(x.group)) { v.f[x.key] = nude; used.add('nude'); (v.prefilled = v.prefilled || []).push(x.key); }
      else if (/^(base )?appearance$/i.test(x.block) && look && !used.has('look') && !/Character 2/.test(x.group)) { v.f[x.key] = look; used.add('look'); (v.prefilled = v.prefilled || []).push(x.key); }
    }
    v.scenes.forEach((sc, i) => { sc.name = `${s.sceneName || 'Scene'} ${i + 1}`; sc.shot = spec.scene.shotPrefix + 'close-up shot'; });
    return v;
  }

  // ------------------------------------------------------------ autofill
  const AF = () => window.BBAuto;
  function phs(spec, v, sec) { const out = []; for (const l of spec[sec].lines) { if (l.opt3 && !v.include3) continue; for (const x of l.segs) if (x.t === 'ph') out.push(x); } return out; }
  function syncAuto(v) {
    for (const [k, a] of Object.entries(v.auto || {})) v.f[k] = a.used.map(i => a.pool[i]).join(' ');
    (v.gAuto || []).forEach((g, i) => { if (g) v.greet[i] = AF().paragraphText(g); });
    if (v.iAuto) v.intro = AF().introText(v.iAuto);
  }
  function fixClothing(c) {
    c = String(c || '').replace(/_/g, ' ').replace(/^she wears\s+/i, '').replace(/\.$/, '')
      .replace(/,?\s*(?:and\s+)?[^,]*\b(shoes?|boots?|heels|sneakers|sandals|slippers|footwear|loafers|pumps|stilettos|flats)\b[^,]*/gi, '')
      .replace(/turtleneck|crew neck|high[\s-]neck|closed collar|fully buttoned/gi, 'deep v-neck').replace(/\s*,\s*,/g, ',').replace(/^[,\s]+|[,\s]+$/g, '');
    if (!c) c = 'fitted deep v-neck blouse, high-waisted black skirt, thin gold necklace';
    if (!/v[\s-]?neck|plunging|deep v|open v|cleavage|low[\s-]cut|sweetheart/i.test(c)) c = `deep v-neckline showing cleavage, ${c}`;
    if (!/dress|gown|robe|jumpsuit|bodysuit|romper|leotard|kimono|yukata|swimsuit|one[\s-]piece|playsuit|catsuit/i.test(c) && !/pants|trousers|jeans|shorts|skirt|leggings|slacks|hakama|sarong|joggers|sweatpants|culottes/i.test(c)) c += ', high-waisted fitted skirt';
    return c;
  }
  // A saved draft can hold the sample line of dialogue an older version wrote into the Scene-Specific Stakes box. That copy is dropped (and, when the
  // card is given, written again from the card) so no rewrite carries it on as if it were the bot's text. Only the tool's own sample line is replaced (even when the box
  // is marked as edited, which a saved AI write does); any other text in the box stays as it is.
  function refreshStaleBoxes(spec, v, scenario) {
    const A = AF(); if (!A || !A.staleStakes || !v) return [];
    const gone = [];
    for (const sec of ['personality', 'scenario']) for (const ph of phs(spec, v, sec)) {
      const a = v.auto && v.auto[ph.key], cur = a ? a.used.map(i => a.pool[i]).join(' ') : (v.f[ph.key] || '');
      if (A.staleStakes(ph, cur) || (A.badNumberBox && A.badNumberBox(ph, cur)) || (A.staleOpening && A.staleOpening(ph, cur, !!a && !(v.touched || {})[ph.key]))) { delete v.f[ph.key]; if (v.auto) delete v.auto[ph.key]; if (v.touched) delete v.touched[ph.key]; if (v.prefilled) v.prefilled = v.prefilled.filter(k => k !== ph.key); gone.push(ph); }
    }
    if (gone.length && scenario) {
      const C = A.context(spec, v, scenario), used = new Set(Object.values(v.f));
      for (const ph of gone) { const r = A.writeField(ph, C, used); if (r && r.single && r.text) { v.f[ph.key] = r.text; used.add(r.text); } }
    }
    return gone;
  }
  function autoComplete(spec, v, scenario) {
    if (v.botVariant === 'female' && scenario) scenario = femaleCard(scenario);
    const A = AF(); v.auto = v.auto || {}; v.gAuto = v.gAuto || []; v.fit = v.fit || {};
    refreshStaleBoxes(spec, v, null);
    const C = A.context(spec, v, scenario);
    v.names[1] = v.names[1] || C.name; if (spec.rules.hasName2 && !v.names[2]) { v.names[2] = C.name2; v.name2Src = C.name2Src; }
    if (v.include3 && !v.names[3]) v.names[3] = 'Juniper Hale';
    v.header.age = v.header.age || C.age;
    v.header.scene = v.header.scene || scenario?.sceneName || `${C.first}'s Secret`;
    for (const k of v.prefilled || []) { const t = v.f[k]; if (!t || v.auto[k]) continue; const ss = A.sentences(t); if (ss.length > 1) v.auto[k] = {pool: ss, used: ss.map((_, i) => i)}; }
    const used = new Set(Object.values(v.f));
    for (const sec of ['personality', 'scenario']) for (const ph of phs(spec, v, sec)) {
      // the role line is always rebuilt from the card unless you typed it yourself (fixes old drafts too)
      if (A.isUserRole(ph) && !(v.touched || {})[ph.key]) { v.f[ph.key] = A.userRole(C); if (v.auto) delete v.auto[ph.key]; continue; }
      if ((v.f[ph.key] || '').trim()) continue;
      const r = A.writeField(ph, C, used);
      if (r.single) { v.f[ph.key] = r.text; used.add(r.text); }
      else if (r.pool.length) { const pool = ph.mode === 'field' ? r.pool : r.pool.slice(0, 1); v.auto[ph.key] = {pool, used: [0]}; used.add(pool[0]); }
    }
    const intro = (v.intro || '').trim();
    if (!intro || intro === (spec.introduction.prefix || '').trim() || !(v.touched || {}).intro) v.iAuto = A.introPlan(spec, C);
    const plan = A.greetingPlan(spec, C);
    v.greet.forEach((p, i) => { if (!(p || '').trim() || !(v.touched || {})['g' + i]) v.gAuto[i] = plan[i]; });
    if (IMG_RULES()) {                                                              // the app's own image defaults (open V-neck outfit, close-up, banned words) are the Personal edition's rules
      const img = A.image(C);
      // an anomaly, creature or monster is never given the human defaults (hair, eyes, skin, a v-neck dress): they are written by "Write appearance with AI", which draws her real kind
      const raceText = phs(spec, v, 'personality').filter(ph => /race|species/i.test(`${ph.label || ''} ${ph.key || ''}`)).map(ph => String(v.f[ph.key] || '')).join(' ');
      const creature = /^SCP\b/i.test(String((scenario && scenario.series) || C.series || '')) || /\b(anomal|creature|monster)/i.test(raceText);
      if (!creature) {
        for (const k of ['appearance', 'clothing']) if (!v.img[k].trim()) v.img[k] = img[k];
        v.img.clothing = fixClothing(v.img.clothing);
      }
      v.img.appearance = v.img.appearance.replace(/_/g, ' ').replace(/hourglass figure,?\s*/gi, '');
      if (!v.img.action.trim() || v.img.action.trim() === 'close-up shot,') v.img.action = img.action;
    }
    const T = spec.tags;
    if (!v.archetype) v.archetype = closestArchetype(T.archetypes, C.arch, scenario);
    if (T.wifeRule && /wife/i.test(C.rel)) v.wife = true;
    const room = () => T.total - tagList(spec, v).length;
    const filler = [...(scenario?.tags || []), 'OC', 'Story/Scene', 'Drama', 'Romance', 'Slow Burn', 'Slice of Life', 'Fictional', 'Serious'];
    for (const t of filler) { if (room() <= 0) break; if (T.approved.includes(t) && !tagList(spec, v).includes(t) && !T.archetypes.includes(t) && t !== 'Wife') v.tags.push(t); }
    syncAuto(v);
    const angles = spec.scene.noPOV ? ['close-up shot', 'eye-level shot', 'low-angle shot', 'intimate camera-facing close-up', 'tilted movement shot', 'close-up shot'] : ['close-up shot', 'eye-level shot', 'seated low-angle shot', 'close-up shot', 'viewer looking up', 'close-up shot'];
    v.scenes.forEach((sc, i) => {
      const narr = A.sentences(String(v.greet[i] || '').replace(/"[^"]*"/g, '').replace(/\*/g, ' '))[0] || '';
      if (!sc.name.trim()) sc.name = `${v.header.scene} ${['Opening', 'Pressure', 'Turn', 'Closer', 'Edge', 'Hook'][i] || i + 1}`;
      if (!sc.shot.trim() || sc.shot.trim() === spec.scene.shotPrefix.trim()) sc.shot = spec.scene.shotPrefix + angles[i % angles.length];
      if (!sc.setting.trim()) sc.setting = `${C.place}, ${C.light}, details from paragraph ${i + 1}`.replace(/_/g, ' ');
      if (!sc.action.trim()) sc.action = `${C.first} faces the viewer/camera. ${narr.replace(/\byour\b/gi, "the viewer's").replace(/\byou\b/gi, 'the viewer')}`.replace(/_/g, ' ').trim();
    });
    fitAll(spec, v);
    growFromCard(spec, v, scenario);
  }
  // a template that asks for long sections (e.g. 2,600+ characters) can need more than the boxes give: add the card's own
  // unused sentences to the section's last free box, one at a time, until the minimum is reached (never past the maximum)
  function growFromCard(spec, v, scenario) {
    if (!scenario || !scenario.fields) return;
    const F = scenario.fields, src = ['The Setup', 'Scenario:System Rules Long-Engagement Engine', "Character's Relationship to You", 'Fresh Angle', 'What Has Already Happened', 'Relationship Condition', 'Immediate Crisis', 'Engine Machine', 'Engine Jobs'];
    const pool = src.flatMap(k => String(F[k] || '').replace(/\[USER AGENCY[\s\S]*$/, '').split(/(?<=[.!?])\s+/)).map(x => x.trim()).filter(x => x.length > 30 && x.length < 400 && !/\{\{user\}\}['’]s (thoughts|dialogue)/i.test(x));
    for (const sec of ['scenario', 'personality']) {
      const L = spec[sec].limit; if (!L) continue;
      const keys = phs(spec, v, sec).filter(x => x.mode !== 'key' && x.mode !== 'phrase').map(x => x.key);
      const key = keys[keys.length - 1]; if (!key) continue;
      let len = compose(spec, v).sec[sec].body.length;
      for (const sent of pool) {
        if (len >= L.min) break;
        const cur = v.f[key] || ''; if (cur.includes(sent)) continue;
        const next = (cur ? cur.replace(/\s*$/, ' ') : '') + sent;
        const grow = next.length - cur.length; if (len + grow > L.max) continue;
        v.f[key] = next; if (v.auto) delete v.auto[key]; len = compose(spec, v).sec[sec].body.length;
      }
    }
  }
  // PolicyWeights must never push the Scenario past the template's limit: when the block cannot fit beside the locked rules, the least important parts of the copy inside the bot are cut (see PolicyWeights.trim) and the cuts are listed in v.policyTrim.
  function fitPolicy(spec, v) {
    const PWX = window.PolicyWeights; if (!PWX || !PWX.enabled || !v || !v.policy || !v.policy.on || !PWX.trim) return false;
    // PolicyWeights are outside the Scenario's own limit: only the template's combined total can make them too long
    const R = spec.rules && spec.rules.total; if (!R) { delete v.policyShort; return false; }
    const nm = v.names && v.names[1]; let did = false;
    delete v.policyShort;
    const total = () => { const c = compose(spec, v); return c.sec.personality.body.length + c.sec.scenario.body.length + c.sec.greeting.prose.length; };
    for (let i = 0; i < 4; i++) {
      const n = total(), over = n - withTol(R).max; if (over <= 0) break;
      const cur = PWX.blockLength(v.policy, nm); if (!cur) break;
      const t = PWX.trim(v.policy, nm, Math.max(0, cur - over));
      v.policyShort = !!t.short;
      if (!t.changed) break;
      v.policy = t.policy; if (t.cuts.length) v.policyTrim = [...new Set([...(v.policyTrim || []), ...t.cuts])]; did = true;
    }
    return did;
  }
  function fitAll(spec, v) {
    const A = AF(), secs = ['personality', 'scenario'];
    const lim = k => k === 'greeting' ? spec.greeting.limit : k === 'introduction' ? (spec.introduction.limit || {min: 440, max: 500}) : spec[k].limit;
    // measuring is the slow part (it runs the rule shortener), so remember results for identical drafts
    const memo = new Map();
    const lens = () => {
      syncAuto(v);
      const key = JSON.stringify([v.f, v.greet, v.intro, v.fit, v.include3, v.names, v.policy, v.over && v.over.scenario]);
      if (memo.has(key)) return memo.get(key);
      const c = compose(spec, v), r = {introduction: c.sec.introduction.body.length, personality: c.sec.personality.body.length, scenario: c.sec.scenario.body.length - policyAdd(v), pol: policyAdd(v), greeting: c.sec.greeting.prose.length};
      if (memo.size > 400) memo.clear(); memo.set(key, r); return r;
    };
    // introduction: pick sentence count + ending that lands inside the range
    if (v.iAuto) {
      // aim a little inside the window: switching to you/your and tidying can shorten the text by a few characters afterwards
      const ip = v.iAuto, L0 = lim('introduction'), mid = Math.round((L0.min + L0.max) / 2), L = {min: Math.min(L0.min + 15, mid), max: Math.max(L0.max - 10, mid)}, E = A.ENDINGS.length;
      // Walk the sentences in story order, skipping any that would overflow, then close
      // with one or two cliffhanger endings until the length lands inside the range.
      const text = (used, ends) => A.introText({...ip, used, ends});
      let best = null;
      for (let start = 0; start < Math.min(3, ip.pool.length) && !best; start++) {
        const used = [];
        for (let i = start; i < ip.pool.length; i++) { if (text([...used, i], [0]).length <= L.max) used.push(i); }
        const tries = [[]]; for (let a = 0; a < E; a++) { tries.push([a]); for (let b = 0; b < E; b++) if (b !== a) tries.push([a, b]); }
        for (let drop = 0; drop <= used.length && !best; drop++) {
          const u = used.slice(0, used.length - drop);
          for (const ends of tries) { const t = text(u, ends); if (t.length >= L.min && t.length <= L.max && /\byou/i.test(t)) { best = {u, ends}; break; } }
        }
      }
      if (!best) best = {u: [0], ends: [0]};
      ip.used = best.u; ip.ends = best.ends;
    }
    // growable units per section
    const units = k => k === 'greeting' ? (v.gAuto || []).map((g, i) => g && {get: g, i}).filter(Boolean) : Object.entries(v.auto || {}).filter(([key]) => key.startsWith(k + '.')).map(([key, a]) => ({get: a, key}));
    const grow = (k, gap) => {
      let best = null;
      const taken = new Set(units(k).flatMap(u => u.get.used.map(i => u.get.pool[i])));
      for (const u of units(k)) u.get.pool.forEach((t, i) => { if (u.get.used.includes(i) || taken.has(t)) return; const d = t.length + 1; if (d <= gap && (!best || d > best.d)) best = {u, i, d}; });
      if (!best) for (const u of units(k)) u.get.pool.forEach((t, i) => { if (!u.get.used.includes(i) && !taken.has(t) && (!best || t.length < best.d)) best = {u, i, d: t.length + 1}; });
      if (!best) return false; best.u.get.used.push(best.i); return true;
    };
    const shrink = (k, gap) => {
      let best = null;
      for (const u of units(k)) { const min = k === 'greeting' ? 0 : 1; if (u.get.used.length <= min) continue; const i = u.get.used[u.get.used.length - 1], d = u.get.pool[i].length + 1; if (!best || Math.abs(d - gap) < Math.abs(best.d - gap)) best = {u, d}; }
      if (!best) return false; best.u.get.used.pop(); return true;
    };
    const settle = () => { for (let guard = 0; guard < 300; guard++) {
      const n = lens(); let changed = false;
      for (const k of [...secs, 'greeting']) {
        const L = lim(k); if (!L) continue;
        const W = withTol(L);
        if (n[k] < W.min) changed = grow(k, (L.min + L.max) / 2 - n[k]) || changed;
        else if (n[k] > W.max) { shrink(k, n[k] - (L.min + L.max) / 2); changed = true; }
      }
      if (!changed) break;
      const m = lens(); if ([...secs, 'greeting'].every(k => !lim(k) || (m[k] >= withTol(lim(k)).min && m[k] <= withTol(lim(k)).max))) break;
    } };
    settle();
    if (fitPolicy(spec, v)) settle();
    // last resort: trim auto-written answers (never ones you typed) at a comma or clause break.
    // Works in a few big passes: measure once, cut the whole excess, measure again.
    // Cut only where the sentence still reads as complete: drop whole trailing
    // sentences first, then trailing ", clauses". Never cut in the middle of a phrase.
    const shorten = (t, by) => {
      const ss = t.match(/[^.!?]+[.!?]+/g) || [t];
      while (ss.length > 1 && by > 0) { by -= ss[ss.length - 1].length; ss.pop(); }
      let out = ss.join('').trim();
      if (by > 0) {
        const body = out.replace(/[.!?]+$/, '');
        const cuts = [...body.matchAll(/, (?=[a-z])| and (?=[a-z]+s? )| (?=(?:with|who|where|when|because|while|until|whenever|so that|even when|as soon as) )/g)].map(m => m.index).filter(i => i >= 26).sort((a, b) => a - b);
        const at = cuts.reverse().find(i => body.length - i >= Math.min(by, 40)) ?? cuts[cuts.length - 1];
        if (at != null) out = body.slice(0, at) + '.';
      }
      return out.length < t.length ? out : t;
    };
    for (const k of secs) {
      const L = lim(k); if (!L) continue;
      for (let pass = 0; pass < 8; pass++) {
        const over = lens()[k] - Math.round(L.max - (L.max - L.min) * 0.25);
        if (over <= 0) break;
        const allKeys = phs(spec, v, k).map(x => x.key);
        const seen = new Map(), dupes = new Set();
        for (const key of allKeys) { const t = (v.f[key] || '').trim(); if (t.length > 30) { if (seen.has(t)) dupes.add(key); else seen.set(t, key); } }
        const keys = allKeys.filter(key => !(v.touched || {})[key] && (v.f[key] || '').length > (pass < 3 ? 60 : 38))
          .sort((a, b) => (dupes.has(b) - dupes.has(a)) || v.f[b].length - v.f[a].length);
        if (!keys.length) break;
        let left = over;
        for (const key of keys) {
          if (left <= 0) break;
          const before = v.f[key].length, next = shorten(v.f[key], Math.ceil(left / 2) + 10);
          if (next === v.f[key]) continue;
          if (v.auto?.[key]) delete v.auto[key];
          v.f[key] = next; left -= before - next.length;
        }
      }
    }
    // still over: shorten long auto/scenario-supplied single values to their first clause
    for (const k of secs) {
      const L = lim(k); if (!L) continue;
      for (let guard = 0; guard < 40 && lens()[k] > L.max; guard++) {
        const mine = phs(spec, v, k).map(x => x.key).filter(key => (v.prefilled || []).includes(key) && !v.auto[key] && (v.f[key] || '').length > 90);
        const key = mine.sort((a, b) => v.f[b].length - v.f[a].length)[0]; if (!key) break;
        const t = v.f[key], cut = t.slice(0, Math.max(60, Math.floor(t.length * 0.6))).replace(/[,;]?\s+\S*$/, '');
        v.f[key] = cut.replace(/[,;:\s]+$/, '') + (/[.!?]$/.test(t) ? '.' : '');
        v.prefilled = v.prefilled.filter(x => !(x === key && v.f[key].length <= 90));
      }
    }
    // overall total
    const tot = spec.rules.total;
    if (tot) for (let guard = 0; guard < 120; guard++) {
      const n = lens(), sum = n.personality + n.scenario + (n.pol || 0) + n.greeting;
      if (sum >= tot.min && sum <= tot.max) break;
      if ((sum > tot.max && tot.softMax) || (sum < tot.min && tot.softMin)) break;    // an approximate bound never cuts a section below its own minimum
      const order = [...secs, 'greeting'].filter(k => lim(k));
      const ok = sum < tot.min ? order.some(k => n[k] + 60 < lim(k).max && grow(k, Math.min(lim(k).max - n[k], tot.min - sum + 50)))
        : order.some(k => n[k] - 60 > lim(k).min && shrink(k, Math.min(n[k] - lim(k).min, sum - tot.max + 50)));
      if (!ok) break;
    }
    syncAuto(v);
  }

  // -------------------------------------------------------------------- UI
  const fieldTag = (k, val, hint, short, rows) => short
    ? `<input class="bb-in" data-k="${e(k)}" value="${e(val)}" placeholder="${e(hint)}">`
    : `<textarea class="bb-in" data-k="${e(k)}" rows="${rows || 2}" placeholder="${e(hint)}">${e(val)}</textarea>`;
  const SHORT = /^(full name|goes by|age|race|gender|pronouns|sexuality|love language|name)$/i;
  function fieldsHtml(spec, v, sec) {
    let html = '', grp = null, blk = null;
    for (const l of spec[sec].lines) for (const s of l.segs) {
      if (s.t !== 'ph') continue;
      if (l.opt3 && !v.include3) continue;
      if (s.group !== grp) { grp = s.group; if (grp) html += `<h5 class="bb-group">${e(grp.replace('Character ', 'Character ') )}: ${e(v.names[grp.slice(-1)] || '')}</h5>`; }
      if (s.block !== blk) { blk = s.block; if (blk && !SHORT.test(s.label)) html += `<div class="bb-block">${e(blk)}</div>`; }
      const short = SHORT.test(s.label) || s.hint.length < 28;
      html += `<label class="bb-field"><span>${e(s.label)}</span>${fieldTag('f.' + s.key, v.f[s.key] || '', s.hint, short, s.hint.length > 120 ? 3 : 2)}</label>`;
    }
    return html || '<p class="bb-note">This section is fixed text from the template. Only the character names change.</p>';
  }
  // the Greeting markdown box: picture links and the bold-italic line get a colour behind the text
  function mdHighlight(t) {
    return String(t || '').split('\n').map(l => { const x = e(l);
      return /^\s*!\[[^\]]*\]\([^)]*\)\s*$/.test(l) ? `<span class="md-img">${x}</span>` : /^\s*\*\*\*.*\*\*\*\s*$/.test(l) ? `<span class="md-hdr">${x}</span>` : x; }).join('\n');
  }
  function subLine(key) {
    const lim = key === 'greeting' ? B.spec.greeting.limit : (B.spec.introduction.limit || {min: 440, max: 500});
    return `${lim ? `${lim.min.toLocaleString()} to ${lim.max.toLocaleString()} characters. ` : ''}${key === 'greeting' ? 'Markdown on the left, how it will look in chat on the right.' : 'Text on the left, how it will look in chat on the right.'} Auto-saved.`;
  }
  // ---------------------------------------------------------------- pictures: upload the Greeting images to your image site (v1.1.0)
  function imgHints() {
    const card = B.v && B.v.sourceId && typeof currentWeekAll === 'function' ? currentWeekAll().find(x => x.id === B.v.sourceId) : null, f = (card && card.fields) || {};
    return [card && card.series, card && card.seriesLabel, card && card.slot, card && card.laneTab, card && card.lane, card && card.type, card && card.day, f['NTR Type'], B.spec && B.spec.name].filter(Boolean).map(String);
  }
  // the link each picture marker holds: '' for a marker that is still ![](imageN). Read from the text as it is now (passages, or the Greeting text you edited).
  const linksOf = text => [...String(text || '').matchAll(/^[ \t]*!\[[^\]]*\]\(([^)\s]*)\)[ \t]*$/gm)].map(m => /^image\d+$/.test(m[1]) ? '' : m[1]);
  const markerLinks = () => linksOf(compose(B.spec, B.v).sec.greeting.body);
  // one line above the Greeting editor: where the pictures go. The Upload image buttons themselves sit beside each marker.
  function imgUpHtml() {
    if (!B.v || !B.v.greet) return '';
    const v = B.v, H = window.ImageHost, fold = H ? H.folderLabel(v.header && v.header.scene, v.names && v.names[1]) : '';
    return `<div class="bb-imgnote" data-imgbox><span>Use <b>Upload image</b> beside a picture marker. Pictures go to your image site, folder <b data-imgfolder>${e(fold || 'Scene name - First name')}</b>.</span>${H && H.accounts ? `<label class="bb-imgacct">Account <select data-imgacct><option value="" ${v.imgAccount ? '' : 'selected'}>Automatic (from the bot's series)</option><option value="ntr" ${v.imgAccount === 'ntr' ? 'selected' : ''}>NTR Account</option><option value="main" ${v.imgAccount === 'main' ? 'selected' : ''}>Main Account</option></select></label>` : ''}<input type="file" accept=".png,.jpg,.jpeg,.webp,.gif,.avif,image/*" multiple hidden data-imgfile></div>`;
  }
  function rebuildKeep() {
    const open = new Set([...document.querySelectorAll('#bb-form .bb-sec[open]')].map(d => d.dataset.sec)), y = window.scrollY;
    build(); document.querySelectorAll('#bb-form .bb-sec').forEach(d => { d.open = open.has(d.dataset.sec); }); window.scrollTo(0, y);
  }
  // put a link into marker i (url '' puts ![](imageN) back). With an edited Greeting text the marker line itself is changed; with the passages the link is kept beside them.
  function setMarker(i, url) {
    const v = B.v, target = url || `image${i + 1}`;
    if (v.over && typeof v.over.greeting === 'string') {
      let n = -1, hit = false;
      v.over.greeting = v.over.greeting.replace(/^([ \t]*)!\[([^\]]*)\]\(([^)\s]*)\)([ \t]*)$/gm, (m, a, alt, t, b) => (++n === i ? (hit = true, `${a}![${alt}](${target})${b}`) : m));
      return hit;
    }
    if (i >= v.greet.length) return false;
    v.imgUrls = v.imgUrls || []; v.imgUrls[i] = url || ''; if (!v.imgUrls.some(Boolean)) delete v.imgUrls; return true;
  }
  // leaving the edited Greeting text for the passages: keep the pictures
  const keepLinks = fn => { const L = markerLinks(); fn(); if (L.some(Boolean)) B.v.imgUrls = L.slice(0, B.v.greet.length); };
  window.__bbImg = {
    get v() { return B.v; }, get spec() { return B.spec; }, hints: imgHints, links: markerLinks,
    firstFree() { const L = markerLinks(), i = L.findIndex(x => !x); return i < 0 ? 0 : i; },
    setLinks(start, urls) { let miss = 0; urls.forEach((u, k) => { if (!setMarker(start + k, u)) miss++; }); save(); applyLinks(); return miss; },
    setAccount(a) { if (a) B.v.imgAccount = a; else delete B.v.imgAccount; save(); },
    clear(i) { setMarker(i, ''); save(); applyLinks(); }
  };
  // show new links without rebuilding the form, so a picture finishing while you type does not take the cursor away
  function applyLinks() {
    const ta = document.querySelector('#bb-form .bb-md-in[data-k="over.greeting"]');
    if (ta) {
      const v = B.v, t = v.over && typeof v.over.greeting === 'string' && !greetFmtOn(v) ? v.over.greeting : compose(B.spec, v).sec.greeting.body;
      if (ta.value !== t) {
        const old = ta.value, has = document.activeElement === ta; let pre = 0; while (pre < old.length && pre < t.length && old[pre] === t[pre]) pre++;
        let suf = 0; while (suf < old.length - pre && suf < t.length - pre && old[old.length - 1 - suf] === t[t.length - 1 - suf]) suf++;
        const at = p0 => p0 <= pre ? p0 : (old.length - p0 <= suf ? t.length - (old.length - p0) : Math.min(p0, t.length)), s0 = at(ta.selectionStart), s1 = at(ta.selectionEnd);   // the caret keeps its place in what you were typing
        ta.value = t; if (has) { try { ta.setSelectionRange(s0, s1); } catch {} } ta.dispatchEvent(new Event('bbrepaint'));
      }
      refresh(); return;
    }
    const a = document.activeElement;
    if (a && a.closest && a.closest('#bb-form') && /^(TEXTAREA|INPUT|SELECT)$/.test(a.tagName)) { refresh(); a.addEventListener('blur', () => rebuildKeep(), {once: true}); return; }   // passage boxes: rebuild once you leave the box you are typing in
    rebuildKeep();
  }
  function secShell(key, inner) {
    const ov = B.v.over && typeof B.v.over[key] === 'string';
    const editing = !!B.editingOver?.[key];
    const fieldKey = key === 'personality' || key === 'scenario';
    const directView = fieldKey && !editing && (ov || !(B.fieldView && B.fieldView[key]));       // Personality and Scenario open as the whole finished text, editable right there; the fields are one click away
    const directText = directView ? String(compose(B.spec, B.v).sec[key].body) : '';       // exactly what Copy gives: the PolicyWeights block, the guardrail paragraph and the Name 2 fill included
    const mdMode = key === 'greeting' && !editing && !B.passMode;                   // the Greeting is one markdown text, like the mock-up; the passage boxes are one click away
    const mdText = mdMode ? (ov && !greetFmtOn(B.v) && !(B.v.imgUrls || []).some(Boolean) ? String(B.v.over[key] || '') : compose(B.spec, B.v).sec.greeting.body) : '';
    const mdEditor = `${greetFmtLabel(B.v)}<div class="bb-md"><pre class="bb-md-hl" aria-hidden="true"></pre><textarea class="bb-in bb-md-in" data-k="over.greeting" spellcheck="false" aria-label="Greeting markdown" placeholder="Write the Greeting here. A picture goes on its own line: ![](https://...)">${e(mdText)}</textarea></div>`;
    const passBtn = key !== 'greeting' ? '' : mdMode ? '' : !editing ? `<div class="bb-sec-actions"><button type="button" class="ghost bb-mdmode">Back to one markdown text</button></div>` : '';
    return `<details class="bb-sec" data-sec="${key}" ${key === 'header' || key === 'introduction' ? 'open' : ''}>
      <summary><span class="bb-sec-title">${SEC_TITLE[key]}</span><span class="bb-count" data-count="${key}"></span><span class="bb-state" data-state="${key}"></span><span class="bb-top-btns"><button type="button" class="secondary bb-rewrite-section" data-sec="${key}" ${window.AI_ON ? '' : 'disabled'} title="Rewrite only this section; review before applying. Other sections stay unchanged.">Rewrite ${SEC_TITLE[key]} with AI</button>${B.rewriteUndo?.section === key && B.rewriteUndo.templateId === B.spec.id && B.rewriteUndo.sourceId === B.v.sourceId && B.rewriteUndo.variant === B.v.botVariant ? `<button type="button" class="ghost bb-undo-rewrite" data-sec="${key}">Undo AI rewrite</button>` : ''}${key === 'introduction' ? `<button type="button" class="primary bb-intro-design">✦ Build Introduction</button>` : ''}${key !== 'header' ? `<button class="copy-btn bb-copy-sec bb-copy-top" data-sec="${key}" title="Copy the ${SEC_TITLE[key]} section">Copy ${SEC_TITLE[key]}</button>` : ''}</span></summary>
      <p class="bb-sec-sub">${key === 'greeting' || key === 'introduction' ? subLine(key) : `${key === 'personality' || key === 'scenario' ? 'The whole text on the left (or the fields, one click away), how it reads in chat on the right.' : 'Fields on the left, how it will read in the bot on the right.'} Auto-saved.`}</p>
      <div class="bb-sec-body bb-has-live${key === 'introduction' || key === 'greeting' ? '' : ' bb-fieldsec'}">
        ${key === 'greeting' ? `<div class="bb-strip" data-strip="greeting"></div>` : ''}
        <div class="bb-live" data-live="${key}"></div>
        <div class="bb-edpane"${key === 'greeting' ? ' data-imgdrop' : ''}><div class="bb-pane-h"><b>${key === 'greeting' ? (mdMode ? 'Greeting markdown' : 'Greeting passages') : key === 'introduction' ? 'Introduction text' : (key === 'personality' || key === 'scenario') ? (directView ? SEC_TITLE[key] + ' text' : SEC_TITLE[key] + ' fields') : SEC_TITLE[key]}</b><span data-pane-count="${key}"></span></div>
        ${key === 'greeting' ? imgUpHtml() : ''}
        ${directView ? `<p class="bb-note">The whole ${SEC_TITLE[key]} is here, exactly as it goes into the bot${key === 'scenario' && policyAdd(B.v) ? `, with the PolicyWeights block (${policyAdd(B.v).toLocaleString()} characters) and its guardrail paragraph the app adds` : ''}. Edit anything in it, including the fixed rules.</p><textarea class="bb-in bb-over bb-direct" data-k="over.${key}" rows="18" spellcheck="false">${e(directText)}</textarea><div class="bb-sec-actions">${/<(input|select|textarea)\b/.test(String(inner || '')) ? `<button type="button" class="ghost bb-showfields" data-sec="${key}">Edit the fields instead</button>` : ''}</div>` : editing ? `<p class="bb-note">You're editing the final text directly.</p><textarea class="bb-in bb-over" data-k="over.${key}" rows="16">${e(((B.v.names && B.v.names[2] && /personality|scenario/.test(key)) ? String(B.v.over[key] || '').replace(/\[Name ?2\]/g, B.v.names[2]) : B.v.over[key]) || '')}</textarea><div class="bb-sec-actions"><button type="button" class="ghost bb-unover" data-sec="${key}">Back to fields</button><button type="button" class="primary bb-save-over" data-sec="${key}">Save edits</button></div>` : mdMode ? mdEditor : inner}
        ${passBtn}
        ${fieldKey && !editing && !directView ? `<div class="bb-sec-actions"><button type="button" class="ghost bb-hidefields" data-sec="${key}">Show the whole ${SEC_TITLE[key]} text</button></div>` : ''}
        ${key === 'greeting' ? '' : `<ul class="bb-checks" data-checks="${key}"></ul>`}
        ${key === 'tags' ? '' : `<details class="bb-preview"><summary>Preview</summary><pre data-preview="${key}"></pre></details>`}
        </div>
      </div></details>`;
  }
  // ---------------------------------------------------------------- upload a fully built bot (.txt) and fill the sections
  const BOT_HEADS = [
    ['introduction', /^(introduction|intro)$/i],
    ['personality', /^(personality)$/i],
    ['scenario', /^(scenario)$/i],
    ['greeting', /^(greeting|first message|opening message)$/i],
    ['image', /^(image generation|image prompt|images?)$/i],
    ['tags', /^(tags)$/i],
    ['scene', /^(scene breakdown|scenes)$/i],
    ['header', /^(basics|header)$/i]
  ];
  // A heading is a section name on its own line with a colon ("Scenario:") or markdown hash. Only when a file has no such
  // headings are bare names ("Scenario") accepted: a line inside a section can easily be just "Scenario".
  function botHeading(line, strict) {
    const raw = String(line || '').trim();
    if (strict && !/:\s*$/.test(raw) && !/^#{1,6}\s/.test(raw)) return '';
    const t = raw.replace(/^#{1,6}\s*/, '').replace(/:\s*$/, '').trim();
    for (const [key, re] of BOT_HEADS) if (re.test(t)) return key;
    return '';
  }
  function splitBuiltBot(raw, strict) {
    const lines = String(raw || '').replace(/\r\n/g, '\n').split('\n');
    const chunks = {preamble: []}; let cur = 'preamble';
    for (const line of lines) {
      const key = botHeading(line, strict);
      if (key) { cur = key; chunks[cur] = chunks[cur] || []; continue; }
      (chunks[cur] = chunks[cur] || []).push(line);
    }
    return chunks;
  }
  function parseBuiltBot(raw) {
    const count = c => ['introduction', 'personality', 'scenario', 'greeting', 'image', 'tags', 'scene'].filter(k => (c[k] || []).join('').trim()).length;
    let chunks = splitBuiltBot(raw, true);
    if (count(chunks) < 2) { const loose = splitBuiltBot(raw, false); if (count(loose) > count(chunks)) chunks = loose; }
    const body = k => (chunks[k] || []).join('\n').trim();
    const found = count(chunks);
    return {found, preamble: (chunks.preamble || []).concat(chunks.header || []).join('\n').trim(), introduction: body('introduction'), personality: body('personality'), scenario: body('scenario'), greeting: body('greeting'), image: body('image'), tags: body('tags'), scene: body('scene')};
  }
  function fieldAfter(text, label) {
    const lines = String(text || '').split('\n'), re = new RegExp('^' + label + '\\s*:\\s*(.*)$', 'i');
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(re); if (!m) continue;
      if (m[1].trim()) return m[1].trim();
      return (lines[i + 1] || '').trim();
    }
    return '';
  }
  function greetingParagraphs(text, count) {
    let t = String(text || '').replace(/```[\s\S]*?```/g, '').replace(/^\s*\*\*\*\s*$/gm, '').trim();
    t = t.replace(/^Please answer the following in your first message:[\s\S]*?address you correctly\.\s*/i, '').trim();
    const parts = t.split(/\n\s*(?:---|\*\*\*)\s*\n|\n\s*!\[\]\(image\d+\)\s*/i).map(x => x.replace(/!\[\]\(image\d+\)/gi, '').trim()).filter(Boolean);
    const n = Math.max(1, count || parts.length || 1);
    const out = Array.from({length: n}, () => '');
    parts.slice(0, n - 1).forEach((p, i) => { out[i] = p; });
    if (parts.length) out[n - 1] = parts.slice(n - 1).join('\n\n').trim();
    return out;
  }
  // Read an uploaded Personality or Scenario back into the template's boxes. The template's fixed sentences are the
  // anchors: each box is the text between its sentence and the next one. Returns what it filled and whether the
  // boxes now rebuild the uploaded text exactly (when they do not, the uploaded text is kept as final text).
  function fillBoxesFromText(sec, text) {
    // the lines compose actually writes: without a third character, optional lines and lines only about that character are left out
    const lines = B.spec[sec].lines.filter(l => (!l.opt3 || B.v.include3) && (B.v.include3 || !(l.segs.some(x => x.t === 'lit' && /\u0001N3\??U?\u0002/.test(x.v)) && !l.segs.some(x => x.t === 'lit' && /\u0001N[12]\??U?\u0002/.test(x.v)))));
    const toks = []; lines.forEach((l, i) => { if (i) toks.push({t: 'lit', v: '\n'}); for (const s of l.segs) toks.push(s); });
    const esc = x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/\\\*\\\*|__/g, '(?:\\*\\*|__)?');   // bold markers around a name are optional: Dialogue.personalityText removes them
    // the fixed text between two boxes as a pattern: words exactly, spaces flexible, a line break needs a line break, a name is the name
    const nameRe = tok => { const m = tok.match(/N([123])/), nm = m && B.v.names && B.v.names[m[1]]; return nm ? esc(/U\u0002$/.test(tok) ? nm.toUpperCase() : nm) : '[^\\n]{1,80}?'; };
    const litPat = part => part.split(/(\s+)/).map((x, i, a) => !x ? '' : /^\s+$/.test(x) ? (i === a.length - 1 ? '[ \\t]*' : /\n/.test(x) ? '\\s*\\n\\s*' : '[ \\t]+') : esc(x)).join('');
    const reOf = str => String(str).split(/(\u0001N[123]\??U?\u0002)/).map(part => /^\u0001N/.test(part) ? nameRe(part) : litPat(part)).join('');
    // a name the file uses but the Basics lines did not give: read it from a fixed line of the template that holds only names ("{{char}} is [Name].")
    const T = String(text || '').replace(/\r\n/g, '\n');
    if (!B.v.names[1] || !B.v.names[2]) for (const L of lines) {
      if (L.segs.some(x => x.t !== 'lit')) continue;
      const str = L.segs.map(x => x.v).join(''); if (!/\u0001N[12]\u0002/.test(str) || /\u0001N3|\u0001N[12]\?|U\u0002/.test(str)) continue;
      const seen = {}; let g = 0;
      const body = str.split(/(\u0001N[12]\u0002)/).map(part => { const m = part.match(/^\u0001N([12])\u0002$/); if (!m) return litPat(part); if (seen[m[1]]) return '\\' + seen[m[1]]; seen[m[1]] = ++g; return '([^\\n]{1,60}?)'; }).join('');
      let m; try { m = new RegExp('^[ \\t]*' + body + '[ \\t]*$', 'm').exec(T); } catch { m = null; }
      if (m) for (const n of ['1', '2']) if (seen[n] && !B.v.names[n] && m[seen[n]] && m[seen[n]].trim()) B.v.names[n] = m[seen[n]].trim();
    }
    const groups = [{ph: null, lits: []}];
    for (const t of toks) { if (t.t === 'ph') groups.push({ph: t, lits: []}); else groups[groups.length - 1].lits.push(t.v); }
    // the longest run of fixed text that is found (prefix for the sentences after a box, suffix for the ones before the first box)
    const find = (lits, from, suffix) => {
      for (let n = lits.length; n >= 1; n--) {
        const sub = suffix ? lits.slice(lits.length - n) : lits.slice(0, n), str = sub.join('');
        if (!str.replace(/\s+/g, '')) continue;
        const re = new RegExp(reOf(str), 'g'); re.lastIndex = from;
        const m = re.exec(T); if (m) return {index: m.index, end: m.index + m[0].length};
      }
      return null;
    };
    let pos = 0; const vals = {};
    if (groups[0].lits.length) { const f = find(groups[0].lits, 0, true); if (f && f.index < 600) pos = f.end; }
    for (let g = 1; g < groups.length; g++) {
      const {ph, lits} = groups[g];
      if (!lits.join('').replace(/\s+/g, '')) { if (g === groups.length - 1) { vals[ph.key] = T.slice(pos).trim(); pos = T.length; } else vals[ph.key] = null; continue; }
      const f = find(lits, pos, false);
      if (!f) { vals[ph.key] = null; continue; }
      vals[ph.key] = T.slice(pos, f.index).trim(); pos = f.end;
    }
    const keys = groups.slice(1).map(g => g.ph.key);
    for (const l of B.spec[sec].lines) for (const sg of l.segs) if (sg.t === 'ph') { delete B.v.f[sg.key]; if (B.v.auto) delete B.v.auto[sg.key]; }
    let filled = 0;
    for (const k of keys) { const val = vals[k]; if (val) { B.v.f[k] = val; B.v.touched[k] = true; filled++; } }
    if (B.v.over) delete B.v.over[sec];
    const rebuilt = compose(B.spec, B.v).sec[sec].body.replace(/\s+/g, '');
    const exact = (filled > 0 || !keys.length) && rebuilt === T.replace(/\s+/g, '');
    // a text that mostly does not follow this template's sentences would only scatter pieces of itself into the boxes: leave them empty
    if (!exact && keys.length && filled < keys.length / 2) { for (const k of keys) { delete B.v.f[k]; if (B.v.touched) delete B.v.touched[k]; } return {filled: 0, total: keys.length, exact: false};}
    return {filled, total: keys.length, exact};
  }
  function applyBuiltBot(parsed) {
    const pre = parsed.preamble || '';
    const name = fieldAfter(pre, 'Name') || fieldAfter(pre, 'Character name') || fieldAfter(pre, 'Name 1');
    const age = fieldAfter(pre, 'Age');
    const scene = fieldAfter(pre, 'Scene name') || fieldAfter(pre, 'Scene Name');
    if (name) B.v.names[1] = name;
    if (age) B.v.header.age = age;
    if (scene) B.v.header.scene = scene;
    B.v.touched = B.v.touched || {};
    if (parsed.introduction) { B.v.intro = parsed.introduction; B.v.touched.intro = true; if (B.v.over) delete B.v.over.introduction; }
    B.v.over = B.v.over || {};
    const notes = [];
    for (const sec of ['personality', 'scenario']) {
      if (!parsed[sec]) continue;
      const r = fillBoxesFromText(sec, parsed[sec]), title = SEC_TITLE[sec];
      if (r.exact) continue;                                   // the boxes rebuild the uploaded text exactly: nothing is kept as final text
      B.v.over[sec] = parsed[sec]; B.v.touched['over.' + sec] = true;   // the file differs from the template somewhere: its text stays exactly as uploaded
      notes.push(!r.total ? `${title}: this template has no boxes for it, and the file's text differs from the template's, so it is kept as final text.` : r.filled ? `${title}: ${r.filled} of ${r.total} boxes filled. The file's text differs from the template in places, so it stays as final text until you click Back to fields.` : `${title}: the text doesn't follow this template's boxes, so it is loaded as final text.`);
    }
    if (parsed.greeting) {
      delete B.v.over.greeting; delete B.v.imgUrls;
      B.v.greet = greetingParagraphs(parsed.greeting, B.spec.greeting && B.spec.greeting.count);
      B.v.greet.forEach((_, i) => { B.v.touched['g' + i] = true; });
    }
    if (parsed.image) {
      const app = fieldAfter(parsed.image, 'Appearance'), cloth = fieldAfter(parsed.image, 'Clothing and Accessories'), act = fieldAfter(parsed.image, 'Action & Background') || fieldAfter(parsed.image, 'Action and Background');
      if (app) B.v.img.appearance = app.replace(/^.*quality prompt[^,]*,\s*/i, '');
      if (cloth) B.v.img.clothing = cloth;
      if (act) B.v.img.action = act;
    }
    if (parsed.tags) {
      const want = parsed.tags.split(/\n|,/).map(x => x.trim()).filter(Boolean);
      const known = new Set([...(B.spec.tags.approved || []), ...(B.spec.tags.mandatory || []), ...(B.spec.tags.archetypes || []), ...eventTagNames()]);
      B.v.tags = want.filter(t => known.has(t) && !repeatsEventTag(t, eventTagNames())); delete B.v.evSlot;
      const arch = want.find(t => (B.spec.tags.archetypes || []).includes(t));
      if (arch) B.v.archetype = arch;
    }
    if (parsed.scene) {
      const blocks = parsed.scene.split(/\n\s*\n/).map(x => x.trim()).filter(Boolean);
      blocks.forEach((block, i) => {
        if (!B.v.scenes[i]) return;
        B.v.scenes[i].name = fieldAfter(block, 'Scene ' + (i + 1)) || fieldAfter(block, 'Scene') || B.v.scenes[i].name;
        const shot = fieldAfter(block, 'Shot Angle'), setting = fieldAfter(block, 'Setting'), action = fieldAfter(block, 'Action');
        if (shot) B.v.scenes[i].shot = shot;
        if (setting) B.v.scenes[i].setting = setting;
        if (action) B.v.scenes[i].action = action;
      });
    }
    return notes;
  }

  function build() {
    normalizeIdentity(B.spec, B.v); renderVariant();
    setTimeout(povUi, 0); setTimeout(renderLimits, 0); setTimeout(renderEvent, 0); setTimeout(checkAppearance, 50); setTimeout(() => { try { window.__builtSync && window.__builtSync(); } catch {} }, 0);
    const spec = B.spec, v = B.v, R = spec.rules;
    const names = `<div class="bb-names">
      <label class="bb-field"><span>${R.hasName2 ? 'Name 1 (main character)' : 'Character name'}</span>${fieldTag('n.1', v.names[1], 'e.g. Luna Hart', true)}</label>
      ${R.hasName2 ? `<label class="bb-field"><span>Name 2</span>${fieldTag('n.2', v.names[2], 'second character', true)}</label>` : ''}
      ${R.hasName3 ? `<label class="bb-check"><input type="checkbox" data-k="include3" ${v.include3 ? 'checked' : ''}> Include a third character</label>${v.include3 ? `<label class="bb-field"><span>Name 3</span>${fieldTag('n.3', v.names[3], 'third character', true)}</label>` : ''}` : ''}</div>`;
    const mlinks = markerLinks();
    const parts = {
      header: `${names}<label class="bb-field"><span>Scene name</span>${fieldTag('h.scene', v.header.scene, 'Scene name', true)}${variantOf(spec, v) ? `<small class="bb-identity-note">30 characters maximum, including ${e(Identity.SUFFIX[variantOf(spec, v)].trim())}. The suffix is kept automatically.</small>` : ''}</label><label class="bb-field"><span>Age</span>${fieldTag('h.age', v.header.age, '21+', true)}</label>`,
      introduction: `<p class="bb-note">${e(spec.introduction.hint || 'Second-person premise that ends on a cliffhanger.')}</p>${variantOf(spec, v) ? `<p class="bb-identity-note">Always starts with ${e(Identity.PREFIX[variantOf(spec, v)])}, unless the Introduction is your own HTML (then it stays exactly as you wrote it).</p>` : ''}<div class="bb-ivw-row"><div class="bb-ivw" data-ivw-bar role="group" aria-label="Introduction view"><button type="button" data-ivw="text" aria-pressed="true">View as text</button><button type="button" data-ivw="html" aria-pressed="false">View as HTML</button></div><button type="button" class="ghost sm bb-ivw-rebuild" data-ivw-rebuild hidden title="Throw away the HTML you edited by hand and build it again from the Introduction text">Rebuild from the text</button></div><div data-ivw-text>${fieldTag('intro', v.intro, 'Introduction', false, 6)}</div><div data-ivw-html hidden><p class="bb-note" data-ihtml-note></p><textarea class="bb-ihtml" data-ihtml rows="14" spellcheck="false" aria-label="Introduction as HTML"></textarea><div class="bb-sec-actions"><button type="button" class="ghost" data-ihtml-reset>Rebuild from the text</button></div></div>`,
      personality: fieldsHtml(spec, v, 'personality'),
      scenario: fieldsHtml(spec, v, 'scenario'),
      greeting: `<label class="bb-check"><input type="checkbox" data-k="autoFormat" ${v.autoFormat ? 'checked' : ''}> Auto-format: put narration in *asterisks* and each "quote" on its own line</label>${greetFmtLabel(v)}
        ${v.greet.map((p, i) => `<label class="bb-field"><span>Passage ${i + 1} <small>→ followed by ![](image${i + 1})</small> <button type="button" class="ghost sm bb-imgbtn bb-imginline" data-imgup="${i}" ${window.ImageHost && window.ImageHost.isBusy(i) ? 'disabled' : ''}>${window.ImageHost && window.ImageHost.isBusy(i) ? 'Uploading…' : mlinks[i] ? 'Replace image' : 'Upload image'}</button>${mlinks[i] ? `<button type="button" class="ghost sm bb-imgbtn bb-imginline" data-imgclear="${i}" title="Take the link out; the marker goes back to ![](image${i + 1})">✕</button>` : ''}</span><small class="bb-hint">${e(spec.greeting.hints[i] || '')}</small>${fieldTag('g.' + i, p, 'Write the passage before this image marker using the selected template instructions.', false, 6)}</label>`).join('')}`,
      image: `${imageTools(v)}<div class="bb-field"><span>Appearance <small>(locked quality prompt${spec.image.qualityFromSettings ? ' from Settings' : ''}, then your text)</small><button type="button" class="copy-btn bb-copy-img" data-img="appearance" title="Copy the locked quality prompt plus Appearance">⧉ Copy</button></span><div class="bb-locked"><pre class="bb-locked-text">${e(spec.image.quality)}</pre></div>${fieldTag('img.appearance', v.img.appearance, spec.image.appearanceHint, false)}</div>
        <div class="bb-field"><span>Clothing and Accessories<button type="button" class="copy-btn bb-copy-img" data-img="clothing" title="Copy Clothing and Accessories">⧉ Copy</button></span>${fieldTag('img.clothing', v.img.clothing, spec.image.clothingHint, false)}</div>
        <div class="bb-field"><span>Action & Background<button type="button" class="copy-btn bb-copy-img" data-img="action" title="Copy Action and Background">⧉ Copy</button></span>${fieldTag('img.action', v.img.action, spec.image.actionHint, false)}</div>
        <div class="bb-field"><span>Negative Prompt <small>(locked, from ${spec.image.negativeFromSettings ? 'Settings' : 'the template'})</small><button type="button" class="copy-btn bb-copy-img" data-img="negative" title="Copy the locked Negative Prompt">⧉ Copy</button></span><div class="bb-locked"><pre class="bb-locked-text">${e(spec.image.negative)}</pre></div></div>`,
      tags: tagsHtml(spec, v),
      scene: v.scenes.map((s, i) => `<div class="bb-scene"><h5 class="bb-group">Scene ${i + 1} <small>matches paragraph ${i + 1}</small></h5>
        <label class="bb-field"><span>Scene name</span>${fieldTag(`sc.${i}.name`, s.name, 'Scene name', true)}</label>
        <label class="bb-field"><span>Shot Angle</span>${fieldTag(`sc.${i}.shot`, s.shot, spec.scene.noPOV ? 'close-up shot, eye-level shot…' : 'First-person POV, close-up shot…', true)}</label>
        <label class="bb-field"><span>Setting</span>${fieldTag(`sc.${i}.setting`, s.setting, spec.scene.settingHint, false)}</label>
        <label class="bb-field"><span>Action</span>${fieldTag(`sc.${i}.action`, s.action, spec.scene.actionHint, false)}</label></div>`).join('')
    };
    { const th = q('bb-tense'), ed = document.querySelector('.bb-editor'); if (th && ed && th.parentNode !== ed) ed.insertBefore(th, q('bb-form')); }   // the tense control lives in the open pane's header: take it out before the form is rebuilt
    const basicsBar = `<div class="bb-basics" id="bb-basics" role="group" aria-label="Basics">${names}<label class="bb-field bb-scene"><span>Scene name</span>${fieldTag('h.scene', v.header.scene, 'Scene name', true)}${variantOf(spec, v) ? `<small class="bb-identity-note">30 characters maximum, including ${e(Identity.SUFFIX[variantOf(spec, v)].trim())}. The suffix is kept automatically.</small>` : ''}</label><label class="bb-field bb-age"><span>Age</span>${fieldTag('h.age', v.header.age, '21+', true)}</label><button type="button" class="secondary bb-rewrite-section bb-basics-btn" data-sec="header" ${window.AI_ON ? '' : 'disabled'} title="Rewrite only the Basics; review before applying. Other sections stay unchanged.">Rewrite Basics with AI</button><ul class="bb-checks" data-checks="header"></ul></div>`;
    q('bb-form').innerHTML = basicsBar + spec.order.filter(k => k !== 'header').map(k => secShell(k, parts[k])).join('');
    bindForm();
    applyActive();
    refresh();
  }
  function tagsHtml(spec, v) {
    const T = spec.tags, locked = [...T.mandatory];
    const evOn = eventActiveFor(v);
    const pick = T.approved.filter(t => !locked.includes(t) && !T.archetypes.includes(t) && t !== 'Wife');
    return `<div class="bb-tag-row"><span class="bb-mini">Required:</span>${locked.map(t => `<span class="bb-tag locked"${/^event$/i.test(t) ? ' data-evslot="1"' + (evOn ? '' : ' style="display:none"') : ''}>${e(slotTags([t], v === B.v ? eventTagName() : '')[0])}</span>`).join('')}</div>
      ${T.archetypeRequired ? `<label class="bb-field"><span>Personality archetype (required tag)</span><select class="bb-in" data-k="archetype"><option value="">Choose…</option>${T.archetypes.map(a => `<option ${a === v.archetype ? 'selected' : ''}>${e(a)}</option>`).join('')}</select></label>` : ''}
      ${T.wifeRule ? `<label class="bb-check"><input type="checkbox" data-k="wife" ${v.wife ? 'checked' : ''}> Name 1 is the wife (adds the required "Wife" tag)</label>` : ''}
      <input class="bb-tag-search" placeholder="Filter tags…">
      <div class="bb-tag-pool">${pick.map(t => `<button type="button" class="bb-tag ${v.tags.includes(t) ? 'on' : ''}" data-tag="${e(t)}">${e(t)}</button>`).join('')}</div>
      ${T.borrowedApproved ? '<p class="bb-note">This template has no tag list of its own, so the approved list from your other templates is used.</p>' : ''}`;
  }
  // The Scenario editor shows the PolicyWeights block the app adds. What is kept is the text without it, so the block still follows the PolicyWeights panel; if the block itself was edited by hand it is kept as written.
  function pwUnbake(val) {
    try {
      const v = B.v, P = window.PolicyWeights; val = String(val == null ? '' : val);
      if (!v.policy || !v.policy.on || !P || !P.enabled || !P.topBlock || !P.guardText) return val;
      const nm = v.names && v.names[1], top = P.topBlock(v.policy, nm), guard = P.guardText(v.policy, nm);
      if (!top || !val.includes(top)) return val;
      for (const [a, b] of [[top + '\n\n', ''], [top, '']]) for (const [g1, g2] of [['\n\n' + guard, ''], ['\n' + guard, ''], ['\n\n' + guard + '\n', '\n'], [guard + '\n', ''], [guard, '']]) {
        if (!val.includes(a) || !val.includes(g1)) continue;
        const cand = val.replace(a, b).replace(g1, g2);
        if (P.insert(cand, v.policy, nm) === val) return cand;
      }
      return val;
    } catch { return val; }
  }
  function setPath(k, val) {
    const v = B.v, p = k.split('.');
    if (p[0] === 'f') { const k = p.slice(1).join('.'); v.f[k] = val; (v.touched = v.touched || {})[k] = true; if (v.auto) delete v.auto[k]; }
    else if (p[0] === 'n') v.names[p[1]] = val;
    else if (p[0] === 'h') v.header[p[1]] = val;
    else if (p[0] === 'g') { v.greet[+p[1]] = val; (v.touched = v.touched || {})['g' + p[1]] = true; if (v.gAuto) v.gAuto[+p[1]] = null; }
    else if (p[0] === 'img') v.img[p[1]] = val;
    else if (p[0] === 'sc') v.scenes[+p[1]][p[2]] = val;
    else if (p[0] === 'over') { v.over[p[1]] = p[1] === 'scenario' ? pwUnbake(val) : val; if (p[1] === 'greeting') delete v.imgUrls; }   // the typed Greeting text holds the links itself
    else if (k === 'intro') { v.intro = val; (v.touched = v.touched || {}).intro = true; v.iAuto = null; }
    else v[k] = val;
  }
  function bindForm() {
    document.querySelectorAll('#bb-form details').forEach(d => d.addEventListener('toggle', () => { if (d.open) resizeFields(); }));
    document.querySelectorAll('#bb-form .bb-in').forEach(el => {
      const ev = el.tagName === 'SELECT' ? 'change' : 'input';
      el.addEventListener(ev, () => {
        const k = el.dataset.k;
        if (k.startsWith('f.') && B.v.auto) delete B.v.auto[k.slice(2)];
        if (k.startsWith('g.') && B.v.gAuto) B.v.gAuto[+k.slice(2)] = null;
        if (k === 'intro') delete B.v.iAuto;
        setPath(k, el.value); if (el.tagName === 'TEXTAREA') grow(el); refresh(); save();
      });
      if (['h.scene', 'intro', 'over.introduction'].includes(el.dataset.k)) el.addEventListener('blur', () => {
        normalizeIdentity(B.spec, B.v);
        el.value = el.dataset.k === 'h.scene' ? B.v.header.scene : el.dataset.k === 'intro' ? B.v.intro : B.v.over.introduction;
        refresh(); save();
      });
      if (/^(?:intro|over\.introduction|over\.greeting|g\.\d+)$/.test(el.dataset.k)) el.addEventListener('blur', () => setTimeout(() => offerAge('You edited the text.'), 0));
      if (el.tagName === 'TEXTAREA') grow(el);
    });
    document.querySelectorAll('#bb-form input[type=checkbox][data-k]').forEach(el => el.addEventListener('change', () => {
      B.v[el.dataset.k] = el.checked; if (el.dataset.k === 'greetFmt') { try { localStorage.setItem('jbs.greetFmt', el.checked ? '1' : '0'); } catch {} } if (el.dataset.k === 'greetBreak') { try { localStorage.setItem('jbs.greetBreak', el.checked ? '1' : '0'); } catch {} } save(); if (el.dataset.k === 'include3' || el.dataset.k === 'greetFmt' || el.dataset.k === 'greetBreak') build(); else refresh();
    }));
    document.querySelectorAll('#bb-form input[data-fit]').forEach(el => el.addEventListener('change', () => { B.v.fit = B.v.fit || {}; B.v.fit[el.dataset.fit] = el.checked; if (el.checked) fitAll(B.spec, B.v); save(); build(); openSec(el.dataset.fit); }));
    document.querySelectorAll('#bb-form .bb-tag[data-tag]').forEach(b => b.onclick = () => {
      const t = b.dataset.tag, i = B.v.tags.indexOf(t);
      if (i >= 0) B.v.tags.splice(i, 1); else B.v.tags.push(t);
      b.classList.toggle('on', i < 0); refresh(); save();
    });
    const fs = document.querySelector('#bb-form .bb-tag-search');
    if (fs) fs.oninput = () => document.querySelectorAll('#bb-form .bb-tag-pool .bb-tag').forEach(b => { b.style.display = b.dataset.tag.toLowerCase().includes(fs.value.toLowerCase()) ? '' : 'none'; });
    document.querySelectorAll('#bb-form .bb-showfields').forEach(b => b.onclick = () => { const sec = b.dataset.sec;
      if (B.v.over && typeof B.v.over[sec] === 'string') { if (!confirm('Go back to the fields? Your edits to the whole text will be dropped.')) return; delete B.v.over[sec]; save(); }
      B.fieldView[sec] = true; rebuildDirectSec(sec); });
    document.querySelectorAll('#bb-form .bb-hidefields').forEach(b => b.onclick = () => { B.fieldView[b.dataset.sec] = false; rebuildDirectSec(b.dataset.sec); });
    document.querySelectorAll('#bb-form .bb-over-btn').forEach(b => b.onclick = () => { const sec = b.dataset.sec; B.v.over[sec] = compose(B.spec, B.v).sec[sec].body; B.editingOver[sec] = true; save(); rebuildDirectSec(sec); });
    document.querySelectorAll('#bb-form .bb-md').forEach(box => {
      const ta = box.querySelector('textarea'), hl = box.querySelector('.bb-md-hl');
      const marks = ta.dataset.k === 'over.greeting' ? Object.assign(document.createElement('div'), {className: 'bb-md-marks'}) : null; if (marks) box.appendChild(marks);
      const place = () => {                                  // an Upload image button beside each picture marker line
        if (!marks) return; const L = linksOf(ta.value); marks.innerHTML = '';
        hl.querySelectorAll('.md-img').forEach((sp, i) => { const b = document.createElement('button'); b.type = 'button'; b.className = 'ghost sm bb-imgbtn'; b.dataset.imgup = i; const busyNow = window.ImageHost && window.ImageHost.isBusy(i); b.disabled = !!busyNow; b.textContent = busyNow ? 'Uploading…' : L[i] ? 'Replace image' : 'Upload image'; b.style.top = (sp.offsetTop + 1) + 'px'; marks.appendChild(b); });
      };
      const paint = () => { hl.innerHTML = mdHighlight(ta.value) + '\n'; hl.scrollTop = ta.scrollTop; place(); };
      ta.addEventListener('bbrepaint', paint);
      ta.addEventListener('input', paint); ta.addEventListener('scroll', () => { hl.scrollTop = ta.scrollTop; }); paint();
      if (window.ResizeObserver) new ResizeObserver(paint).observe(ta);
    });
    document.querySelectorAll('#bb-form .bb-passmode').forEach(b => b.onclick = () => {
      if (B.v.over && typeof B.v.over.greeting === 'string') { if (!confirm('Go back to the passage boxes? Your edits in the Greeting markdown will be dropped.')) return; keepLinks(() => { delete B.v.over.greeting; }); }
      B.passMode = true; save(); rebuildDirectSec('greeting'); });
    document.querySelectorAll('#bb-form .bb-mdmode').forEach(b => b.onclick = () => { B.passMode = false; save(); rebuildDirectSec('greeting'); });
    document.querySelectorAll('#bb-form .bb-unover').forEach(b => b.onclick = () => { const sec = b.dataset.sec; if (!confirm('Go back to the fields? Your direct edits to this section will be dropped.')) return; if (sec === 'greeting') keepLinks(() => { delete B.v.over[sec]; }); else delete B.v.over[sec]; delete B.editingOver[sec]; save(); rebuildDirectSec(sec); });
    document.querySelectorAll('#bb-form .bb-save-over').forEach(b => b.onclick = () => { const sec = b.dataset.sec; delete B.editingOver[sec]; save(); rebuildDirectSec(sec); toast(`${SEC_TITLE[sec] || 'Section'} edits saved.`); });
    document.querySelectorAll('#bb-form .bb-rewrite-section').forEach(b => b.onclick = ev => { ev.preventDefault(); ev.stopPropagation(); rewriteSection(b.dataset.sec); });
    document.querySelectorAll('#bb-form .bb-undo-rewrite').forEach(b => b.onclick = ev => { ev.preventDefault(); ev.stopPropagation(); undoRewrite(b.dataset.sec); });
    wireIvw();
    document.querySelectorAll('#bb-form .bb-copy-sec').forEach(b => b.onclick = async ev => { ev.preventDefault(); ev.stopPropagation(); if (await copySection(b.dataset.sec)) flash(b); });
    document.querySelectorAll('#bb-form .bb-intro-design').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();openIntroductionDesigner();});
    document.querySelectorAll('#bb-form .bb-kw').forEach(b => b.onclick = () => offerKeywords('You asked to check the image keywords.', true));
    document.querySelectorAll('#bb-form .bb-ai-look').forEach(b => b.onclick = () => aiAppearance(false));
    document.querySelectorAll('#bb-form .bb-copy-img').forEach(b => b.onclick = async ev => {
      ev.preventDefault(); ev.stopPropagation();
      const spec = B.spec, im = B.v.img || {};
      const text = b.dataset.img === 'quality' ? spec.image.quality
        : b.dataset.img === 'appearance' ? [spec.image.quality, String(im.appearance || '').trim()].filter(Boolean).join(', ')
        : b.dataset.img === 'clothing' ? String(im.clothing || '').trim()
        : b.dataset.img === 'action' ? String(im.action || '').trim()
        : spec.image.negative;
      await window.copyText(text || ''); flash(b); toast(b.dataset.img === 'quality' || b.dataset.img === 'negative' ? 'Locked prompt copied.' : 'Copied.');
    });
  }
  // ---- one section at a time, with the section list on the left (counts and state for every section)
  function activeKey() { const keys = B.spec ? B.spec.order.filter(k => k !== 'header') : []; if (!keys.includes(B.activeSec)) B.activeSec = keys[0]; return B.activeSec; }      // Basics is the bar at the top of the editor, not a section in the list
  // the one-line summary under the Greeting editor and preview (the full list of checks opens from it)
  function greetStrip(c, list) {
    const box = document.querySelector('[data-strip="greeting"]'); if (!box) return;
    const g = B.spec.greeting, lim = g.limit, n = c.sec.greeting.prose.length, tol = lim ? withTol(lim) : null;
    const markers = (c.sec.greeting.body.match(/^[ \t]*!\[[^\]]*\]\([^)\s]*\)[ \t]*$/gm) || []).length;
    const bad = re => list.filter(x => x[0] === 'bad' && re.test(x[1])), nb = a => a.length === 1 ? '1 to fix' : `${a.length} to fix`;
    const dia = bad(/dialogue|quot|delivery|speech|spoken|narration outside/i), agency = bad(/\{\{user\}\}|user agency|reader/i);
    const open = box.querySelector('details') ? box.querySelector('details').open : false;
    const item = (ok, name, text) => `<span class="st ${ok ? 'ok' : 'bad'}"><b>${name}</b> ${e(text)}</span>`;
    const real = list.filter(x => x[0] !== 'ok').length;
    box.innerHTML = `<div class="st-row">${item(!lim || (n >= tol.min && n <= tol.max), 'Length', lim ? `${n.toLocaleString()} of ${lim.min.toLocaleString()} to ${lim.max.toLocaleString()}` : n.toLocaleString())}
      ${item(markers === g.count, 'Images', `${markers} of ${g.count} markers`)}
      ${item(!dia.length, 'Dialogue', dia.length ? nb(dia) : 'template rules met')}
      ${item(!agency.length, 'User agency', agency.length ? nb(agency) : 'the reader is never written')}</div>
      <div class="st-note">Preview shows pictures from your image host. A broken link shows a grey box with the address.</div>
      <details class="st-all"${open ? ' open' : ''}><summary>All checks for the Greeting${real ? ` (${real} to look at)` : ''}</summary><ul class="bb-checks" data-checks="greeting">${list.map(([lvl, m]) => `<li class="${lvl}">${lvl === 'ok' ? '✓' : lvl === 'warn' ? '•' : '!'} ${e(m)}</li>`).join('')}</ul></details>`;
  }
  function navTags() { try { const n = tagList(B.spec, B.v).length; return n ? `${n} tags` : 'done'; } catch { return 'done'; } }
  function navScenes() { const n = ((B.v && B.v.scenes) || []).length; return n ? `${n} scenes` : 'done'; }
  // The Checks panel is one collapsed box, closed until opened. Its border and its one-line summary show the worst thing inside: red something to fix, yellow only notes or reminders, green all good.
  function syncChecks() {
    const chk = q('bb-checks'); if (!chk) return;
    const res = B.lastRes || {}; let nb = 0, nw = 0;
    for (const k of Object.keys(res)) if (Array.isArray(res[k])) for (const x of res[k]) { if (x && x[0] === 'bad') nb++; else if (x && x[0] === 'warn') nw++; }
    const ev = q('bb-event'), evOn = !!(ev && ev.style.display !== 'none'), evBad = evOn && ev.classList.contains('ev-bad'), evWarn = evOn && ev.classList.contains('ev-warn');
    const state = nb || evBad ? 'bad' : nw || evWarn ? 'warn' : 'ok';
    chk.className = 'bb-nav-sum ' + state;
    const parts = [nb ? `${nb} to fix` : '', nw ? `${nw} note${nw > 1 ? 's' : ''}` : '', evBad ? 'event to fix' : evWarn ? 'event reminders' : ''].filter(Boolean);
    const sum = q('bb-checks-sum'); if (sum) sum.textContent = parts.length ? parts.join(' \u00b7 ') : '\u2713 all good';
  }
  function renderNav(res) {
    const nav = q('bb-nav'); if (!nav || !B.spec) return;
    const act = activeKey(), all = q('bb-form').classList.contains('bb-all'); let bad = 0, warn = 0;
    const items = B.spec.order.map(k => {
      const list = (res && res[k]) || [], nb = list.filter(x => x[0] === 'bad').length, nw = list.filter(x => x[0] === 'warn').length; bad += nb; warn += nw;
      if (k === 'header') return '';                                                  // Basics is the bar at the top of the editor: no slot in the list
      const ct = document.querySelector(`[data-count="${k}"]`), cnt = ct ? ct.textContent.trim().replace(/^[\d,]+ \+ [\d,]+ PolicyWeights = /, '').replace(/\/\s*[\d,]+\s*[\u2013-]\s*/, '/ ') : '';   // the list is narrow: the Scenario shows its whole total there (text + PolicyWeights), the sum is spelled out in the section header
      const hasCt = /\//.test(cnt), ctBad = !!(ct && ct.classList.contains('bad'));     // the number is red only when the LENGTH is out of range; another problem in the section shows as a pink ! beside a green number
      return `<div class="bb-nav-row"><button type="button" class="bb-nav-item ${nb ? 'bad' : 'ok'}${k === act ? ' on' : ''}" data-nav="${k}" aria-current="${k === act ? 'true' : 'false'}"><span class="bb-nav-t">${e(SEC_TITLE[k] || k)}</span><span class="bb-nav-c ${hasCt ? (ctBad ? 'bad' : 'ok') : (nb ? 'bad' : '')}">${hasCt && nb && !ctBad ? '<b class="bb-nav-bang" title="Something else in this section needs a look">!</b> ' : ''}${e(cnt || (k === 'tags' && !nb ? navTags() : k === 'scene' && !nb ? navScenes() : nb ? 'to fix' : 'done'))}</span></button>${k !== 'header' ? `<button type="button" class="bb-nav-copy" data-navcopy="${k}" title="Copy ${e(SEC_TITLE[k] || k)}" aria-label="Copy ${e(SEC_TITLE[k] || k)}">\u29c9</button>` : ''}</div>`;
    }).join('');
    if (res && res.total) { bad += res.total.filter(x => x[0] === 'bad').length; warn += res.total.filter(x => x[0] === 'warn').length; }
    const fk = document.activeElement && document.activeElement.dataset && document.activeElement.dataset.nav;
    const foc = !!(document.querySelector('.bb-layout') || {classList: {contains: () => false}}).classList.contains('bb-focus');
    const lst = q('bb-nav-list'), tls = q('bb-nav-tools'), chk = q('bb-checks');
    if (lst) {
      const tot = q('bb-total'); if (tot && lst.contains(tot)) nav.insertBefore(tot, lst);           // keep the node alive while the list is redrawn
      lst.innerHTML = `<div class="bb-nav-h">Sections</div>${items}`;
      if (tot) lst.insertBefore(tot, lst.querySelector('.bb-nav-row'));                            // the Personality + Scenario + Greeting total sits above Basics
    }
    syncChecks();
    if (tls) tls.innerHTML = '';     // the one-section view and the side preview are fixed now: no "Show all sections" / "Show full bot" switches

    if (fk) { const b = nav.querySelector(`[data-nav="${fk}"]`); if (b) b.focus(); }
  }
  // the menu bar at the top stays put while the page scrolls: remember its height so a section's title and its Rewrite / Copy buttons are never hidden under it
  function topbarVar() { try { const t = document.querySelector('.sidebar'); document.documentElement.style.setProperty('--topbar-h', ((t && t.offsetHeight) || 66) + 'px'); } catch { /* ignore */ } }
  if (typeof window !== 'undefined' && !window.__bbTopbarBound) { window.__bbTopbarBound = true; window.addEventListener('resize', topbarVar); }
  if (typeof window !== 'undefined' && window.ResizeObserver && !window.__bbTopbarRO) { const tb = document.querySelector('.sidebar'); if (tb) { window.__bbTopbarRO = new ResizeObserver(topbarVar); window.__bbTopbarRO.observe(tb); } }
  function applyActive() {
    topbarVar();
    const form = q('bb-form'); if (!form || !B.spec) return;
    const act = activeKey();
    form.querySelectorAll(':scope > .bb-sec').forEach(d => d.classList.toggle('bb-active', d.dataset.sec === act));
    const lay = document.querySelector('.bb-layout'); if (lay) lay.dataset.act = act;
    { const th = q('bb-tense'), ph = form.querySelector(`.bb-sec[data-sec="${act}"] .bb-pane-h`), ed = document.querySelector('.bb-editor');
      if (th) { if (ph && (act === 'introduction' || act === 'greeting')) { if (th.parentNode !== ph) ph.insertBefore(th, ph.querySelector('[data-pane-count]')); } else if (ed && th.parentNode !== ed) ed.insertBefore(th, q('bb-form')); } }
    // only the shown section stays open, so opening any other one (from a problem, a rewrite) is seen and switches to it
    if (!form.classList.contains('bb-all')) form.querySelectorAll(':scope > .bb-sec').forEach(d => { d.open = d.dataset.sec === act; });
    renderNav(B.lastRes || {});
  }
  function setActive(k, scroll) {
    if (k === 'header') { const bar = q('bb-basics'); if (bar) { bar.scrollIntoView({block: 'nearest'}); const i = bar.querySelector('input'); if (i) i.focus(); } return; }
    if (!B.spec || !B.spec.order.includes(k)) return;
    B.activeSec = k; applyActive();
    const d = q('bb-form').querySelector(`:scope > .bb-sec[data-sec="${k}"]`);
    if (scroll && d) requestAnimationFrame(() => d.scrollIntoView({block: 'start'}));
  }
  function rebuildDirectSec(sec) {
    const open = new Set([...document.querySelectorAll('#bb-form .bb-sec[open]')].map(d => d.dataset.sec));
    build();
    document.querySelectorAll('#bb-form .bb-sec').forEach(d => { d.open = open.has(d.dataset.sec) || d.dataset.sec === sec; });
    const d = document.querySelector(`#bb-form .bb-sec[data-sec="${sec}"]`);
    if (d) requestAnimationFrame(() => d.scrollIntoView({block: 'start'}));
  }
  const openSec = k => { const d = document.querySelector(`#bb-form .bb-sec[data-sec="${k}"]`); if (d) d.open = true; };
  function grow(el) { if (el.classList.contains('bb-md-in')) return; if (!el.getClientRects().length) { el.style.height = ''; return; } el.style.height = 'auto'; el.style.height = Math.max(96, el.scrollHeight + 2) + 'px'; }
  function resizeFields() { document.querySelectorAll('#bb-form textarea').forEach(grow); }
  function flash(b) { const t = b.textContent; b.classList.add('copied'); b.textContent = '✓ Copied'; setTimeout(() => { b.classList.remove('copied'); b.textContent = t; }, 1500); }
  function flashSave(b) { const t = b.textContent; b.textContent = '✓ Saved'; b.disabled = true; setTimeout(() => { b.textContent = t; b.disabled = false; }, 1500); }
  function markEmpty() {
    let n = 0;
    document.querySelectorAll('#bb-form .bb-in[data-k]').forEach(el => { if (el.tagName === 'SELECT' || el.type === 'checkbox') return; const k = el.dataset.k; if (!/^(f\.|g\.|intro$|img\.|sc\.|h\.|n\.1$)/.test(k)) return; const empty = !String(el.value || '').trim(); el.classList.toggle('bb-empty', empty); if (empty) n++; });
    const b = q('bb-blanks'); if (b) { b.textContent = n ? `${n} empty box${n > 1 ? 'es' : ''} · show first` : ''; b.style.display = n ? '' : 'none'; }
  }
  function refresh() {
    reconcileEventSlot(B.spec, B.v);
    const c = compose(B.spec, B.v), res = check(B.spec, B.v, c);
    B.last = c; try { addWordingNotes(res); } catch (err) { console.warn('spelling check:', err && err.message); }
    { const en = eventTagName(), act = eventActiveFor(B.v); document.querySelectorAll('#bb-form .bb-tag.locked[data-evslot]').forEach(x => { const t = en || 'Event'; if (x.textContent !== t) x.textContent = t; x.style.display = act ? '' : 'none'; });
      document.querySelectorAll('#bb-form .bb-tag[data-tag]').forEach(b => b.classList.toggle('on', B.v.tags.includes(b.dataset.tag))); }
    let bad = 0, warn = 0;
    for (const k of B.spec.order) {
      const list = res[k] || [], nb = list.filter(x => x[0] === 'bad').length, nw = list.filter(x => x[0] === 'warn').length;
      bad += nb; warn += nw;
      const ul = document.querySelector(`[data-checks="${k}"]`); if (ul) ul.innerHTML = list.map(([lvl, m]) => `<li class="${lvl}">${lvl === 'ok' ? '✓' : lvl === 'warn' ? '•' : '!'} ${e(m)}</li>`).join('');
      const st = document.querySelector(`[data-state="${k}"]`); if (st) { st.className = 'bb-state ' + (nb ? 'bad' : 'ok'); st.textContent = nb ? `${nb} to fix` : '✓ ready'; }
      const ct = document.querySelector(`[data-count="${k}"]`);
      if (ct) { const pwA = k === 'scenario' ? policyAdd(B.v) : 0; const n = k === 'greeting' ? c.sec.greeting.prose.length : k === 'introduction' ? introVis(c.sec[k].body).length : ['personality', 'scenario'].includes(k) ? c.sec[k].body.length - pwA : null; const lim = (B.spec[k] || {}).limit || (k === 'greeting' ? B.spec.greeting.limit : null); const whole = n == null ? null : n + pwA, WT = lim ? withTol(lim) : null;   // the Scenario shows what the editor holds: the text plus the PolicyWeights block the app adds
        ct.textContent = n == null ? '' : `${pwA ? `${n.toLocaleString()} + ${pwA.toLocaleString()} PolicyWeights = ${whole.toLocaleString()}` : n.toLocaleString()}${lim ? ` / ${lim.min.toLocaleString()}–${lim.max.toLocaleString()}` : ''}`; ct.className = 'bb-count' + (lim && n != null ? ((n < WT.min || n > WT.max) && (!pwA || whole < WT.min || whole > WT.max) ? ' bad' : ' ok') : ''); }
      const pv = document.querySelector(`[data-preview="${k}"]`); if (pv) pv.textContent = c.sec[k].body;
      const pc = document.querySelector(`[data-pane-count="${k}"]`); if (pc && ct) { pc.textContent = k === 'greeting' ? `${c.sec.greeting.prose.length.toLocaleString()} chars` : ct.textContent.replace(/\s+/g, ' ').trim(); pc.classList.toggle('bad', ct.classList.contains('bad')); }
    }
    greetStrip(c, res.greeting || []);
    // the live preview next to the Introduction and the Greeting (display only: nothing here is added to the bot)
    try { if (window.LivePreview && typeof DOMParser !== 'undefined') {
      window.LivePreview.update('introduction', introPayload(c));
      window.LivePreview.update('greeting', c.sec.greeting.body);
      for (const k of B.spec.order) if (k !== 'introduction' && k !== 'greeting' && c.sec[k]) window.LivePreview.update(k, c.sec[k].body); } } catch (err) { console.warn('live preview:', err && err.message); }
    try { syncIvw(false); } catch (err) { console.warn('intro view:', err && err.message); }
    B.lastRes = res; try { renderNav(res); } catch (err) { console.warn('section list:', err && err.message); }
    if (res.total) bad += res.total.filter(x => x[0] === 'bad').length;
    q('bb-total').innerHTML = (res.total || []).map(([lvl, m]) => `<div class="${lvl}">${lvl === 'ok' ? '✓' : '!'} ${e(m)}</div>`).join('');
    if (res.total) warn += res.total.filter(x => x[0] === 'warn').length;
    // every thing to fix and every note, with the section it belongs to; click the bar to show or hide the list, click an item to jump to its section
    const issues = [];
    for (const k of B.spec.order) for (const [lvl, m] of (res[k] || [])) if (lvl === 'bad' || lvl === 'warn') issues.push({lvl, k, m});
    for (const [lvl, m] of (res.total || [])) if (lvl === 'bad' || lvl === 'warn') issues.push({lvl, k: '', m});
    issues.sort((a, b) => (a.lvl === 'bad' ? 0 : 1) - (b.lvl === 'bad' ? 0 : 1));
    const open = issues.length > 0;     // inside the collapsed Checks box the list is always shown
    const sb = q('bb-status');
    sb.className = 'bb-status ' + (bad ? 'bad' : 'ok') + (issues.length ? ' bb-status-click' : '');
    sb.textContent = (bad ? `${bad} thing${bad > 1 ? 's' : ''} to fix${warn ? ` · ${warn} note${warn > 1 ? 's' : ''}` : ''}` : `✓ All limits met${warn ? ` · ${warn} note${warn > 1 ? 's' : ''}` : ''}`) + (issues.length ? (open ? '  ▾' : '  ▸') : '');
    sb.title = issues.length ? (open ? 'Click to hide the list' : 'Click to see what needs fixing') : '';
    sb.setAttribute('role', issues.length ? 'button' : 'status'); sb.tabIndex = issues.length ? 0 : -1;
    const il = q('bb-issues');
    if (il) { il.hidden = !open; il.innerHTML = open ? issues.map(x => `<div class="bb-issue ${x.lvl}" role="button" tabindex="0" title="Click to copy this text" data-copy="${e((x.k ? (SEC_TITLE[x.k] || x.k) : 'Whole bot') + ': ' + x.m)}" ${x.k ? `data-sec="${x.k}"` : ''}><b>${x.lvl === 'bad' ? '!' : '•'} ${x.k ? e(SEC_TITLE[x.k] || x.k) : 'Whole bot'}</b>${e(x.m)}${x.k ? '<button type="button" class="bb-goto" data-goto title="Jump to this section">Go to section ›</button>' : ''}</div>`).join('') : ''; }
    B.last = c;
    q('bb-full').textContent = c.full;
    markEmpty(); renderTense();
  }
  async function rewriteSection(section, opts = {}) {
    if (!B.v || !B.spec || B.rewriteBusy) return;
    if (!window.AI_ON || !window.juicyApp.aiRewriteSection) return toast('Connect the AI writer in Settings before rewriting.', true);
    const SR = window.SectionRewrite;
    if (!SR) return toast('The section editor did not load. Restart the app.', true);
    if ((B.spec.missingLimits || []).includes(section)) return toast('Set the character limit for this section first.', true);
    const sourceId = B.v.sourceId;
    if (!sourceId) return toast('Fill from a scenario or load a saved bot before rewriting a section.', true);
    B.rewriteBusy = true;
    try {
      const snapshot = await window.juicyApp.getState();
      // Same lookup as Write with AI: every list in the week, including the Preventable and Post-NTR lanes, before the archive.
      const card = [...(snapshot.week?.scenarios || []), ...(snapshot.week?.ntr || []), ...(snapshot.week?.bonus || []), ...Object.keys(snapshot.week || {}).filter(k => k.startsWith('lane:')).flatMap(k => snapshot.week[k] || []), ...(snapshot.cardArchive || [])].find(c => c.id === sourceId);
      if (!card) throw new Error('The linked scenario card is no longer available.');
      const spec = B.spec, beforeValues = clone(B.v), before = compose(spec, clone(beforeValues)).sec[section].body;
      let plan = null, notes = '';
      if (section === 'greeting') {
        const previous = beforeValues.greetingPlan || (snapshot.builder?.greetingPlans || []).find(r => r.templateId === spec.id && r.cardId === sourceId)?.plan;
        // Continue after a stopped rewrite: the plan you chose (and your edits to its beats) was saved, so it is used as it is, without asking again.
        plan = opts.again && previous ? previous : await window.GreetingPlanner.open({card, spec, previous, rewrite: true, current: before, eventName: beforeValues.eventOn !== false && snapshot.event?.active ? snapshot.event.rulebook?.event || snapshot.event.parsed?.name || '' : ''});
        if (!plan) return; notes = plan.notes;
        // Saved as soon as it is chosen, not only after the result is approved, so a stopped or failed rewrite never loses the plan or the beat edits.
        if (window.juicyApp.builderSaveGreetingPlan) { try { await window.juicyApp.builderSaveGreetingPlan(spec.id, sourceId, plan); } catch {} }
      } else {
        const choice = await SR.ask({section, current: before, notes: beforeValues.rewriteNotes?.[section] || ''});
        if (!choice) return; notes = choice.notes;
      }
      const result = await window.aiRun(() => window.juicyApp.aiRewriteSection(spec.id, section, beforeValues, notes, plan), 'Rewriting ' + SEC_TITLE[section]);
      if (!result?.values) return;
      const modal = q('ai-modal'); if (modal) modal.style.display = 'none';
      const after = compose(spec, clone(result.values)).sec[section].body;
      const choice = await SR.review({section, before, after, warnings: result.warnings || []});
      if (!choice) {toast('Kept the current ' + SEC_TITLE[section] + '.'); return;}
      // Never apply a late result to a different card, template or bot version.
      if (B.spec.id !== spec.id || B.v.sourceId !== sourceId || B.v.botVariant !== beforeValues.botVariant) throw new Error('The selected bot changed during the rewrite. Its current text has been kept.');
      if (compose(B.spec, clone(B.v)).sec[section].body !== before) throw new Error('This section was edited while the AI was writing. Your newer text has been kept.');
      if (section === 'greeting' && plan && window.juicyApp.builderSaveGreetingPlan) await window.juicyApp.builderSaveGreetingPlan(spec.id, sourceId, plan);
      B.rewriteUndo = {section, values: clone(B.v), templateId: spec.id, sourceId, variant: B.v.botVariant};
      B.v = SR.merge(B.v, result.values, section);
      if (result.story) B.v.story = result.story;     // the Story engine topics this rewrite used
      if (B.pair?.[B.variant]) B.pair[B.variant].v = B.v; // Same bot, not a new source: preserve the other version.
      save(); build(); const panel = document.querySelector(`#bb-form .bb-sec[data-sec="${section}"]`); if (panel) {panel.open = true; panel.scrollIntoView({block:'nearest'});}
      toast(SEC_TITLE[section] + ' rewritten. Other sections are unchanged. Save to card to update its saved copy.');
      if (section === 'image') offerKeywords('The AI wrote this Image Generation section as sentences.');
      if (section === 'introduction' || section === 'greeting') offerAge(`The AI rewrote the ${SEC_TITLE[section]}.`);
    } catch (err) { console.error(err); toast(err.message || 'The section could not be rewritten.', true); }
    finally { B.rewriteBusy = false; }
  }
  function undoRewrite(section) {
    const u = B.rewriteUndo;
    if (!u || u.section !== section || u.templateId !== B.spec?.id || u.sourceId !== B.v?.sourceId || u.variant !== B.v.botVariant) return;
    B.v = window.SectionRewrite.merge(B.v, u.values, section); B.rewriteUndo = null;
    if (B.pair?.[B.variant]) B.pair[B.variant].v = B.v;
    save(); build(); const panel = document.querySelector(`#bb-form .bb-sec[data-sec="${section}"]`); if(panel) panel.open = true;
    toast('Restored the previous ' + SEC_TITLE[section] + '. Other sections were kept.');
  }
  function flushPendingSave() {
    clearTimeout(B.saveT);
    if (!B.pendingSave) return;
    const {id, values} = B.pendingSave; B.pendingSave = null;
    window.juicyApp.builderSaveDraft(id, values).catch(err => { console.error(err); toast('Draft could not be saved: ' + err.message, true); });
  }
  function save() {
    normalizeIdentity(B.spec, B.v); rememberActive();
    let id = B.spec.id, values = clone(B.v);
    if (B.pair) {
      const main = B.pair.main, female = B.pair.female;
      id = main.spec.id; values = plainVariant(main.v); values.activeVariant = B.variant;
      if (female) values.femaleVersion = {templateId: female.spec.id, values: plainVariant(female.v), sourceHash: female.sourceHash, baselineHash: female.baselineHash};
      B.drafts[id] = clone(values);
    } else B.drafts[id] = clone(values);
    B.lastTemplate = id;
    clearTimeout(B.saveT); B.pendingSave = {id, values}; B.saveT = setTimeout(flushPendingSave, 500);
  }
  function fillScenarioPicker() {
    const picker = q('bb-from'), selected = picker.value || B.v?.sourceId || '';
    const all = (typeof currentWeekAll === 'function' ? currentWeekAll() : []);
    picker.innerHTML = `<option value="">${all.length ? 'Start from a Weekly Blueprint scenario\u2026' : 'No weekly scenarios yet'}</option>` +
      all.map(card => `<option value="${e(card.id)}">${e(Identity.draftLabel(card, window.IS_SHARE === true))}</option>`).join('');
    if ([...picker.options].some(o => o.value === selected)) picker.value = selected;
  }
  function prepareValues(spec, saved) {
    const v = Object.assign(blank(spec), saved ? clone(saved) : {});
    while (v.greet.length < spec.greeting.count) v.greet.push(''); v.greet.length = spec.greeting.count;
    while (v.scenes.length < spec.greeting.count) v.scenes.push({name: '', shot: spec.scene.shotPrefix, setting: '', action: ''}); v.scenes.length = spec.greeting.count;
    normalizeIdentity(spec, v); if (spec.rules && spec.rules.hasName2) settleName2(spec, v); return v;
  }
  // NTR cards have four dedicated bot templates: Emotional (8), Misunderstanding (9), Light (11) and Emotional Post-NTR (12). The card's type decides which one fits.
  const NC0 = window.NtrCanon || {};
  const NTR_TYPE_BY_DAY = NC0.TYPE_BY_DAY || {Monday: 'emotional', Thursday: 'misunderstanding', Saturday: 'light', Sunday: 'emotionalpost'};
  const NTR_TYPE_NAME = NC0.NAME || {emotional: 'Emotional NTR', misunderstanding: 'Misunderstanding NTR', light: 'Light NTR', emotionalpost: 'Emotional Post-NTR'};
  function cardNtrType(card) {
    if (!card || !Identity.isNtrCard(card)) return '';
    if (/preventable|post[\s_-]*ntr/i.test(`${card.laneTab || ''} ${card.series || ''} ${card.lane || ''}`)) return '';      // Preventable NTR and Post-NTR cards have their own templates
    const t = NC0.typeKey ? NC0.typeKey((card.fields || {})['NTR Type']) : '';
    if (t) return t;
    const d = String(card.day || (card.fields || {})['Day Assignment'] || ''), k = Object.keys(NTR_TYPE_BY_DAY).find(x => new RegExp('\\b' + x + '\\b', 'i').test(d));
    return k ? NTR_TYPE_BY_DAY[k] : '';
  }
  const templateNtrType = spec => NC0.templateType ? NC0.templateType(spec && spec.raw) : '';
  // Open the template that matches the card. force: the card was just opened with "Build bot", so any other template is replaced; otherwise only the other NTR type is corrected.
  function ensureNtrTemplate(card, force) {
    const want = cardNtrType(card); if (!want) return '';
    const have = templateNtrType(B.spec); if (have === want || (!force && !have)) return '';
    const t = B.templates.find(x => !x.error && !x.unlisted && templateNtrType(x) === want); if (!t) return '';
    selectTemplate(t.id); save();
    return `Switched to the ${NTR_TYPE_NAME[want]} template for this ${card.day || 'NTR'} card.`;
  }
  function selectTemplate(id) {
    flushPendingSave(); B.editingOver = {}; B.fieldView = {}; B.passMode = false;
    let spec = B.templates.find(t => t.id === id && !t.error) || B.templates.find(t => !t.error && !t.unlisted) || B.templates.find(t => !t.error);
    if (!spec) { B.pair = null; B.spec = null; B.v = null; renderVariant(); renderTense(); { const th = q('bb-tense'), ed = document.querySelector('.bb-editor'); if (th && ed && th.parentNode !== ed) ed.insertBefore(th, q('bb-form')); } q('bb-form').innerHTML = '<div class="bb-empty-state"><h3>Add your bot templates to get started</h3><p>Click <b>+ Add</b> above and choose your template .txt files.</p></div>'; return; }
    let saved = B.drafts[spec.id], chosenFemale = null;
    if (saved?.botVariant === 'female' && saved.pairedOrigin) {
      const mainSpec = B.templates.find(t => t.id === saved.pairedOrigin.templateId && !t.error);
      if (mainSpec && isFuta(mainSpec)) { chosenFemale = {spec: variantSpec(spec, 'female'), v: prepareValues(variantSpec(spec, 'female'), saved)}; spec = mainSpec; saved = saved.pairedOrigin.values; }
    }
    B.pair = null; B.variant = 'main';
    spec = variantSpec(spec, isFuta(spec) ? 'futa' : saved?.botVariant === 'female' ? 'female' : '');
    B.spec = spec; B.v = prepareValues(spec, saved);
    if (isFuta(spec)) {
      B.pair = {main: {spec, v: B.v}, female: chosenFemale};
      if (!chosenFemale && saved?.femaleVersion) {
        const rec = saved.femaleVersion, fs = B.templates.find(t => t.id === rec.templateId && !t.error && !isFuta(t));
        if (fs) { const fSpec = variantSpec(fs, 'female'); B.pair.female = {spec: fSpec, v: prepareValues(fSpec, {...rec.values, botVariant: 'female'}), sourceHash: rec.sourceHash, baselineHash: rec.baselineHash}; }
      }
      if (B.pair.female && (chosenFemale || saved?.activeVariant === 'female')) { B.variant = 'female'; B.spec = B.pair.female.spec; B.v = B.pair.female.v; }
    }
    q('bb-template').value = B.spec.id; if (window.__bbTplInfo) window.__bbTplInfo(); build();
  }

  // the locked quality and negative prompts were changed in Settings: take the new ones into every template the Builder holds, keep everything typed
  window.refreshImageLocks = async () => {
    if (!B.templates) return;
    try {
      const fresh = await window.juicyApp.builderTemplates();
      const specs = [...B.templates, B.spec, B.pair && B.pair.main && B.pair.main.spec, B.pair && B.pair.female && B.pair.female.spec].filter(Boolean);
      for (const s of specs) { const f = fresh.find(t => t.id === s.id); if (f && f.image && s.image) Object.assign(s.image, {quality: f.image.quality, negative: f.image.negative, qualityFromSettings: f.image.qualityFromSettings, negativeFromSettings: f.image.negativeFromSettings}); }
      if (B.spec && B.v) build();
    } catch (err) { console.error(err); }
  };
  async function loadList(pick) {
    B.templates = await window.juicyApp.builderTemplates();
    // only your own templates are listed, by their file names; two with the same name say which is which by date
    const listed = B.templates.filter(t => !t.unlisted || t.id === pick);      // a built-in one shows only while a saved bot made on it is open
    const label = t => { const dup = listed.filter(x => x.name === t.name).length > 1, d = t.updatedAt ? new Date(t.updatedAt).toLocaleDateString(undefined, {day: 'numeric', month: 'short'}) : '';
      return dup && d ? ` (${d})` : ''; };
    q('bb-template').innerHTML = listed.map(t => `<option value="${e(t.id)}" ${t.error ? 'disabled' : ''}>${e(t.name)}${label(t)}${t.error ? ' (could not read)' : ''}</option>`).join('');
    if (pick && !B.templates.some(t => t.id === pick)) pick = '';
    selectTemplate(pick || (listed.some(t => t.id === B.lastTemplate) ? B.lastTemplate : (listed[0] && listed[0].id) || ''));
    if (window.__bbTplInfo) window.__bbTplInfo();
  }

  // closeable "what changed" box: a template was updated or added (Replace, + Add) or a built-in one changed with an app update
  const tplLogText = l => [`${l.name}: what changed${l.from ? ` (${l.from})` : ''}`, l.summary, '', ...(l.sections && l.sections.length ? ['Sections: ' + l.sections.join('; '), ''] : []),
    ...(l.entries || []).flatMap(e => { const d = e.diff || {}, m = d.more || {}, more = (m.added || 0) + (m.removed || 0) + (m.changed || 0);
      return [`${e.title}${e.kind === 'changed' ? '' : ` (${e.kind === 'added' ? 'new section' : 'section removed'})`}`, ...(d.changed || []).map(c => '  ~ ' + (c.parts || []).map(([op, t]) => op === 0 ? t : op < 0 ? `[-${t.trim()}-] ` : `{+${t.trim()}+} `).join('').replace(/\s+/g, ' ').trim()),
        ...(d.added || []).map(x => '  + ' + x), ...(d.removed || []).map(x => '  - ' + x), ...(more ? [`  ...and ${more} more`] : []), '']; })].join('\n').trim();
  async function showTplLogs() {
    const host = q('bb-tpl-log'); if (!host) return;
    let logs = []; try { logs = await window.juicyApp.builderTemplateLogs(); } catch {}
    if (!logs.length) { host.hidden = true; host.innerHTML = ''; return; }
    const E = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
    const what = {updated: 'Updated', builtin: 'Updated', added: 'Added'};
    host.hidden = false;
    host.innerHTML = `<div class="bb-tl-head"><b>Template changes</b><span class="micro">Green = words put in, <del>red</del> = words taken out. A line marked + is new, &minus; was removed, ~ was reworded.</span>${logs.length > 1 ? '<button class="ghost sm" data-tl-all>Close all</button>' : ''}</div>` +
      logs.map(l => `<div class="bb-tl-item" data-tl="${E(l.id)}"><div class="bb-tl-top"><span><b>${E(l.name)}</b> <em>${what[l.kind] || 'Updated'}${l.from ? ` · ${E(l.from)}` : ''}</em></span><span><button class="ghost sm" data-tl-copy="${E(l.id)}">Copy change log</button><button class="ghost sm" data-tl-close="${E(l.id)}">Close</button></span></div>
        <p class="bp-sum">${E(l.summary)}</p>${l.sections && l.sections.length ? `<p class="micro">${l.sections.map(E).join(' · ')}</p>` : ''}${typeof bpEntryHtml === 'function' ? (l.entries || []).map(e => bpEntryHtml(e, e.title).replace('<details class="bp-log" open>', (l.entries || []).length > 4 ? '<details class="bp-log">' : '<details class="bp-log" open>')).join('') : ''}</div>`).join('');
    host.querySelectorAll('[data-tl-close]').forEach(b => b.onclick = async () => { try { await window.juicyApp.builderCloseTemplateLog(b.dataset.tlClose); } catch {} showTplLogs(); });
    const all = host.querySelector('[data-tl-all]'); if (all) all.onclick = async () => { try { await window.juicyApp.builderCloseTemplateLog('all'); } catch {} showTplLogs(); };
    host.querySelectorAll('[data-tl-copy]').forEach(b => b.onclick = async () => { const l = logs.find(x => x.id === b.dataset.tlCopy); if (!l) return; try { await navigator.clipboard.writeText(tplLogText(l)); toast('Change log copied.'); } catch { toast('Could not copy.', true); } });
  }
  window.__bbTplLogs = showTplLogs;

  window.initBuilder = async function () {
    showTplLogs();
    B.drafts = JSON.parse(JSON.stringify(state?.builder?.drafts || {})); B.lastTemplate = state?.builder?.lastTemplate || '';
    q('bb-template').onchange = () => { selectTemplate(q('bb-template').value); save(); };
    let tplSeq = 0;
    const tplInfo = async () => { const my = ++tplSeq; try { const i = await window.juicyApp.builderTemplateInfo(B.spec?.id); if (my !== tplSeq) return; q('bb-tpl-info').innerHTML = i.replaced ? `Your updated version${i.updatedAt ? ` (${new Date(i.updatedAt).toLocaleDateString()})` : ''} · <a href="#" id="bb-restore">use the original</a>` : i.yours ? 'Added by you' : ''; const r = q('bb-restore'); if (r) r.onclick = async e => { e.preventDefault(); if (!confirm('Go back to the template that came with the tool?')) return; const x = await window.juicyApp.builderRestore(B.spec.id); if (!x.restored) return toast(x.reason, true); await loadList(B.spec.id); toast('Back to the original template.'); }; } catch { q('bb-tpl-info').textContent = ''; } };
    window.__bbTplInfo = () => tplInfo();
    q('bb-remove').onclick = async () => {
      const t = B.spec; if (!t) return toast('Pick a template first.', true);
      const msg = t.source === 'yours'
        ? (t.replacesBuiltIn ? `Delete your version of "${t.name}"? It's deleted permanently, and the built-in version comes back in its place.` : `Delete "${t.name}"? The template file is deleted permanently.`)
        : `Remove the built-in "${t.name}" from your list? (Built-in templates come with the app, so an update would bring the file back; this keeps it off your list.)`;
      if (!confirm(msg)) return;
      try { const r = await window.juicyApp.builderRemove(t.id); await loadList(r.removed === 'yours' && r.builtInReturns ? t.id : '');
        toast(r.removed === 'hidden' ? `"${t.name}" is off your list.` : r.builtInReturns ? `Deleted your version. "${t.name}" is back to the built-in one.` : `Deleted "${t.name}".`); }
      catch (err) { toast(err.message, true); }
    };
    q('bb-replace').onclick = async () => {
      if (!B.spec) return toast('Pick a template first.', true);
      if (!confirm(`Replace "${B.spec.name}" with your updated file? Your drafts for it are kept. (You can go back to the original afterwards.)`)) return;
      try { const r = await window.juicyApp.builderReplace(B.spec.id); if (!r.replaced) return; await loadList(r.id); showTplLogs(); toast(`"${B.spec.name}" now uses ${r.from}. Every box, limit and rule comes from the new file.`); }
      catch (err) { toast(err.message, true); }
    };
    q('bb-import').onclick = async () => { try { const r = await window.juicyApp.builderImport(); if (r?.added?.length) { await loadList(r.added[0]); showTplLogs(); toast(`Added template: ${r.added.join(', ')}`); } if (r?.errors?.length) toast(r.errors.join(' · '), true); } catch (err) { toast(err.message, true); } };
    q('bb-fill').onclick = () => {
      const s = currentWeekAll().find(x => x.id === q('bb-from').value);
      if (!s) return toast('Pick a Weekly Blueprint scenario first.', true);
      const tplNote = ensureNtrTemplate(s, !!B.preselecting);
      if (Object.keys(B.v.f).length && !confirm('Replace what you have typed with a fresh draft from this scenario?')) return;
      const pov = B.v.pov, female = B.variant === 'female';
      if (B.pair) { B.spec = B.pair.main.spec; B.variant = 'main'; }
      const keepHtml = htmlIntro(B.v.intro) ? String(B.v.intro).trim() : null;           // an Introduction that is the user's own HTML (series tag included) is left exactly as it is
      B.v = prefill(B.spec, s); B.v.sourceId = s.id; B.v.pov = pov; B.v.intro = (window.NtrCanon && window.NtrCanon.topicTag(s)) || B.spec.introduction.prefix || ''; B.v.greet = B.v.greet.map(() => ''); autoComplete(B.spec, B.v, s);
      if (keepHtml) { B.v.intro = keepHtml; B.v.iAuto = null; (B.v.touched = B.v.touched || {}).intro = true; }
      applyPov(B.spec, B.v); save(); build();
      if (female && B.pair) switchVariant('female'); toast((tplNote ? tplNote + ' ' : '') + (B.v.castNote || 'Every box filled from the scenario and sized to the template limits. Edit anything you like; the checks update as you type.'), !!B.v.castNote);
      offerAge('The draft was filled from the scenario.');
    };
    q('bb-auto').onclick = () => {
      const source = currentWeekAll().find(x => x.id === (q('bb-from').value || B.v.sourceId));
      const s = source && B.v.botVariant === 'female' ? femaleCard(source) : source;
      autoComplete(B.spec, B.v, s || null); applyPov(B.spec, B.v); save(); build();
      toast(s ? 'Empty boxes filled and every section sized to its limit.' : 'Empty boxes filled from the names and details already here, and every section sized to its limit.');
      offerAge('The empty boxes were filled in.');
    };
    // ---- story brief for the chatbot you already use, and its reply
    const srcScenario = () => { const card = currentWeekAll().find(x => x.id === (q('bb-from').value || B.v.sourceId)) || null; return card && B.v.botVariant === 'female' ? femaleCard(card) : card; };
    q('bb-brief').onclick = async () => {
      const txt = window.StoryBrief.build(B.spec, B.v, srcScenario(), state);
      await window.copyText(txt); flash(q('bb-brief'));
      toast(srcScenario() ? 'Story brief copied. Paste it into ChatGPT, then paste its reply back here.' : 'Story brief copied. Tip: pick a scenario under "Draft from" first for a much richer brief.', !srcScenario());
      q('bb-story-box').open = true;
    };
    const useStory = fill => {
      const r = window.StoryBrief.parse(q('bb-story-text').value, B.spec);
      if (!r.paras.length && !r.intro) return toast('Nothing to use yet. Paste the chatbot\'s whole reply first.', true);
      const T = x => window.StoryBrief.tidy(x, B.spec), pre = B.spec.introduction.prefix || '';
      B.v.touched = B.v.touched || {};
      if (r.intro && !htmlIntro(B.v.intro)) {        // an Introduction that is the user's own HTML is not replaced and gets no series or template tag put in front
        // keep any series / template prefix already on the introduction ("[Bully Series 03]", "[NTR]")
        const had = (String(B.v.intro || '').match(/^((?:\[[^\]]+\]\s*)+)/) || [, ''])[1].trim();
        let i = T(r.intro).replace(/\{\{user\}\}/g, 'you');
        const sc = srcScenario(), series = !window.IS_SHARE && sc && SERIES_PREFIX.find(x => x === sc.series);
        const topic = sc && window.NtrCanon ? window.NtrCanon.topicTag(sc) : '';
        const want = topic || had || [series && !/Series/.test(pre) ? `[${series} 00]` : '', pre].filter(Boolean).join(' ');
        i = Identity.cleanIntroPrefix(i, want, sc && sc.series);        // a label the chatbot made up (an event's name, say) is not part of the Introduction
        if (want && !i.startsWith(want.split(' ')[0])) i = `${want} ${i}`;
        if (topic) i = window.NtrCanon.withTopic(i, topic);
        B.v.intro = i; B.v.touched.intro = true; B.v.iAuto = null;
      }
      r.paras.forEach((p, i) => { if (i < B.v.greet.length) { B.v.greet[i] = T(p); B.v.touched['g' + i] = true; if (B.v.gAuto) B.v.gAuto[i] = null; } });
      if (fill) autoComplete(B.spec, B.v, srcScenario());
      applyPov(B.spec, B.v);
      save(); build();
      const miss = r.found.paragraphs < r.found.expected ? ` Only ${r.found.paragraphs} of ${r.found.expected} paragraphs came through; the rest ${fill ? 'were filled in' : 'are still empty'}.` : '';
      toast(`Story placed: ${r.intro ? 'introduction and ' : ''}${Math.min(r.found.paragraphs, r.found.expected)} greeting paragraph${r.found.paragraphs === 1 ? '' : 's'}.${miss} Check the Greeting and Introduction sections for anything to adjust.`);
      offerAge('The story was placed.');
    };
    q('bb-story-use').onclick = () => useStory(false);
    q('bb-story-auto').onclick = () => useStory(true);
    q('bb-refit').onclick = () => { fitAll(B.spec, B.v); save(); build(); toast('Sections re-sized to the template limits.'); };
    { const sb = q('bb-status'), il = q('bb-issues');
      const toggle = () => { if (!sb.classList.contains('bb-status-click')) return; const open = il && !il.hidden; B.issuesOpen = !open; refresh(); };
      sb.onclick = toggle; sb.onkeydown = ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); toggle(); } };
      // clicking a check copies its text (drag over it to copy only part); "Go to section" jumps to the section it is about
      if (il) il.onclick = ev => { const b = ev.target.closest('.bb-issue'); if (!b) return; if (ev.target.closest('[data-goto]')) { if (!b.dataset.sec) return; const d = document.querySelector(`#bb-form .bb-sec[data-sec="${b.dataset.sec}"]`); if (d) { d.open = true; d.scrollIntoView({block: 'start', behavior: 'smooth'}); } return; } copyCheck(b, b.dataset.copy); };
      if (il) il.onkeydown = ev => { if (ev.key !== 'Enter' && ev.key !== ' ') return; const b = ev.target.closest('.bb-issue'); if (!b || ev.target !== b) return; ev.preventDefault(); copyCheck(b, b.dataset.copy); }; }
    // the other check lines (under each section, the totals) copy their text the same way
    if (!window.__bbCopyChecks) { window.__bbCopyChecks = true; document.addEventListener('click', ev => { const li = ev.target.closest && ev.target.closest('.bb-checks li, .bb-total > div, .bb-event li'); if (!li || ev.target.closest('button, a, input, select')) return; copyCheck(li, li.textContent.replace(/^\s*[✓!•]\s*/, '').trim()); }); }
    { const sp = q('bb-spell'); if (sp) sp.onclick = () => offerWording(true); }
    q('bb-blanks').onclick = () => { const el = document.querySelector('#bb-form .bb-empty'); if (!el) return; const d = el.closest('details.bb-sec'); if (d) d.open = true; el.scrollIntoView({block: 'center'}); el.focus(); };
    q('bb-clear').onclick = () => { if (!confirm('Clear everything in this template?')) return; const female = B.variant === 'female'; B.v = blank(B.spec); if (female) B.v.botVariant = 'female'; save(); build(); };
    { const ab = q('bb-ai'); if (ab) ab.onclick = () => { if ((B.spec.missingLimits || []).length) { renderLimits(); q('bb-limits').scrollIntoView({block: 'center'}); return toast(`Set the character limit for the ${B.spec.missingLimits.map(x => SEC_NAME[x]).join(', ')} first, so the AI knows how long to write.`, true); } window.aiWriteBot && window.aiWriteBot(B.spec.id, q('bb-from').value || B.v.sourceId, B.v.pov === 'user' ? 'user' : 'you', {botVariant:B.v.botVariant, narrativeTense:tenseForAi(B.v), story: B.v.story ? clone(B.v.story) : undefined, counterpart: (() => { const v=saveValues(); return {pairedOrigin:v.pairedOrigin,femaleVersion:v.femaleVersion}; })()}); }; }
    q('bb-pov').querySelectorAll('button').forEach(b => b.onclick = () => {
      const m = b.dataset.pov; if (b.disabled) return; B.v.pov = m; applyPov(B.spec, B.v); save(); build();
      const L = window.Pov ? window.Pov.locks(B.spec) : {};
      toast(m === 'user' ? `The narration now refers to the reader as {{user}}${L.intro || L.greet ? ` (${[L.intro && 'the Introduction', L.greet && 'the Greeting'].filter(Boolean).join(' and ')} stay${L.intro && L.greet ? '' : 's'} "you": ${[L.intro, L.greet].filter(Boolean).join(' ')})` : ''}. Dialogue still says "you".` : 'The narration now addresses the reader as "you / your".');
    });
    q('bb-saved').onchange = async () => {
      const key = q('bb-saved').value; const del = q('bb-saved-del'); if (del) del.style.display = key ? '' : 'none'; if (!key) return;
      try { const b = await window.juicyApp.builderLoadSavedBot(key); B.drafts[b.templateId] = Object.assign(JSON.parse(JSON.stringify(b.values)), {savedKey: key, sourceId: b.cardId}); selectTemplate(b.templateId); fillScenarioPicker(); if ([...q('bb-from').options].some(o => o.value === b.cardId)) q('bb-from').value = b.cardId; save(); toast(`Loaded "${b.sceneName}" (${b.templateName}), saved ${new Date(b.savedAt).toLocaleString(undefined, {month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit'})}.`); }
      catch (err) { toast(err.message, true); }
    };
    q('bb-saved-del').onclick = async () => { const key = q('bb-saved').value; if (!key) return toast('Choose the saved bot to delete in Saved bots first.', true); const name = q('bb-saved').selectedOptions[0]?.textContent || 'this saved bot'; if (!confirm(`Delete "${name}"? The bot in the Bot Builder stays as it is.`)) return; try { B.savedIndex = await window.juicyApp.builderDeleteSavedBot(key); if (B.v.savedKey === key) delete B.v.savedKey; await loadSaved(); save(); if (typeof window.dispatchEvent === 'function' && typeof Event === 'function') window.dispatchEvent(new Event('saved-bots-changed')); toast('Saved bot deleted.'); } catch (err) { toast(err.message, true); } };
    // Built: the same Built box the scenario card has in the Weekly Blueprint, set from here for the card this bot belongs to
    const builtTarget = () => (q('bb-from') && q('bb-from').value) || (B.v && B.v.sourceId) || '';
    async function syncBuilt() {
      const box = q('bb-built-check'), lab = q('bb-built'); if (!box || !lab) return;
      const id = builtTarget(); let on = false;
      if (id) { try { const st = await window.juicyApp.getState(); const s = (st.week && st.week.statuses || {})[id]; on = s === 'Built' || s === 'Published'; } catch {} }
      box.checked = on; lab.classList.toggle('on', on); lab.classList.toggle('off', !id);
      const mark = lab.querySelector('.bt-box'); if (mark) mark.textContent = on ? '✓' : '';
      lab.title = id ? 'Mark this bot as Built on its scenario card in the Weekly Blueprint (the same Built box as on the card)' : 'Choose the scenario card this bot belongs to in "Draft from" first.';
    }
    window.__builtSync = syncBuilt;
    { const box = q('bb-built-check'); if (box) box.onchange = async () => {
      const id = builtTarget();
      if (!id) { box.checked = false; syncBuilt(); return toast('Choose the scenario card this bot belongs to in "Draft from" first.', true); }
      const want = box.checked;
      try {
        const st = await window.juicyApp.setStatus(id, want ? 'Built' : 'Idea');
        window.dispatchEvent(new CustomEvent('card-status-changed', {detail: {state: st}}));
        const card = [...((st.week && st.week.scenarios) || []), ...((st.week && st.week.ntr) || []), ...((st.week && st.week.bonus) || []), ...(st.cardArchive || [])].find(c => c.id === id);
        toast(want ? `Marked "${card ? card.sceneName : 'the card'}" as Built in the Weekly Blueprint.${B.v.savedKey ? '' : ' It is not saved to the card yet: use Save to card to keep this bot.'}` : 'Unmarked: the card is back to Idea in the Weekly Blueprint.');
      } catch (err) { console.error(err); toast(err.message || 'Could not change the Built mark.', true); }
      syncBuilt();
    }; }
    { const from = q('bb-from'); if (from) from.addEventListener('change', syncBuilt); }
    window.addEventListener('card-status-changed', () => syncBuilt());
    { const nav = document.querySelector('.nav-btn[data-view="builder"]'); if (nav) nav.addEventListener('click', () => setTimeout(syncBuilt, 50)); }
    setTimeout(syncBuilt, 0);
    q('bb-savecard').onclick = async () => {
      // the card chosen in "Draft from" is where it goes; otherwise the card it was filled from
      const target = q('bb-from').value || B.v.sourceId;
      if (!target) return toast('Choose the scenario card this bot belongs to in "Draft from" first.', true);
      const previous = B.v.savedKey || '';
      B.v.sourceId = target;
      try {
        const r = await window.juicyApp.builderSaveBot(B.spec.id, saveValues(), compose(B.spec, B.v).full);
        B.v.savedKey = r.key; B.savedIndex = r.saved;
        const b = r.saved.find(x => x.key === r.key), old = previous && previous !== r.key ? r.saved.find(x => x.key === previous) : null;
        if (old && confirm(`Saved to "${b ? b.sceneName : 'the card'}". This bot was also saved to "${old.sceneName}" before. Remove that earlier save?`)) B.savedIndex = await window.juicyApp.builderDeleteSavedBot(previous);
        await loadSaved(r.key); save();
        toast(`Saved to "${b ? b.sceneName : 'the card'}"${b && b.day && b.day !== 'Bonus' ? ` (${b.day})` : ''}. Load it from Saved bots, or from the card in the Weekly Blueprint.`);
        if (typeof window.dispatchEvent === 'function' && typeof Event === 'function') window.dispatchEvent(new Event('saved-bots-changed'));
      } catch (err) { toast(err.message, true); }
    };
    window.juicyApp.builderSavedBots().then(l => { B.savedIndex = l; loadSaved(); if (typeof window.dispatchEvent === 'function' && typeof Event === 'function') window.dispatchEvent(new Event('saved-bots-changed')); }).catch(() => {});
    (function () {
      const pre = q('bb-full'), btn = q('bb-enlarge');
      if (!pre || !btn) return;
      const set = (on) => { pre.classList.toggle('big', on); btn.textContent = on ? '✕ Close' : '⤢ Enlarge'; if (on) btn.style.cssText = 'position:fixed;top:calc(4vh + 8px);right:calc(4vw + 14px);z-index:61'; else btn.style.cssText = ''; };
      btn.onclick = () => set(!pre.classList.contains('big'));
      pre.ondblclick = () => set(!pre.classList.contains('big'));
      document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && pre.classList.contains('big')) set(false); });
    })();
    q('bb-build-intro').onclick=()=>openIntroductionDesigner();
    q('bb-copy').onclick = async () => { await window.copyText(compose(B.spec, B.v).full); flash(q('bb-copy')); toast(B.variant === 'female' ? 'Female version copied.' : 'Full bot copied.'); };
    q('bb-savetxt').onclick = async () => { try { const full = compose(B.spec, B.v).full; const path = await window.juicyApp.builderExport(`${B.v.header.scene || B.v.names[1] || 'Bot'}.txt`, full); if (path) toast('Saved: ' + path); } catch (err) { toast(err.message, true); } };
    q('bb-upload').onclick = async () => {
      try {
        const file = await window.juicyApp.builderOpenBot();
        if (!file || !file.text) return;
        const parsed = parseBuiltBot(file.text);
        if (!parsed.found) return toast('That file has no Introduction, Personality, Scenario or Greeting section to load.', true);
        const dirty = (B.v.intro || '').trim() || (B.v.greet || []).some(x => String(x || '').trim()) || (B.v.over && Object.keys(B.v.over).length);
        if (dirty && !confirm(`Replace the sections in this template with "${file.name}"?`)) return;
        const notes = applyBuiltBot(parsed) || [];
        if (B.variant === 'female') B.femaleTouched = true;
        save(); build();
        toast(`Loaded ${parsed.found} section${parsed.found === 1 ? '' : 's'} from ${file.name}.${notes.length ? ' ' + notes.join(' ') : ''}`, !!notes.length);
        offerAge(`The file "${file.name}" was loaded.`);
      } catch (err) { toast(err.message, true); }
    };
    // any code that opens a section (jump from a problem, rewrite, edit directly) makes it the one shown
    new MutationObserver(ms => { const form = q('bb-form'); if (!form || form.classList.contains('bb-all')) return; for (const m of ms) { const d = m.target; if (d && d.classList && d.classList.contains('bb-sec') && d.open && d.dataset.sec !== B.activeSec) { setActive(d.dataset.sec, true); break; } } })
      .observe(q('bb-form'), {attributes: true, attributeFilter: ['open'], subtree: true});
    q('bb-nav').addEventListener('click', ev => {
      const cb = ev.target.closest('[data-navcopy]');
      if (cb) { ev.preventDefault(); copySection(cb.dataset.navcopy).then(ok => { if (ok) { cb.classList.add('copied'); cb.textContent = '\u2713'; setTimeout(() => { cb.classList.remove('copied'); cb.textContent = '\u29c9'; }, 1200); } }); return; }
      const t = ev.target.closest('[data-navtool]'), n = ev.target.closest('[data-nav]');
      if (t && t.dataset.navtool === 'all') { const f = q('bb-form'), on = f.classList.toggle('bb-all'); if (on) f.querySelectorAll(':scope > .bb-sec').forEach(d => { d.open = true; }); else applyActive(); renderNav(B.lastRes || {}); return; }
      if (t && t.dataset.navtool === 'side') { const L = document.querySelector('.bb-layout'), on = L.classList.toggle('bb-focus'); try { localStorage.setItem('jbs.bbFocus2', on ? '1' : '0'); } catch { /* ignore */ } renderNav(B.lastRes || {}); return; }
      if (n) setActive(n.dataset.nav, true);
    });
    try { if (localStorage.getItem('jbs.bbFocus2') === '0') document.querySelector('.bb-layout').classList.remove('bb-focus'); } catch { /* ignore */ }
    await loadList();
  };
  // Only the editor has a real browser window. The background AI runner loads
  // this same core without DOM window methods and saves its own job checkpoints.
  if (typeof window.addEventListener === 'function') window.addEventListener('beforeunload', flushPendingSave);
  window.builderOnShow = () => { fillScenarioPicker(); requestAnimationFrame(resizeFields); };
  // a bot the AI writer finished: open it in its template
  window.builderLoadDraft = (id, values) => { if (values) B.drafts[id] = JSON.parse(JSON.stringify(values)); selectTemplate(id); { const sid = B.v && B.v.sourceId; fillScenarioPicker(); const from = q('bb-from'); if (sid && from && [...from.options].some(o => o.value === sid)) from.value = sid; if (typeof window.__builtSync === 'function') window.__builtSync(); } toast('The AI-written bot is in the Bot Builder. Read it through, then copy it as usual.'); setTimeout(async () => { await offerKeywords('The AI wrote this bot\'s Image Generation as sentences.'); offerAge('The AI wrote this bot.'); }, 600); };
  window.builderPreselect = id => { fillScenarioPicker(); q('bb-from').value = id; if (B.spec && q('bb-fill')) { B.preselecting = true; try { q('bb-fill').onclick(); } finally { B.preselecting = false; } } else toast('Pick a template, then click Fill from scenario.'); };
  // "Build Bot" on a Weekly Blueprint card: pick the template (the best match for the card is already selected), then straight to the AI writing window (Choose the story, then plan the Greeting, then write). Nothing is composed locally.
  // The template that fits a card: a dedicated template for its type if you have one (ANTI-NTR, Preventable NTR, Post-NTR, Futa, or the NTR tab's Emotional, Misunderstanding, Light or Emotional Post-NTR), otherwise the one used last in the Bot Builder.
  const templateKindOfCard = card => {
    const s = [card.series, card.seriesLabel, card.slot, card.laneTab, card.lane, card.type].filter(Boolean).join(' ');
    if (/anti[- ]?ntr/i.test(s)) return 'anti';
    if (/\bcrush series\b/i.test(s)) return 'crush';
    if (/preventable/i.test(s)) return 'preventable';
    if (/post[- ]?ntr/i.test(s)) return 'post';
    if (/futa/i.test(s)) return 'futa';
    return '';
  };
  const TEMPLATE_KIND_RE = {anti: /anti[- ]?ntr/i, crush: /\bcrush\b/i, preventable: /preventable/i, post: /^(?!.*emotional[\s_-]*post).*post[\s_-]?ntr/i, futa: /futa/i};
  const bestTemplateFor = (card, usable) => {
    const ntr = cardNtrType(card), kind = templateKindOfCard(card);
    // the plain NTR card also fits your NTR template when it has no type lock yet ("6. PigeonGuy Template NTR ..."): NTR in its name and nothing else
    const plainNtr = x => !templateNtrType(x) && /\bntr\b/i.test(x.name || x.id) && !/anti|preventable|post|light|emotional|misunderstand/i.test(x.name || x.id);
    return (ntr && usable.find(x => templateNtrType(x) === ntr)) || (ntr === 'full' && usable.find(plainNtr)) || (kind && usable.find(x => TEMPLATE_KIND_RE[kind].test(x.name || x.id))) || usable.find(x => x.id === B.lastTemplate) || usable[0];
  };
  const pickTemplateDialog = (card, usable, best) => new Promise(res => {
    const root = document.createElement('div'); root.className = 'upd-modal sr-modal'; root.id = 'bb-template-modal';
    root.innerHTML = `<section class="upd-box sr-box" role="dialog" aria-modal="true" tabindex="-1"><header><h3>Build "${e(card.sceneName || 'this card')}" on which template?</h3><p>The best match for this card is selected. Click Next to use it, or choose another template.</p></header>
      <div class="sr-body">${usable.map(x => `<label class="bb-check"><input type="radio" name="bb-tpl" value="${e(x.id)}" ${x.id === best.id ? 'checked' : ''}> ${e(x.name || x.id)}${x.id === best.id ? ' <b>(best match)</b>' : ''}</label>`).join('')}</div>
      <footer><span class="micro">Next: choose the story, then plan the Greeting. Nothing is sent to the AI yet.</span><div class="button-row"><button type="button" class="ghost" id="bbt-cancel">Cancel</button><button type="button" class="primary" id="bbt-go">Next</button></div></footer></section>`;
    document.body.appendChild(root);
    const done = v => { root.remove(); res(v); };
    root.querySelector('#bbt-cancel').onclick = () => done(null);
    root.querySelector('#bbt-go').onclick = () => { const r = root.querySelector('input[name=bb-tpl]:checked'); done(r ? r.value : best.id); };
    root.addEventListener('keydown', ev => { if (ev.key === 'Escape') done(null); });
    root.querySelector('.sr-box').focus();
  });
  window.builderBuildWithAI = async id => {
    try {
      const usable = (B.templates || []).filter(x => !x.error && !x.unlisted);
      if (!usable.length) return toast('Add your bot templates in the Bot Builder first.', true);
      const snap = await window.juicyApp.getState(), wk = snap.week || {};
      const card = [...(wk.scenarios || []), ...(wk.ntr || []), ...(wk.bonus || []), ...Object.keys(wk).filter(k => k.startsWith('lane:')).flatMap(k => wk[k] || []), ...(snap.cardArchive || [])].find(c => c.id === id);
      if (!card) return toast('That scenario card is no longer available.', true);
      const best = bestTemplateFor(card, usable);
      const chosen = usable.length > 1 ? await pickTemplateDialog(card, usable, best) : best.id;
      if (!chosen) return;
      const tpl = usable.find(x => x.id === chosen) || best;
      if ((tpl.missingLimits || []).length) {
        selectTemplate(tpl.id); if (typeof switchView === 'function') switchView('builder'); renderLimits();
        return toast(`Set the character limit for the ${tpl.missingLimits.map(x => SEC_NAME[x]).join(', ')} first, so the AI knows how long to write.`, true);
      }
      const saved = (B.drafts && B.drafts[tpl.id]) || {};
      window.aiWriteBot && window.aiWriteBot(tpl.id, id, saved.pov === 'user' ? 'user' : 'you', {narrativeTense: tenseForAi(saved)});
    } catch (err) { toast(err.message || 'Build Bot could not start.', true); }
  };
  window.builderRewriteSection = (section, opts) => rewriteSection(section, opts);
  window.__builderCore = {refreshStaleBoxes, withTol, compose, check, blank, prefill, autoFormat, autoComplete, fitAll, fitPolicy, closestArchetype, deFutaProse, deFutaList, isFuta, futaLead, normalizeIdentity, variantSpec, prepareValues, femaleCard, buildFemale, switchVariant, selectTemplate, fillScenarioPicker, saveValues, changeTense, renderTense, rewriteSection, undoRewrite, renderEvent, state: B, offerKeywords, keywordChanges, offerAge, ageFindings, appearanceUsable, aiAppearance, checkAppearance, build};   // for tests
})();
