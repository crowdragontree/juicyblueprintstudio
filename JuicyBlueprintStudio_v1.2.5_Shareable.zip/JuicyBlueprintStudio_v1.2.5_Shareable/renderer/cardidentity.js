/* Card and bot identity rules. Shared by Node and the renderer. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CardIdentity = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  const PREFIX = {futa: '[Male/Female POV | Futa Bot]', female: '[Female Bot]'};
  const SUFFIX = {futa: ' [Futa]', female: ' [Female]'};
  const stripSuffix = title => String(title || '').replace(/(?:\s*\[(?:futa|female)\])+\s*$/i, '').trim();
  function sceneName(title, variant, max = 30) {
    const base = stripSuffix(title), suffix = SUFFIX[variant] || '';
    if (!base) return '';
    const limit = Math.max(0, max - suffix.length);
    // Do not split a Unicode surrogate pair. The UI uses JS character counts.
    let out = '';
    for (const ch of base) { if (out.length + ch.length > limit) break; out += ch; }
    if (out.length < base.length && /\S/.test(base[out.length] || '') && /\s/.test(out)) out = out.replace(/\s+\S*$/, '');
    return out.trimEnd() + suffix;
  }
  function introduction(text, variant) {
    if (!PREFIX[variant]) return String(text || '').trim();
    if (/<\/?(?:div|p|span|br|img|a|b|i|u|em|strong|h[1-6]|ul|ol|li|table|tr|td|center|font|section|article|hr|style|small|blockquote)\b[^>]*>/i.test(String(text || ''))) return String(text || '').trim();   // the Introduction is the user's own HTML: its tags are already in it, nothing is put in front
    let body = String(text || '').trim();
    const leading = (body.match(/^(?:\[[^\]]*\]\s*)+/) || [''])[0];
    const tags = (leading.match(/\[[^\]]*\]/g) || []).filter(t =>
      !/\b(futa(?:nari)?|female\s+bot|any\s+pov|male\s*\/\s*female\s+pov)\b/i.test(t));
    body = body.slice(leading.length).trim();
    return [PREFIX[variant], ...new Set(tags), body].filter(Boolean).join(' ');
  }
  // The Introduction's leading [labels]: only the template's own prefix, the card's own series label and the Futa/Female markers belong there.
  // A label the AI made up (for example the event's name written as "[Monsters Next Door 00]") is removed; nothing else is touched.
  const LEAD = /^(?:\s*\[[^\]\n]*\])+/;
  const norm = g => String(g || '').toLowerCase().replace(/\s+/g, ' ').trim();
  const VARIANT = /\b(futa(?:nari)?|female\s+bot|any\s+pov|male\s*\/\s*female\s+pov)\b/i;
  function cleanIntroPrefix(text, introPre, seriesName) {
    const t = String(text || ''), lead = (t.match(LEAD) || [''])[0];
    if (!lead) return t;
    const own = new Set(((String(introPre || '').match(/\[[^\]\n]*\]/g)) || []).map(norm));
    const sn = String(seriesName || '').replace(/\s+series$/i, '').trim().toLowerCase();
    const ok = g => own.has(norm(g)) || VARIANT.test(g) || (sn && new RegExp(`^\\[\\s*(?:"?${sn.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}"?)\\s+series(?:\\s+\\d+)?\\s*\\]$`, 'i').test(g.trim()));
    const keep = (lead.match(/\[[^\]\n]*\]/g) || []).filter(ok);
    const rest = t.slice(lead.length).replace(/^\s+/, '');
    return keep.length ? `${keep.join(' ')} ${rest}`.trim() : rest;
  }
  function isFutaCard(card) {
    if (!card) return false;
    const F = card.fields || {}, main = (card.cast || []).find(c => c.role === 'Primary');
    return card.futa === true || /\[futa\]\s*$/i.test(card.sceneName || '') ||
      /^Futa Friday(?: Series)?$/i.test(card.series || '') ||
      /^(?:yes|true|futa(?:nari)?)\b/i.test(String(F['Primary Character Futanari'] || F['Futanari Marker'] || '')) ||
      /\bfuta(?:nari)?\b/i.test(main?.gender || '') ||
      (card.tags || []).some(t => /^futa(?:nari)?$/i.test(t));
  }
  function normalizeCard(card) {
    if (!isFutaCard(card)) return card;
    card.sceneName = sceneName(card.sceneName || card.fields?.['Scene Name'], 'futa');
    card.fields = card.fields || {}; card.fields['Scene Name'] = card.sceneName;
    return card;
  }
  function isNtrCard(card) {
    return /^(?:NTR|Likeable NTR)$/i.test(card?.day || '') || /^NTR\b/i.test(card?.slot || '') ||
      /^(?:Likeable NTR|NTR)(?: Series)?$/i.test(card?.series || '');
  }
  function draftLabel(card, share) {
    let label = '';
    if (!share) {
      if (isNtrCard(card)) label = '[NTR] ';
      else if (/^ANTI-NTR\b/i.test(card.series || '')) label = '[ANTI-NTR] ';
      else if (/^Preventable-NTR\b/i.test(card.series || '')) label = '[Preventable-NTR] ';
    }
    return label + [card.day || '', `${card.sceneName || 'Untitled'} (${card.primaryCharacter || ''})`].filter(Boolean).join(' \u00b7 ');
  }
  return {PREFIX, SUFFIX, stripSuffix, sceneName, introduction, cleanIntroPrefix, isFutaCard, normalizeCard, isNtrCard, draftLabel};
});
