/* The character's race, read from the card, so it can be seen at a glance. Shared by Node and the renderer.
   A card has no Race row of its own, so the race comes from what the card says about HER: an explicit Race/Species field or weekly trait first, then her
   Appearance, Figure, Nude Appearance, Personality and image fields, then the Tags, then the Setup and title. A word that has other meanings (siren, angel,
   ghost, troll, alien, robot) only counts when it is used as a kind of person ("a siren", "angel-born", "ghost woman"). With no race named, a card whose text calls
   her a monster or creature shows "Non-human"; any other card shows "Human". */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CardRace = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  const KIND = '(?:woman|girl|anthro|queen|maiden|lady|princess|monster|spirit|creature|-born|-blooded|-kin|-like)';
  const strict = w => new RegExp(`\\b(?:an?|half|part)[- ]${w}\\b|\\b${w}[- ]?${KIND}`, 'i');
  const RACES = [
    ['Werewolf', /\b(werewol(?:f|ves)|lycanthrop\w*|lycans?|wolf[- ]?girl|wolf anthro|were-?wolf)\b/i],
    ['Vampire', /\b(vampires?|vampiric|dhampir)\b/i],
    ['Kitsune', /\b(kitsune|fox spirit|nine-tailed)\b/i],
    ['Kemonomimi', /\b(kemonomimi|kemono[- ]?mimi|(?:cat|fox|wolf|dog|rabbit|bunny|bear|deer|cow|tiger|fennec|mouse|sheep|animal)[- ]eared|animal ears)\b/i],
    ['Catgirl', /\b(cat[- ]?girl|nekomimi|catfolk|feline anthro|panther anthro|lioness|tigress)\b/i],
    ['Succubus', /\b(succub(?:us|i)|incub(?:us|i))\b/i],
    ['Demon', /\b(demons?|demoness|imps?)\b/i],
    ['Tiefling', /\btieflings?\b/i],
    ['Angel', strict('(?:angels?|seraphs?|seraphim|nephilim|valkyrie)')],
    ['Dragon', /\b(dragons?|dragonkin|dragon-?born|dragonborn)\b/i],
    ['Lamia', /\b(lamia|naga|snake[- ]?girl|lizard(?:folk|[- ]?girl)|reptilian)\b/i],
    ['Mermaid', /\b(mermaids?|merfolk|selkies?)\b/i],
    ['Siren', strict('sirens?')],
    ['Harpy', /\bharp(?:y|ies)\b/i],
    ['Gorgon', /\b(gorgons?|medusa)\b/i],
    ['Minotaur', /\bminotaurs?\b/i],
    ['Centaur', /\bcentaurs?\b/i],
    ['Satyr', /\b(satyrs?|fauns?|dryads?|nymphs?)\b/i],
    ['Orc', /\b(orcs?|half-orc|orcish|uruk)\b/i],
    ['Elf', /\b(elf|elves|elven|elvish|half-elf|dark elf|high elf|wood elf)\b/i],
    ['Dwarf', /\b(dwarf|dwarves|dwarven|dwarfish)\b/i],
    ['Goblin', /\b(goblins?|hobgoblins?|kobolds?)\b/i],
    ['Ogre', /\bogres?\b|\btroll-?(?:born|woman|girl)\b|\ba troll\b/i],
    ['Fae', /\b(fae|faerie|fairies|changelings?|pixies?)\b|\b(?:a|the) fairy\b|\bfairy[- ]?(?:woman|girl|queen|-born)\b/i],
    ['Witch', /\b(witch(?:es)?|witch-?born|hags?)\b/i],
    ['Banshee', /\bbanshees?\b/i],
    ['Wendigo', /\bwendigos?\b/i],
    ['Ghoul', /\bghouls?\b/i],
    ['Mummy', /\bmumm(?:y|ies)\b/i],
    ['Zombie', /\bzombies?\b/i],
    ['Lich', /\b(liches|lich)\b|\bskeleton[- ]?(?:woman|girl|queen)\b/i],
    ['Ghost', strict('(?:ghosts?|spectres?|specters?|poltergeists?|apparition)')],
    ['Gargoyle', /\bgargoyles?\b/i],
    ['Golem', /\bgolems?\b/i],
    ['Slime', /\bslime[- ]?(?:girl|woman|monster)\b|\ba slime\b|\bslimes?\b/i],
    ['Shapeshifter', /\b(shapeshift\w*|shape-?shifters?|skinwalkers?|changeling)\b/i],
    ['Abyssal', /\b(abyssal|deep[- ]sea (?:horror|creature|thing|being)|eldritch)\b/i],
    ['Alien', strict('(?:aliens?|extraterrestrial)')],
    ['Android', /\b(androids?|cyborgs?|gynoid)\b|\b(?:a|an|the) robot\b|\brobot[- ]?(?:girl|woman|maid)\b/i],
    ['Cryptid', /\b(cryptids?|mothman|jersey devil|bigfoot|sasquatch)\b/i],
    ['Scarecrow', /\bscarecrows?\b/i],
    ['Giantess', /\b(giantess|giant (?:woman|girl|anthro))\b/i],
    ['Gorilla', /\b(gorillas?|silverbacks?)\b/i],
  ];
  // words that say she is not an ordinary woman even when no race is named
  const NONHUMAN = /\b(monster|creature|inhuman|otherworldly|abomination|undead|beast(?:ial)?|entity|anomal(?:y|ies|ous)|unnatural|supernatural being|not human|isn'?t human)\b/i;
  // words with other everyday meanings: read from her own description or the tags, never guessed from the story text
  const LOOSE = new Set(['Siren', 'Angel', 'Ghost', 'Alien', 'Android', 'Ogre', 'Fae', 'Slime']);
  const text = v => Array.isArray(v) ? v.join(', ') : String(v == null ? '' : v);
  const fieldsOf = (c, re) => Object.entries((c && c.fields) || {}).filter(([k]) => re.test(k)).map(([, v]) => text(v)).join(' \n ');
  const find = (src, tight) => { src = String(src || ''); let best = null; for (const [name, re] of RACES) { if (tight && LOOSE.has(name)) continue; const m = src.match(re); if (m && (best === null || m.index < best.at)) best = {name, at: m.index}; } return best ? best.name : ''; };
  const tidy = s => { s = String(s || '').replace(/\s+/g, ' ').replace(/^[\s:–—-]+|[\s.]+$/g, ''); return s.length > 28 ? s.slice(0, 27).trim() + '…' : s; };

  // {race, source, known} for a card, or null when the card has nothing written about her yet
  function of(c) {
    if (!c) return null;
    const F = c.fields || {};
    const written = Object.keys(F).length && (F['The Setup'] || F['Appearance Requirements'] || F["Character's Personality"] || F['Scene Name'] || c.sceneName);
    const explicit = fieldsOf(c, /^(race|species)\b/i).trim() || (typeof c.race === 'string' ? c.race.trim() : '');
    if (explicit) return {race: tidy(explicit), source: 'the card\'s own Race line', known: true};
    if (c.trait && String(c.trait).trim()) return {race: tidy(c.trait), source: 'this card\'s weekly trait', known: true};
    if (!written) return null;
    const look = fieldsOf(c, /appearance|figure|nude|personality|image gen|keyword/i), tags = fieldsOf(c, /^tags$/i) + ' ' + (Array.isArray(c.tags) ? c.tags.join(', ') : ''), story = [c.sceneName, fieldsOf(c, /^(scene name|the setup|what has already happened|character's relationship to you|user interaction hook)$/i)].join(' ');
    let r = find(look); if (r) return {race: r, source: 'her appearance and personality', known: true};
    r = find(tags); if (r) return {race: r, source: 'the card\'s tags', known: true};
    r = find(story, true); if (r) return {race: r, source: 'the Setup', known: true};
    if (NONHUMAN.test(look + ' ' + story)) return {race: 'Non-human', source: 'the card calls her a monster or creature without naming a race', known: false};
    return {race: 'Human', source: 'nothing in the card makes her anything else', known: false};
  }
  return {of, find, RACES};
});
