/* Greeting planning: deterministic source extraction and instructions shared by
   the editor and the headless AI writer. No DOM, AI, network or dependencies. */
(function () {
  'use strict';
  const VERSION = 2, MAX_NOTES = 12000, MAX_EDIT = 3000;
  const text = x => x == null ? '' : typeof x === 'string' ? x : Array.isArray(x) ? x.map(text).filter(Boolean).join('\n') : typeof x === 'object' ? Object.entries(x).map(([k, v]) => `${k}: ${text(v)}`).join('; ') : String(x);
  const keyOf = x => String(x || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const SETUP = new Set(['thesetup', 'setup', 'whathappened', 'scenariosetup']);
  const HOOK = new Set(['userinteractionhook', 'interactionhook', 'hook', 'openinghook']);
  const RELATIONSHIP = new Set([
    'relationship', 'relationshipbackground', 'relationshipbackstory', 'relationshiphistory',
    'relationshiptoyou', 'relationshiptouser', 'sharedhistory', 'sharedbackground', 'howtheymet',
    'charactersrelationshiptoyou', 'charactersrelationshiptouser',
    'whatshebringstotherelationship', 'whattherelationshipgivesher',
    'whatshebelievesshemustkeepgivingtodeserveherplaceinuserslife', 'whatshebelievesshemustkeepgiving',
    'twoordinarymomentsthatmaketheirbondfeellivedin', 'twoordinarymomentsthatmakethebondfeellivedin'
  ]);
  const sectionOf = k => {
    const key = keyOf(k);
    return SETUP.has(key) ? 'setup' : HOOK.has(key) ? 'hook'
      : RELATIONSHIP.has(key) || /^character\d+s?relationshipto(?:you|user)$/.test(key) ? 'relationship' : '';
  };
  const sectionName = s => ({relationship: 'Relationship', setup: 'Setup', hook: 'Hook'}[s] || 'Detail');
  // The creator's own wording for one beat (the Edit button): kept next to the beat's original text, never in place of it, so Restore original always works.
  const editedOf = (value, original) => { const t = typeof value === 'string' ? value.replace(/\r\n?/g, '\n').trim().slice(0, MAX_EDIT) : ''; return t && t !== String(original || '').trim() ? t : ''; };
  const textOf = item => (item && typeof item.edited === 'string' && item.edited.trim()) ? item.edited.trim() : String(item && item.text != null ? item.text : '');
  const supported = p => p && [1, VERSION].includes(p.version) && Array.isArray(p.items);
  // Compare words, not source-field names. Keep negation, numbers, names,
  // punctuation inside sentences and placeholders significant; no fuzzy matching.
  function beatKey(value) {
    return text(value).normalize('NFKC').replace(/[\u200b\ufeff]/g, '')
      .replace(/[\u2018\u2019]/g, "'").replace(/[\u201c\u201d]/g, '"')
      .replace(/[\u2010\u2011]/g, '-').replace(/\u2014/g, '\u2013')
      .replace(/(^|\s)[*_]{1,3}(?=\S)/g, '$1').replace(/(\S)[*_]{1,3}(?=\s|$|[.,!?;:])/g, '$1')
      .replace(/\s+/g, ' ').trim().replace(/\.$/, '').toLowerCase();
  }
  function sourcesOf(item) { return Array.isArray(item.sources) && item.sources.length ? item.sources : [{section: item.section, field: item.field, ordinal: item.ordinal}]; }
  function addSources(target, item) {
    for (const source of sourcesOf(item)) if (!target.sources.some(s => s.section === source.section && s.field === source.field)) target.sources.push({...source});
  }
  function sourceLabel(item, numbered = false) {
    const seen = new Set();
    return sourcesOf(item).filter(s => { if (seen.has(s.section)) return false; seen.add(s.section); return true; })
      .map(s => sectionName(s.section) + (numbered ? ` ${s.ordinal}` : '')).join(' + ');
  }
  // Also used for pre-v0.88 saved plans. Inclusion wins when old duplicate
  // copies disagreed, and the first selected occurrence owns the flow position.
  function uniqueItems(items) {
    const groups = new Map();
    (items || []).forEach((item, index) => {
      const key = beatKey(item.text); if (!key) return;
      let g = groups.get(key);
      if (!g) { g = {item: {...item, sources: sourcesOf(item).map(s => ({...s})), selected: item.selected === true}, first: index, chosen: item.selected === true ? index : null}; groups.set(key, g); }
      else { addSources(g.item, item); if (!g.item.edited && item.edited) g.item.edited = item.edited; if (item.selected === true) { g.item.selected = true; if (g.chosen == null) g.chosen = index; } }
    });
    return [...groups.values()].sort((a,b) => (a.chosen ?? a.first) - (b.chosen ?? b.first)).map(g => g.item);
  }
  // The creator's dialogue share for the Greeting: null (follow the template) or a whole number 0-100.
  function pctOf(v) {
    if (v == null || v === '') return null;
    const n = Math.round(Number(v));
    return Number.isFinite(n) ? Math.max(0, Math.min(100, n)) : null;
  }
  const clone = x => JSON.parse(JSON.stringify(x));
  // Stable non-cryptographic identity, not a security hash.
  function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }
  function collectEntries(card, includeRelationship) {
    card = card || {}; const f = card.fields || {}, out = [], seen = new Set();
    const add = (label, value) => { const t = text(value).trim(); if (!t || seen.has(keyOf(label))) return; seen.add(keyOf(label)); out.push({label, text: t}); };
    add('Scene Name', card.sceneName || f['Scene Name']);
    for (const [label, value] of Object.entries(f)) add(label, value);
    for (const [label, value] of [['Series',card.series], ['Primary character',card.primaryCharacter], ['Primary archetype',card.primaryArchetype], ['Cast',card.cast], ['Tags',card.tags], ['The Setup',card.setup], ['User Interaction Hook',card.hook]]) add(label, value);
    if (includeRelationship) for (const [label, value] of Object.entries(card)) {
      if (sectionOf(label) === 'relationship') add(label.replace(/([a-z])([A-Z])/g, '$1 $2'), value);
    }
    return out;
  }
  const entries = card => collectEntries(card, true);
  // v0.87 fingerprints/IDs are retained only to validate and migrate old plans
  // and interrupted jobs without discarding their choices, notes or order.
  const legacyEntries = card => collectEntries(card, false);
  // With a plan, every beat the creator reworded (the Edit button) is swapped for its new wording inside the card text, so the AI never sees the original sentence next to the edited one.
  // For Greeting requests ({greeting: true}) every beat the creator left UNCHECKED is also cut out of the Setup / Hook / Relationship fields, so the AI cannot write what was rejected.
  function fullCardText(card, plan, opts) {
    const items = plan && Array.isArray(plan.items) ? plan.items.filter(i => i && typeof i.text === 'string' && i.text.trim()) : [];
    const edits = items.filter(i => typeof i.edited === 'string' && i.edited.trim());
    const keep = new Set(items.filter(i => i.selected === true).map(i => beatKey(i.text)));
    const drop = opts && opts.greeting ? items.filter(i => i.selected !== true && !keep.has(beatKey(i.text))) : [];
    return entries(card).map(e => {
      let t = e.text;
      for (const i of edits) if (t.includes(i.text)) t = t.split(i.text).join(i.edited.trim());
      if (opts && opts.greeting && sectionOf(e.label)) for (const beat of splitBeats(t)) if (isCommentary(beat)) t = t.split(beat).join(' ');
      if (drop.length && sectionOf(e.label)) { for (const i of drop) if (t.includes(i.text)) t = t.split(i.text).join(' '); t = t.replace(/[ \t]{2,}/g, ' ').replace(/ *\n */g, '\n').trim(); }
      return t ? `${e.label}: ${t}` : '';
    }).filter(Boolean).join('\n\n');
  }
  function fingerprintOf(list) { return hash(JSON.stringify(list.map(e => [keyOf(e.label),e.text]).sort((a,b) => a[0].localeCompare(b[0])))); }
  function fingerprint(card) { return fingerprintOf(entries(card)); }

  // Sentence-level checklist items. Keep quoted speech together, don't split
  // titles, initials or decimal numbers, and retain every nonblank source word.
  function splitBeats(value) {
    const out = [], source = text(value).replace(/\r\n?/g, '\n').trim();
    const abbrev = /\b(?:Mr|Mrs|Ms|Dr|Prof|St|Mt|Sr|Jr|Capt|Lt|Gen|Rev|vs|etc|e\.g|i\.e)\.$/i;
    for (const block0 of source.split(/\n+/)) {
      const block = block0.trim().replace(/^(?:[-*\u2022]\s+|\d+[.)]\s+)/, '');
      if (!block) continue;
      let start = 0, quoted = false; const spans = [];
      for (let i = 0; i < block.length; i++) {
        const ch = block[i];
        if ((ch === '"' || ch === '\u201c' || ch === '\u201d') && block[i - 1] !== '\\') quoted = ch === '\u201c' ? true : ch === '\u201d' ? false : !quoted;
        if (!/[.!?\u2026]/.test(ch)) continue;
        if (ch === '.' && (/\d/.test(block[i - 1] || '') && /\d/.test(block[i + 1] || '') || abbrev.test(block.slice(start, i + 1)) || /\b[A-Z]\.$/.test(block.slice(start,i+1)))) continue;
        let end = i + 1;
        while (end < block.length && /[.!?\u2026]/.test(block[end])) end++;
        let closingQuote = false;
        while (end < block.length && /["\u201d\u2019')\]*}]/.test(block[end])) { if (/["\u201d]/.test(block[end])) closingQuote = true; end++; }
        if (quoted && !closingQuote) continue;
        const rest = block.slice(end), next = rest.trimStart();
        if (!next || /^\s/.test(rest) || /^[A-Z{\u201c"]/.test(next)) {
          // A speech attribution is still part of its quoted line.
          if (closingQuote && /^[a-z]/.test(next)) { quoted = false; i = end - 1; continue; }
          if (block.slice(start,end).trim()) spans.push([start,end]);
          start = end; i = end - 1; if (closingQuote) quoted = false;
        }
      }
      if (block.slice(start).trim()) spans.push([start, block.length]);
      // A run of two or more short fragments ("He is gone. Not circling. Not waiting. Just gone.") is one detail, not one row each. A short line between long ones stays alone.
      const joined = [], isShort = sp => { const piece = block.slice(sp[0], sp[1]).trim(); return piece.split(/\s+/).length <= 4 && !/["\u201c\u201d]/.test(piece); };
      for (let k = 0; k < spans.length; k++) {
        if (!isShort(spans[k])) { joined.push([spans[k][0], spans[k][1]]); continue; }
        let m = k; while (m + 1 < spans.length && isShort(spans[m + 1])) m++;
        joined.push([spans[k][0], spans[m][1]]); k = m;
      }
      for (const sp of joined) { const beat = block.slice(sp[0], sp[1]).trim(); if (beat) out.push(beat); }
    }
    return out;
  }
  // Plain wording, decided by the tool (no AI): a card often opens a sentence with a label ("The thing that ended it was physical: ...") instead of just saying it.
  // The label is taken off so the line says what happened. The original stays on the row (Restore original).
  const LEAD_INS = [
    /^the (?:thing|reason|part) (?:that|which) (?:ended|broke|ruined) (?:it|things|them)(?: up)? was [^:.]{1,40}:\s*/i,
    /^the pressure behind it was real and it was (?:hers|his|theirs):\s*/i
  ];
  function plainOf(t) {
    let out = String(t || '');
    for (const re of LEAD_INS) out = out.replace(re, '');
    out = out.replace(/^([a-z])/, m => m.toUpperCase());
    return out !== String(t || '') ? out : '';
  }
  // Lines that only comment on the story ("What happened, happened, and she owns it.") are not listed as rows, and a Greeting request leaves them out of the card text it sends.
  const COMMENTARY = [
    /^(?:she|he|they) (?:has|have) never (?:once )?(?:claimed|said|pretended) (?:that |it )/i,
    /^what happened,? happened\b/i,
    /^that is the whole reason\b/i,
    /\bwaiting for you to say something\b/i,
    /\bno idea what you are going to say\b/i
  ];
  const isCommentary = t => COMMENTARY.some(re => re.test(String(t || '').trim()));
  function legacyCandidates(card) {
    const found = legacyEntries(card).filter(e => ['setup','hook'].includes(sectionOf(e.label)));
    const out = [], counts = new Map(), ordinal = {setup: 0, hook: 0};
    for (const section of ['setup','hook']) for (const source of found.filter(e => sectionOf(e.label) === section)) {
      for (const value of splitBeats(source.text)) {
        const base = `${section}-${hash(keyOf(source.label) + '\n' + value)}`;
        const n = (counts.get(base) || 0) + 1; counts.set(base,n);
        out.push({id: `${base}-${n}`, section, field: source.label, ordinal: ++ordinal[section], text: value, selected: true});
      }
    }
    return out;
  }
  function candidates(card) {
    const found = entries(card).filter(e => sectionOf(e.label)), out = [], byText = new Map(), ids = new Map();
    const ordinal = {relationship: 0, setup: 0, hook: 0};
    // New plans start with relationship context, then setup, then the live hook.
    // Saved plans keep the creator's order; every row can still be moved.
    for (const section of ['relationship','setup','hook']) for (const source of found.filter(e => sectionOf(e.label) === section)) {
      for (const value of splitBeats(source.text)) {
        const key = beatKey(value); if (!key || isCommentary(value)) continue;
        const existing = byText.get(key);
        if (existing) {
          if (!existing.sources.some(s => s.section === section && s.field === source.label)) existing.sources.push({section, field: source.label, ordinal: ++ordinal[section]});
          continue;
        }
        const base = `beat-${hash(key)}`, count = (ids.get(base) || 0) + 1; ids.set(base, count);
        const src = {section, field: source.label, ordinal: ++ordinal[section]};
        const item = {id: `${base}-${count}`, ...src, text: value, selected: true, sources: [{...src}]};
        byText.set(key, item); out.push(item);
      }
    }
    return out;
  }
  function create(card, previous) {
    card = card || {};
    const base = candidates(card), byId = new Map(base.map(i => [i.id,i])), byText = new Map(base.map(i => [beatKey(i.text),i]));
    const reuse = supported(previous) && previous.cardId === String(card.id || '');
    const oldIds = reuse && previous.version === 1 ? new Map(legacyCandidates(card).map(i => [i.id,i])) : null;
    const groups = new Map();
    if (reuse) previous.items.forEach((item, index) => {
      if (!item) return;
      const old = oldIds && oldIds.get(item.id);
      const current = (oldIds ? old && byText.get(beatKey(old.text)) : byId.get(item.id))
        || (typeof item.text === 'string' && byText.get(beatKey(item.text)));
      if (!current) return;
      let group = groups.get(current.id);
      if (!group) { group = {item: {...current, selected: false}, first: index, chosen: null}; groups.set(current.id, group); }
      if (item.selected === true) { group.item.selected = true; if (group.chosen == null) group.chosen = index; }
      const ed = editedOf(item.edited, group.item.text); if (ed && !group.item.edited) group.item.edited = ed;
    });
    // A plan saved before the plain-wording step (no plain mark) gets it once on its rows the creator has not reworded; after that the creator's choices, including Restore original, are left alone.
    const needsPlain = reuse && previous.plain !== 1;
    const items = [...groups.values()].sort((a,b) => (a.chosen ?? a.first) - (b.chosen ?? b.first)).map(g => g.item);
    if (needsPlain) for (const it of items) if (!it.edited) { const plain = plainOf(it.text); if (plain) it.edited = plain; }
    for (const item of base) if (!groups.has(item.id)) {
      const row = {...item, selected: !reuse};
      const plain = plainOf(item.text); if (plain) row.edited = plain;
      items.push(row);
    }
    return {version: VERSION, plain: 1, cardId: String(card.id || ''), sourceHash: fingerprint(card), items, notes: reuse && typeof previous.notes === 'string' ? previous.notes : '', dialoguePercent: reuse ? pctOf(previous.dialoguePercent) : null};
  }
  function selected(plan) { return uniqueItems(plan && Array.isArray(plan.items) ? plan.items : []).filter(i => i.selected === true); }
  function error(plan) {
    if (typeof plan.notes !== 'string' || plan.notes.length > MAX_NOTES) return `Additional notes must be at most ${MAX_NOTES.toLocaleString()} characters.`;
    if (!selected(plan).length && !plan.notes.trim()) return 'Select at least one detail or add notes describing the Greeting.';
    { let M = null; try { M = (typeof window !== 'undefined' && window.Minors) || (typeof require === 'function' ? require('./minors.js') : null); } catch (e) { M = null; }   // everyone in a story is 18 or older
      if (M) { const hits = M.find([...selected(plan).map(textOf), plan.notes]); if (hits.length) return `The Greeting plan mentions a child, a teenager or a school setting (${hits.slice(0, 3).join(', ')}). Everyone in the story must be 18 or older: edit or untick the detail (shown in red).`; } }
    return '';
  }
  // Rebuild from the real card in the main process; client text is never trusted
  // as source material. Reject stale/incomplete plans rather than silently reset.
  function validate(card, input) {
    if (!supported(input) || input.cardId !== String(card.id || '')) throw new Error('The Greeting plan is invalid. Open the planner again before writing.');
    if (input.sourceHash !== (input.version === 1 ? fingerprintOf(legacyEntries(card)) : fingerprint(card))) throw new Error('The scenario card changed after the Greeting planner opened. Open the planner again and review the updated details. Nothing was sent to the AI.');
    const base = input.version === 1 ? legacyCandidates(card) : candidates(card), ids = new Set(base.map(i => i.id)), used = new Set();
    if (input.items.length !== base.length) throw new Error('The Greeting checklist changed. Open the planner again and review it.');
    for (const item of input.items) {
      if (!item || !ids.has(item.id) || used.has(item.id) || typeof item.selected !== 'boolean') throw new Error('The Greeting checklist is invalid. Open the planner again.');
      used.add(item.id);
    }
    for (const item of input.items) if (item.edited != null && (typeof item.edited !== 'string' || item.edited.length > MAX_EDIT)) throw new Error(`An edited Greeting beat must be text of at most ${MAX_EDIT.toLocaleString()} characters.`);
    if (typeof input.notes !== 'string') throw new Error('Additional notes must be text.');
    if (input.dialoguePercent != null && input.dialoguePercent !== '' && (!Number.isFinite(Number(input.dialoguePercent)) || Number(input.dialoguePercent) < 0 || Number(input.dialoguePercent) > 100)) throw new Error('The dialogue share must be a number from 0 to 100.');
    const plan = create(card,input); const problem = error(plan); if (problem) throw new Error(problem);
    return plan;
  }
  function move(plan, id, targetId, after = false) {
    const a = plan.items.findIndex(i => i.id === id), b = plan.items.findIndex(i => i.id === targetId);
    if (a < 0 || b < 0 || a === b) return false;
    const [item] = plan.items.splice(a,1), at = plan.items.findIndex(i => i.id === targetId);
    plan.items.splice(at + (after ? 1 : 0),0,item); return true;
  }
  function moveBy(plan, id, delta) {
    const a = plan.items.findIndex(i => i.id === id), b = a + delta;
    return b >= 0 && b < plan.items.length ? move(plan,id,plan.items[b].id,delta > 0) : false;
  }
  function forCard(card, plan) { return supported(plan) && (!card || plan.cardId === String(card.id || '')) ? plan : null; }
  function factInputs(card, plan) {
    const p = forCard(card,plan), items = p ? selected(p) : candidates(card);
    // Existing detail-check callers accept setup + hook. Include selected
    // relationship context in the first input, once, without restoring omissions.
    return {setup: items.filter(i => i.section !== 'hook').map(textOf).join('\n'), hook: items.filter(i => i.section === 'hook').map(textOf).join('\n'), relationship: items.filter(i => sourcesOf(i).some(s => s.section === 'relationship')).map(textOf).join('\n'), planned: !!p};
  }
  // The creator's dialogue share. It is sent with every request that carries the plan (whole bot, each step, every repair and every section rewrite).
  function shareText(plan) {
    const pct = pctOf(plan && plan.dialoguePercent); if (pct == null) return '';
    const lo = Math.max(0, pct - 5), hi = Math.min(100, pct + 5);
    return `DIALOGUE SHARE (set by the creator for the Greeting): the spoken dialogue (everything inside the quotation marks) must be ${lo}% to ${hi}% of the Greeting's text, aiming at ${pct}%; the rest is narration. That is about ${pct * 10} characters inside quotation marks for every 1,000 characters of Greeting, roughly ${Math.max(1, Math.round(pct / 9))} spoken lines (of about 90 characters each) for every 1,000 characters. Count your quoted lines before you answer and adjust until the share is inside ${lo}%-${hi}%. This is the creator's number, not a suggestion. It takes the place of any dialogue amount or ratio the template gives. The template's own formatting (each quoted line on its own line, the delivery cue after it), point of view, length and hard locks still apply, so reach the number by letting the characters SPEAK the beats instead of narrating them, never by padding or by going over the Greeting's length. The dialogue is the characters responding or reacting to the beat in their own voices, not reporting it. Keep this range in every rewrite, shortening or lengthening.`;
  }
  const shareLines = plan => { const t = shareText(plan); return t ? ['', t] : []; };
  function instructions(plan, opts) {
    if (!forCard(null,plan)) return '';
    const items = uniqueItems(plan.items), chosen = items.filter(i => i.selected), excluded = items.filter(i => !i.selected);
    return [
      'CREATOR-APPROVED GREETING PLAN (selection and narrative order)',
      'The full scenario card remains the background truth for Personality, Scenario, Introduction and character continuity. It is NOT a list of facts that must all appear in the Greeting.',
      'For the GREETING only, use the selected beats below in their exact numbered narrative order. Preserve their meaning, not their verbatim wording. The order is deliberate, including any flashback or Hook placed earlier. Begin with the first selected beat and stop at the final selected beat, leaving the situation open for the reader to respond. Do not move the original card Hook back to the end unless it is the last selected beat.',
      'Do not introduce unchecked history, events, revelations or future developments into the Greeting. Minimal identity/setting orientation and transitions are allowed, but must not smuggle in omitted plot details. A fact shared by a selected and unchecked passage can still appear because it was selected.',
      'One beat is NOT necessarily one paragraph. Distribute the chosen material across the template\'s required paragraphs and image markers; fit the chosen meaning inside its character limits by writing each beat as one natural moment of the scene in complete, well-formed sentences, and by merging closely related beats. Never shrink a beat into clipped notes, fragments or a recited list of facts, and do not copy the card\'s report-style wording: a beat is a fact to tell as story. Never invent reader actions, dialogue or decisions.',
      'The creator\'s template hard locks, character limits, agency boundaries and active event requirements still apply. Additional notes refine this plan but do not replace those requirements. All later length, detail, dialogue and event repairs must preserve this selection and order; do not restore unselected Relationship, Setup or Hook facts merely because they appear in the full card.',
      'Each numbered beat appears once, even when it has multiple source labels. Those labels show where the same passage was found, not additional occurrences to repeat in the Greeting.',
      '', 'SELECTED GREETING BEATS (in order):',
      chosen.length ? chosen.map((i,n) => `${n+1}. [${sourceLabel(i)}]${i.edited ? ' (the creator reworded this beat; use ONLY this wording, never the card\'s earlier wording of it)' : ''} ${textOf(i)}`).join('\n') : '(No source beats selected. Use the additional notes to stage the Greeting, consistent with the full card. Do not automatically insert the unselected Relationship, Setup or Hook.)',
      ...(opts && opts.greeting ? ['', 'Everything the creator did not tick has been removed from this request. Write nothing beyond the numbered beats above, the additional notes and the template.'] : ['', 'UNCHECKED PASSAGES (background only; do not dramatize in the Greeting):', excluded.length ? excluded.map(i => `- [${sourceLabel(i)}] ${textOf(i)}`).join('\n') : '(None.)']),
      ...shareLines(plan),
      '', 'ADDITIONAL NOTES FROM THE CREATOR:', plan.notes.trim() || '(None.)', 'END OF GREETING PLAN'
    ].join('\n');
  }
  const api = {VERSION, MAX_NOTES, MAX_EDIT, editedOf, textOf, pctOf, shareText, text, beatKey, sourceLabel, sourcesOf, entries, fullCardText, fingerprint, splitBeats, plainOf, isCommentary, candidates, create, validate, selected, error, move, moveBy, forCard, factInputs, instructions, clone};
  if (typeof window !== 'undefined') window.GreetingPlan = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
