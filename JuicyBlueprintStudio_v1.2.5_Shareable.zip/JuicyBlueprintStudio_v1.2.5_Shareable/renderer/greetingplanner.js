/* Preflight dialog only. Nothing here calls an AI API. The caller starts the
   writer after an explicit confirmation, never on open, drag, edit or cancel. */
(function () {
  'use strict';
  let active = null;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  function open({card, spec, previous, eventName, rewrite = false, current = ''}) {
    if (active) { active.focus(); return Promise.resolve(null); }
    const GP = window.GreetingPlan;
    if (!GP) return Promise.reject(new Error('The Greeting planner did not load. Restart the app before writing.'));
    const submitLabel = rewrite ? 'Rewrite Greeting with this plan' : 'Write bot with this plan';
    const plan = GP.create(card, previous), changed = previous && previous.cardId === plan.cardId && previous.sourceHash !== plan.sourceHash;
    const upgraded = previous && previous.cardId === plan.cardId && previous.version === 1;
    const merged = plan.items.filter(i => GP.sourcesOf(i).length > 1).length;
    const fields = GP.entries(card), originalFocus = document.activeElement;
    const root = document.createElement('div'); root.id = 'greeting-plan-modal'; root.className = 'upd-modal gp-modal';
    root.innerHTML = `<section class="upd-box gp-box" role="dialog" aria-modal="true" aria-labelledby="gp-title" aria-describedby="gp-help" tabindex="-1">
      <header class="gp-header"><span class="gp-eyebrow">BEFORE AI WRITING</span><h3 id="gp-title">${rewrite ? 'Rewrite the Greeting' : 'Plan the Greeting'}</h3><p class="gp-subtitle">${esc(card.sceneName || 'Untitled scene')}${spec && spec.name ? ` <span>\u00b7 ${esc(spec.name)}</span>` : ''}</p>
      <p id="gp-help">Choose which Relationship, Setup and Hook details belong in the Greeting, then drag them into narrative order. The full card stays available to the AI as background.</p></header>
      <div class="gp-body">
        ${rewrite ? `<p class="gp-notice">Only the Greeting will be rewritten. All other sections and the current text stay unchanged until you approve the result.</p><details class="gp-context"><summary>Read the current Greeting</summary><pre class="sr-current-text">${esc(current)}</pre></details>` : ''}
        ${upgraded ? '<p class="gp-notice" id="gp-old-note">Your saved flow was upgraded: repeated passages were merged and existing choices, order and notes were kept. Newly available Relationship details are unchecked for you to review.</p>' : changed ? '<p class="gp-notice" id="gp-old-note">This card has changed. Matching choices were kept; new details are unchecked. Review the list before writing.</p>' : ''}
        <details class="gp-context"><summary>Read the full scenario card <span>${fields.length} fields</span></summary><dl>${fields.map(f => `<dt>${esc(f.label)}</dt><dd>${esc(f.text)}</dd>`).join('')}</dl></details>
        <div class="gp-flow-heading"><div><h4>Greeting flow <span id="gp-count"></span></h4><p>Checked details are sent in the order shown. Drag any row by clicking and holding it anywhere, use the arrows, or press Alt + \u2191 / \u2193 on a row. Use Edit on a row to tweak the wording of that beat; the card itself is not changed.</p></div></div>
        <div class="gp-tools"><button type="button" class="ghost sm" id="gp-all">Select all</button><button type="button" class="ghost sm" id="gp-none">Clear selection</button><button type="button" class="ghost sm" id="gp-reset">Reset order</button>${previous && previous.cardId === plan.cardId ? '<button type="button" class="ghost sm" id="gp-fresh" title="Forget the saved choices, edits and notes for this card and rebuild the list from the card">Start fresh</button>' : ''}<span id="gp-source-count"></span></div>
        ${merged ? `<p class="gp-dedup">${merged} shared passage${merged === 1 ? ' appears' : 's appear'} only once. Combined labels identify its sources.</p>` : ''}
        <ol class="gp-list" id="gp-list" aria-label="Relationship, Setup and Hook details in narrative order"></ol>
        ${!plan.items.length ? '<p class="gp-notice">No Relationship, Setup or Hook text was found in this card. Read the full card above and describe the opening in Additional notes.</p>' : ''}
        <p class="gp-limits">${spec && spec.greeting ? `${spec.greeting.count || 1} Greeting passages / image markers${spec.greeting.limit ? ` \u00b7 ${spec.greeting.limit.min.toLocaleString()}\u2013${spec.greeting.limit.max.toLocaleString()} characters` : ''}. ` : ''}Selected source text can be condensed to fit. Template rules${eventName ? ` and the ${esc(eventName)} event requirements` : ' and active event requirements'} still apply.</p>
        <label class="gp-notes-label" for="gp-share">Dialogue share <span>Optional</span></label>
        <div class="gp-share-row"><input type="number" id="gp-share" min="0" max="100" step="5" inputmode="numeric" placeholder="e.g. 40"><span>% of the Greeting that is dialogue. Leave empty to follow the template. The AI is given this number as a range of plus or minus 5 points, with a line count to aim for, in the first request. The app measures the finished Greeting and warns you if it is outside the range. Nothing is sent back to the AI. The template's format and length still apply.</span></div>
        <label class="gp-notes-label" for="gp-notes">Additional notes <span>Optional</span></label>
        <textarea id="gp-notes" rows="3" maxlength="${GP.MAX_NOTES}" placeholder="Add context, pacing, tone, where to begin or stop, or anything the Greeting should avoid."></textarea>
        <div class="gp-notes-meta"><span>Use notes for extra direction, not a replacement for your template.</span><span id="gp-notes-count"></span></div>
      </div>
      <footer class="gp-footer"><div><span id="gp-error" class="gp-error" role="status"></span><span class="gp-no-ai">Nothing is sent to the AI until you click ${submitLabel}.</span></div><div class="gp-footer-buttons"><button type="button" class="ghost" id="gp-cancel">Cancel</button><button type="button" class="primary" id="gp-write">${submitLabel}</button></div></footer>
      <span id="gp-live" class="gp-sr-only" role="status" aria-live="polite"></span>
    </section>`;
    document.body.appendChild(root);
    const box = root.querySelector('.gp-box'), $ = id => root.querySelector('#' + id), list = $('gp-list');
    const priorOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const siblings = [...document.body.children].filter(e => e !== root && !/^(SCRIPT|STYLE)$/.test(e.tagName)).map(e => [e,e.inert]);
    siblings.forEach(([e]) => { e.inert = true; });
    active = box; let dragId = null, finished = false, editingId = null, draftText = null;
    $('gp-notes').value = plan.notes;
    $('gp-share').value = plan.dialoguePercent == null ? '' : plan.dialoguePercent;
    function announce(message) { $('gp-live').textContent = message; }
    // everyone in a story is 18 or older: a beat that names a child, a teenager or a school setting is flagged and cannot be sent
    const MI = () => window.Minors || null;
    const minorNote = t => { const hits = MI() ? MI().find(t) : []; return hits.length ? `<span class="gp-minor" role="alert">Not allowed: this names a minor or a school setting (${esc(hits.slice(0, 3).join(', '))}). Everyone in the story is 18 or older. Use \u270e Edit to rewrite it, or untick it.</span>` : ''; };
    // spelling, grammar and wording of each beat, checked here on this computer (no AI, no credits). A beat with a problem shows what is wrong; when the app
    // knows the fix it also shows the corrected line and asks: Use this line / Keep mine. Nothing changes until you choose.
    const WN = new Map(), PROP = new Map(), KEEP = new Set();
    const wordNote = (t, item) => {
      const TC = window.TextCheck; if (!TC || !t || (item && KEEP.has(item.id + '|' + t))) return '';
      if (!WN.has(t)) { let hits = []; try { hits = TC.check(t, {names: [card.primaryCharacter, ...((card.cast || []).map(c => c && c.name))]}); } catch (_) { hits = []; } WN.set(t, hits); }
      const hits = WN.get(t); if (!hits.length) return '';
      const picks = hits.filter(h => !(h.src === 'languagetool' && h.kind === 'wording')).map(h => h.fix != null ? {start: h.start, end: h.end, replacement: h.fix} : h.suggest && h.suggest.length ? {start: h.start, end: h.end, replacement: h.suggest[0]} : null).filter(Boolean);
      const proposed = picks.length ? TC.apply(t, picks) : '', canFix = proposed && proposed !== t, left = hits.filter(h => h.fix == null && !(h.suggest && h.suggest.length)).length;
      if (item) PROP.set(item.id, proposed);
      return `<div class="gp-wording" role="note"><b>Check the wording</b>${hits.slice(0, 4).map(h => `<span class="gp-wmsg">${esc(h.msg)}</span>`).join('')}${hits.length > 4 ? `<span class="gp-wmsg">\u2026and ${hits.length - 4} more.</span>` : ''}${canFix ? `<span class="gp-wprop"><i>Suggested line</i>${esc(proposed)}</span><span class="gp-wbtns"><button type="button" class="gp-edit" data-action="usefix">Use this line</button><button type="button" class="gp-edit" data-action="keepfix">Keep mine</button>${left ? `<span class="gp-edit-hint">${left} thing${left > 1 ? 's' : ''} still need${left > 1 ? '' : 's'} your own words: use Edit.</span>` : ''}</span>` : `<span class="gp-wbtns"><button type="button" class="gp-edit" data-action="edit">Edit this line</button><button type="button" class="gp-edit" data-action="keepfix">Keep mine</button></span>`}</div>`;
    };
    function minorError(chosen) {
      if (!MI()) return '';
      const bad = chosen.filter(i => MI().find(GP.textOf(i)).length), notes = MI().find(plan.notes || '');
      if (bad.length) return `${bad.length} selected detail${bad.length === 1 ? '' : 's'} mention${bad.length === 1 ? 's' : ''} a child, a teenager or a school setting. Everyone in the story must be 18 or older: edit or untick ${bad.length === 1 ? 'it' : 'them'} (shown in red).`;
      if (notes.length) return `Your notes mention a minor or a school setting (${notes.slice(0, 3).join(', ')}). Everyone in the story must be 18 or older.`;
      return '';
    }
    function summary() {
      const chosen = GP.selected(plan), err = minorError(chosen) || GP.error(plan);
      $('gp-count').textContent = `${chosen.length} of ${plan.items.length} selected`;
      $('gp-source-count').textContent = `${chosen.reduce((n,i) => n+GP.textOf(i).length,0).toLocaleString()} source characters`;
      $('gp-notes-count').textContent = `${plan.notes.length.toLocaleString()} / ${GP.MAX_NOTES.toLocaleString()}`;
      $('gp-error').textContent = err; $('gp-write').disabled = !!err;
    }
    function draw(focusId, action) {
      const live = list.querySelector('.gp-edit-box'); if (live && editingId) draftText = live.value;      // typing in an open editor survives a redraw (a tick box, a move)
      const top = list.scrollTop; let rank = 0;
      list.innerHTML = plan.items.map((item,i) => {
        const source = GP.sourceLabel(item, true), sources = GP.sourcesOf(item), fields = [...new Set(sources.map(s => s.field))].join(' / ');
        const hasRelationship = sources.some(s => s.section === 'relationship');
        const editing = editingId === item.id, shown = editing && draftText != null ? draftText : GP.textOf(item), tag = `<span class="gp-source ${hasRelationship ? 'gp-relationship' : item.section === 'hook' ? 'gp-hook' : ''}" title="${esc(fields)}">${esc(source)}</span>`;
        const main = editing
          ? `<div class="gp-main">${tag}<textarea class="gp-edit-box" data-action="editbox" rows="${Math.min(8, Math.max(3, Math.ceil(shown.length / 70)))}" maxlength="${GP.MAX_EDIT}" aria-label="Edit the wording of ${source}">${esc(shown)}</textarea><div class="gp-rowtools"><button type="button" class="gp-edit" data-action="save-edit">Save edit</button><button type="button" class="gp-edit" data-action="cancel-edit">Cancel</button><span class="gp-edit-hint">Ctrl + Enter saves, Esc cancels. Only this plan changes, not the card.</span></div></div>`
          : `<div class="gp-main"><label for="gp-check-${esc(item.id)}">${tag}${hasRelationship ? `<span class="gp-field">${esc(fields)}</span>` : ''}<span class="gp-text">${esc(shown)}</span>${minorNote(shown)}</label>${editing ? '' : wordNote(shown, item)}<div class="gp-rowtools"><button type="button" class="gp-edit" data-action="edit" aria-label="Edit ${source}">Edit</button>${item.edited ? '<span class="gp-edited">edited</span><button type="button" class="gp-edit" data-action="restore" title="Put back the wording from the card">Restore original</button>' : ''}</div></div>`;
        return `<li class="gp-item${item.selected ? ' is-selected' : ''}${editing ? ' is-editing' : ''}" data-id="${esc(item.id)}" draggable="${editing ? 'false' : 'true'}">
          <button class="gp-grip" type="button" draggable="${editing ? 'false' : 'true'}" data-action="grip" aria-label="Drag ${source} to reorder, or use Alt and arrow keys" title="Drag to reorder; Alt + Up / Down also works">\u283f</button>
          <span class="gp-rank" aria-label="${item.selected ? `Greeting position ${rank+1}` : 'Not selected'}">${item.selected ? ++rank : '\u00b7'}</span>
          <input type="checkbox" id="gp-check-${esc(item.id)}" data-action="check" ${item.selected ? 'checked' : ''}>
          ${main}
          <span class="gp-moves"><button type="button" data-action="up" aria-label="Move ${source} up" title="Move up" ${i === 0 ? 'disabled' : ''}>\u2191</button><button type="button" data-action="down" aria-label="Move ${source} down" title="Move down" ${i === plan.items.length-1 ? 'disabled' : ''}>\u2193</button></span>
        </li>`;
      }).join('');
      list.scrollTop = top; summary();
      if (editingId && !focusId) { const box = list.querySelector('.gp-edit-box'); if (box) { box.focus({preventScroll:true}); box.setSelectionRange(box.value.length, box.value.length); } }
      if (focusId) { const row = [...list.children].find(e => e.dataset.id === focusId), control = row && row.querySelector(`[data-action="${action || 'grip'}"]`); if (control) { control.focus({preventScroll:true}); if (action !== 'check') row.scrollIntoView({block:'nearest'}); } }
    }
    function reorder(id, delta, action = 'grip') { if (GP.moveBy(plan,id,delta)) { draw(id,action); announce('Narrative order updated.'); } }
    list.addEventListener('change', e => { if (e.target.dataset.action !== 'check') return; const id = e.target.closest('.gp-item').dataset.id, item = plan.items.find(i => i.id === id); if (item) item.selected = e.target.checked; draw(id,'check'); });
    function commitEdit() {
      if (!editingId) return false;
      const box = list.querySelector('.gp-edit-box'), item = plan.items.find(i => i.id === editingId);
      if (box && item) { const ed = GP.editedOf(box.value, item.text); if (ed) item.edited = ed; else delete item.edited; }
      editingId = null; draftText = null; return true;
    }
    function startEdit(id) { commitEdit(); editingId = id; draftText = null; draw(); const box = list.querySelector('.gp-edit-box'); if (box) { box.focus({preventScroll:true}); box.setSelectionRange(box.value.length, box.value.length); box.scrollIntoView({block:'nearest'}); } }
    list.addEventListener('click', e => {
      const button = e.target.closest('[data-action]'), row = button && button.closest('.gp-item'); if (!row) return;
      const act = button.dataset.action, id = row.dataset.id, item = plan.items.find(i => i.id === id);
      if (act === 'up' || act === 'down') { if (editingId) { commitEdit(); draw(); } reorder(id, act === 'up' ? -1 : 1, act); }
      else if (act === 'edit') startEdit(id);
      else if (act === 'usefix' && item) { const ed = GP.editedOf(PROP.get(id) || '', item.text); if (ed) item.edited = ed; else if (PROP.get(id) === item.text) delete item.edited; draw(id, 'edit'); announce('Corrected line will be sent.'); }
      else if (act === 'keepfix' && item) { KEEP.add(item.id + '|' + GP.textOf(item)); draw(id, 'edit'); announce('Kept as it is.'); }
      else if (act === 'save-edit') { commitEdit(); draw(id, 'edit'); announce('Beat edited. It will be sent with your wording.'); }
      else if (act === 'cancel-edit') { editingId = null; draftText = null; draw(id, 'edit'); announce('Edit cancelled.'); }
      else if (act === 'restore' && item) { delete item.edited; draw(id, 'edit'); announce('Original wording restored.'); }
    });
    list.addEventListener('keydown', e => { if (e.target.classList && e.target.classList.contains('gp-edit-box') && e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); e.stopPropagation(); const id = editingId; commitEdit(); draw(id, 'edit'); announce('Beat edited. It will be sent with your wording.'); } });
    list.addEventListener('keydown', e => { if (e.target.tagName === 'TEXTAREA') return; if (!e.altKey || !['ArrowUp','ArrowDown'].includes(e.key)) return; const row = e.target.closest('.gp-item'); if (!row) return; e.preventDefault(); reorder(row.dataset.id,e.key === 'ArrowUp' ? -1 : 1); });
    const clearDrop = () => list.querySelectorAll('.gp-drop-before,.gp-drop-after,.gp-dragging').forEach(e => e.classList.remove('gp-drop-before','gp-drop-after','gp-dragging'));
    list.addEventListener('dragstart', e => { const row = e.target.closest && e.target.closest('.gp-item'); if (!row) { e.preventDefault(); return; } dragId = row.dataset.id; if (e.dataTransfer) { e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain',dragId); e.dataTransfer.setDragImage(row,24,24); } row.classList.add('gp-dragging'); });
    list.addEventListener('dragover', e => { if (!dragId) return; e.preventDefault(); if (e.dataTransfer) e.dataTransfer.dropEffect = 'move'; const row = e.target.closest('.gp-item'); list.querySelectorAll('.gp-drop-before,.gp-drop-after').forEach(el => el.classList.remove('gp-drop-before','gp-drop-after')); if (row && row.dataset.id !== dragId) { const r = row.getBoundingClientRect(); row.classList.add(e.clientY > r.top+r.height/2 ? 'gp-drop-after' : 'gp-drop-before'); }
      const r = list.getBoundingClientRect(); if (e.clientY < r.top+32) list.scrollTop -= 16; else if (e.clientY > r.bottom-32) list.scrollTop += 16;
    });
    list.addEventListener('drop', e => { if (!dragId) return; e.preventDefault(); const row = e.target.closest('.gp-item'), id = dragId; if (row) { const r = row.getBoundingClientRect(); GP.move(plan,id,row.dataset.id,e.clientY > r.top+r.height/2); } else if (plan.items.length) GP.move(plan,id,plan.items[plan.items.length-1].id,true); dragId = null; clearDrop(); draw(id); announce('Narrative order updated.'); });
    list.addEventListener('dragend', () => { dragId = null; clearDrop(); });
    $('gp-all').onclick = () => { plan.items.forEach(i => { i.selected = true; }); draw(); announce('All details selected.'); };
    $('gp-none').onclick = () => { plan.items.forEach(i => { i.selected = false; }); draw(); announce('All details unchecked.'); };
    $('gp-reset').onclick = () => { const positions = new Map(GP.candidates(card).map((i,n) => [i.id,n])); plan.items.sort((a,b) => positions.get(a.id)-positions.get(b.id)); draw(); announce('Original card order restored. Selections and notes were kept.'); };
    if ($('gp-fresh')) $('gp-fresh').onclick = () => { const fresh = GP.create(card, null); plan.items = fresh.items; plan.notes = ''; plan.dialoguePercent = null; editingId = null; draftText = null; WN.clear(); KEEP.clear(); $('gp-notes').value = ''; $('gp-share').value = ''; const note = $('gp-old-note'); if (note) note.remove(); $('gp-fresh').remove(); draw(); announce('Started fresh from the card. Nothing saved before is used.'); };
    $('gp-notes').oninput = () => { plan.notes = $('gp-notes').value; summary(); };
    $('gp-share').oninput = () => { const raw = $('gp-share').value.trim(); plan.dialoguePercent = raw === '' ? null : Math.max(0, Math.min(100, Math.round(Number(raw)))); if (raw !== '' && Number(raw) !== plan.dialoguePercent) $('gp-share').value = plan.dialoguePercent; };
    draw();
    const onLt = () => { if (finished || editingId) return; WN.clear(); draw(); };      // LanguageTool's answer for a beat arrives after the first draw
    window.addEventListener('jbs-lt-update', onLt);
    return new Promise(resolve => {
      function close(value) { if (finished) return; finished = true; window.removeEventListener('jbs-lt-update', onLt); document.removeEventListener('keydown',keys,true); root.remove(); document.body.style.overflow = priorOverflow; siblings.forEach(([e,old]) => { e.inert = old; }); active = null; if (originalFocus && originalFocus.isConnected) originalFocus.focus({preventScroll:true}); resolve(value); }
      function keys(e) {
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); if (editingId) { const id = editingId; editingId = null; draftText = null; draw(id, 'edit'); announce('Edit cancelled.'); } else close(null); return; }
        if (e.key !== 'Tab') return;
        const focusable = [...box.querySelectorAll('button:not([disabled]),input:not([disabled]),textarea,summary,[tabindex="0"]')].filter(e => e.getClientRects().length);
        const first = focusable[0], last = focusable[focusable.length-1];
        if (e.shiftKey && (document.activeElement === first || document.activeElement === box)) { e.preventDefault(); last && last.focus(); }
        else if (!e.shiftKey && (document.activeElement === last || !box.contains(document.activeElement))) { e.preventDefault(); first && first.focus(); }
      }
      document.addEventListener('keydown',keys,true);
      $('gp-cancel').onclick = () => close(null);
      $('gp-write').onclick = () => { try { if (commitEdit()) draw(); close(GP.validate(card,plan)); } catch (e) { $('gp-error').textContent = e.message; } };
      box.focus({preventScroll:true});
    });
  }
  window.GreetingPlanner = {open};
})();
