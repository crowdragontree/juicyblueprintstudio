// Image site (v1.1.0): the Settings block (address, login, folders) and the Greeting "Pictures" uploader.
// The uploader sends the picked or dropped images to your image site (through the app, never the AI relay) and puts the returned links into the Greeting.
(function () {
  const api = window.juicyApp || {};
  if (!api.imageHostGet) return;
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]));
  const say = (m, bad) => { try { toast(m, !!bad); } catch {} };
  let st = null, pendingIdx = 0;
  const busyIdx = new Set();                                   // markers whose picture is uploading right now: only those buttons wait, you can start the next picture at once
  function paintBusy() { const L = window.__bbImg ? window.__bbImg.links() : []; document.querySelectorAll('[data-imgup]').forEach(b => { const i = +b.dataset.imgup, on = busyIdx.has(i); b.disabled = on; b.textContent = on ? 'Uploading…' : (L[i] ? 'Replace image' : 'Upload image'); }); }

  async function load() { try { st = await api.imageHostGet(); } catch (e) { st = {ok: false, error: String(e && e.message || e)}; } return st; }

  // the folder the pictures will go into, as "Scene - First name" (same rule the app uses when it uploads)
  const folderLabel = (scene, name) => [String(scene || '').replace(/\s+/g, ' ').trim(), String(name || '').trim().split(/\s+/)[0] || ''].filter(Boolean).join(' - ');

  // ---------------------------------------------------------------- Settings block
  function paint() {
    const el = $('imghost-box'); if (!el) return;
    if (!st || st.ok === false) { el.innerHTML = '<p class="micro">' + esc(st && st.error || 'The image site is not available here.') + '</p>'; return; }
    const c = st.config || {};
    el.innerHTML = `<div class="ih-grid">
        <label class="ih-f"><span>Site address</span><input id="ih-base" type="url" value="${esc(c.baseUrl || st.defaultBase)}" autocomplete="off"></label>
        <label class="ih-f"><span>Username</span><input id="ih-user" type="text" value="${esc(c.username)}" autocomplete="off"></label>
        <label class="ih-f"><span>Password</span><input id="ih-pass" type="password" value="" placeholder="${st.hasPassword ? 'Saved on this PC (type to change it)' : 'Your image site password'}" autocomplete="new-password"></label>
        ${st.accounts
          ? `<label class="ih-f"><span>Folder for NTR bots</span><input id="ih-ntr" type="text" value="${esc(c.ntrRoot)}" autocomplete="off"></label>
             <label class="ih-f"><span>Folder for all other bots</span><input id="ih-main" type="text" value="${esc(c.mainRoot)}" autocomplete="off"></label>`
          : `<label class="ih-f"><span>Put bot folders inside (optional)</span><input id="ih-root" type="text" value="${esc(c.root)}" placeholder="leave empty for the top level" autocomplete="off"></label>`}
      </div>
      <div class="block-add" style="flex-wrap:wrap;gap:8px"><button class="primary sm" type="button" data-ih="save">Save</button><button class="ghost sm" type="button" data-ih="test">Test connection</button>${st.hasPassword ? '<button class="ghost sm" type="button" data-ih="forget">Forget the saved password</button>' : ''}</div>
      <p class="micro" id="ih-msg"></p>
      <p class="micro">${st.accounts ? 'NTR, Likeable, Preventable, Post-NTR, Emotional NTR and Misunderstanding bots go into the NTR folder; every other bot (ANTI-NTR and Crush included) goes into the other one. ' : ''}Each bot gets a folder named “Scene name - Character first name”, and the same folder is reused next time. The password is stored encrypted by Windows on this PC${st.encrypted ? '' : ' (encryption is not available here, so it is only lightly scrambled)'} and is never part of a backup.</p>`;
  }
  const form = () => ({baseUrl: ($('ih-base') || {}).value, username: ($('ih-user') || {}).value, ntrRoot: ($('ih-ntr') || {}).value, mainRoot: ($('ih-main') || {}).value, root: ($('ih-root') || {}).value});
  const msg = (t, bad) => { const m = $('ih-msg'); if (m) { m.textContent = t || ''; m.style.color = bad ? '#ff8a8a' : ''; } };
  async function act(what) {
    const pw = ($('ih-pass') || {}).value || '';
    try {
      if (what === 'save') { const r = await api.imageHostSave(form(), pw, false); if (r.ok === false) throw new Error(r.error); await load(); paint(); msg('Saved.'); }
      else if (what === 'forget') { const r = await api.imageHostSave(form(), '', true); if (r.ok === false) throw new Error(r.error); await load(); paint(); msg('The saved password was removed.'); }
      else if (what === 'test') {
        msg('Testing…'); const r = await api.imageHostTest(form(), pw);
        if (!r || r.ok === false) return msg(r && r.error || 'The test failed.', true);
        msg(`Connected as ${form().username}. ${r.folders.length ? 'Folders found: ' + r.folders.join(', ') + '.' : 'No folders yet.'}`);
      }
    } catch (e) { msg(String(e && e.message || e), true); }
  }
  function ensureBlock() {
    if ($('imghost-panel')) return;
    const col = document.querySelector('#view-settings .set-col'); if (!col) return;
    const p = document.createElement('div'); p.className = 'panel'; p.id = 'imghost-panel';
    p.innerHTML = '<div class="panel-head"><div><h3>Image site</h3><p>Upload a bot\'s Greeting pictures straight to your image site and put the links in the Greeting.</p></div></div><div id="imghost-box"></div>';
    const bp = $('backup-panel'); if (bp && bp.parentNode === col) col.insertBefore(p, bp.nextSibling); else col.insertBefore(p, col.firstChild);
    p.addEventListener('click', ev => { const b = ev.target.closest('[data-ih]'); if (b) { ev.preventDefault(); act(b.dataset.ih); } });
  }

  // ---------------------------------------------------------------- sign-in question (inside the app window, in the tool's own style)
  let loginWait = null;
  function loginModal(problem) {
    if (loginWait) return loginWait;
    loginWait = new Promise(done => {
      const m = document.createElement('div'); m.id = 'ih-login'; m.className = 'upd-modal'; m.style.display = 'flex';
      const c = (st && st.config) || {};
      m.innerHTML = `<div class="upd-box"><h3>Sign in to your image site</h3>
        <p class="upd-sub">Sign in once to upload pictures. The tool keeps your login encrypted on this PC, so you are not asked again.</p>
        ${problem ? `<p class="micro" style="color:#ff8a8a">${esc(problem)}</p>` : ''}
        <label class="ih-f"><span>Username</span><input id="ihl-user" type="text" value="${esc(c.username || '')}" autocomplete="off"></label>
        <label class="ih-f" style="margin-top:8px"><span>Password</span><input id="ihl-pass" type="password" value="" autocomplete="new-password"></label>
        <p class="micro" id="ihl-msg"></p>
        <div class="upd-actions" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px"><button class="primary" type="button" data-ihl="go">Sign in</button><button class="ghost" type="button" data-ihl="cancel">Cancel</button></div>
        <p class="micro" style="margin-top:10px">Site: ${esc(c.baseUrl || (st && st.defaultBase) || '')}. Change it in Settings &gt; Image site.</p></div>`;
      document.body.appendChild(m);
      const q = id => m.querySelector(id), say2 = (t, bad) => { q('#ihl-msg').textContent = t || ''; q('#ihl-msg').style.color = bad ? '#ff8a8a' : ''; };
      const close = ok => { m.remove(); loginWait = null; done(ok); };
      const go = async () => {
        const user = q('#ihl-user').value.trim(), pw = q('#ihl-pass').value;
        if (!user || !pw) return say2('Enter your username and password.', true);
        say2('Signing in…');
        try {
          const cfg = {...((st && st.config) || {}), username: user};
          let r = await api.imageHostSave(cfg, pw, false); if (r.ok === false) throw new Error(r.error);
          r = await api.imageHostTest(cfg, pw);
          if (!r || r.ok === false) { await api.imageHostSave(cfg, '', true); return say2(r && r.error || 'Sign-in failed.', true); }
          await load(); paint(); close(true);
        } catch (e) { say2(String(e && e.message || e), true); }
      };
      m.addEventListener('click', ev => { const b = ev.target.closest('[data-ihl]'); if (b) { ev.preventDefault(); b.dataset.ihl === 'go' ? go() : close(false); } else if (ev.target === m) close(false); });
      m.addEventListener('keydown', ev => { if (ev.key === 'Enter') { ev.preventDefault(); go(); } else if (ev.key === 'Escape') close(false); });
      setTimeout(() => q(c.username ? '#ihl-pass' : '#ihl-user').focus(), 30);
    });
    return loginWait;
  }
  // true when the tool is signed in (a saved login exists); otherwise asks for it first
  async function ensureLogin() {
    await load(); if (st && st.ok !== false && st.hasPassword && st.config && st.config.username) return true;
    return loginModal('');
  }

  // ---------------------------------------------------------------- Greeting pictures (buttons beside each picture marker)
  // what the site's own uploader does: a PNG or JPG becomes high-quality WebP when that is clearly smaller (transparency is kept); otherwise the original goes up unchanged
  async function readFile(f) {
    const type = f.type || ({png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg'}[(f.name.split('.').pop() || '').toLowerCase()] || '');
    if ((type === 'image/png' || type === 'image/jpeg') && window.createImageBitmap) {
      try {
        const bmp = await createImageBitmap(f), c = document.createElement('canvas'); c.width = bmp.width; c.height = bmp.height;
        c.getContext('2d').drawImage(bmp, 0, 0); if (bmp.close) bmp.close();
        const b = await new Promise(ok => c.toBlob(ok, 'image/webp', 0.9));
        if (b && b.type === 'image/webp' && b.size < f.size * 0.9) return {name: f.name.replace(/\.(png|jpe?g)$/i, '') + '.webp', bytes: new Uint8Array(await b.arrayBuffer())};
      } catch {}
    }
    return {name: f.name, bytes: new Uint8Array(await f.arrayBuffer())};
  }
  async function send(fileList, start) {
    const H = window.__bbImg; if (!H || !H.v) return;
    const files = [...fileList].filter(f => /^image\//.test(f.type) || /\.(png|jpe?g|webp|gif|avif)$/i.test(f.name));
    if (!files.length) return say('Choose picture files (PNG, JPG, WebP, GIF or AVIF).', true);
    const v = H.v, room = Math.max(H.links().length, v.greet.length) - start; if (room <= 0) return;
    if (files.length > room) { say(`Only ${room} marker${room === 1 ? '' : 's'} left from image ${start + 1}: the first ${room} picture${room === 1 ? '' : 's'} will be used.`); files.length = room; }
    const scene = (v.header && v.header.scene || '').trim(), first = String((v.names && v.names[1]) || '').trim().split(/\s+/)[0];
    if (!scene || !first) return say('Fill in the Scene name and the character name first: the pictures are filed in a folder called “Scene name - First name”.', true);
    if (!(await ensureLogin())) return;
    const idx = files.map((_, k) => start + k), taken = idx.find(i => busyIdx.has(i));
    if (taken != null) return say(`Image ${taken + 1} is still uploading.`, true);
    idx.forEach(i => busyIdx.add(i)); paintBusy();
    say(`Preparing and uploading ${files.length} picture${files.length === 1 ? '' : 's'}…`);
    try {
      const payload = {files: await Promise.all(files.map(readFile)), scene, name: first, hints: H.hints(), account: v.imgAccount || ''};
      let r = await api.imageHostUpload(payload);
      if (r && r.ok === false && r.needsLogin) { if (!(await loginModal(r.error))) return; r = await api.imageHostUpload(payload); }
      if (!r || r.ok === false) return say(r && r.error || 'The upload did not work.', true);
      idx.forEach(i => busyIdx.delete(i)); const miss = H.setLinks(start, r.urls);
      say(miss ? `Uploaded ${r.urls.length}, but ${miss} had no picture marker to go into (check the Greeting text).` : `Uploaded ${r.urls.length} picture${r.urls.length === 1 ? '' : 's'} to ${[r.root, r.folder].filter(Boolean).join(' / ')}${r.createdFolder ? ' (new folder)' : ''}.`, !!miss);
    } catch (e) { say(String(e && e.message || e), true); }
    finally { idx.forEach(i => busyIdx.delete(i)); paintBusy(); }
  }
  document.addEventListener('click', async ev => {
    const up = ev.target.closest && ev.target.closest('[data-imgup]');
    if (up) {
      ev.preventDefault(); ev.stopPropagation(); pendingIdx = +up.dataset.imgup || 0;
      const inp = document.querySelector('[data-imgfile]'); if (!inp) return;
      if (!(await ensureLogin())) return;
      inp.value = ''; try { inp.click(); } catch {} return;
    }
    const cl = ev.target.closest && ev.target.closest('[data-imgclear]');
    if (cl && window.__bbImg) { ev.preventDefault(); ev.stopPropagation(); window.__bbImg.clear(+cl.dataset.imgclear); }
  }, true);
  document.addEventListener('change', ev => {
    const inp = ev.target.closest && ev.target.closest('[data-imgfile]');
    if (inp && inp.files && inp.files.length) { const files = [...inp.files], at = pendingIdx; inp.value = ''; send(files, at); return; }
    const sel = ev.target.closest && ev.target.closest('[data-imgacct]');
    if (sel && window.__bbImg) window.__bbImg.setAccount(sel.value);
  });
  document.addEventListener('input', ev => {            // the folder name in the box follows the Scene name and character name as they are typed
    const k = ev.target && ev.target.dataset && ev.target.dataset.k; if (k !== 'h.scene' && k !== 'n.1') return;
    const H = window.__bbImg, f = H && H.v ? folderLabel(H.v.header && H.v.header.scene, H.v.names && H.v.names[1]) : '';
    document.querySelectorAll('[data-imgfolder]').forEach(el => { el.textContent = f || 'Scene name - First name'; });
  });
  const firstFree = () => { const L = window.__bbImg ? window.__bbImg.links() : []; const i = L.findIndex((x, k) => !x && !busyIdx.has(k)); return i < 0 ? 0 : i; };
  const dropPane = ev => ev.target.closest && ev.target.closest('[data-imgdrop]');
  document.addEventListener('dragover', ev => { const d = dropPane(ev); if (d && ev.dataTransfer && [...(ev.dataTransfer.types || [])].includes('Files')) { ev.preventDefault(); d.classList.add('drop'); } });
  document.addEventListener('dragleave', ev => { const d = dropPane(ev); if (d && !d.contains(ev.relatedTarget)) d.classList.remove('drop'); });
  document.addEventListener('drop', ev => {                 // dropped pictures fill the markers in order, from the marker you drop on (or the first one still empty)
    const d = dropPane(ev); if (!d) return; ev.preventDefault(); d.classList.remove('drop');
    const onBtn = ev.target.closest && ev.target.closest('[data-imgup]');
    send(ev.dataTransfer.files || [], onBtn ? +onBtn.dataset.imgup || 0 : firstFree());
  });

  window.ImageHost = {folderLabel, ensureLogin, isBusy: i => busyIdx.has(i), get accounts() { return !!(st && st.accounts); }, refresh: async () => { await load(); paint(); }};
  async function init() { ensureBlock(); await load(); paint(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  document.addEventListener('click', ev => { const t = ev.target.closest && ev.target.closest('[data-view="settings"], [data-tab="settings"]'); if (t) setTimeout(() => window.ImageHost.refresh(), 50); });
})();
