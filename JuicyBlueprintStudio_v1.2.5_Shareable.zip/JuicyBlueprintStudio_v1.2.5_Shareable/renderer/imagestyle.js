/* The Image Generation section is a list of keywords for an image model, not sentences.
   "soft ash-brown hair in a long loose braid woven with tiny glass beads" should be
   "ash-brown hair, long loose braid, glass beads".
   - issues(text, kind): the items that read like a sentence (too many words, or filler words), and why
   - RULE: what the AI is told                                                                        */
(function () {
  // The tool's own Image Generation rules (the style limits, the creature and human instructions to the AI, the checks and the defaults it fills in) are for the Personal edition. The Shareable edition is built with this set to false: its people use their own template's instructions and their own rules, and the app adds none.
  const IMAGE_RULES = false;
  const FILLER = /\b(in a|in an|in the|woven with|woven into|with a|with an|with tiny|that|which|while|who|as if|as though|so that|because|slightly|faintly|barely|somewhat|very|rather|tiny|little bit|a bit|kind of|sort of)\b/i;
  const VERB = /\b(is|are|was|were|has|have|had|looks|looking|seems|appears|wears|wearing (?:a|an|the))\b/i;
  // appearance and clothing are short keywords; the action/background can be a short phrase or two
  const MAXW = {appearance: 4, clothing: 5, action: 7};
  // Her hands are always empty, and the image keywords never mention hands or anything held ("wrench in hand", "holding a cup", but also "empty hands" or "hands free"):
  // an item that does is taken out. Gloves, rings and bracelets are clothing and stay.
  const HANDS = /\b(?:hands?\b(?!-)|hand-?held|handheld|fists?|holds?ing|holding|holds|carrying|carries|wielding|wields|gripping|grasping|clutching|brandishing|empty-handed)/i;
  const mentionsHands = it => IMAGE_RULES && HANDS.test(String(it || ''));
  function stripHands(text) {
    if (!IMAGE_RULES) return {text: String(text == null ? '' : text), removed: []};
    const removed = [], keep = [];
    for (const it of items(text)) (mentionsHands(it) ? removed : keep).push(it);
    return {text: removed.length ? keep.join(', ') : String(text == null ? '' : text), removed};
  }
  function items(text) { return String(text || '').split(/[,;\n]+/).map(x => x.trim()).filter(Boolean); }
  function issues(text, kind = 'appearance') {
    const max = MAXW[kind] || 5, out = [];
    for (const it of items(text)) {
      if (/^close-up shot$/i.test(it)) continue;
      const words = it.split(/\s+/).filter(Boolean).length, why = [];
      if (words > max) why.push(`${words} words`);
      if (FILLER.test(it)) why.push(`filler ("${it.match(FILLER)[0]}")`);
      if (VERB.test(it) || /[.!?]$/.test(it)) why.push('reads like a sentence');
      if (mentionsHands(it)) why.push('mentions hands or something held (her hands are always empty and never mentioned)');
      if (why.length) out.push({item: it, why: why.join(', ')});
    }
    return out;
  }
  const RULE = 'HANDS: her hands are ALWAYS empty and are NEVER mentioned. Do not write anything about her hands, fingers or fists, or about anything she holds, carries or grips (no "wrench in hand", no "holding a cup", no "carrying a bag"), and also do not write "empty hands", "bare hands" or "hands free": leave hands out completely. Clothing and Accessories are things she wears, never things she holds. IMAGE GENERATION STYLE: comma-separated keywords for an image model, never sentences. Each item is one to four words (the action and background may use short phrases), with no filler words ("in a", "woven with", "tiny", "faintly", "very") and no verbs like "has" or "wears". Example: "ash-brown hair, long loose braid, large gray-green eyes, pale skin, freckles, delicate features, soft rounded cheeks, faint collarbone scars". Keep every real detail; drop only the filler.';
  // Turn sentence-like prompts into keywords the app can offer instead: drop the subject and verb ("She wears"), the articles and the
  // filler, and split on the joining words ("in a", "woven with", "with a", "and") so every item is a short keyword.
  const VERBS = '(?:has|have|had|wears?|wearing|is|are|was|were|looks?|looking|seems?|appears?|sports?|carries|carrying|dressed in|clad in)';
  const SUBJ_PRO = new RegExp('^(?:(?:she|he|they|the character|her|his)\\s+)?' + VERBS + '\\s+', 'i'), SUBJ_NAME = new RegExp('^[A-Z][a-z]+(?:\\s[A-Z][a-z]+)?\\s+' + VERBS + '\\s+');
  const JOIN = /\s+(?:woven (?:with|into)|braided (?:with|into)|tied (?:with|in)|in|with|and|of|that|which|while|who|where|when|featuring|topped with|wrapped in|adorned with|decorated with|framing|falling over|over)\s+/i;
  const ADV = /\b(?:very|slightly|faintly|barely|somewhat|rather|tiny|little bit|a bit|kind of|sort of|really|quite)\b/gi;
  const CLAUSE = /^(?:is|are|was|were|has|have|had|seems?|appears?|looks?|glows?|shimmers?|falls?|hangs?|rests?|sits?|stands?)\b/i;
  // {text, dropped}: the keywords, and the pieces that only make sense as a sentence (left out, shown to the person so nothing is lost silently)
  function convert(text, kind = 'appearance') {
    const max = MAXW[kind] || 5, out = [], dropped = [], seen = new Set();
    const push = w => { w = w.replace(/\s+/g, ' ').replace(/^[\s,;:.\-]+|[\s,;:.\-]+$/g, '').trim(); if (w.length < 3 || /^(?:and|with|the|a|an|her|his)$/i.test(w) || seen.has(w.toLowerCase())) return; seen.add(w.toLowerCase()); out.push(w); };
    for (const raw of items(text)) {
      const it0 = raw.replace(/[.!?]+$/, '').trim();
      if (!issues(it0, kind).length) { push(it0); continue; }
      const it = it0.replace(/^(?:and|but|while|then)\s+/i, '').replace(SUBJ_PRO, '').replace(SUBJ_NAME, '');
      for (let part of it.split(JOIN)) {
        part = part.replace(/^(?:with|and|in|of|on)\s+/i, '').replace(/^(?:a|an|the|some|her|his|their|its)\s+/i, '').replace(ADV, ' ').replace(/\b(?:in a|in an|in the|with a|with an|that|which|as if|as though|so that|because)\b/gi, ' ').replace(/\s+/g, ' ').trim();
        if (!part) continue;
        if (CLAUSE.test(part)) { dropped.push(part); continue; }
        const w = part.split(' ').filter(Boolean); if (w.length > max) part = w.slice(-max).join(' ');
        if (issues(part, kind).length) { dropped.push(part); continue; }
        push(part);
      }
    }
    return {text: out.join(', '), dropped};
  }
  const toKeywords = (text, kind = 'appearance') => convert(text, kind).text;
  // What an AI must never put into the Appearance keywords, and what the app takes out if it does anyway:
  // the locked quality line and the negative line, which the template already has, so repeating them doubles them;
  // the character's age ("22-year-old woman": the age has its own field), and a tattoo the scenario card never gave her.
  const DONT_BASE = 'APPEARANCE KEYWORDS, WHAT NOT TO WRITE: (1) never the character\'s age or any age words such as "N-year-old", "adult woman" or "young woman"; the age has its own field and the image keywords do not state it. (2) Never repeat the locked quality line: masterpiece, 8k, best quality, hyper detailed, soft shading, cinematic lighting, ultra-HD, sharp focus, high saturation, detailed eyes, detailed face, realistic textures, large breasts, thick thighs, wide hips, voluptuous; or any negative words such as low quality, blurry, deformed, bad anatomy, watermark; the app already adds them.';
  const TATTOO_OPT = ' (3) A tattoo or a scar is optional: write one only when the scenario card or the creator\'s notes give her one; most characters have neither.';
  const ONE_VALUE = ' (5) One value per feature: one hair color and style, one eye color, one skin color. Never two colors or two phrases for the same feature (not "steel gray eyes, glowing amber eyes", not "wine red skin, deep red skin").';
  // an ordinary character: the template\'s lock, nothing but hair, eyes, skin
  const DONT = DONT_BASE + TATTOO_OPT + ' (4) The template\'s lock is: ONLY hair, eyes, skin (and a tattoo or scar only when the card gives one). Write nothing else about her, even if the card describes it: no build or body shape, no face, jaw, nose or cheek shape, no freckles or moles, no expression, no accessories.' + ONE_VALUE;
  // a creature, a monster or an SCP anomaly: the Appearance is the creature\'s body, not a human woman with a few features added. This replaces the template\'s "hair, eyes, skin only" line for the Appearance.
  const DONT_CREATURE = DONT_BASE + TATTOO_OPT + ' (4) THIS CARD IS A CREATURE, MONSTER OR ANOMALY, SO THE APPEARANCE IS CREATURE-FOCUSED, NOT HUMAN-FOCUSED, and this replaces the template\'s "only hair, eyes, skin" line for the Appearance. Write what she IS first: the features of her kind that an image model can draw: head and face (horns, ears, muzzle or snout, fangs, mandibles, slit or glowing eyes), what covers her body (fur, scales, feathers, chitin, stone, bark, translucent or slick skin), and her extra parts (tail, wings, claws, hooves, antennae, extra limbs), with their colors and textures; then her hair or mane if she has one. Her eyes, skin and hair are written as her kind\'s own, not as an ordinary woman\'s. She is one kind of creature: never mix features of different kinds (an imp gets imp features, not fae wings), and never a human with a horn or a tail added on top. For an SCP anomaly the look comes from what the anomaly is, so it must read as the anomaly. No build, face-shape or expression words, and no accessories; those stay out.' + ONE_VALUE;
  const QUAL = /^(?:masterpiece|8k|4k|best quality|high quality|hyper[- ]?detailed|highly detailed|ultra[- ]?detailed|soft shading|cinematic lighting|ultra[- ]?hd|sharp focus|high saturation|detailed eyes|detailed face|realistic textures?|large breasts|thick thighs|wide hips|voluptuous|photorealistic)$/i;
  const NEG = /^(?:low quality|child|blurry(?: face| eyes)?|out of focus|deformed|bad anatomy|extra limbs|extra fingers|fused fingers|mutated hands|poorly drawn (?:hands|face)|bad proportions|cloned face|duplicate|watermark|text|logo|signature|mixed hair|hair color bleed|character mixup|clothing swap|identical faces|merged bodies|bad hands|low detail|ugly|censored|border|frame)$/i;
  const NUMW = '(?:\\d{1,2}|(?:twenty|thirty|forty|fifty|sixty)(?:[- ](?:one|two|three|four|five|six|seven|eight|nine))?)';
  const AGEPH = new RegExp('\\b(?:an?\\s+)?' + NUMW + '[- ]?(?:years?|yrs?)[- ]?old\\b(?:\\s+(?:woman|female|lady|girl))?|\\b(?:aged?|age)[: ]+' + NUMW + '\\b|\\b' + NUMW + '\\s*(?:yo|y\\/o)\\b(?:\\s+(?:woman|female))?', 'gi');
  const AGEWORD = /^(?:an?\s+)?(?:adult|young|mature|grown|older|youthful)\s+(?:woman|female|lady)$|^(?:woman|female|lady|girl)$/i;
  const TATTOO = /\b(?:tattoo(?:s|ed)?|inked|body ink|body art)\b/i;
  // {text, removed}: the keywords without those items
  function clean(text, opt = {}) {
    const removed = []; let t = String(text || '');
    if (!IMAGE_RULES) { const own0 = new Set(items(`${opt.quality || ''},${opt.negative || ''}`.replace(/[()]/g, ' ')).map(x => x.toLowerCase())); if (!own0.size) return {text: t.trim(), removed}; const ownIt = x => own0.has(String(x).toLowerCase()); t = t.replace(/\(([^()]*)\)/g, (m, inner) => { const its = items(inner); const hit = its.filter(ownIt).length; if (hit >= 3 || (hit >= 1 && hit === its.length)) { removed.push(m); return ''; } return m; }); const keep = items(t).filter(it => { it = it.replace(/^\(|\)$/g, '').trim(); if (ownIt(it)) { removed.push(it); return false; } return true; }); return {text: keep.join(', '), removed}; }    // Shareable: only a copy of the template's own locked lines is taken out, nothing else about what was written
    // the locked quality and negative prompts of this template or Settings (whatever the person set), item by item
    const own = new Set(items(`${opt.quality || ''},${opt.negative || ''}`.replace(/[()]/g, ' ')).map(x => x.toLowerCase()));
    const locked = x => QUAL.test(x) || NEG.test(x) || own.has(x.toLowerCase());
    t = t.replace(/\(([^()]*)\)/g, (m, inner) => { const its = items(inner); const hit = its.filter(locked).length; if (hit >= 3 || (hit >= 1 && hit === its.length)) { removed.push(m); return ''; } return m; });
    const out = [], seen = new Set();
    for (let it of items(t)) {
      it = it.replace(/^\(|\)$/g, '').trim();
      if (QUAL.test(it) || own.has(it.toLowerCase())) { removed.push(it); continue; }
      const noAge = it.replace(AGEPH, ' ').replace(/\s+/g, ' ').replace(/^[\s,;:.\-]+|[\s,;:.\-]+$/g, '').trim();
      if (noAge !== it) { removed.push(it); it = noAge; }
      if (!it || AGEWORD.test(it) || /^\d{1,2}$/.test(it)) { if (it) removed.push(it); continue; }
      if (!opt.allowTattoo && TATTOO.test(it)) { removed.push(it); continue; }
      if (seen.has(it.toLowerCase())) continue; seen.add(it.toLowerCase()); out.push(it);
    }
    return {text: out.join(', '), removed};
  }
  const api = {rulesOn: IMAGE_RULES, issues, items, stripHands, RULE, DONT, DONT_CREATURE, toKeywords, convert, clean};
  if (typeof window !== 'undefined') window.ImageStyle = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
