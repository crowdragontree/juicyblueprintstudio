/* Likeable NTR cards (the NTR tab) come in five types, fixed by day: Monday Emotional, Tuesday NTR, Thursday Misunderstanding,
   Saturday Light and Sunday Emotional Post-NTR. A chat model must never be left guessing what happened: a model that finds a gap fills it with full
   cheating (or, in a Light card, with an ongoing affair), and a model told the relationship "was" something treats it as over.
   This checks the things that cause that: the relationship written in the past tense, wording that reads as more than happened, and a
   Scenario / System Rules text (or the card's Long-Engagement Engine) that does not state the fixed facts. It also holds the type names,
   the day order and the template numbers, so the app and the Bot Builder use one list. Shared by Node and the renderer.
   ANTI-NTR is not NTR and never has an NTR type. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.NtrCanon = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  // ---- the four types: key, what the card's NTR Type field says, the badge, the template number, the day
  // 'full' is the plain NTR card: a real, voluntary betrayal (an affair), named plainly and never shown
  const TYPES = ['emotional', 'misunderstanding', 'full', 'light', 'emotionalpost'];
  const LABEL = {emotional: 'EMOTIONAL', misunderstanding: 'MISUNDERSTANDING', full: 'NTR', light: 'LIGHT', emotionalpost: 'EMOTIONAL POST-NTR'};
  const NAME = {emotional: 'Emotional NTR', misunderstanding: 'Misunderstanding NTR', full: 'NTR', light: 'Light NTR', emotionalpost: 'Emotional Post-NTR'};
  const TEMPLATE_NO = {emotional: 8, misunderstanding: 9, full: 6, light: 11, emotionalpost: 12};
  const TYPE_BY_DAY = {Monday: 'emotional', Tuesday: 'full', Thursday: 'misunderstanding', Saturday: 'light', Sunday: 'emotionalpost'};
  const ORDER_TEXT = 'Monday Emotional NTR, Tuesday NTR, Thursday Misunderstanding NTR, Saturday Light NTR, Sunday Emotional Post-NTR';
  // the type a piece of text names ("EMOTIONAL POST-NTR" is checked before "EMOTIONAL", and plain "NTR" last); '' when it names none
  const typeKey = t => { t = String(t || ''); if (/anti[\s_-]*ntr/i.test(t)) return ''; if (/post[\s_-]*ntr|emotional[\s_-]*post/i.test(t)) return 'emotionalpost'; if (/misunderstand/i.test(t)) return 'misunderstanding'; if (/\blight\b/i.test(t)) return 'light'; if (/emotional/i.test(t)) return 'emotional'; if (/\bntr\b|\bfull\b/i.test(t)) return 'full'; return ''; };
  // The Introduction of every NTR bot starts with its topic: [Emotional NTR], [Misunderstanding NTR], [NTR], [Light NTR], [Emotional Post-NTR],
  // [Preventable NTR] or [Post-NTR]. ANTI-NTR is not NTR and never gets one ('' for it, and for every card that is not NTR).
  const ANTI = /anti[\s_-]*ntr|"ntr\?"|ntr\?/i;
  function topicTag(card) {
    if (!card) return '';
    const F = card.fields || {}, where = `${card.laneTab || ''} ${card.series || ''} ${card.lane || ''} ${card.slot || ''} ${card.seriesLabel || ''}`;
    if (ANTI.test(where) || ANTI.test(String(F['Series'] || ''))) return '';
    if (/preventable/i.test(where)) return '[Preventable NTR]';
    if (/post[\s_-]*ntr/i.test(`${card.laneTab || ''} ${card.series || ''} ${card.lane || ''}`) && !F['NTR Type']) return '[Post-NTR]';
    if (!/\bntr\b/i.test(where) && !F['NTR Type']) return '';
    const t = typeKey(F['NTR Type']) || TYPE_BY_DAY[String(card.day || F['Day Assignment'] || '').trim()] || 'full';
    return `[${NAME[t]}]`;
  }
  // puts the topic in front of an Introduction: any other leading [label] is dropped (a Futa / Female marker stays, after the topic)
  function withTopic(text, tag) {
    const t = String(text || ''); if (!tag) return t;
    const lead = (t.match(/^(?:\s*\[[^\]\n]*\])+/) || [''])[0], keep = (lead.match(/\[[^\]\n]*\]/g) || []).filter(g => /futa|female\s+bot|any\s+pov|male\s*\/\s*female/i.test(g));
    return [tag, ...keep, t.slice(lead.length).replace(/^\s+/, '')].filter(Boolean).join(' ').trim();
  }
  // the form of a Light card: KISS, ONE-TIME AFFAIR or DEFECTION (she left {{user}}'s company to work for his)
  const LIGHT_FORMS = {kiss: 'KISS', once: 'ONE-TIME AFFAIR', defection: 'DEFECTION'};
  const lightForm = t => { t = String(t || ''); if (/defect|left (?:your|the) company|his company/i.test(t)) return 'defection'; if (/one[\s-]*time|affair|one night|slept/i.test(t)) return 'once'; if (/kiss/i.test(t)) return 'kiss'; return ''; };
  // a bot template says which type it is written for: [NTR TEMPLATE TYPE LOCK: EMOTIONAL | MISUNDERSTANDING | LIGHT | EMOTIONAL POST-NTR]
  const TEMPLATE_RE = /\[NTR TEMPLATE TYPE LOCK: (EMOTIONAL POST-NTR|EMOTIONAL|MISUNDERSTANDING|LIGHT|NTR)\]/;
  const templateType = raw => { const m = TEMPLATE_RE.exec(String(raw || '')); return m ? typeKey(m[1]) : ''; };

  const U = '\\{\\{user\\}\\}[\'’]s';
  // the relationship written as something that is over ("was your wife", "used to be {{user}}'s girlfriend", "your ex-wife")
  const PAST = new RegExp(`\\b(?:was|were|used to be|once was)\\s+(?:still\\s+)?(?:${U}|your|his)\\s+(?:wife|girlfriend|partner|fianc(?:e|é)e)\\b(?!\\s+(?:when|before|until|then|at the time|back then))|\\b(?:ex|former)[- ](?:wife|girlfriend|partner)\\b`, 'i');
  const NEG = /(?:never|n't|not|no|nothing|without|hasn't|hadn't|didn't)\s+(?:\w+\s+){0,2}$/i;
  const HEDGE = /(?:looks?|looked|seems?|seemed|like|as if|as though|might|could|may|maybe|suspect\w*|think\w*|thought|believe\w*|wonder\w*|fear\w*|afraid)\s+(?:\w+\s+){0,3}$/i;
  // words that read as physical cheating when used for what she did
  const LOADED_EMO = /\b(?:an? (?:secret )?affair|the affair|having an affair|cheated on|cheating on|cheat(?:ed|ing)\b|cheater|unfaithful|infidelity|adulter\w*|betrayed you with|another man'?s bed)\b/gi;
  const LOADED_MIS = /\b(?:cheated on you|cheating on you|she (?:is|was|has been) (?:cheating|unfaithful)|had an affair|having an affair|an affair with|betrayed you with|unfaithful)\b/gi;
  // a Light card names one act plainly; wording that makes it an ongoing affair is what it must never say
  const LOADED_LIGHT = /\b(?:having an affair|an ongoing affair|(?:still|keeps?|been) sleeping with|sleeping with him (?:for|since|every)|(?:still|keeps?) (?:seeing|meeting) him (?:in secret|behind)|affair (?:for|since) (?:weeks|months|years))\b/gi;
  const affirmative = (re, t, hedge) => {
    re.lastIndex = 0; let m;
    while ((m = re.exec(t))) {
      const before = t.slice(Math.max(0, m.index - 30), m.index);
      if (NEG.test(before) || (hedge && HEDGE.test(before))) continue;
      return m[0];
    }
    return null;
  };
  // the relationship status in the past tense
  const tense = text => { const m = String(text || '').match(PAST); return m ? m[0] : null; };
  const loaded = (text, type) => type === 'full' ? null : type === 'emotional' || type === 'emotionalpost' ? affirmative(LOADED_EMO, String(text || ''), false)
    : type === 'misunderstanding' ? affirmative(LOADED_MIS, String(text || ''), true)
    : type === 'light' ? affirmative(LOADED_LIGHT, String(text || ''), false) : null;

  // what the Scenario / System Rules text (or the card's Long-Engagement Engine) must say, per type
  const NOTHING_PHYSICAL = /\b(?:nothing physical|no sex|never (?:touched|kissed|slept|been physical)|(?:has not|hasn['’]t|have not|haven['’]t) (?:touched|kissed|slept|been physical))\b/i;
  const NEVER = {
    emotional: NOTHING_PHYSICAL,
    emotionalpost: NOTHING_PHYSICAL,
    misunderstanding: /\b(?:no betrayal|nothing wrong|done nothing|not (?:cheat|betray)\w*|never (?:cheat|betray)\w*|did not (?:cheat|betray)|didn['’]t (?:cheat|betray)|is innocent|are innocent)\b/i,
    light: /\b(?:only once|just once|one time|happened once|once and never again|a single (?:kiss|night)|one kiss|one night|nothing (?:more|else) (?:has )?happened|(?:has not|hasn['’]t|never) happened again|never again|it is over|it's over)\b/i,
    full: /\b(?:that is all|this is all|all of it|nothing (?:more|else|worse)|never (?:shown|replayed|invent\w*)|no (?:other|second|new) (?:man|affair|secret))\b/i
  };
  const ASKED = /\b(?:accus\w*|asks? (?:her )?(?:directly|point[- ]blank|if|whether)|direct(?:ly)? (?:question|ask\w*)|if \{\{user\}\} (?:asks|accuses|suspects|questions))/i;
  const STATUS = new RegExp(`\\bis (?:still )?(?:${U}|your|his) (?:wife|girlfriend)\\b|\\b(?:wife|girlfriend) and (?:they|you) are together\\b|present tense`, 'i');
  const WHAT = {
    emotional: 'what she did is nothing physical, only the emotional line',
    misunderstanding: 'she has done nothing wrong and no betrayal of any kind has happened',
    light: 'what she did is one act, already over: one kiss, one night, or leaving {{user}}\'s company for his, and nothing more',
    emotionalpost: 'what she did is nothing physical, only the emotional line, and {{user}} found out weeks ago',
    full: 'what she did is a real, voluntary affair with the other man, named plainly and never shown, and nothing beyond it'
  };
  const MISSING_NEVER = {
    emotional: 'what has never happened, stated plainly (nothing physical: no sex, no kiss, no touching beyond ordinary social contact, no hotel, no almost)',
    emotionalpost: 'what has never happened, stated plainly (nothing physical: no sex, no kiss, no touching beyond ordinary social contact, no hotel, no almost)',
    misunderstanding: 'that she has done nothing wrong and no betrayal of any kind has happened',
    light: 'that what she did happened once and is over (one kiss, one night, or the move to his company), and that nothing more has happened since',
    full: 'exactly what she did, in plain non-graphic words (the affair: with whom, how long it has been going on; it is ACTIVE and still going on, never ended), and that this is all of it: nothing worse is ever invented'
  };
  // the items a Scenario / engine text is missing ([] when it is complete)
  function missing(text, type) {
    if (!NEVER[type]) return [];
    const t = String(text || ''), out = [];
    if (!STATUS.test(t)) out.push('the relationship in the present tense (she IS {{user}}\'s wife or girlfriend and they are together now)');
    if (!NEVER[type].test(t)) out.push(MISSING_NEVER[type]);
    if (!ASKED.test(t)) out.push('what she says when {{user}} accuses or asks her directly (a true answer, never a confirmation of more)');
    return out;
  }
  // a Scenario / System Rules text, a card's Long-Engagement Engine, or prose (Introduction, Greeting, Setup, Personality)
  // where: 'scenario' (also the card's engine field) checks the fixed facts and the tense; 'prose' checks the tense and the wording
  function problem(text, type, where) {
    const t = String(text || ''); if (t.trim().length < 80 || !NEVER[type]) return null;
    const ts = tense(t); if (ts) return `writes the relationship in the past tense ("${ts}"). She IS {{user}}'s wife or girlfriend and they are together now: write "is", never "was", "used to be", "ex" or "former". A past-tense relationship makes the chat model treat it as over.`;
    if (where === 'scenario') {
      const m = missing(t, type);
      return m.length ? `does not state the fixed facts the chat model needs. The CANON LOCK must say: ${m.join('; ')}. A model that finds a gap here fills it with ${type === 'light' ? 'an ongoing affair' : type === 'full' ? 'a worse betrayal than the card states' : 'full cheating'}.` : null;
    }
    const l = loaded(t, type);
    if (l) return type === 'emotional' || type === 'emotionalpost'
      ? `uses wording that reads as physical cheating ("${l}"). Name the emotional line in concrete words (what she told him, shared with him or gave him, and for how long) and never call it an affair or cheating. Nothing physical has happened.`
      : type === 'light'
        ? `makes it more than one act ("${l}"). A Light NTR card is one kiss, one night, or her move to his company: it happened once, it is over, and nothing more has happened since.`
        : `calls her a cheater or confirms a betrayal ("${l}"). Nothing happened. Show only the clues, and never write the betrayal it looks like as fact.`;
    return null;
  }
  // the rule the AI is given for the System Rules / Scenario of an NTR bot and for the card's Long-Engagement Engine
  const RULE = {
    emotional: 'CANON LOCK (the Scenario / System Rules must state these facts plainly, because a chat model that finds a gap fills it with full cheating): (1) she IS {{user}}\'s wife or girlfriend and they are together now, always in the present tense, never "was"; (2) nothing physical has ever happened between her and the other man (no sex, no kiss, no touching beyond ordinary social contact, no hotel, no almost); (3) what she did, in plain words (what she gave him, for how long), and that this is all of it; (4) no character or narration calls her a cheater or hints at more, and nothing worse is ever invented (a physical affair, a hidden past, a new secret); (5) if {{user}} accuses her of more she answers truthfully ("No, nothing physical") and admits what is true in stages as the conversation earns it.',
    misunderstanding: 'CANON LOCK (the Scenario / System Rules must state these facts plainly, because a chat model that finds a gap fills it with real cheating): (1) she IS {{user}}\'s wife or girlfriend and they are together now, always in the present tense, never "was"; (2) she has done nothing wrong: no betrayal of any kind, physical or emotional, has happened, and the other man is innocent; (3) the true explanation of what {{user}} sees, in one plain sentence; (4) no character or narration calls her a cheater, confirms the betrayal it looks like, or invents a real one; (5) if {{user}} asks or accuses her directly she answers truthfully ("No, I didn\'t") and gives the rest of the truth in stages, each with proof in the scene, as the conversation earns it.',
    light: 'CANON LOCK (the Scenario / System Rules must state these facts plainly, because a chat model that finds a gap turns one mistake into an ongoing affair): (1) she IS {{user}}\'s wife or girlfriend and they are together now, always in the present tense, never "was"; (2) exactly what she did, in one plain, non-graphic sentence: one kiss, one night with him, or leaving {{user}}\'s company to work for his; (3) it happened once and it is over: nothing more has happened since, and there is no ongoing affair; (4) she regrets it and still loves {{user}}; no character or narration replays it in detail, hints at more, or invents anything worse (other times, a longer affair, a hidden past, a new secret); (5) if {{user}} accuses her of more she answers truthfully ("Once. Only once." or "Just the kiss") and tells the rest of what is true in stages as the conversation earns it.',
    full: 'CANON LOCK (the Scenario / System Rules must state these facts plainly, because a chat model that finds a gap invents a worse betrayal or a different story): (1) she IS {{user}}\'s wife or girlfriend and they are together now, always in the present tense, never "was"; (2) exactly what she did, in plain, non-graphic words: the affair with the other man, how long it has been going on (weeks to about 3 months, never more than 4), and that it is ACTIVE and ONGOING (she has not ended it, it has not stopped, and it is never written as past; an affair that is over is Post-NTR or Light, not NTR); and that {{user}} and she have been together 3 to 7 years in all (1 to 4 years married if she is his wife); (3) it is never shown or replayed: no sex scene and no sexual detail; (4) that is all of it: no character or narration invents more (other men, a hidden child, a secret past, a new betrayal) or retcons it into innocence, coercion or a misunderstanding; (5) if {{user}} asks or accuses her directly she answers truthfully, and tells the rest of what is true in stages as the conversation earns it.',
    emotionalpost: 'CANON LOCK (the Scenario / System Rules must state these facts plainly, because a chat model that finds a gap fills it with full cheating): (1) she IS {{user}}\'s wife or girlfriend and they are together now, always in the present tense, never "was"; (2) the emotional betrayal is already in the open: {{user}} found out (say when, in weeks), she admitted it, and they are still together; what comes after is this card\'s own story, not a stock repair routine; (3) nothing physical has ever happened between her and the other man (no sex, no kiss, no touching beyond ordinary social contact, no hotel, no almost), and what she did is the emotional line in plain words (what she gave him, for how long); (4) no character or narration calls her a cheater or hints at more, and nothing worse is ever invented (a physical affair, a hidden past, a new secret); (5) if {{user}} accuses her of more she answers truthfully ("No, nothing physical") and admits what is still unsaid in stages as the conversation earns it.'
  };
  // the CANON LOCK paragraph itself, for a bot whose Scenario came back without it (the templates carry the same rule; this is the safety net)
  const sentence = (t, max) => { t = String(t || '').replace(/\s+/g, ' ').trim(); if (!t) return ''; const m = t.match(/^.{20,}?[.!?](?=\s|$)/); let x = m ? m[0] : t; if (x.length > max) x = x.slice(0, max).replace(/\s+\S*$/, ''); return x.replace(/[.!?\s]+$/, '').replace(/^(She|He|They)\b/, m => m.toLowerCase()); };
  function ledger(type, o, compact) {
    o = o || {}; let n1 = o.n1 || 'She', n2 = o.n2 || 'the other man', rel = /girlfriend/i.test(o.rel || '') ? 'girlfriend' : 'wife', fact = sentence(o.fact, 220);
    if (/\b(?:divorc\w*|lawyers?|attorneys?|custody|legal papers|trial separation|legal separation|moving out|moved out|signed the papers)\b/i.test(fact)) fact = '';   // a fact that reads as a divorce plot would trip the NTR check on the ledger itself: the ledger then states only the fixed facts
    if (!NEVER[type]) type = 'emotional';
    if (compact) {   // the same facts in fewer words, for a Scenario with no room left in its limit
      const c = `[CANON LOCK]: ${n1} IS {{user}}'s ${rel} and they are together now (present tense, never "was"). `;
      if (type === 'emotional') return c + `Nothing physical has ever happened between her and ${n2}. ${fact ? `What she did, plainly: ${fact}. ` : ''}No one calls her a cheater or hints at more, and nothing worse is invented. If {{user}} accuses her of more, she answers truthfully ("No, nothing physical") and admits what is true in stages.`;
      if (type === 'full') return c + `${fact ? `What she did, plainly: ${fact}. ` : ''}It is never shown or replayed, and that is all of it: nothing worse is invented and nothing is retconned into innocence. If {{user}} asks her directly, she answers truthfully and tells the rest in stages.`;
      if (type === 'emotionalpost') return c + `{{user}} already found out and she admitted it; they are still together. Nothing physical has ever happened between her and ${n2}. ${fact ? `What she did, plainly: ${fact}. ` : ''}No one calls her a cheater or hints at more, and nothing worse is invented. If {{user}} accuses her of more, she answers truthfully ("No, nothing physical") and admits what is still unsaid in stages.`;
      if (type === 'light') return c + `${fact ? `What she did, plainly: ${fact}. ` : ''}It happened once and it is over: nothing more has happened since, and there is no ongoing affair. No one replays it, hints at more, or invents anything worse. If {{user}} accuses her of more, she answers truthfully ("Once. Only once.") and tells the rest in stages.`;
      return c + `She has done nothing wrong: no betrayal of any kind has happened, and ${n2} is innocent. ${fact ? `The true explanation: ${fact}. ` : ''}No one calls her a cheater or confirms a betrayal. If {{user}} accuses her directly, she answers truthfully ("No, I didn't") and gives the rest in stages, with proof.`;
    }
    const head = `[CANON LOCK]: These facts never change, whatever {{user}} says, assumes, or accuses. ${n1} IS {{user}}'s ${rel} and they are together now. Always write the relationship in the present tense, never "was". `;
    if (type === 'emotional') return head + `Nothing physical has ever happened between ${n1} and ${n2}: no sex, no kiss, no touching beyond ordinary social contact, no hotel, no almost. ${fact ? `What she did, plainly: ${fact}. That is all of it. ` : ''}No character or narration calls her a cheater or hints at more, and nothing worse is ever invented, such as a physical affair, a hidden past, or a new secret. If {{user}} accuses her of more, she answers truthfully ("No, nothing physical") and admits what is true in stages as the conversation earns it.`;
    if (type === 'full') return head + `${fact ? `What ${n1} did, plainly: ${fact}. ` : ''}It is real and it is never shown or replayed: no sex scene and no sexual detail. That is all of it: no character or narration invents more, such as other men, a hidden child, a secret past or a new betrayal, and nothing retcons it into innocence, coercion or a misunderstanding. If {{user}} asks or accuses her directly, she answers truthfully and tells the rest of what is true in stages as the conversation earns it.`;
    if (type === 'emotionalpost') return head + `The emotional betrayal is already in the open: {{user}} found out, ${n1} admitted it, and they are still together. Nothing physical has ever happened between ${n1} and ${n2}: no sex, no kiss, no touching beyond ordinary social contact, no hotel, no almost. ${fact ? `What she did, plainly: ${fact}. That is all of it. ` : ''}No character or narration calls her a cheater or hints at more, and nothing worse is ever invented, such as a physical affair, a hidden past, or a new secret. If {{user}} accuses her of more, she answers truthfully ("No, nothing physical") and admits what is still unsaid in stages as the conversation earns it.`;
    if (type === 'light') return head + `${fact ? `What ${n1} did, plainly: ${fact}. ` : ''}It happened once and it is over: nothing more has happened between ${n1} and ${n2} since, and there is no ongoing affair. She regrets it and still loves {{user}}. No character or narration replays it in detail, hints at more, or invents anything worse, such as other times, a longer affair, a hidden past, or a new secret. If {{user}} accuses her of more, she answers truthfully ("Once. Only once.") and tells the rest of what is true in stages as the conversation earns it.`;
    return head + `${n1} has done nothing wrong: no betrayal of any kind, physical or emotional, has happened, and ${n2} is innocent. ${fact ? `What {{user}} sees has this true explanation: ${fact}. ` : ''}No character or narration calls her a cheater, confirms the betrayal it looks like, or invents a real one. If {{user}} asks or accuses her directly, she answers truthfully ("No, I didn't") and gives the rest of the truth in stages, each with proof in the scene, as the conversation earns it.`;
  }
  // puts the CANON LOCK paragraph into a System Rules block: replaces one that lost its facts, else goes right after the protected User Agency block (or the opening line)
  function withLedger(text, para) {
    const t = String(text || '');
    const at = t.search(/(^|\n)\[CANON LOCK\]/);
    if (at >= 0) { const s0 = t.indexOf('[CANON LOCK]', at); const e0 = t.indexOf('\n\n', s0); return t.slice(0, s0) + para + (e0 >= 0 ? t.slice(e0) : ''); }
    const m = t.match(/\[END USER AGENCY HARD LOCK\]\s*\n/);
    if (m) { const i = m.index + m[0].length; return t.slice(0, i) + para + '\n\n' + t.slice(i).replace(/^\s+/, ''); }
    const o = t.match(/System Rules\s*\{\s*\n/);
    if (o) { const i = o.index + o[0].length; return t.slice(0, i) + para + '\n\n' + t.slice(i).replace(/^\s+/, ''); }
    return para + '\n\n' + t;
  }
  return {TYPES, LABEL, NAME, TEMPLATE_NO, TYPE_BY_DAY, ORDER_TEXT, typeKey, topicTag, withTopic, LIGHT_FORMS, lightForm, TEMPLATE_RE, templateType,
    tense, loaded, missing, problem, RULE, PAST, STATUS, NEVER, ASKED, WHAT, ledger, withLedger};
});
