/* PolicyWeights.
 * Hidden steering numbers for a bot, in the community author's format. They live on the scenario card (visible and editable there); the AI writes the bot from them;
 * the app then places them in the final Scenario block, in the author's order:  [Scenario story] > PolicyWeights > Tracker > System Rules with Guardrails.
 * The lists below are the author's, with their flags:  g = "Needs guardrails",  c = "never go above .8".
 * Pure functions, no requests. Loaded by the renderer and by the AI writer (both editions). */
(function () {
  'use strict';
const POOLS = {
 "Slow Burn": "EmotionalSlowBurn:.7|TenseSlowBurn:.7|SensualSlowBurn:.6|RomanticSlowBurn:.6|PsychologicalSlowBurn:.6|YearningSlowBurn:.7|RestrainedSlowBurn:.6|IntellectualSlowBurn:.5|QuietSlowBurn:.6|DomesticSlowBurn:.5|AgonizingSlowBurn:.7|FrustratingSlowBurn:.6|LongingSlowBurn:.7|UnspokenSlowBurn:.7|BittersweetSlowBurn:.6|DangerousSlowBurn:.6|RivalrySlowBurn:.6|EnemiesToLoversSlowBurn:.7|HealingSlowBurn:.5|TraumaBondSlowBurn:.6|TrustBuildingSlowBurn:.6|FatedSlowBurn:.5|InevitableSlowBurn:.6|AwkwardSlowBurn:.5|TenderSlowBurn:.6|ObsessiveSlowBurn:.5|PossessiveSlowBurn:.6|MelancholicSlowBurn:.6|HopefulSlowBurn:.5|SpiritualSlowBurn:.4|MythicSlowBurn:.4|AnticipationSustain:.8|PayoffDeferral:.7|EmotionalWithholding:.7|SubtextDensity:.8|UnspokenWeight:.7|MeaningInSilence:.8|TensionElasticity:.7|NearMissFrequency:.6|AlmostMomentsBias:.7|IntimacyLatency:.8|TouchDelay:.7|ContactSignificance:.8|DesireSuppression:.6|ImpulseRestraint:.7|GlanceIntensity:.7|MicroReactionFocus:.6|TrustIncrementSize:.6|GradualBonding:.7|VulnerabilityTiming:.6|ConfessionInhibition:.7|EmotionalEchoing:.6|LingeringAftermath:.7|RoutineFamiliarity:.6|ComfortCreep:.7|FrictionMaintenance:.6|SoftConflictPresence:.6|EmotionalRestraint:.7|DetailSelectiveFocus:.6|HeatUnderControl:.6|DesireUnderstatement:.7|UncertaintyPreservation:.7|OutcomeOpacity:.6|PatienceRewardBias:.7|HastePenalty:.6|AtmosphericIntimacy:.6|MoodCarryover:.7|ResonanceOverResolution:.7|ClosureDelay:.6",
 "Horror": "Oppressiveatmosphere:.8|Dread:.7|TensionPersistence:.7|UncertaintyDominance:.8|InformationWithholding:.7|FalseSafetyMoments:.6|PsychologicalErosion:.7g|ParanoiaGrowth:.6g|SelfDoubt:.6|IsolationPressure:.7|AbandonmentThreat:.6|UnseenPresenceIntensity:.8|WatcherEffect:.7|ProximityAnxiety:.6|AnticipationDelay:.7|ThreatAmbiguity:.8|RealityInstability:.6|PerceptualDistortion:.6|Hopelessness:.6c|ReliefScarcity:.7|OppressiveSilence:.8|SoundIntrusionSeverity:.6|EnvironmentalMalevolence:.7g|LocationHostility:.6g|TrustErosion:.6|AllyUncertainty:.6|PursuitPressure:.6|EscapeUncertainty:.7|WaitingAnxiety:.6|NormalcyCorruption:.7|FamiliarUncannyShift:.8|MoralDiscomfort:.6c|NoWinScenarios:.6c|Helplessness:.6|ControlIllusion:.7|RevelationPace:.2|TruthFragmentation:.7|PredatorIntelligence:.6|MaliceImplied:.7|SurveillanceParanoia:.7|ObservationWithoutContact:.8|InternalMonologueIntrusion:.6|IntrusiveThoughts:.6|ThreatInevitability:.6|OutcomeFatalism:.5",
 "Romance": "RomanticTension:.8|EmotionalSlowBurn:.7|ChemistryVolatility:.6|EmotionalIntimacy:.7|VulnerabilityExposure:.6|ConfessionReluctance:.5|AffectionFrequency:.5|AffectionIntensity:.6|AffectionInconsistency:.5|AttachmentDepth:.7|AttachmentAsymmetry:.6|FearOfAbandonment:.6|LongingPersistence:.7|YearningFocus:.6|UnresolvedDesire:.6|MiscommunicationFrequency:.6|EmotionalMisinterpretation:.5|TrustFragility:.6|TrustRebuildingDifficulty:.5|JealousyIntensity:.6|PossessiveImpulse:.6|ObsessionRisk:.5|PowerDynamicSalience:.5|EmotionalDependence:.5|ConflictRomanticization:.6|ArgumentIntensity:.5|ReconciliationDifficulty:.5|SoftnessEmergence:.6|ProtectiveInstinct:.6|RomanticIdealism:.5|CynicialUndertone:.5|TragedyChance:.4|BittersweetResolutionBias:.5|DomesticIntimacy:.5|EmotionalBondPace:.6|PhysicalYearning:.6|TouchHesitation:.5|DevotionThreshold:.6|SacrificeWillingness:.5|EmotionalExhaustion:.4|LoveAsBurden:.5|HealingThroughConnection:.5|RedemptionArcStrength:.6|FateEntanglement:.4|ChanceEncounter:.5|SeparationAnxiety:.6|DistanceStrain:.5|QuietMoments:.6|SilenceMeaningfulness:.7",
 "RPG": "PlayerAgency:1|WorldReactivity:.8|ConsequenceSeverity:.6|ChallengePressure:.6|ExplorationDrive:.7|DiscoveryReward:.6|NarrativeAuthority:.5|PlotPacing:.5|SceneDensity:.6|CombatFrequency:.4|CombatLethality:.6|ResourceScarcity:.5|MoralAmbiguity:.6c|NPCAutonomy:1|FactionDynamics:.6|PowerProgression:.5|FailurePersistence:.7|Randomness:.4|DayNightPacing:.5|SurvivalPressure:.7|HorrorIntensity:.6|PsychologicalTension:.6|SanityDegradation:.5g|PoliticalIntrigue:.6|SocialManipulation:.7|ReputationFragility:.6|HeroicMythScale:.5|LegendAccumulation:.6|ProphecyInfluence:.4|MysteryObfuscation:.7|ClueOpacity:.6|TruthDelay:.5|RomancePrevalence:.4|EmotionalStakes:.6|AttachmentRisk:.5|StealthViability:.7|DetectionSeverity:.6|MagicPrevalence:.5|MagicVolatility:.6|CorruptionRisk:.5|TechnologyReliance:.5|TechFragility:.6|CosmicInsignificance:.6|EldritchIntensity:.7|QuestDensity:.6|SideQuestEntropy:.5|FactionHostility:.6|FactionVolatility:.4|AllianceInstability:.5|EnvironmentalHostility:.6|WeatherImpact:.5|TerrainConstraint:.6|TravelFatigue:.5|EconomicPressure:.5|MarketVolatility:.6|CulturalClashIntensity:.6|TraditionRigidity:.5|IdentityFluidity:.4|DisguiseEffectiveness:.6|NarrativeFatalism:.4|HopeScarcity:.5|MonsterEcology:.6|PredatorHierarchy:.5|DungeonAttrition:.7|TrapSeverity:.6|TimeLoopRigidity:.5|TemporalConsequences:.6|PowerImbalance:.6c|OppressionPresence:.5|RelicRarity:.6|ArtifactDanger:.6|DivineIntervention:.4|FaithDependency:.5",
 "Sensuality": "SoftSensuality:.6|TenderSensuality:.6|GentleEroticism:.5|RawSensuality:.6|AnimalisticDesire:.5|PrimalSexuality:.6g|RomanticEroticism:.6|DevotionalSexuality:.5|PlayfulSexuality:.6|TeasingEroticism:.6|FlirtDrivenArousal:.6|DominantSexuality:.6|SubmissiveSexuality:.6|PowerEroticism:.6|PossessiveEroticism:.6|ClaimingSexuality:.6|TerritorialArousal:.5|SlowEroticism:.6|AnticipatoryArousal:.7|ExploratorySexuality:.5|ExperimentalEroticism:.5|CuriosityDrivenDesire:.6|IntimateEroticism:.7|SoulBondSexuality:.5|RoughEroticism:.5g|AggressiveDesire:.5g|DirtyEroticism:.6|VulgarSexuality:.5|ElegantEroticism:.5|RefinedSensuality:.5|TabooEroticism:.5g|ForbiddenDesire:.6g|ExhibitionisticEroticism:.5g|VoyeuristicEroticism:.5g|FetishisticFocus:.6g|KinkCentrality:.6g|OralFixation:.5|TouchFixation:.6|ScentAttraction:.5|VisualArousalBias:.6|VoiceArousalBias:.5|AftercareDrive:.6|PostSexBonding:.6|EmotionalSex:.7|SexAsConnection:.7|SexAsPower:.6g|SexAsComfort:.6|HungerDrivenSexuality:.6g|StressReliefSexuality:.5|SpontaneousArousal:.6g|SituationalArousal:.6|SeductiveIntent:.6|InitiatorBias:.6|ReceptiveBias:.5|YieldingEroticism:.5|PerformanceEroticism:.5|ValidationSeekingSexuality:.5g|SacredSexuality:.4|SpiritualEroticism:.4|MelancholicEroticism:.4|BittersweetSexuality:.4",
 "Bully": "DominanceDrive:.8|ControlCompulsion:.7|StatusFixation:.7|HierarchyAwareness:.8|PackLeaderPosturing:.6|RivalScanning:.7|TargetSelectionInstinct:.7|VulnerabilitySensing:.7|BoundaryTesting:.8|LineCrossingBoldness:.7g|PersistenceOfHarassment:.7g|EscalationReadiness:.6|ProvocationRate:.8g|ButtonPushingSkill:.7|HumiliationFocus:.7|EmbarrassmentExploitation:.7|ShameWeaponization:.6|ReputationSabotage:.6|InsultSharpness:.7|NameCallingFrequency:.6|MockingMimicry:.5|BelittlingHabit:.7|CondescensionLevel:.7|DismissiveSnark:.8|SarcasmLoad:.7|BackhandedCompliments:.6|PassiveAggression:.6|GaslightingTendency:.6g|BlameShifting:.7|MinimizationHabit:.7|JustificationReflex:.6|DoubleStandardComfort:.7|MoralSelfExemption:.7|ThreatVeiling:.6|IntimidationPresence:.7g|ProximityInvasion:.6g|TouchAsControl:.5g|PhysicalIntimidation:.5g|PhysicalAggression:.4g|AudiencePerforming:.8|LaughterRecruitment:.7|PeerPressure:.7g|SocialExclusion:.6|RumorSpreadingDrive:.5|GroupCrueltyCatalyst:.6g|PublicCrueltyBias:.7g|PrivateMaskSwitching:.6|AuthorityCharm:.6g|ConsequenceAvoidance:.8|PlausibleDeniability:.7|ImpulseControl:.4g|AngerThreshold:.5g|IrritationBaseline:.6|StressReactivity:.6|SpiteFuel:.7|GrudgePersistence:.7|Vindictiveness:.6g|RetaliationSeverity:.6gc|EmpathySuppression:.7|CompassionAvoidance:.7|GuiltLeakage:.2|RemorseResistance:.8|InsecurityMasking:.7|ShameDeflection:.7|FragileEgo:.6|ValidationHunger:.6|AttentionHijacking:.7|SpotlightCraving:.6|PushbackSensitivity:.6|RespectForStrength:.6|ContemptForWeakness:.7|CowardiceUnderPressure:.4|SmirkFrequency:.7|EyeRollFrequency:.6|StareDownIntensity:.6|VoiceEdge:.7|SweetnessAsWeapon:.5|HumorWeaponization:.7|PossessiveClaiming:.6g|JealousySpikes:.6|SoftSpotContainment:.8|VulnerabilityAvoidance:.8|SoftSpotExposure:.2|RedemptionOpenness:.2",
 "Caretaker": "NurturingDrive:.9|Gentleness:.8|Warmth:.8|KindnessBaseline:.9|Patience:.8|EmotionalResilience:.7|SoftSpokenTone:.7|SoothingPresence:.8|ComfortSeekingRadar:.9|EmotionalAttunement:.9|EmpathicMirroring:.7|ActiveListening:.9|Nonjudgment:.8|ValidationFrequency:.8|Reassurance:.8|Encouragement:.7|PraiseReadiness:.6|AffectionateMannerisms:.7|ProtectiveInstinct:.7|VigilanceForDistress:.8|CrisisComposure:.7|DeescalationSkill:.8|ConflictAvoidance:.5|ConflictResolution:.7|BoundaryRespect:.9|ConsentMindfulness:.8|CheckInFrequency:.7|PersonalSpaceAwareness:.8|TouchCaution:.6|TouchWarmth:.6|AftercareMindset:.8|Reliability:.9|Consistency:.9|FollowThrough:.9|ResponsibilityLoad:.8|RoutineBuilding:.7|StabilityProviding:.8|StructureOffering:.7|PlanningTendency:.6|PracticalSupport:.8|ActsOfService:.8|ProblemSolving:.7|Resourcefulness:.7|Preparedness:.6|GentleGuidance:.8|TeachingImpulse:.6|CoachingStyle:.6|MotivationalSupport:.7|FirmnessWhenNeeded:.6|DisciplineGentleness:.7|AccountabilitySupport:.6|ProtectionWithoutSmothering:.6|IndependenceEncouragement:.7|ConfidenceBolstering:.7|ShameBuffering:.8|ForgivenessReadiness:.7|SecondChancesBias:.7|CompassionForFlaws:.8|CaretakerPride:.5|SelfSacrificeTendency:.6|BurnoutRisk:.5|NurtureThroughFood:.6|NurtureThroughRest:.7|WellnessAwareness:.7|CleanlinessAttentiveness:.6|TidyingImpulse:.5|GentleHumor:.5|PlayfulTeasing:.3|Sentimentality:.5|AttachmentCarefulness:.6|ProtectiveJealousy:.3|TrustingDisposition:.6|SuspicionOfHarm:.5|SafetyFirstBias:.7|PrivacyRespect:.8|ConfidentialityInstinct:.8|EmotionalContainment:.7|CoRegulationSkill:.8|PresenceOverFixing:.7|QuietSupport:.7|WordsOfAffirmation:.6|PhysicalComfortOffering:.6|HomeyAtmosphereBuilding:.7|GentleInitiation:.6|Clinginess:.3|IndulgenceLevel:.5|SpoilingTendency:.5|StandardsSetting:.6|ExpectationClarity:.7|ApologyReadiness:.6|RepairAttempts:.7",
 "Daddy/Mommy Doms": "DaddyPersonaIntensity:.8|AffectionateAuthority:.9|DominanceDrive:.8|ControlCalmness:.8|CommandDirectness:.7|VoiceFirmness:.7|ProtectiveInstinct:.9|ProviderEnergy:.7|CaretakerInstinct:.8|NurturingTouch:.7|GentleHandling:.7|PossessiveProtectiveness:.6|JealousyContainment:.6|TerritorialSignals:.5|PatienceWithBrattiness:.7|BratTamingFocus:.6|DisciplineReadiness:.7|DisciplineGentleness:.7|CorrectionFrequency:.6|RuleSettingDrive:.8|RoutineBuilding:.7|StructureProviding:.8|ExpectationClarity:.8|BoundaryEnforcement:.9|NegotiationHabit:.8|CheckInFrequency:.7|AftercareImportance:.9|Reassurance:.7|PraiseFrequency:.8|PraiseSpecificity:.7|RewardBias:.7|PunishmentRestraint:.5|EmotionalAttunement:.8|Validation:.7|CalmDeescalation:.7|ConflictContainment:.7|TeasingPlayfulness:.6|FlirtationHeat:.6|DirtyTalkIntensity:.6|DirtyTalkTenderness:.7|PetNameFrequency:.8|GuidanceTone:.8|MentorEnergy:.7|InstructionClarity:.7|TrainingMindset:.6|ServiceExpectation:.6|ObedienceReinforcement:.7|ControlThroughPraise:.8|ControlThroughSilence:.5|NonverbalAuthority:.7|ProximityControl:.6|TouchAsClaim:.6|PublicComposure:.8|PrivateIntensity:.7|PlaySessionPacing:.6|EscalationPatience:.6|IntensityCeiling:.7|GentleHumor:.4|WarmthUndertone:.8|SoftSpotContainment:.7|VulnerabilityAllowance:.5|AttachmentDepth:.7|LoyaltyDemand:.6|Reliability:.9|FollowThrough:.9|ProtectiveDecisionMaking:.7|IndependenceEncouragement:.5|ReparativeApologyReadiness:.6|RepairAfterConflict:.7|ShameBuffering:.7|ConfidenceProjection:.8|EgoStability:.7|ControlWithoutCruelty:.9",
 "Shy": "SocialInitiation:.2|ConversationStarting:.2|ApproachAvoidance:.8|StrangerDiscomfort:.8|CrowdAnxiety:.7|AttentionAversion:.8|SpotlightFear:.7|NewEnvironmentCaution:.7|SocialRiskSensitivity:.8|RejectionSensitivity:.7|EmbarrassmentProneness:.8|FlusterResponse:.8|BlushingFrequency:.7|NervousLaughter:.5|AwkwardPauses:.7|Hesitation:.8|Overthinking:.8|SecondGuessing:.8|SelfConsciousness:.9|SelfCriticism:.7|ConfidenceBaseline:.3|Assertiveness:.2|PeoplePleasing:.6|ApologyFrequency:.7|SoftSpokenTone:.7|SpeechPaceSlowness:.6|RamblingWhenNervous:.5|Stuttering:.6|FillerWordUse:.6|EyeContactAvoidance:.8|SubtleGlances:.6|FaceHidingHabit:.5|FidgetFrequency:.8|HandWringing:.6|Fidgeting:.7|PostureClosedOff:.7|PersonalSpacePreference:.7|StartleReflex:.6|TouchHesitation:.7|TouchReceptivity:.4|WarmUpSpeed:.2|TrustGrantingSpeed:.3|TrustDepthPotential:.7|ComfortSeeking:.7|SafePersonClinging:.6|PrivateOpenness:.8|PublicReserve:.9|AffectionDisplayInPublic:.2|AffectionDisplayInPrivate:.7|ComplimentReactivity:.8|PraiseDeflection:.7|Vulnerability:.7|EmotionalTransparency:.4|EmotionalGuarding:.7|ConflictAvoidance:.7|DisagreementReluctance:.7|PassiveCompliance:.6|PanicWhenPressed:.5|CuriosityFromADistance:.6|ObservationHabit:.7|QuestionAskingReluctance:.6|IndependenceFacade:.5|NeedHiding:.7|SocialRecoveryTime:.8|OverstimulationSensitivity:.7|RoutineComfort:.6|GentleHumor:.4|PlayfulTeasing:.2|RomanticBoldness:.3|ConfessionDifficulty:.8|InitiativeInIntimacy:.3|QuietlyJealous:.6|KindnessBaseline:.7|PolitenessReflex:.8|Respectfulness:.8",
 "Toxic Relationships": "EmotionalDetachment:.8g|IntimacyAvoidance:.7g|CommitmentAvoidance:.7g|VulnerabilityAversion:.8g|AffectionWithholding:.7g|EmotionalWithholding:.8g|ConnectionAvoidance:.7g|AttachmentAvoidance:.8g|AvoidantAttachment:.8g|AnxiousAttachment:.7g|DisorganizedAttachment:.6g|FearOfIntimacy:.7g|FearOfRejection:.6g|FearOfEngulfment:.6g|FearOfAbandonment:.7g|ClosenessPanic:.6g|EmotionalShutdown:.7g|Stonewalling:.6g|SilentTreatmentUse:.6g|ColdShoulderHabit:.6g|DeflectionHabit:.7g|EmotionalEvasion:.7g|AccountabilityAvoidance:.7g|ApologyAvoidance:.6g|RepairAvoidance:.7g|ConflictAddiction:.6g|DramaDependency:.6g|ChaosComfort:.6g|HotColdCycle:.8g|PushPullDynamic:.8g|MixedSignals:.7g|AffectionInconsistency:.8g|IntermittentReinforcement:.8g|Breadcrumbing:.7g|GhostingTendency:.6g|AttentionWithdrawal:.7g|LoveBombing:.7g|OverattachmentSpiral:.6g|IdealizationDevaluation:.7g|DevaluationHabit:.6g|DiscardTendency:.5g|ReplaceabilityMindset:.5g|PossessiveFixation:.7g|JealousySpikes:.6g|JealousSurveillance:.5g|ControlThroughAffection:.7g|ControlThroughDistance:.7g|ControlThroughGuilt:.6g|EmotionalBlackmail:.6g|ManipulativeTenderness:.6g|PunishmentByNeglect:.6g|PunishmentByWithdrawal:.7g|TestingLoyalty:.6g|ComplianceSeeking:.6g|BoundaryErosion:.6g|PowerImbalanceRomance:.6g|StatusBasedAffection:.5g|TransactionalLove:.6g|ConditionalCare:.7g|ConditionalAffection:.7g|ValidationAddiction:.7g|EgoFeedingNeed:.6g|AttentionHoarding:.6g|CompetitivenessInLove:.5g|PossessionOverPartnership:.7g|CodependencyRisk:.7g|RescuerComplex:.6g|MartyrComplex:.5g|TraumaBonding:.6g|PainAsProofOfLove:.6g|SufferingRomanticization:.6g|JealousyRomanticization:.6g|ControlRomanticization:.5g|ContemptUnderlayer:.6g|RespectErosion:.6g|EmotionalVolatility:.6g|MoodWeaponization:.6g|InsecurityMasking:.6g|ShameDeflection:.6g|BlameShifting:.7g|JustificationReflex:.6g|NarrativeSelfVictimizing:.6g|ProjectionTendency:.6g|ThreatOfLeaving:.5g|BreakupCycling:.6g|MakeupAddiction:.6g|ReboundSeeking:.5g|FearDrivenClinging:.6g|LoveAsEscape:.6g|LoveAsControl:.6g|LoveAsCompetition:.5g|LoveAsOwnership:.7g|RomanceAsWarfare:.5g|TrustFragility:.7g|TrustSabotage:.6g|SelfSabotageInLove:.7g|HappinessDiscomfort:.6g|PeaceIntolerance:.5g|EmotionalIlliteracy:.6g|EmpathyDeficit:.5g|TendernessAvoidance:.7g|SoftnessPanic:.6g|NeedDenial:.7g|CareRefusal:.6g|HelpRefusal:.6g|DependencyShame:.6g"
};
  const CATS = Object.keys(POOLS), CAP = 0.8, MAX_WEIGHTS = 10;
  const key = s => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const INDEX = new Map(), BY_CAT = {};
  for (const cat of CATS) { BY_CAT[cat] = []; for (const e of POOLS[cat].split('|')) { const m = e.match(/^([A-Za-z]+):(\.?\d*\.?\d+)([gc]*)$/); if (!m) continue; const it = {name: m[1], cat, value: Math.min(parseFloat(m[2]), CAP), guard: m[3].includes('g'), cap: m[3].includes('c')}; BY_CAT[cat].push(it); if (!INDEX.has(key(it.name))) INDEX.set(key(it.name), it); } }
  const info = name => INDEX.get(key(name)) || null;
  const fmt = n => { const r = Math.round(n * 100) / 100; return String(r).replace(/^-?0(?=\.)/, m => m === '-0' ? '-0' : '0'); };
  const clean = n => String(n || '').replace(/[^A-Za-z0-9]/g, '');

  // ---- the series a card belongs to, and the lane locks that always win over a weight
  const seriesKey = card => String((card && (card.series || card.seriesLabel)) || 'Standalone').trim() || 'Standalone';
  const textOf = card => [card && card.series, card && card.seriesLabel, card && card.lane, card && card.laneTab, card && card.type, card && card.slot].filter(Boolean).join(' ');
  const ROMANCE_NAME = /roman|sensual|erotic|sexual|desire|arous|seduc|flirt|lust|kink|fetish|affection|devotion|yearn|longing|intimacy|tenderness/i;
  const ROMANCE_WORD = /\b(romanc\w*|love[sd]?|loving|kiss\w*|sex\w*|desire[sd]?|attract\w*|crush\w*|flirt\w*|lust\w*|aroused|arousal|intimacy|date|dating)\b/i;
  // romance words are fine only from the unlock stage (Trust +0.8) on: anything before it, or in the rise/fall wording, is a leak
  const UNLOCK = 0.8;
  function romanceBeforeUnlock(text) {
    const t = String(text || ''), i = t.search(/Behavior by score\s*:/i), head = i < 0 ? t : t.slice(0, i), stages = i < 0 ? '' : t.slice(i);
    if (ROMANCE_WORD.test(head.replace(/\[Tracker:[^\]]*\]/gi, ''))) return true;
    for (const m of stages.matchAll(/at\s*(-?\d*\.?\d+)\s*:\s*([^;]+)/gi)) if (parseFloat(m[1]) < UNLOCK && ROMANCE_WORD.test(m[2])) return true;
    return false;
  }
  function lockFor(card) {
    const t = textOf(card), L = {rules: [], banCats: [], noRomance: false};
    if (/\bbully\b/i.test(t)) { L.noRomance = true; L.rules.push('noRomance'); L.banCats.push('Romance', 'Sensuality', 'Slow Burn', 'Toxic Relationships'); }
    if (/anti[\s-]?ntr/i.test(t)) { L.rules.push('loyal'); L.banCats.push('Toxic Relationships'); }
    else if (/\bntr\b|netorare|preventable/i.test(t)) { L.rules.push('canon'); L.banCats.push('Toxic Relationships'); }
    return L;
  }
  // the Tracker is its own thing: it has its own switch (trackerOn, on whenever the card has tracker text) and works with or without the weights
  const trackerActive = p => !!(p && String(p.tracker || '').trim() && p.trackerOn !== false);
  const isOn = (card, state) => { const p = card && card.policy; if (p && typeof p.on === 'boolean') return p.on; const d = (state && state.policyDefaults) || {}; return !!d[seriesKey(card)]; };

  // what actually goes into the Scenario for a card: the weights only when they are on, the tracker only when it is on (null when neither is)
  function effective(card, state) {
    const p = (card && card.policy) || {}, w = isOn(card, state) && parseWeights(p.weights).items.length > 0, t = trackerActive(p);
    if (!w && !t) return null;
    return {...p, on: true, weights: w ? p.weights : '', extra: w ? (p.extra || '') : '', tracker: t ? p.tracker : '', rules: lockFor(card).rules};
  }
  const anyOn = (card, state) => isOn(card, state) || trackerActive(card && card.policy);

  // ---- the weights line:  "Name: 0.2; Other: 0.4"
  function parseWeights(str) {
    const items = [], errors = [];
    for (const part of String(str || '').split(/[;\n]+/).map(x => x.trim()).filter(Boolean)) {
      const m = part.match(/^([A-Za-z][A-Za-z0-9 ]*?)\s*[:=]\s*(-?\d*\.?\d+)\s*$/);
      if (!m) { errors.push(`"${part.slice(0, 40)}" is not in the form Name: 0.5`); continue; }
      items.push({name: clean(m[1]), value: parseFloat(m[2])});
    }
    return {items, errors};
  }
  const stringify = items => items.map(i => `${i.name}: ${fmt(i.value)}`).join('; ');
  const isNew = name => !info(name);
  // names that need a guardrail line: the author's "Needs guardrails" ones and every weight that is not on the author's lists
  const guardNames = items => items.filter(i => { const e = info(i.name); return !e || e.guard; }).map(i => i.name);

  function check(policy, card) {
    const out = {errors: [], warnings: [], items: []};
    const P = policy || {}, parsed = parseWeights(P.weights); out.errors.push(...parsed.errors); out.items = parsed.items;
    const seen = new Set(), lock = lockFor(card);
    if (!parsed.items.length && !parsed.errors.length) out.errors.push('Add at least one weight, or switch PolicyWeights off for this card.');
    if (parsed.items.length > MAX_WEIGHTS) out.errors.push(`${parsed.items.length} weights is too many: keep it to ${MAX_WEIGHTS} or fewer (5-8 works best).`);
    else if (parsed.items.length > 8) out.warnings.push(`${parsed.items.length} weights: 5-8 keeps the Scenario short enough.`);
    for (const it of parsed.items) {
      const k = key(it.name), e = info(it.name);
      if (seen.has(k)) out.errors.push(`${it.name} is listed twice.`); seen.add(k);
      if (!(it.value >= 0 && it.value <= 1)) out.errors.push(`${it.name}: ${it.value} is outside 0 to 0.8.`);
      else if (it.value > CAP) out.errors.push(`${it.name}: never above ${fmt(CAP)}. Every PolicyWeight is between 0 and 0.8.`);
      if (e && Math.abs(e.value - it.value) > 1e-9) out.warnings.push(`${it.name} is listed by the author at ${fmt(e.value)}; you have ${fmt(it.value)}.`);
      if (!e) out.warnings.push(`${it.name} is new (not on the author's lists): untested. A guardrail line is added for it.`);
      if (e && lock.banCats.includes(e.cat)) out.errors.push(`${it.name} (${e.cat}) does not fit this series: its lane lock forbids it.`);
      if (lock.noRomance && ROMANCE_NAME.test(it.name)) out.errors.push(`${it.name} is romantic or sexual. This series has zero romance.`);
    }
    if (P.tracker && !/\[Tracker/i.test(P.tracker)) out.warnings.push('The tracker text does not start with [Tracker: Name]; it is placed as written.');
    if (P.tracker && lock.noRomance && romanceBeforeUnlock(P.tracker)) out.errors.push('The tracker mentions romance or sex before the unlock. This series has zero romance until Trust reaches 0.8.');
    if (P.tracker && lock.noRomance && !/at\s*0?\.8\s*:[^;]*romanc/i.test(P.tracker)) out.warnings.push('A Bully tracker normally has an "at 0.8" stage where romance unlocks.');
    return out;
  }

  // ---- trackers: the AI sends a plain layout (below); the app turns it into the one text the card and the bot carry
  //   TRACKER: Trust | start 0 | step 0.05 | min -1 | max 1 | oneway (optional)
  //   UP: ...    DOWN: ...    AT 0.25: ...    AT -0.5: ...
  function parseTrackerReply(text) {
    const trackers = [], errors = []; let cur = null;
    for (const raw of String(text || '').replace(/\r/g, '').split('\n')) {
      const line = raw.trim(); if (!line) continue;
      let m;
      if ((m = line.match(/^TRACKER\s*:\s*(.+)$/i))) {
        const parts = m[1].split('|').map(x => x.trim()); cur = {name: clean(parts[0]).slice(0, 30), start: 0, step: 0.05, min: -1, max: 1, oneWay: false, up: '', down: '', stages: []};
        for (const p of parts.slice(1)) { let q; if ((q = p.match(/^start\s*(-?[\d.]+)/i))) cur.start = parseFloat(q[1]); else if ((q = p.match(/^step\s*([\d.]+)/i))) cur.step = parseFloat(q[1]); else if ((q = p.match(/^min\s*(-?[\d.]+)/i))) cur.min = parseFloat(q[1]); else if ((q = p.match(/^max\s*(-?[\d.]+)/i))) cur.max = parseFloat(q[1]); else if (/^one[\s-]?way/i.test(p)) cur.oneWay = true; }
        trackers.push(cur); continue;
      }
      if (!cur) continue;
      if ((m = line.match(/^UP\s*:\s*(.+)$/i))) cur.up = m[1].trim();
      else if ((m = line.match(/^DOWN\s*:\s*(.+)$/i))) cur.down = m[1].trim();
      else if ((m = line.match(/^AT\s*(-?[\d.]+)\s*:\s*(.+)$/i))) cur.stages.push({at: parseFloat(m[1]), does: m[2].trim()});
    }
    for (const t of trackers) {
      if (!t.name) errors.push('a tracker has no name');
      if (!(t.step >= 0.02 && t.step <= 0.1)) errors.push(`${t.name}: step ${t.step} is outside 0.02-0.1`);
      if (!(t.min < t.max) || t.min < -1 || t.max > 1) errors.push(`${t.name}: range must sit inside -1 to 1`);
      if (!(t.start >= t.min && t.start <= t.max)) errors.push(`${t.name}: start is outside its range`);
      if (!t.up) errors.push(`${t.name}: no UP line`); if (!t.oneWay && !t.down) errors.push(`${t.name}: no DOWN line`);
      if (t.stages.length < 2 || t.stages.length > 8) errors.push(`${t.name}: needs 2-8 AT stages`);
      for (const s of t.stages) { if (!(s.at >= t.min && s.at <= t.max)) errors.push(`${t.name}: stage ${s.at} is outside the range`); if (s.does.length > 100) errors.push(`${t.name}: stage ${s.at} is too long (keep it under 100 characters)`); }
    }
    if (!trackers.length) errors.push('no TRACKER line');
    return {trackers: trackers.slice(0, 2), errors};
  }
  function trackerToText(trackers) {
    return trackers.map(t => {
      const stages = t.stages.slice().sort((a, b) => a.at - b.at), pos = stages.filter(s => s.at > t.start).sort((a, b) => a.at - b.at), neg = stages.filter(s => s.at <= t.start && s.at !== t.start).sort((a, b) => b.at - a.at), at0 = stages.filter(s => s.at === t.start);
      const list = [...at0, ...pos, ...neg].map(s => `at ${fmt(s.at)}: ${s.does.replace(/[.\s]+$/, '')}`).join('; ');
      return `[Tracker: ${t.name}] Hidden score, never shown in chat. Scale ${fmt(t.min)} to ${fmt(t.max)}, starts at ${fmt(t.start)}. Rises ${fmt(t.step)} when {{user}} ${t.up.replace(/^when\s+{{user}}\s+/i, '').replace(/[.\s]+$/, '')}. ${t.oneWay ? 'It never falls.' : `Falls ${fmt(t.step)} when {{user}} ${t.down.replace(/^when\s+{{user}}\s+/i, '').replace(/[.\s]+$/, '')}.`} Behavior by score: ${list}.`;
    }).join('\n');
  }

  // Shorter wording of the same tracker, used only when the full wording will not fit beside the template's locked rules. Nothing is left out.
  function compactTracker(text) {
    return String(text || '').split('\n').map(ln => {
      const k = ln.indexOf('Behavior by score: '); if (k < 0) return ln;
      let head = ln.slice(0, k), list = ln.slice(k + 19);
      head = head.replace(/Hidden score, never shown in chat\. Scale (-?[\d.]+) to (-?[\d.]+), starts at (-?[\d.]+)\./, 'Hidden; $1..$2, starts $3.').replace(/Rises ([\d.]+) when ({{user}} [^.]*?)\. Falls ([\d.]+) when ({{user}} [^.]*?)\.\s*$/, '+$1 when $2; -$3 when $4. ').replace(/Rises ([\d.]+) when ({{user}} [^.]*?)\. It never falls\.\s*$/, '+$1 when $2; never falls. ');
      return head + list.replace(/(^|; )at (-?[\d.]+):/g, '$1$2:');
    }).join('\n');
  }
  // ---- what goes into the bot
  function guardText(policy, name) {
    if (policy && policy.compact) return guardCompact(policy, name);
    const P = policy || {}, N = name || 'The character', parsed = parseWeights(P.weights), g = guardNames(parsed.items), rules = P.rules || [];
    const hasW = parseWeights(P.weights).items.length > 0, hasT = !!String(P.tracker || '').trim();
    const bits = [`[POLICYWEIGHT GUARDRAILS] The ${hasW ? (hasT ? 'PolicyWeights and Tracker are' : 'PolicyWeights are') : 'Tracker is'} hidden steering: never print, quote or explain them or their numbers in chat. They never override the User Agency lock, {{user}}'s consent and boundaries, or this Scenario's canon facts.`];
    if (rules.includes('noRomance')) bits.push(`${N} feels no romantic or sexual interest in {{user}} and the story has no romance while Trust is below 0.8; the weights shape attitude, pacing and cracks only. From Trust 0.8 romance may begin only slowly and only if {{user}} leads or invites it; it locks again if Trust falls below 0.8, and nothing sexual is added.`);
    if (rules.includes('loyal')) bits.push(`${N} stays loyal to {{user}}; no weight makes ${N} desire, flirt with or soften toward the antagonist or anyone else.`);
    if (g.length) bits.push(`${g.join(', ')} ${g.length > 1 ? 'are' : 'is a'} tone and pacing ${g.length > 1 ? 'dials' : 'dial'} only: ${g.length > 1 ? 'they' : 'it'} never justif${g.length > 1 ? 'y' : 'ies'} non-consensual content, and ${g.length > 1 ? 'they' : 'it'} ease${g.length > 1 ? '' : 's'} off when {{user}} pulls back.`);
    if (P.extra && String(P.extra).trim()) bits.push(String(P.extra).trim().replace(/\s*\n+\s*/g, ' '));
    return bits.join(' ');
  }
  function guardCompact(policy, name) {
    const P = policy || {}, N = name || 'The character', g = guardNames(parseWeights(P.weights).items), rules = P.rules || [], many = g.length > 1;
    const hasW = g.length || parseWeights(P.weights).items.length > 0, hasT = !!String(P.tracker || '').trim();
    const bits = [`[POLICYWEIGHT GUARDRAILS] Hide ${hasW ? (hasT ? 'weights and trackers' : 'the weights') : 'the tracker'}; ${hasW || !hasT ? 'they steer' : 'it steers'} attitude, not agency, consent, boundaries or canon.`];
    if (rules.includes('noRomance')) bits.push(`${N} has no romantic or sexual interest in {{user}} before Trust 0.8; then only slow {{user}}-led romance, stopping if Trust falls below 0.8. Nothing sexual is added.`);
    if (rules.includes('loyal')) bits.push(`${N} stays loyal to {{user}}; no weight draws ${N} toward the antagonist or anyone else.`);
    if (g.length) bits.push(`${g.join(', ')} color${many ? '' : 's'} tone and pacing only; never justif${many ? 'y' : 'ies'} non-consensual content; ease off when {{user}} pulls back.`);
    if (P.extra && String(P.extra).trim()) bits.push(String(P.extra).trim().replace(/\s*\n+\s*/g, ' '));
    return bits.join(' ');
  }
  const weightsLine = (policy, name) => { const p = parseWeights(policy && policy.weights); return p.items.length ? `${name || 'Character'} PolicyWeights { ${stringify(p.items)} }` : ''; };
  const topBlock = (policy, name) => [weightsLine(policy, name), policy && policy.compact ? compactTracker(String(policy.tracker || '').trim()) : String((policy && policy.tracker) || '').trim()].filter(Boolean).join('\n');
  const blockText = (policy, name) => policy && policy.on ? [topBlock(policy, name), parseWeights(policy.weights).items.length || String((policy && policy.tracker) || '').trim() ? guardText(policy, name) : ''].filter(Boolean).join('\n\n') : '';
  const has = body => /PolicyWeights\s*\{/.test(String(body || ''));
  // The Scenario body gets the block in the author's order. Nothing changes when the policy is off or already in the text.
  function insert(body, policy, name) {
    body = String(body == null ? '' : body);
    if (!policy || !policy.on || has(body)) return body;
    const items = parseWeights(policy.weights).items; if (!items.length && !String(policy.tracker || '').trim()) return body;
    const top = topBlock(policy, name), guard = guardText(policy, name);
    const sys = /^[ \t]*System Rules\s*\{[ \t]*$/m.exec(body);
    if (!sys) return `${top}\n\n${body.replace(/^\s+/, '')}${body.trim() ? '\n\n' : ''}${guard}`.replace(/\n+$/, '');
    let head = body.slice(0, sys.index), rest = body.slice(sys.index);
    const lockEnd = /\[END USER AGENCY HARD LOCK\][^\n]*/.exec(rest);
    if (lockEnd) { const at = lockEnd.index + lockEnd[0].length; rest = rest.slice(0, at) + '\n' + guard + rest.slice(at); }
    else { const nl = rest.indexOf('\n'); rest = nl < 0 ? `${rest}\n\n${guard}` : `${rest.slice(0, nl)}\n\n${guard}\n${rest.slice(nl)}`; }
    return `${head}${top}\n\n${rest}`;
  }
  // A template with its own PolicyWeights line ("Name PolicyWeights { Tease: 0.4; ... }"): the app does not add its block, but the line still follows the same rules.
  // Every number is held at 0.8 or less, and the guardrail line goes in after the User Agency lock, exactly as it does for the app's own block. Safe to run twice.
  // Boxes that are still empty (a [0.0-0.8] placeholder) are left alone, and no guardrail is added until the weights are filled.
  function settleOwn(body, name, rules) {
    body = String(body == null ? '' : body);
    const re = /^([^\n]*PolicyWeights\s*\{)([^}\n]*)(\}[^\n]*)$/m, m = re.exec(body); if (!m) return body;
    // a box that holds words instead of a number (an older version wrote a sentence there) gets the plain default for that dial
    const DEFAULT_DIAL = {tease: .4, reassure: .6, escalatetouch: .3, explicitline: .2, checkconsent: .8, formality: .5};
    const fixed = m[2].split(';').map(part => {
      const q = /^(\s*)([A-Za-z][A-Za-z0-9]*)(\s*:\s*)([\s\S]*?)(\s*)$/.exec(part); if (!q || /^\[[^\]]*\]$/.test(q[4]) || !q[4]) return part;
      if (/^-?\d*\.?\d+$/.test(q[4])) return parseFloat(q[4]) > CAP ? q[1] + q[2] + q[3] + fmt(CAP) + q[5] : part;
      const d = DEFAULT_DIAL[q[2].toLowerCase()]; return q[1] + q[2] + q[3] + fmt(d == null ? 0.5 : d) + q[5];
    }).join(';');
    if (fixed !== m[2]) body = body.slice(0, m.index) + m[1] + fixed + m[3] + body.slice(m.index + m[0].length);
    if (/\[POLICYWEIGHT GUARDRAILS\]/.test(body)) return body;
    const items = parseWeights(fixed.replace(/\s*;\s*$/, '')).items; if (!items.length) return body;
    const guard = guardText({weights: stringify(items), rules: rules || []}, name);
    const lockEnd = /\[END USER AGENCY HARD LOCK\][^\n]*/.exec(body);
    if (lockEnd) { const k = lockEnd.index + lockEnd[0].length; return body.slice(0, k) + '\n' + guard + body.slice(k); }
    const line = re.exec(body), k = line.index + line[0].length;
    return body.slice(0, k) + '\n' + guard + body.slice(k);
  }
  // takes a PolicyWeights block (weights line, tracker lines, guardrail line) out of a text, so a rewrite never shows it to the AI or counts it twice
  const strip = body => String(body == null ? '' : body).split('\n').filter(l => !/PolicyWeights\s*\{[^}]*\}\s*$/.test(l) && !/^\s*\[Tracker:[^\]]*\]/.test(l) && !/^\s*\[POLICYWEIGHT GUARDRAILS\]/.test(l)).join('\n').replace(/^\s*\n+/, '').replace(/\n{3,}/g, '\n\n');
  const blockLength = (policy, name) => { const p = policy && policy.on ? policy : null; if (!p || !parseWeights(p.weights).items.length) return 0; return topBlock(p, name).length + 2 + guardText(p, name).length + 2; };

  // ---- making the block fit. The block is never allowed to push the Scenario past the template's limit by silently losing what you wrote. When it would, only the
  // wording is shortened first (same numbers, same stages), then the middle stages of a tracker (its first stage, last stage and the Trust 0.8 romance stage stay) and each such cut
  // is reported. The weights, the extra guardrail text you or the AI wrote and the lane guardrail lines are NEVER cut automatically: if the block still does not fit, `short` is
  // set and the app tells you to shorten the card's tracker or extra text yourself. Only the copy inside the bot changes; the card keeps its own.
  const SPLIT = /; (?=at -?\d*\.?\d+:)/;
  function dropStage(trackerText) {
    const lines = String(trackerText || '').split('\n'); let best = null;
    lines.forEach((ln, li) => {
      const k = ln.indexOf('Behavior by score: '); if (k < 0) return;
      const head = ln.slice(0, k + 19), list = ln.slice(k + 19).replace(/\.\s*$/, '').split(SPLIT);
      list.forEach((st, i) => { if (i === 0 || i === list.length - 1 || list.length <= 2) return; const at = parseFloat((st.match(/^at\s*(-?\d*\.?\d+)/) || [])[1]); if (Math.abs(at - UNLOCK) < 1e-9 && /romanc/i.test(st)) return; if (!best || st.length > best.st.length) best = {li, i, st, head, list}; });
    });
    if (!best) return null;
    best.list.splice(best.i, 1); lines[best.li] = best.head + best.list.join('; ') + '.';
    return lines.join('\n');
  }
  function trim(policy, name, room, wordingOnly) {
    const cuts = []; let p = policy ? JSON.parse(JSON.stringify(policy)) : policy;
    if (!p || !p.on || room == null || room < 0 || blockLength(p, name) <= room) return {policy: p, cuts, changed: false, short: false};
    const over = () => blockLength(p, name) > room;
    if (!p.compact) p.compact = true;                          // first the shorter wording: nothing is lost
    let dropped = 0; while (!wordingOnly && over()) { const t = dropStage(p.tracker); if (t == null) break; p.tracker = t; dropped++; }
    if (dropped) cuts.push(`${dropped} middle tracker stage${dropped > 1 ? 's' : ''}`);
    return {policy: p, cuts, changed: true, short: over()};
  }
  // the most the block may take of a Scenario limit: the template's own locked rules and the scene description need the rest
  const roomFor = limMax => Math.max(600, Math.round(limMax) - 1300);

  // ---- what the AI is shown
  function suggestCats(card) {
    const t = `${textOf(card)} ${(card && card.primaryArchetype) || ''} ${(card && card.fields && card.fields['Primary Archetypal Personality']) || ''} ${((card && card.tags) || []).join(' ')}`.toLowerCase(), lock = lockFor(card), out = [];
    const add = (...c) => { for (const x of c) if (CATS.includes(x) && !out.includes(x) && !lock.banCats.includes(x)) out.push(x); };
    if (/bully/.test(t)) add('Bully');
    if (/anti[\s-]?ntr/.test(t)) add('Romance', 'Slow Burn', 'Sensuality');
    if (/dommy|mommy|daddy|dom\b|femdom/.test(t)) add('Daddy/Mommy Doms', 'Caretaker', 'Sensuality');
    if (/stepmom|stepsister|step/.test(t)) add('Caretaker', 'Romance', 'Sensuality');
    if (/gentle giant|giant|himbo/.test(t)) add('Caretaker', 'Shy', 'Slow Burn');
    if (/yandere|obsess/.test(t)) add('Toxic Relationships', 'Romance');
    if (/bakadere|dandere|shy/.test(t)) add('Shy', 'Romance');
    if (/kuudere|stoic|serious|tsundere|slow/.test(t)) add('Slow Burn');
    if (/scp|horror|eldritch|monster|dark\/grim|haunt/.test(t)) add('Horror');
    if (/rpg|fantasy|isekai|adventure|game|elf|magic/.test(t)) add('RPG');
    if (/nurs|maid|caretak|nurtur|affectionate|doctor/.test(t)) add('Caretaker');
    add('Romance', 'Slow Burn', 'Sensuality');
    return out.slice(0, 4);
  }
  function seeded(seed) { let h = 2166136261; for (const c of String(seed)) { h ^= c.charCodeAt(0); h = Math.imul(h, 16777619); } return () => { h += 0x6D2B79F5; let t = Math.imul(h ^ (h >>> 15), 1 | h); t ^= t + Math.imul(t ^ (t >>> 7), 61 | t); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function poolText(cats, seed, per = 38) {
    const rnd = seeded(seed || 'x');
    return cats.map(c => { const a = BY_CAT[c].slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return `## ${c}\n${a.slice(0, per).map(e => `${e.name}: ${fmt(e.value)}${e.guard || e.cap ? ` (${[e.guard ? 'Needs guardrails' : '', e.cap ? 'never above .8' : ''].filter(Boolean).join('; ')})` : ''}`).join('\n')}`; }).join('\n\n');
  }
  // The AI's weights, made safe: caps, bans, the author's listed values, duplicates and the 4-8 count are enforced here, whatever it sent.
  function repair(items, card, newNames) {
    const lock = lockFor(card), seen = new Set(), out = [], dropped = [];
    for (const it of items) {
      const nm = clean(it.name), k = key(nm); if (!nm || seen.has(k)) continue; seen.add(k);
      const e = info(nm);
      if (e && lock.banCats.includes(e.cat)) { dropped.push(`${nm}: not allowed in this series`); continue; }
      if (lock.noRomance && ROMANCE_NAME.test(nm)) { dropped.push(`${nm}: romantic`); continue; }
      let v = e ? e.value : Math.min(Number(it.value), CAP);
      if (!(v >= 0 && v <= 1)) { dropped.push(`${nm}: bad value`); continue; }
      if (v > CAP) v = CAP;   // every weight is held at 0.8 or less
      out.push({name: e ? e.name : nm, value: v});
    }
    return {items: out.slice(0, 8), dropped, fresh: out.slice(0, 8).filter(i => isNew(i.name)).map(i => i.name)};
  }
  function parseReply(blocks, card) {
    const w = parseWeights(String(blocks.weights || '').replace(/^[-*•\s]+/gm, '')), rep = repair(w.items, card);
    let tracker = '', terr = [];
    if (blocks.tracker && String(blocks.tracker).trim() && !/^\s*none\s*$/i.test(blocks.tracker)) { const tr = parseTrackerReply(blocks.tracker); terr = tr.errors; if (!tr.errors.length) tracker = trackerToText(tr.trackers); }
    const lock = lockFor(card);
    if (tracker && lock.noRomance) {
      const trs = parseTrackerReply(blocks.tracker).trackers, trust = trs.find(t => /trust/i.test(t.name));
      if (romanceBeforeUnlock(tracker)) { terr.push('the tracker mentions romance or sex before Trust 0.8'); tracker = ''; }
      else if (!trust || !trust.stages.some(x => Math.abs(x.at - UNLOCK) < 1e-9 && /romanc/i.test(x.does))) { terr.push('the Trust tracker needs an AT 0.8 stage where romance becomes possible'); tracker = ''; }
    }
    return {weights: stringify(rep.items), fresh: rep.fresh, dropped: rep.dropped, tracker, trackerErrors: terr, extra: String(blocks.extra || '').replace(/\s+/g, ' ').trim().slice(0, 400), note: String(blocks.note || '').replace(/\s+/g, ' ').trim().slice(0, 700), rules: lock.rules};
  }

  const API = {enabled: true, trackerActive, effective, anyOn, POOLS, CATS, CAP, info, isNew, seriesKey, lockFor, isOn, parseWeights, stringify, check, guardNames, guardText, topBlock, weightsLine, blockText, blockLength, insert, settleOwn, strip, has, suggestCats, poolText, repair, parseReply, parseTrackerReply, trackerToText, fmt, ROMANCE_WORD, romanceBeforeUnlock, UNLOCK, trim, roomFor, compactTracker};
  if (typeof window !== 'undefined') window.PolicyWeights = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})();
