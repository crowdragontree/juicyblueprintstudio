/* Scope-safe section replacement plus local, accessible preflight/review dialogs.
   Requiring this module in Node never accesses the DOM or starts a request. */
(function () {
  'use strict';
  const TITLES = {header: 'Basics', introduction: 'Introduction', personality: 'Personality', scenario: 'Scenario', greeting: 'Greeting', image: 'Image Generation', tags: 'Tags', scene: 'Scene Breakdown'};
  const clone = x => x == null ? x : JSON.parse(JSON.stringify(x));
  function copyProp(dst, src, key) { if (Object.prototype.hasOwnProperty.call(src || {}, key)) dst[key] = clone(src[key]); else delete dst[key]; }
  function merge(target, source, section) {
    if (!TITLES[section]) throw new Error('Unknown bot section.');
    const out = clone(target);
    const top = {header: ['header','names','include3'], introduction: ['intro','iAuto'], personality: [], scenario: [], greeting: ['greet','gAuto','autoFormat','greetingPlan'], image: ['img'], tags: ['tags'], scene: ['scenes']}[section];
    for (const k of top) copyProp(out, source, k);
    // Only the selected section's override, autofill data and edit flags change.
    const matches = k => k === 'over.' + section || (section === 'introduction' && k === 'intro') || (section === 'greeting' && /^g\d+$/.test(k)) || (['personality','scenario'].includes(section) && k.startsWith(section + '.'));
    for (const dict of ['f','auto','touched']) {
      const dst = {...(out[dict] || {})}, src = source[dict] || {};
      for (const k of Object.keys(dst)) if (matches(k)) delete dst[k];
      for (const k of Object.keys(src)) if (matches(k)) dst[k] = clone(src[k]);
      if (out[dict] || Object.keys(dst).length) out[dict] = dst;
    }
    for (const dict of ['over','baseOver','fit','rewriteNotes']) {
      const dst = {...(out[dict] || {})}; copyProp(dst, source[dict] || {}, section);
      if (out[dict] || Object.keys(dst).length) out[dict] = dst;
    }
    return out;
  }
  const esc = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let active = null;
  function dialog({title, intro, body, ok, init}) {
    if (active) { active.focus(); return Promise.resolve(null); }
    const root = document.createElement('div'); root.className = 'upd-modal sr-modal'; root.id = 'section-rewrite-modal';
    root.innerHTML = `<section class="upd-box sr-box" role="dialog" aria-modal="true" aria-labelledby="sr-title" tabindex="-1"><header><h3 id="sr-title">${esc(title)}</h3><p>${esc(intro)}</p></header><div class="sr-body">${body}</div><footer><span class="micro">Only the selected section can change.</span><div class="button-row"><button type="button" class="ghost" id="sr-cancel">${ok === 'Apply rewrite' ? 'Keep current' : 'Cancel'}</button><button type="button" class="primary" id="sr-ok">${esc(ok)}</button></div></footer></section>`;
    const focus = document.activeElement, scroll = document.body.style.overflow;
    document.body.appendChild(root); const box = root.querySelector('.sr-box'); active = box;
    const siblings = [...document.body.children].filter(x => x !== root && !/^(SCRIPT|STYLE)$/.test(x.tagName)).map(x => [x,x.inert]); siblings.forEach(([x]) => x.inert = true);
    document.body.style.overflow = 'hidden'; if (init) init(root);
    return new Promise(resolve => {
      function close(value) { document.removeEventListener('keydown', keys, true); root.remove(); active = null; document.body.style.overflow = scroll; siblings.forEach(([x,old]) => x.inert = old); if (focus?.isConnected) focus.focus({preventScroll:true}); resolve(value); }
      function keys(e) { if (e.key === 'Escape') {e.preventDefault();e.stopPropagation();close(null);} else if (e.key === 'Tab') {const els=[...box.querySelectorAll('button,textarea,summary')].filter(x=>!x.disabled && x.getClientRects().length); const first=els[0],last=els[els.length-1]; if(e.shiftKey&&(document.activeElement===first||document.activeElement===box)){e.preventDefault();last?.focus();}else if(!e.shiftKey&&(document.activeElement===last||document.activeElement===box)){e.preventDefault();first?.focus();}} }
      document.addEventListener('keydown', keys, true);
      root.querySelector('#sr-cancel').onclick = () => close(null);
      root.querySelector('#sr-ok').onclick = () => close({notes: root.querySelector('#sr-notes')?.value || ''});
      box.focus({preventScroll:true});
    });
  }
  function ask({section, current, notes = ''}) {
    return dialog({title: 'Rewrite ' + TITLES[section] + ' with AI', intro: 'The AI receives your card, the finished bot as read-only background, and the template text for this section plus the template-wide rules. It will return only this section. You review the result before applying it.', ok: 'Generate rewrite',
      body: `<details class="sr-current"><summary>Current ${esc(TITLES[section])}</summary><pre>${esc(current)}</pre></details><label for="sr-notes">Additional notes <span class="micro">Optional</span></label><textarea id="sr-notes" maxlength="8000" rows="5" placeholder="What should change? What should stay the same?"></textarea><p class="micro">No request is made until you click Generate rewrite.</p>`,
      init: root => {root.querySelector('#sr-notes').value = notes;}});
  }
  function review({section, before, after, warnings = []}) {
    return dialog({title: 'Review ' + TITLES[section] + ' rewrite', intro: 'Your current text is still unchanged. Apply this version or keep the current one.', ok: 'Apply rewrite',
      body: `${warnings.length ? `<div class="sr-warnings" role="status"><b>Review before applying</b>${warnings.map(x=>`<p>${esc(x)}</p>`).join('')}</div>` : ''}<details class="sr-current"><summary>Current version <span>${before.length.toLocaleString()} characters</span></summary><pre>${esc(before)}</pre></details><h4>Proposed version <span class="micro">${after.length.toLocaleString()} characters</span></h4><pre class="sr-proposal">${esc(after)}</pre>`});
  }
  const api = {TITLES, merge, ask, review};
  if (typeof module !== 'undefined') module.exports = api;
  if (typeof window !== 'undefined') window.SectionRewrite = api;
})();
