/* The Greeting must dramatize The Setup, so its concrete details have to make it into the Greeting.
   - facts(setup, hook): the details worth checking: names of people, places and things ("the Temple of the
     Pale Rose", "Saint-Orlanne"), numbers and times ("three nights", "the eleventh bell"), and quoted words.
   - missing(facts, greeting): the ones the Greeting doesn't contain.                                     */
(function () {
  const STOP = new Set(('A An The This That These Those It Its He She They Them Their His Her Hers Him You Your Yours We Our I Me My ' +
    'And But Or So Yet For Nor If When While After Before Since Until Because Although Though As At In On Of To From With Without By Into Onto ' +
    'Now Then Tonight Today Yesterday Tomorrow There Here Every Each Both All Some Any No Not Only Even Still Just Also Once Twice ' +
    'Mr Mrs Ms Dr Sir Lady Lord Monday Tuesday Wednesday Thursday Friday Saturday Sunday January February March April May June July ' +
    'August September October November December Who What Where Why How Which Whose One Two Three').split(/\s+/));
  const NUMW = 'one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|twenty|thirty|forty|fifty|hundred|' +
    'first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|half|dozen';
  const plain = x => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const strip = t => String(t || '').replace(/\{\{[^}]+\}\}/g, ' ').replace(/\[[^\]]*\]/g, ' ');

  function facts(setup, hook, skip = []) {
    const out = [], seen = new Set(), add = (f0, kind) => {
      const f = String(f0).replace(/['’]s$/i, '').trim(), k = plain(f);                       // "Opaline's" is "Opaline"
      if (k.length < 3 || seen.has(k) || skip.some(s => plain(s) === k) || /^(i|you|we|they|she|he|it)['’](m|re|ll|ve|d|s)$/i.test(f)) return;
      seen.add(k); out.push({text: f, kind}); };
    const text = strip(`${setup || ''}\n${hook || ''}`);
    // quoted words
    for (const m of text.matchAll(/["“]([^"”\n]{3,60})["”]/g)) if (m[1].split(/\s+/).length <= 8) add(m[1], 'quote');
    // names: runs of Capitalized words, joined by "of", "the", "de" (Temple of the Pale Rose); not a lone sentence-starter
    for (const sent of text.split(/(?<=[.!?…])\s+|\n+/)) {
      const words = sent.replace(/["“”]/g, '').split(/\s+/).filter(Boolean);
      for (let i = 0; i < words.length; i++) {
        const w = words[i].replace(/[^\p{L}'’-]/gu, '');
        if (!/^\p{Lu}[\p{L}'’-]{1,}$/u.test(w) || STOP.has(w)) continue;
        const run = [w]; let j = i + 1;
        while (j < words.length) {
          const x = words[j].replace(/[^\p{L}'’-]/gu, ''), next = (words[j + 1] || '').replace(/[^\p{L}'’-]/gu, '');
          if (/^\p{Lu}[\p{L}'’-]+$/u.test(x) && !STOP.has(x)) { run.push(x); j++; }
          else if (/^(of|the|de|du|la|le|von|van)$/i.test(x) && /^\p{Lu}/u.test(next)) { run.push(x); j++; }
          else break;
          if (/[,.;:!?]$/.test(words[j - 1])) break;
        }
        while (run.length > 1 && /^(of|the|de|du|la|le|von|van)$/i.test(run[run.length - 1])) run.pop();
        const name = run.join(' ');
        if (i === 0 && run.length === 1 && !/[A-Z].*[A-Z]|-/.test(name)) { i = j - 1; continue; }   // a lone capitalised first word is usually just the start of a sentence
        add(name, 'name'); i = j - 1;
      }
    }
    // numbers and times: "three nights", "the eleventh bell", "two years", "9 p.m."
    for (const m of text.matchAll(new RegExp(`\\b((?:\\d+(?:[.:]\\d+)?|${NUMW})(?:[- ](?:${NUMW}))?)\\s+([a-z][a-z'-]{2,})`, 'gi')))
      if (!/^one$/i.test(m[1]) && !/^(of|the|and|or|to|in|on|at|for|with|by|a|an|times?|more|less|other|another|last|next|particular|way|ways|thing|things|more|single|small|big|last)$/i.test(m[2])) add(`${m[1]} ${m[2]}`, 'number');
    // a name that is part of a longer name already listed ("Saphrine" in "Saphrine Aldermoor") is covered by it
    const names = out.filter(f => f.kind === 'name' && /\s/.test(f.text)).map(f => plain(f.text));
    const kept = out.filter(f => !(f.kind === 'name' && !/\s/.test(f.text) && names.some(n => (' ' + n + ' ').includes(' ' + plain(f.text) + ' '))));
    // names first (people, places, things), then numbers and times, then quoted words
    const order = {name: 0, number: 1, quote: 2};
    return kept.sort((a, b) => order[a.kind] - order[b.kind]).slice(0, 16);
  }

  // a detail is kept when the Greeting has it (all of a name's main words; a number with its noun, singular or plural)
  function has(greeting, f) {
    const g = ' ' + plain(greeting).replace(/[^a-z0-9'\s-]/g, ' ').replace(/\s+/g, ' ') + ' ';
    const words = plain(f.text).replace(/[^a-z0-9'\s-]/g, ' ').split(/\s+/).filter(w => w.length > 2 && !/^(the|of|and|de|du|la|le|von|van)$/.test(w));
    if (!words.length) return true;
    return words.every(w => g.includes(' ' + w + ' ') || g.includes(' ' + w.replace(/s$/, '') + ' ') || g.includes(' ' + w + 's ') || g.includes(' ' + w.replace(/'s$/, '') + ' '));
  }
  function missing(list, greeting) { return (list || []).filter(f => !has(greeting, f)); }

  const api = {facts, missing, has};
  if (typeof window !== 'undefined') window.SetupFacts = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
