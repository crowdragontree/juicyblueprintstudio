/* The story request carries the actual selected template and creator plan. */
(function () {
  const clean = t => String(t || '').replace(/\s+/g, ' ').trim();
  const toYou = t => clean(t).replace(/\{\{user\}\}['’]s/g, 'your').replace(/\{\{user\}\}/g, 'you');

  function build(spec, v, card, state, options = {}) {
    const TC = window.TemplateContract, GP = window.GreetingPlan;
    const plan = GP && GP.forCard(card, v && v.greetingPlan);
    const n = spec.greeting.count, hasIntro = !spec.introduction.absent;
    const lines = ["Write only the requested Introduction and Greeting using the selected template's actual instructions.",
      "The numbered reply blocks below are transport labels, not a replacement narrative structure. Each numbered block corresponds to the template passage before that image marker.",
      "", ...(options.includeTemplate === false ? [] : [TC.system(spec)]), "", "RESOLVED BOT BUILDER SETTINGS", TC.resolved(spec, v),
      "", "COMPLETE SCENARIO CARD (source context, not a requirement to include every detail in the Greeting)",
      GP ? GP.fullCardText(card, plan, {greeting: true}) : JSON.stringify(card || {}, null, 2)];
    if (plan) lines.push("", GP.instructions(plan, {greeting: true}));
    lines.push("", "GREETING SECTION FROM THE SELECTED TEMPLATE (including its dialogue slots)", TC.sectionRaw(spec, 'greeting'));
    if (hasIntro) lines.push("", "INTRODUCTION SECTION FROM THE SELECTED TEMPLATE", TC.sectionRaw(spec, 'introduction'));
    lines.push("", "REPLY LAYOUT: return only these sections. Do not include the template's instructional text, headings for other sections, or image markers; the app inserts the existing markers between the numbered passages.");
    if (hasIntro) lines.push('INTRODUCTION:', '(the Introduction)');
    lines.push('GREETING:');
    for (let i=1;i<=n;i++) lines.push('['+i+']', '(template Greeting passage '+i+')');
    return lines.join('\n');
  }

  // Read the chatbot's reply: introduction + numbered greeting paragraphs.
  function parse(text, spec) {
    // headings arrive as INTRODUCTION:, **INTRODUCTION:**, ## Introduction, __GREETING__ ...
    let t = String(text || '').replace(/\r\n/g, '\n').replace(/^[ \t]*#+[ \t]*/gm, '')
      .replace(/^[ \t]*[*_]{1,3}[ \t]*(INTRODUCTION|GREETING)[ \t]*:?[ \t]*[*_]{0,3}[ \t]*:?[ \t]*$/gim, (m, h) => h.toUpperCase() + ':');
    // chatty sign-offs after the story ("Hope this works!", "Let me know if...")
    t = t.replace(/\n+[ \t]*(hope (this|that|it)|let me know|feel free|i hope|would you like|want me to|happy to|enjoy)[^\n]*\s*$/i, '');
    const iI = t.search(/^\s*INTRODUCTION\s*:?\s*$/im), iG = t.search(/^\s*GREETING\s*:?\s*$/im);
    let intro = '', greet = '';
    if (iG >= 0) { greet = t.slice(iG).replace(/^\s*GREETING\s*:?\s*\n/i, ''); intro = iI >= 0 && iI < iG ? t.slice(iI, iG).replace(/^\s*INTRODUCTION\s*:?\s*\n?/i, '') : ''; }
    else greet = t;
    intro = clean(intro.replace(/^\(|\)$/g, ''));
    const n = spec.greeting.count;
    let paras;
    if (/^\s*\[\d+\]\s*$/m.test(greet)) paras = greet.split(/^\s*\[\d+\]\s*$/m).map(x => x.trim()).filter(Boolean);
    else {
      // no numbers: split on blank lines, then join pieces so there are n paragraphs
      const blocks = greet.split(/\n\s*\n/).map(x => x.trim()).filter(Boolean);
      paras = [];
      const per = Math.max(1, Math.round(blocks.length / n));
      for (let i = 0; i < blocks.length; i += per) paras.push(blocks.slice(i, i + per).join('\n'));
      // grouping by that size can come out SHORT (9 or 10 blocks for 6 passages gives 5): when there are enough blocks, share them out evenly so there are exactly n passages
      if (paras.length < n && blocks.length >= n) { paras = []; for (let i = 0; i < n; i++) paras.push(blocks.slice(Math.round(i * blocks.length / n), Math.round((i + 1) * blocks.length / n)).join('\n')); }
    }
    while (paras.length > n) { const last = paras.pop(); paras[paras.length - 1] += '\n' + last; }
    paras = paras.map(p => p.split('\n').map(l => l.trim()).filter(l => !/^!\[\]\(image\d+\)$/.test(l) && !/^---+$/.test(l)).join('\n').replace(/\n{3,}/g,'\n\n').trim());
    return {intro, paras, found: {intro: !!intro, paragraphs: paras.length, expected: n}};
  }

  // Fix the small things chatbots slip in: banned punctuation and {{user}}.
  function tidy(t, spec) {
    if (typeof window !== 'undefined' && window.Dialogue && /contractions/i.test(spec.raw || '')) t = window.Dialogue.contract(t);   // dialogue stays casual: don't, I'm, it's (inside quotes only)
    const g = spec.greeting; let x = String(t || '');
    if (g.banEmDash) x = x.replace(/\s*[—–]\s*/g, ', ');
    if (g.banColonSemi) x = x.replace(/;\s*/g, ', ').replace(/(\S):\s+/g, '$1, ');
    if (g.banUserToken) x = x.replace(/\{\{user\}\}['’]s/g, 'your').replace(/\{\{user\}\}/g, 'you');
    return x.replace(/,\s*,/g, ',').replace(/ {2,}/g, ' ');
  }

  window.StoryBrief = {build, parse, tidy};
})();
