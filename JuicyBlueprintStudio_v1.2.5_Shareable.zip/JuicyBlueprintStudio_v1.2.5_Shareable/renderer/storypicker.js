/* Step 1 of Write with AI: choose the story. The Story engine reads the scenario card and offers the three best-fitting topics for the pacing,
   the tone and the character. Nothing here calls an AI; the caller opens the Greeting planner next and starts the writer only after that. */
(function () {
  'use strict';
  let active = null;
  const GROUPS = [['pacing', 'Pacing', 'How the plot moves'], ['tone', 'Tone', 'How the scenes feel'], ['character', 'Character', 'How she behaves as a person']];
  const MODE_TEXT = {
    auto: 'Auto offers the three best matches for this card in each group. The first is the best fit and is selected for you. Click another to use it instead.',
    pick: 'Pick lets you choose any topic from the whole library for each group. What you selected in Auto is shown here.',
    off: 'Off writes this bot without any Story engine directions, exactly as before.'
  };
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const RANK = ['Best match', '2nd match', '3rd match'];
  const reasonText = m => m.reasons && m.reasons.length ? m.reasons.join('; ') : 'no strong match in the card';

  function open({card, spec, story}) {
    if (active) { active.focus(); return Promise.resolve(null); }
    const api = window.juicyApp, originalFocus = document.activeElement;
    const S = {mode: ['auto', 'pick', 'off'].includes(story && story.mode) ? story.mode : 'auto', picks: {...((story && story.picks) || {})}, details: (story && story.details) || '', chosen: (story && story.chosen) || {}, locked: !!(story && story.locked)};
    const root = document.createElement('div'); root.id = 'story-picker-modal'; root.className = 'upd-modal sp-modal';
    root.innerHTML = `<section class="upd-box sp-box" role="dialog" aria-modal="true" aria-labelledby="sp-title" aria-describedby="sp-help" tabindex="-1">
      <header class="sp-header"><span class="sp-eyebrow">BEFORE AI WRITING · STEP 1 OF 2</span><h3 id="sp-title">Choose the story</h3>
        <p class="sp-subtitle">${esc(card.sceneName || 'Untitled scene')}${spec && spec.name ? ` <span>· ${esc(spec.name)}</span>` : ''}</p>
        <p id="sp-help">The Story engine reads the character, her archetype, her personality and the scenario, and picks how the bot paces, feels and behaves. The next step plans the Greeting.</p></header>
      <div class="sp-body">
        <div class="sp-modes" role="group" aria-label="Story engine mode"><button type="button" data-mode="auto">Auto</button><button type="button" data-mode="pick">Pick</button><button type="button" data-mode="off">Off</button></div>
        <p class="sp-mode-help" id="sp-mode-help"></p>
        <div id="sp-groups"></div>
        <p class="sp-drive" id="sp-drive"></p>
        <label class="sp-details" for="sp-details"><span>Details <i>Optional</i></span><input id="sp-details" type="text" maxlength="300" placeholder="e.g. make it angsty and fast-paced. Typing here re-picks the matches."></label>
      </div>
      <footer class="sp-footer"><div><span id="sp-error" class="sp-error" role="status"></span><span class="sp-no-ai">Nothing is sent to the AI until you click Write bot with this plan in the next step.</span></div>
        <div class="sp-footer-buttons"><button type="button" class="ghost" id="sp-cancel">Cancel</button><button type="button" class="primary" id="sp-next">Next: plan the Greeting</button></div></footer>
      <span id="sp-live" class="sp-sr-only" role="status" aria-live="polite"></span></section>`;
    document.body.appendChild(root);
    const box = root.querySelector('.sp-box'), $ = id => root.querySelector('#' + id);
    const priorOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
    const siblings = [...document.body.children].filter(e => e !== root && !/^(SCRIPT|STYLE)$/.test(e.tagName)).map(e => [e, e.inert]);
    siblings.forEach(([e]) => { e.inert = true; });
    active = box;
    let plan = null, token = 0, finished = false;
    const announce = m => { $('sp-live').textContent = m; };
    const current = () => ({mode: S.mode, picks: {...S.picks}, details: S.details, chosen: S.chosen, locked: S.locked});

    let inflight = Promise.resolve();
    const refresh = focusSel => (inflight = doRefresh(focusSel));
    async function doRefresh(focusSel) {
      const mine = ++token;
      try { plan = await api.storyPlan(card.id, current()); } catch (e) { plan = null; $('sp-error').textContent = 'The Story engine could not read this card. You can continue; it will pick automatically.'; }
      if (mine !== token || finished) return;
      draw(focusSel);
    }

    function group(g, label, hint) {
      const p = plan.picks[g];
      const opts = (plan.options && plan.options[g]) || [];
      let control = '';
      if (S.mode === 'auto') {
        const extra = p.inMatches ? '' : `<button type="button" class="sp-match is-selected" data-pick="${g}:${esc(p.id)}" aria-pressed="true"><span class="sp-rank">${p.manual ? 'Your pick' : 'Used last time'}</span><b>${esc(p.name)}</b><span class="sp-why">${esc(p.reasons.length ? p.reasons.join('; ') : 'not one of the three best matches for this card')}</span></button>`;
        control = `<div class="sp-matches">${p.matches.map((m, i) => `<button type="button" class="sp-match${m.id === p.id ? ' is-selected' : ''}" data-pick="${g}:${esc(m.id)}" aria-pressed="${m.id === p.id}"><span class="sp-rank">${RANK[i]}</span><b>${esc(m.name)}</b><span class="sp-why">${esc(reasonText(m))}</span></button>`).join('')}${extra}</div>`;
      } else {
        const top = new Set(p.matches.map(m => m.id));
        const line = o => `<option value="${esc(o.id)}" ${o.id === p.id ? 'selected' : ''}>${esc(o.name)}</option>`;
        const best = p.matches.map((m, i) => ({...m, name: `${RANK[i]}: ${m.name}`})).map(line).join('');
        control = `<label class="sp-select"><span class="sp-sr-only">${label} topic</span><select data-pickbox="${g}"><optgroup label="Best matches for this card">${best}</optgroup><optgroup label="All ${label.toLowerCase()} topics">${opts.filter(o => !top.has(o.id)).map(line).join('')}</optgroup></select></label>`;
      }
      return `<section class="sp-group" aria-label="${label}"><h4>${label} <span>${hint}</span></h4>${control}<p class="sp-says"><b>Tells the AI:</b> ${esc(p.directive)}</p></section>`;
    }

    function draw(focusSel) {
      root.querySelectorAll('[data-mode]').forEach(b => { b.classList.toggle('on', b.dataset.mode === S.mode); b.setAttribute('aria-pressed', String(b.dataset.mode === S.mode)); });
      $('sp-mode-help').textContent = MODE_TEXT[S.mode];
      const off = S.mode === 'off';
      $('sp-groups').innerHTML = off || !plan ? '' : GROUPS.map(([g, l, h]) => group(g, l, h)).join('');
      $('sp-drive').hidden = off || !plan;
      if (!off && plan) $('sp-drive').innerHTML = `<b>Character drive (always on):</b> she wants something, fears something, shows it, starts things and pushes back.${plan.drive && plan.drive.stoic ? ' This is a quiet archetype, so the stoic guard is also on.' : ''}`;
      root.querySelectorAll('[data-pick]').forEach(b => b.onclick = () => { const [g, id] = b.dataset.pick.split(':'); S.picks[g] = id; announce(`${g} set to ${b.querySelector('b').textContent}.`); refresh(`[data-pick="${g}:${id}"]`); });
      root.querySelectorAll('[data-pickbox]').forEach(sel => sel.onchange = () => { S.picks[sel.dataset.pickbox] = sel.value; announce(`${sel.dataset.pickbox} set.`); refresh(`[data-pickbox="${sel.dataset.pickbox}"]`); });
      if (focusSel) { const el = root.querySelector(focusSel); if (el) el.focus({preventScroll: true}); }
    }

    root.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => { S.mode = b.dataset.mode; announce(`${b.textContent} selected.`); if (S.mode === 'off') draw(); else refresh(); });
    $('sp-details').value = S.details;
    let appliedDetails = S.details;
    // typing details re-picks the matches (your words beat the automatic choice); it also runs when you click Next straight after typing
    const applyDetails = async () => { const v = $('sp-details').value; if (v === appliedDetails) return; appliedDetails = S.details = v; S.picks = {}; S.chosen = {}; S.locked = false; await refresh(); };
    $('sp-details').onchange = () => { applyDetails(); };

    return new Promise(resolve => {
      function close(value) { if (finished) return; finished = true; document.removeEventListener('keydown', keys, true); root.remove(); document.body.style.overflow = priorOverflow; siblings.forEach(([e, old]) => { e.inert = old; }); active = null; if (originalFocus && originalFocus.isConnected) originalFocus.focus({preventScroll: true}); resolve(value); }
      function keys(e) {
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(null); return; }
        if (e.key !== 'Tab') return;
        const focusable = [...box.querySelectorAll('button:not([disabled]),input:not([disabled]),select,[tabindex="0"]')].filter(x => x.getClientRects().length);
        const first = focusable[0], last = focusable[focusable.length - 1];
        if (e.shiftKey && (document.activeElement === first || document.activeElement === box)) { e.preventDefault(); last && last.focus(); }
        else if (!e.shiftKey && (document.activeElement === last || !box.contains(document.activeElement))) { e.preventDefault(); first && first.focus(); }
      }
      document.addEventListener('keydown', keys, true);
      $('sp-cancel').onclick = () => close(null);
      $('sp-next').onclick = async () => {
        await applyDetails(); await inflight; S.details = $('sp-details').value;
        if (S.mode === 'off') return close({mode: 'off'});
        // what the window shows is exactly what is written: every group's selected topic is sent
        const picks = {}; if (plan) for (const [g] of GROUPS) picks[g] = plan.picks[g].id;
        close({mode: S.mode, picks, details: S.details, chosen: S.chosen, locked: S.locked});
      };
      box.focus({preventScroll: true});
      refresh();
    });
  }
  window.StoryPicker = {open};
})();
