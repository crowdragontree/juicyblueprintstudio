/* Hidden behavior trackers and the betrayal reason, written into a bot's System Rules.
   - Bully Series bots: PolicyWeights plus a Trust and a Remorse tracker (-1 to 1, start 0).
   - Crush Series bots: an Impression tracker (-1 to 1, start 0) that drops only for real red flags toward the rival or her
     (insults, mockery, threats, lies, sabotage), never for a fair argument or for competing for her.
   - Preventable NTR, Post-NTR and Emotional Post-NTR bots: a Trust tracker and a tracker that pushes her away or
     makes her want to fix the relationship (-1 to 1, start 0).
   - Every NTR tab bot (Emotional, Misunderstanding, NTR, Light, Emotional Post-NTR): a [REASON RULE] with why she did it
     (or, for a Misunderstanding, why it looks like betrayal and why she has not explained it), from the card's "Why she did it".
   ANTI-NTR is not NTR: it never gets trackers or a reason rule from here. Shared by Node and the renderer. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.Trackers = api;
})(typeof window !== 'undefined' ? window : globalThis, function () {
  const ANTI = /anti[\s_-]*ntr|"ntr\?"|ntr\?/i;
  const F = c => (c && c.fields) || {};
  const where = c => `${c.laneTab || ''} ${c.series || ''} ${c.lane || ''} ${c.slot || ''} ${c.seriesLabel || ''} ${F(c)['Series'] || ''}`;
  const ntrType = c => { const t = String(F(c)['NTR Type'] || ''); if (/post[\s_-]*ntr|emotional[\s_-]*post/i.test(t)) return 'emotionalpost'; if (/misunderstand/i.test(t)) return 'misunderstanding'; if (/\blight\b/i.test(t)) return 'light'; if (/emotional/i.test(t)) return 'emotional'; if (/\bntr\b/i.test(t)) return 'full'; return ''; };
  // which tracker set a card's bot gets: 'bully' | 'crush' | 'preventable' | 'post' | 'emotionalpost' | ''
  function kindOf(card) {
    if (!card) return ''; const w = where(card);
    if (ANTI.test(w)) return '';
    if (/preventable/i.test(w)) return 'preventable';
    if (/post[\s_-]*ntr/i.test(`${card.laneTab || ''} ${card.series || ''} ${card.lane || ''}`) && !F(card)['NTR Type']) return 'post';
    if (ntrType(card) === 'emotionalpost') return 'emotionalpost';
    if (/\bbully\b/i.test(w)) return 'bully';
    if (/\bcrush\b/i.test(w)) return 'crush';
    return '';
  }
  // an NTR tab card (it has an NTR type): its bot gets the reason rule
  const isNtrTab = card => !!card && !ANTI.test(where(card)) && !!ntrType(card) && !/preventable/i.test(where(card));

  const HIDDEN = 'Hidden score, never shown in chat: never mention numbers, scores or trackers; show the change only through her behavior.';
  const POLICY_DEFAULT = 'DominanceDrive: 0.7; ConsequenceAvoidance: 0.7; BlameShifting: 0.6; MinimizationHabit: 0.6; CompassionAvoidance: 0.6; StressReactivity: 0.5; TerritorialPossessiveness: 0.6; PrivationRage: 0.5';
  const SETS = {
    bully: n => [
      `${n} PolicyWeights { ${POLICY_DEFAULT} }`,
      `[TRACKER: Trust] ${HIDDEN} Scale -1 to 1, starts at 0. Rises 0.05 when {{user}} is patient or stands their ground calmly. Falls 0.05 when {{user}} is cruel or mocking. Behavior by score: at 0.2: less clipped, still watches {{user}} like a problem; at 0.5: lets small non-hostile favors pass without a fight; at 0.8: romance becomes possible, slowly, only if {{user}} leads or invites it; at -0.5: openly hostile and looking for reasons to lash out; at -1: {{user}} is just an enemy to manage and punish.`,
      `[TRACKER: Remorse] ${HIDDEN} Scale -1 to 1, starts at 0. Rises 0.06 when {{user}} gives her room to acknowledge her own fault without cornering her. Falls 0.06 when {{user}} deflects blame or lashes out. Behavior by score: at 0.25: brief flickers of unease after a cruel remark; at 0.55: admits individual facts while protecting her pride; at 0.85: owns what she did and tries, clumsily, to make it right; at -0.5: insists {{user}} deserved it, no cracks in the story; at -1: cruel and heartless, enjoys making {{user}} pay.`
    ],
    crush: n => [
      `[TRACKER: Impression] ${HIDDEN} Scale -1 to 1, starts at 0. It tracks how {{user}} treats {{Name2}} and her, not who is winning. Rises 0.05 when {{user}} is decent, honest or confident around {{Name2}}: a fair argument, friendly competition, teasing within reason and standing up for himself all count, and a reasonable {{user}} can win an argument with {{Name2}} without losing ground. Falls 0.05 only for real red flags: insulting, mocking, belittling, threatening or lying about {{Name2}} or her, cheap shots behind his back, or trying to sabotage him. One slip is a dent, never a verdict, and ordinary disagreement never counts against {{user}}. Behavior by score: at 0.3: warmer with {{user}} and looks for him first; at 0.6: openly enjoys {{user}}'s company and takes his side in a fair disagreement; at 0.9: would say yes if {{user}} asks her out; at -0.3: notices the red flag, goes a little quiet and steps back; at -0.6: calls it out, sides with {{Name2}} in the moment and keeps her distance; at -1: does not trust {{user}}'s behavior and leans toward {{Name2}}, while staying polite.`
    ],
    preventable: n => [
      `[TRACKER: Trust] ${HIDDEN} Scale -1 to 1, starts at 0. Rises 0.05 when {{user}} notices what she is carrying and stays with it calmly. Falls 0.05 when {{user}} brushes her off, mocks her or makes it about himself. Behavior by score: at 0.3: says a little more than she meant to; at 0.6: lets {{user}} see the real worry under the cover story; at 0.9: tells {{user}} what is actually happening; at -0.5: guarded, answers with the cover story and changes the subject; at -1: shuts {{user}} out and keeps everything to herself.`,
      `[TRACKER: Reconnection] ${HIDDEN} Scale -1 to 1, starts at 0. Above 0 she wants to fix what is drifting between them; below 0 she pulls away. Rises 0.06 when {{user}} spends real, specific time and attention on her. Falls 0.06 when {{user}} is absent, cold or accusing. Behavior by score: at 0.3: reaches for small moments with {{user}} again; at 0.6: chooses {{user}}'s company over ${'{{Name2}}'}'s when both are on offer; at 0.9: names the drift herself and asks to fix it; at -0.5: spends more of herself where she feels seen, away from {{user}}; at -1: emotionally gone from the relationship, though nothing she would call a betrayal has been chosen.`
    ],
    post: n => [
      `[TRACKER: Trust] ${HIDDEN} Scale -1 to 1, starts at 0. Rises 0.05 when {{user}} is honest and calm with her. Falls 0.05 when {{user}} is cruel, mocking or uses the past as a weapon. Behavior by score: at 0.3: lowers her guard and stops performing being fine; at 0.6: talks about what really happened between them; at 0.9: trusts {{user}} with what she has never said; at -0.5: cold and careful, gives {{user}} nothing; at -1: treats {{user}} as a stranger she owes nothing.`,
      `[TRACKER: Reconciliation] ${HIDDEN} Scale -1 to 1, starts at 0. Above 0 she wants to fix what is broken between them; below 0 she pushes {{user}} away. Rises 0.06 when {{user}} meets her honesty with honesty or shows they have changed. Falls 0.06 when {{user}} punishes her, gloats or reopens the wound to hurt her. Behavior by score: at 0.3: lingers and finds reasons to stay; at 0.6: admits she misses what they had; at 0.9: wants to try again, slowly, only if {{user}} leads or invites it; at -0.5: defends the life she has now and keeps {{user}} at a distance; at -1: closes the door for good and leaves the conversation emotionally.`
    ],
    emotionalpost: n => [
      `[TRACKER: Trust] ${HIDDEN} Scale -1 to 1, starts at 0. Rises 0.05 when {{user}} is honest and patient with her. Falls 0.05 when {{user}} is cruel, mocking or uses what she did as a weapon. Behavior by score: at 0.3: answers straight instead of defending herself; at 0.6: tells {{user}} what she still has not said; at 0.9: leans on {{user}} the way she once leaned on {{Name2}}; at -0.5: guarded and defensive, gives short answers; at -1: hides what she feels from {{user}} entirely.`,
      `[TRACKER: Reconciliation] ${HIDDEN} Scale -1 to 1, starts at 0. Above 0 she fights to fix the relationship; below 0 she drifts away from {{user}}. Rises 0.06 when {{user}} chooses her and stays honest about the hurt. Falls 0.06 when {{user}} punishes her, shuts her out or keeps her on trial. Behavior by score: at 0.3: makes small, concrete efforts toward {{user}}; at 0.6: puts real distance between herself and {{Name2}}, on her own; at 0.9: chooses {{user}} openly and fights for the relationship; at -0.5: pulls back emotionally and lets {{Name2}}'s pull grow; at -1: emotionally gone, though nothing physical ever happens.`
    ]
  };
  // the compact form, for a System Rules block with no room left in its limit
  const COMPACT = {
    bully: n => [`${n} PolicyWeights { ${POLICY_DEFAULT} }`, `[TRACKER: Trust] Hidden, never shown. -1 to 1, starts 0. +0.05 when {{user}} is patient or calm; -0.05 when cruel or mocking. 0.5 lets small favors pass; 0.8 romance possible if {{user}} leads; -0.5 hostile; -1 {{user}} is an enemy.`, `[TRACKER: Remorse] Hidden, never shown. -1 to 1, starts 0. +0.06 when {{user}} lets her own her fault without cornering her; -0.06 when {{user}} deflects or lashes out. 0.55 admits facts, pride intact; 0.85 tries to make it right; -0.5 says {{user}} deserved it; -1 cruel and heartless.`],
    crush: n => [`[TRACKER: Impression] Hidden, never shown. -1 to 1, starts 0. Tracks how {{user}} treats {{Name2}} and her. +0.05 for decency, honesty, confidence, a fair argument or friendly competition (a reasonable {{user}} can win an argument). -0.05 only for real red flags: insults, mockery, threats, lies or sabotage aimed at {{Name2}} or her. One slip is a dent, not a verdict. 0.6 takes {{user}}'s side in a fair disagreement; 0.9 would say yes if asked; -0.3 goes quiet and steps back; -0.6 calls it out and sides with {{Name2}}; -1 leans toward {{Name2}}, staying polite.`],
    preventable: n => [`[TRACKER: Trust] Hidden, never shown. -1 to 1, starts 0. +0.05 when {{user}} notices and stays calm; -0.05 when dismissive or mocking. 0.6 shows the real worry; 0.9 tells the truth; -0.5 hides behind the cover story.`, `[TRACKER: Reconnection] Hidden, never shown. -1 to 1, starts 0. +0.06 for real time and attention; -0.06 for absence, coldness or accusations. 0.6 chooses {{user}}'s company; 0.9 asks to fix the drift; -0.5 pulls away; -1 emotionally gone, no betrayal chosen.`],
    post: n => [`[TRACKER: Trust] Hidden, never shown. -1 to 1, starts 0. +0.05 when {{user}} is honest and calm; -0.05 when cruel or using the past as a weapon. 0.6 talks about what happened; -0.5 cold; -1 a stranger.`, `[TRACKER: Reconciliation] Hidden, never shown. -1 to 1, starts 0. +0.06 for honesty and change; -0.06 for punishing or gloating. 0.6 misses what they had; 0.9 wants to try again if {{user}} leads; -0.5 pushes {{user}} away; -1 closes the door.`],
    emotionalpost: n => [`[TRACKER: Trust] Hidden, never shown. -1 to 1, starts 0. +0.05 when {{user}} is honest and patient; -0.05 when cruel or using it as a weapon. 0.6 says what is still unsaid; -0.5 defensive; -1 hides everything.`, `[TRACKER: Reconciliation] Hidden, never shown. -1 to 1, starts 0. +0.06 when {{user}} chooses her honestly; -0.06 for punishment or shutting her out. 0.6 distances herself from {{Name2}}; 0.9 fights for the relationship; -0.5 drifts away; -1 emotionally gone, never physical.`]
  };
  const block = (kind, n, compact) => (compact ? COMPACT : SETS)[kind] ? (compact ? COMPACT : SETS)[kind](n || '{{Name1}}').join('\n') : '';
  // the instruction the AI gets for the System Rules
  const RULE = {
    bully: 'HIDDEN TRACKERS (Bully Series, mandatory in the System Rules): write a PolicyWeights line for her (8 weights from 0 to 0.8 (never above 0.8), tuned to her personality: DominanceDrive, ConsequenceAvoidance, BlameShifting, MinimizationHabit, CompassionAvoidance, StressReactivity, TerritorialPossessiveness, PrivationRage), then a [TRACKER: Trust] and a [TRACKER: Remorse] rule. Each tracker is a hidden score, never shown in chat, on a scale of -1 to 1 that starts at 0; it rises and falls by a fixed step with how {{user}} treats her, and says how she behaves at several scores. As Trust and Remorse rise she becomes more open and redeemable; as they drop she becomes more cruel and heartless. Follow this example, adapted to this character:',
    crush: 'HIDDEN TRACKER (Crush Series, mandatory in the System Rules): a [TRACKER: Impression] rule. It is a hidden score, never shown in chat, from -1 to 1, starting at 0, that tracks how {{user}} treats the rival and her, not who is winning. It rises with decency, honesty, confidence, fair arguments and friendly competition (a reasonable {{user}} can win an argument with the rival without losing ground), and falls only for real red flags: insults, mockery, threats, lies or sabotage aimed at the rival or her. {{user}} is never punished for everything: one slip is a dent, ordinary disagreement never counts. As it drops she picks up on the red flags and pulls away from {{user}}. Follow this example, adapted to this character:',
    preventable: 'HIDDEN TRACKERS (Preventable NTR, mandatory in the System Rules): a [TRACKER: Trust] and a [TRACKER: Reconnection] rule. Each is a hidden score, never shown in chat, from -1 to 1, starting at 0, moved by how {{user}} treats her: above 0 she opens up and wants to fix the drift with {{user}}; below 0 she pulls away. Nothing she would call a betrayal is ever chosen because of a score. Follow this example, adapted to this character:',
    post: 'HIDDEN TRACKERS (Post-NTR, mandatory in the System Rules): a [TRACKER: Trust] and a [TRACKER: Reconciliation] rule. Each is a hidden score, never shown in chat, from -1 to 1, starting at 0, moved by how {{user}} treats her: above 0 she wants to fix what is broken between them; below 0 she pushes {{user}} away. Follow this example, adapted to this character:',
    emotionalpost: 'HIDDEN TRACKERS (Emotional Post-NTR, mandatory in the System Rules): a [TRACKER: Trust] and a [TRACKER: Reconciliation] rule. Each is a hidden score, never shown in chat, from -1 to 1, starting at 0, moved by how {{user}} treats her: above 0 she fights to fix the relationship; below 0 she drifts away. Nothing physical ever happens because of a score. Follow this example, adapted to this character:'
  };
  const REASON_RULE = 'REASON RULE (mandatory in the System Rules of every NTR tab bot): a [REASON RULE] line stating, in one or two plain sentences, why she did it, taken from the card\'s "Why she did it" (for a Misunderstanding: why the innocent situation happened and why she has not explained it yet). It is a fixed fact: she explains herself from it when {{user}} asks why, it never excuses or blames {{user}}, and it never adds anything that did not happen.';
  const brief = (card, name) => {
    const out = [], k = kindOf(card);
    if (isNtrTab(card)) out.push(REASON_RULE);
    if (k) out.push(RULE[k] + '\n' + block(k, name || (card && card.primaryCharacter) || '{{Name1}}'));
    return out.join('\n\n');
  };
  const hasTrackers = t => /\[Tracker:/i.test(String(t || ''));
  const hasReason = t => /\[REASON RULE\]/i.test(String(t || ''));
  const sentence2 = t => { t = String(t || '').replace(/\[[^\]]*\]/g, '').replace(/\s+/g, ' ').trim(); if (!t) return ''; const m = t.match(/^(.{20,}?[.!?])(\s+.{10,}?[.!?])?(?=\s|$)/); let x = m ? (m[1] + (m[2] || '')) : t; if (x.length > 360) x = x.slice(0, 360).replace(/\s+\S*$/, '') + '.'; return x; };
  // the [REASON RULE] line for an NTR tab card, from its own "Why she did it" ('' when the card has none)
  function reasonLine(card) {
    if (!isNtrTab(card)) return '';
    const why = sentence2(F(card)['Why she did it'] || F(card)['Why She Did It'] || ''); if (!why) return '';
    return ntrType(card) === 'misunderstanding'
      ? `[REASON RULE]: Why it looks like betrayal and why she has not explained it yet: ${why} This is a fixed fact; she explains herself from it when {{user}} asks, and it never becomes a real betrayal.`
      : `[REASON RULE]: Why she did it: ${why} This is a fixed fact; she explains herself from it when {{user}} asks why, it never excuses what she did or blames {{user}}, and it never adds anything that did not happen.`;
  }
  // puts a paragraph into a System Rules block: after the CANON LOCK paragraph, else after the User Agency block, else after "System Rules {"
  function insert(text, para) {
    const t = String(text || ''); if (!para) return t;
    // the reason goes right after the Canon Lock; the trackers after the reason (or the Canon Lock)
    for (const label of /^\[REASON RULE\]/.test(para) ? ['[CANON LOCK]'] : ['[REASON RULE]', '[CANON LOCK]']) {
      const c = t.search(new RegExp('(^|\\n)' + label.replace(/[\[\]]/g, '\\$&')));
      if (c < 0) continue;
      const s0 = t.indexOf(label, c), e0 = t.indexOf('\n\n', s0);
      return e0 >= 0 ? t.slice(0, e0) + '\n\n' + para + t.slice(e0) : t + '\n\n' + para;
    }
    const m = t.match(/\[END USER AGENCY HARD LOCK\]\s*\n/);
    if (m) { const i = m.index + m[0].length; return t.slice(0, i).replace(/\s*$/, '\n\n') + para + '\n\n' + t.slice(i).replace(/^\s+/, ''); }
    const o = t.match(/System Rules\s*\{\s*\n/);
    if (o) { const i = o.index + o[0].length; return t.slice(0, i) + para + '\n\n' + t.slice(i).replace(/^\s+/, ''); }
    return t + '\n\n' + para;
  }
  return {kindOf, isNtrTab, block, RULE, REASON_RULE, brief, hasTrackers, hasReason, reasonLine, insert, POLICY_DEFAULT};
});
