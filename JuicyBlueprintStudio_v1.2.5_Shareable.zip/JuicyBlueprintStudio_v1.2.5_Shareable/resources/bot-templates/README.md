This folder is intentionally empty. Add your own bot templates inside the app:
Bot Builder > "+ Add template..." (they are stored in the app's data folder).
