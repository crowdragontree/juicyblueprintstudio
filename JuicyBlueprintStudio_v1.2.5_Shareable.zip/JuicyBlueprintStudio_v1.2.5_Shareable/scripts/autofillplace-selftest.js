'use strict';
/* A card that names its own place gets that place in Action & Background and the scene settings, never a random house with a living room. */
const fs = require('fs'), vm = require('vm'), path = require('path'), assert = require('assert');
const win = {}; vm.runInNewContext(fs.readFileSync(path.join(__dirname, '..', 'renderer', 'autofill.js'), 'utf8'), {window: win, console});
const A = win.BBAuto;
const spec = {id: 'x', name: 'SCP', tags: {archetypes: []}, rules: {}};
const ctx = setup => A.context(spec, {names: {1: 'SCP-024'}, header: {}, f: {}}, {fields: {'The Setup': setup}});

const scp = ctx('The Foundation is gone. The upper floors of a dead department store are dry, so you wade in through the broken doors. Something is already standing on the fifth step.');
assert.strictEqual(scp.place, 'a dead department store', 'the place is the one the card names: ' + scp.place);
const a = A.image(scp).action;
assert(!/living room|lakeside|rental house/i.test(a) && /department store/i.test(a), 'Action & Background uses the card place: ' + a);

const home = ctx('You come home late and she is waiting inside your apartment.');
assert(/apartment/i.test(home.place), 'a home is still found: ' + home.place);
assert(/living room/.test(A.image(home).action), 'a home keeps its living room');

const none = ctx('Something strange happens tonight.');
assert(/apartment|house|party|cafe/.test(none.place), 'no place named: one is still picked (' + none.place + ')');
console.log('Autofill place self-test passed: the card\'s own place is used; a random house only when the card names none.');
