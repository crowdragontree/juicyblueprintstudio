'use strict';
// Move a card to another tab: where it lands, what happens to the old spot, what is refused. Uses a week the app itself generates.
const assert = require('assert'), CM = require('../lib/cardMove'), P = require('../lib/procedural');
const mk = () => { const g = P.generateWeekLocal({engineAnalysis: null, activeEvent: null, weekStart: '2026-10-18', performance: null, plan: null});
  return {week: {weekStart: g.weekStart, scenarios: g.days.flatMap(d => d.scenarios), ntr: g.ntr || [], bonus: [], statuses: {}}}; };
const day = (s, d) => s.week.scenarios.filter(c => c.day === d);
{ // reset: the old spot stays as an empty slot, the card goes first on the other day as an extra
  const s = mk(), tue = day(s, 'Tuesday'), card = tue[0], id = card.id, n0 = s.week.scenarios.length, mon0 = day(s, 'Monday').length;
  s.week.statuses[id] = 'Built'; const slot0 = card.slot, series0 = card.series;
  assert.equal(CM.check(s, id, 'Monday', ''), 'Choose what happens to the old spot: reset it or delete it.');
  assert.equal(CM.check(s, id, 'Tuesday', 'reset'), 'That card is already in Tuesday.');
  assert.equal(CM.check(s, id, 'Nope', 'reset'), 'Pick Monday to Sunday or Bonus as the destination.');
  const placed = CM.move(s, id, 'Monday', 'reset', 'established');
  assert.equal(placed, 'the top of Monday'); assert.equal(day(s, 'Monday').length, mon0 + 1); assert.equal(day(s, 'Monday')[0].id, id, 'first card of Monday');
  const moved = day(s, 'Monday')[0]; assert.ok(moved.addedBonus && moved.movedFrom === 'Tuesday' && moved.movedType === 'established' && moved.day === 'Monday'); assert.equal(moved.slot, `Scenario ${mon0 + 1}`);
  assert.equal(day(s, 'Tuesday').length, tue.length, 'Tuesday still has its spots'); const blank = day(s, 'Tuesday').find(c => c.blankSlot);
  assert.ok(blank && blank.id !== id && blank.slot === slot0 && blank.sceneName === 'Untitled' && blank.series === series0, 'old spot is an empty slot with the same slot and series');
  assert.equal(s.week.statuses[id], 'Built', 'Built tick stays with the card'); assert.equal(s.week.scenarios.length, n0 + 1);
  // moving the extra again leaves nothing behind (no mode needed), to Bonus it is placed first
  assert.equal(CM.check(s, id, 'Bonus', ''), ''); CM.move(s, id, 'Bonus', '', 'established');
  assert.equal(s.week.bonus[0].id, id); assert.equal(s.week.bonus[0].slot, 'Bonus'); assert.ok(!s.week.bonus[0].addedBonus); assert.equal(day(s, 'Monday').length, mon0); assert.equal(s.week.scenarios.length, n0);
  // ...and from Bonus onto a day
  CM.move(s, id, 'Friday', '', ''); assert.equal(day(s, 'Friday')[0].id, id); assert.equal(s.week.bonus.length, 0);
}
{ // delete: the old spot is gone
  const s = mk(), card = day(s, 'Wednesday')[1], id = card.id, n0 = day(s, 'Wednesday').length;
  CM.move(s, id, 'Sunday', 'delete', ''); assert.equal(day(s, 'Wednesday').length, n0 - 1); assert.ok(!day(s, 'Wednesday').some(c => c.blankSlot)); assert.equal(day(s, 'Sunday')[0].id, id);
  // two cards moved to the same day: the last one moved is on top
  const other = day(s, 'Thursday')[0].id; CM.move(s, other, 'Sunday', 'reset', ''); assert.deepEqual(day(s, 'Sunday').slice(0, 2).map(c => c.id), [other, id]);
  assert.deepEqual(day(s, 'Sunday').filter(c => c.addedBonus).map(c => c.slot), ['Scenario 4', 'Scenario 5'], 'extras numbered after the day\'s own cards');
}
{ // refused: NTR cards, empty slots, missing cards; nothing changes when refused
  const s = mk(); if (s.week.ntr[0]) assert.match(CM.check(s, s.week.ntr[0].id, 'Monday', 'reset'), /NTR/);
  const c = day(s, 'Monday')[0]; CM.move(s, c.id, 'Tuesday', 'reset', ''); const blank = day(s, 'Monday').find(x => x.blankSlot);
  assert.match(CM.check(s, blank.id, 'Tuesday', 'reset'), /empty slot/); assert.match(CM.check(s, 'zzz', 'Tuesday', 'reset'), /no longer/);
  const before = JSON.stringify(s); assert.throws(() => CM.move(s, blank.id, 'Tuesday', 'reset', '')); assert.equal(JSON.stringify(s), before);
}
console.log('Card move self-test passed: reset or delete the old spot, top of the destination, Bonus both ways, refusals.');
