// Greeting rows read plainly: short fragments are joined, label lead-ins come off, comment-only lines start unticked. Rule based, no AI.
'use strict';
const assert = require('assert');
const GP = require('../renderer/greetingplan.js');
const card = {id: 'c1', fields: {
  'The Setup': 'You were together for two years, and it ended eight months ago. The thing that ended it was physical: she slept with Andrew Collins. She told you herself. The pressure behind it was real and it was hers: she was lonely and you were never home. She has never once claimed that made it okay. What happened, happened, and she owns it. That is the whole reason you still see her. He is gone. Not circling. Not waiting. Just gone. You still have keys. She is home.',
  'User Interaction Hook': 'She does not sit down. She is waiting for you to say something, and she has no idea what you are going to say.'}};
const beats = GP.splitBeats(card.fields['The Setup']);
assert.ok(beats.some(b => b.startsWith('He is gone. Not circling. Not waiting. Just gone.')), 'fragments join: ' + JSON.stringify(beats));
assert.ok(beats.some(b => b.endsWith('You still have keys. She is home.')), 'keys/home join');
assert.ok(beats.every(b => card.fields['The Setup'].includes(b)), 'every row stays an exact piece of the card');
assert.strictEqual(GP.splitBeats('"No." She waits.').length, 2, 'speech is not merged into narration');
const plan = GP.create(card), by = t => plan.items.find(i => i.text.startsWith(t));
assert.strictEqual(by('The thing that ended it was physical').edited, 'She slept with Andrew Collins.');
assert.strictEqual(by('The pressure behind it').edited, 'She was lonely and you were never home.');
for (const t of ['She has never once claimed', 'What happened, happened', 'That is the whole reason', 'She is waiting for you']) assert.ok(!by(t), t + ' is not a row');
for (const t of ['You were together', 'She told you herself', 'He is gone', 'She does not sit down']) assert.strictEqual(by(t).selected, true, t + ' stays ticked');
assert.ok(plan.items.length < 12, 'fewer rows than before: ' + plan.items.length);
// a saved plan keeps the creator's choices (Restore original must stick)
const saved = JSON.parse(JSON.stringify(plan)); delete saved.items.find(i => i.text.startsWith('The thing that ended it was physical')).edited;
const again = GP.create(card, saved);
assert.ok(!again.items.find(i => i.text.startsWith('The thing that ended it was physical')).edited, 'restored original stays restored');
assert.ok(!again.items.find(i => i.text.startsWith('What happened')), 'a saved plan does not bring the comment line back');
GP.validate(card, saved);
// what goes to the writer uses the plain wording and leaves out the unticked lines
const sent = GP.fullCardText(card, plan, {greeting: true});
assert.ok(sent.includes('She slept with Andrew Collins.') && !sent.includes('physical:') && !sent.includes('owns it'), sent);
console.log('greeting plain-wording self-test passed (' + plan.items.length + ' rows)');
// the screenshot case: a plan saved earlier (old rows, nothing ticked, no plain mark) reopens with the plain wording, once
const old = {version: 2, cardId: 'c1', sourceHash: 'stale', notes: 'keep me', items: [
  {id: 'x1', section: 'setup', field: 'The Setup', ordinal: 1, text: 'The thing that ended it was physical: she slept with Andrew Collins, a man she met at the shop where she worked.', selected: false},
  {id: 'x2', section: 'setup', field: 'The Setup', ordinal: 2, text: 'She told you herself.', selected: true}]};
const card2 = {id: 'c1', fields: {'The Setup': old.items[0].text + ' She told you herself.'}};
const reopened = GP.create(card2, old), row = reopened.items.find(i => i.text.startsWith('The thing that ended it was physical'));
assert.strictEqual(row.edited, 'She slept with Andrew Collins, a man she met at the shop where she worked.', 'saved plan row is made plain: ' + row.edited);
assert.strictEqual(reopened.notes, 'keep me'); assert.strictEqual(reopened.plain, 1);
delete row.edited; const second = GP.create(card2, reopened);
assert.ok(!second.items.find(i => i.text.startsWith('The thing that ended it was physical')).edited, 'after the first open, Restore original sticks');
console.log('saved-plan case passed');
