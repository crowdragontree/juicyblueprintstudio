// Self-test of the Google Drive backup client (lib/gscript.js) against an in-memory copy of the Google script. No network.
const assert = require('assert'), path = require('path'), fs = require('fs'), os = require('os');
const GS = require(path.join(__dirname, '..', 'lib', 'gscript.js'));
const URL = 'https://script.google.com/macros/s/' + 'A'.repeat(40) + '/exec';
function receiver(opts = {}) {
  const boxes = new Map(), log = []; let calls = 0;
  const fetchFn = async (u, init) => {
    calls++; const r = JSON.parse(init.body); log.push(r.action + (r.name ? ' ' + r.name : ''));
    if (opts.fail && opts.fail(r, calls)) { const e = new TypeError('terminated'); throw e; }
    if (opts.hang && opts.hang(r, calls)) await new Promise((_, rej) => init.signal.addEventListener('abort', () => rej(new Error('aborted'))));
    const f = boxes.get(r.box) || boxes.set(r.box, new Map()).get(r.box); let out = {ok: true};
    if (r.action === 'put') f.set(r.name, Buffer.from(r.data, 'base64'));
    else if (r.action === 'list') out.files = [...f.entries()].map(([name, b]) => ({name, size: b.length}));
    else if (r.action === 'get') f.has(r.name) ? out.data = f.get(r.name).toString('base64') : out = {ok: false, error: 'not found'};
    else if (r.action === 'delete') f.delete(r.name);
    return {status: 200, text: async () => JSON.stringify(out)};
  };
  return {fetchFn, boxes, log, calls: () => calls};
}
(async () => {
  const stamp = '2026-10-26_1155', name = stamp + '.jbsbackup.gz';
  // 1. a small backup stays one file; a big one goes up in parts and comes back identical
  { const R = receiver(), gs = GS.create({fetchFn: R.fetchFn, chunk: 1000, pause: async () => {}});
    await gs.put(URL, 'jbs-1', name, Buffer.alloc(900, 7)); assert.deepEqual([...R.boxes.get('jbs-1').keys()], [name]);
    const big = Buffer.from(Array.from({length: 4500}, (_, i) => i % 251)), seen = [];
    await gs.put(URL, 'jbs-1', '2026-10-27_0900.jbsbackup.gz', big, {progress: p => seen.push(p.done + '/' + p.total)});
    assert.deepEqual(seen, ['0/5', '1/5', '2/5', '3/5', '4/5', '5/5']);
    const list = await gs.list(URL, 'jbs-1'); assert.deepEqual(list.map(x => x.name + ':' + x.parts), ['2026-10-27_0900:5', stamp + ':1']);
    assert.ok((await gs.get(URL, 'jbs-1', '2026-10-27_0900')).equals(big));
    await gs.remove(URL, 'jbs-1', '2026-10-27_0900'); assert.deepEqual([...R.boxes.get('jbs-1').keys()], [name]);
  }
  // 2. Google drops the connection in the middle: that part is sent again and the backup completes
  { let dropped = 0; const R = receiver({fail: (r, n) => r.action === 'put' && /p002of/.test(r.name) && dropped++ < 2}), retries = [];
    const gs = GS.create({fetchFn: R.fetchFn, chunk: 1000, pause: async () => {}}), big = Buffer.alloc(3500, 9);
    await gs.put(URL, 'b', name, big, {retry: (a, t) => retries.push(a + '/' + t)}); assert.deepEqual(retries, ['2/3', '3/3']);
    assert.ok((await gs.get(URL, 'b', stamp)).equals(big));
  }
  // 3. it keeps failing: a clear message, and the half-finished upload never shows up as a backup
  { const R = receiver({fail: r => r.action === 'put' && /p003of/.test(r.name)}), gs = GS.create({fetchFn: R.fetchFn, chunk: 1000, pause: async () => {}});
    await assert.rejects(gs.put(URL, 'c', name, Buffer.alloc(3500, 1)), e => /closed the connection/.test(e.message) && /Tried 3 times/.test(e.message));
    assert.deepEqual(await gs.list(URL, 'c'), []);
    await gs.clean(URL, 'c', 'other'); assert.equal(R.boxes.get('c').size, 0);
  }
  // 4. no answer at all: it gives up after the time limit instead of hanging
  { const R = receiver({hang: () => true}), gs = GS.create({fetchFn: R.fetchFn, timeoutMs: 40, tries: 2, pause: async () => {}});
    await assert.rejects(gs.put(URL, 'd', name, Buffer.alloc(10)), e => /did not answer within/.test(e.message));
  }
  // 5. a script error that is not a passing one is not repeated
  { let n = 0; const gs = GS.create({fetchFn: async () => { n++; return {status: 200, text: async () => JSON.stringify({ok: false, error: 'Exception: no permission'})}; }, pause: async () => {}});
    await assert.rejects(gs.ping(URL, 'e'), /no permission/); assert.equal(n, 1);
  }
  // 6. pack and unpack still round-trip
  { const d = fs.mkdtempSync(path.join(os.tmpdir(), 'gsx-')), f = path.join(d, 'a.json'); fs.writeFileSync(f, '{"x":1}');
    const out = path.join(d, 'out'); assert.equal(GS.unpack(GS.pack([{rel: 'a.json', full: f}]), out), 1); assert.equal(fs.readFileSync(path.join(out, 'a.json'), 'utf8'), '{"x":1}'); fs.rmSync(d, {recursive: true, force: true}); }
  console.log('Google Drive backup self-test passed: parts, retries, time limit, clean-up.');
})().catch(e => { console.error(e); process.exit(1); });
