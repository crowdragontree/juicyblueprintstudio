// Her hands are always empty and never mentioned in the image keywords (Personal edition).
const assert = require('assert'), path = require('path');
const IS = require(path.join(__dirname, '..', 'renderer', 'imagestyle.js'));
if (!IS.rulesOn) { console.log('Image hands self-test skipped: the Shareable edition adds no image rules.'); process.exit(0); }
const r = IS.stripHands('dark blue work polo, deep open V-neck, black tool belt, wrench in hand, casual wear');
assert.equal(r.text, 'dark blue work polo, deep open V-neck, black tool belt, casual wear'); assert.deepEqual(r.removed, ['wrench in hand']);
for (const bad of ['holding a cup', 'empty hands', 'bare hands', 'hands free', 'hands on hips', 'carrying a bag', 'fists clenched', 'gripping a rail', 'handheld lantern'])
  assert.equal(IS.stripHands('silk blouse, ' + bad).text, 'silk blouse', bad);
for (const ok of ['hand-stitched lace top', 'leather handbag', 'fingerless gloves', 'diamond ring', 'handkerchief collar'])
  assert.equal(IS.stripHands(ok).text, ok, ok);
assert.ok(IS.issues('wrench in hand', 'clothing').some(x => /hands/.test(x.why)));
assert.ok(/NEVER mentioned/.test(IS.RULE) && /empty hands/.test(IS.RULE), 'the AI is told, including not to say "empty hands"');
console.log('Image hands self-test passed.');
