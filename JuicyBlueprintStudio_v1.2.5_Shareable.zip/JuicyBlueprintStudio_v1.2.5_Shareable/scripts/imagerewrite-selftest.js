'use strict';
/* "Rewrite Image Generation with AI" must not crash after the AI answers: Image Generation has no character limit, and the length checks that follow
   the answer used to read that missing limit ("Cannot read properties of undefined (reading 'max')"). The AI is replaced by a fixed answer here. */
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const root = path.join(__dirname, '..');
const BT = require(path.join(root, 'lib', 'botTemplates')), {AiBotWriter, loadCore, parseBlocks} = require(path.join(root, 'lib', 'aiBotWriter.js'));
const {C} = loadCore(path.join(root, 'renderer'));
const dir = path.join(root, 'resources', 'bot-templates');
const files = fs.readdirSync(dir).filter(f => f.endsWith('.txt'));
const ANSWER = `@@image.appearance\nwet cloudy riverglass plates, black sclera, pale green slit pupils, black wet wolf ears, black river weed hair, inhuman creature\n\n@@image.clothing\nshredded open-front V-neck work shirt, torn sleeves, frayed shorts\n\n@@image.action\nclose-up shot, flooded department store ground floor, black still water to the ankle`;
(async () => {
  if (!files.length) { console.log('Image rewrite self-test skipped: this edition ships no bot templates.'); return; }
  let tried = 0;
  for (const f of files) {
    const spec = BT.parseTemplate(fs.readFileSync(path.join(dir, f), 'utf8'), f);
    if (!spec.image || !spec.image.present) continue;
    spec.id = spec.id || f;
    const card = {id: 'c1', series: 'SCP Series', sceneName: 'SCP-024: The Standing Flood', primaryCharacter: 'SCP-024', fields: {'The Setup': 'The upper floors of a dead department store are dry.'}};
    const w = new AiBotWriter({relay: {}, rendererDir: path.join(root, 'renderer'), jobsDir: fs.mkdtempSync(path.join(os.tmpdir(), 'jbs-')), store: {}, templates: () => [spec], engineNotes: () => '', send() {}, storyFor: () => null});
    w._ask = async (job, step, messages, opts, parse) => { step.state = 'done'; return parse(ANSWER); };
    const v = C.blank(spec); v.names[1] = 'SCP-024'; v.sourceId = 'c1';
    let r; try { r = await w.rewriteSection({templateId: spec.id, section: 'image', values: v, notes: '', card}); }
    catch (e) { assert.fail(`${f}: ${e.message}`); }
    assert.strictEqual(r.kind, 'section');
    assert(/flooded department store/.test(r.values.img.action) && /shredded/.test(r.values.img.clothing) && /riverglass/.test(r.values.img.appearance), f + ': the proposal carries the AI text');
    tried++;
  }
  assert(tried > 0, 'no template with an Image Generation section was tried');
  console.log(`Image rewrite self-test passed: ${tried} templates, no crash after the AI answers.`);
})().catch(e => { console.error(e); process.exit(1); });
