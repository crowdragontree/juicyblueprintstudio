'use strict';
// LanguageTool support: the zip reader, the install/remove flow, the local server round trip and the conversion into the app's hit shape.
// It uses a stand-in server and a made-up zip, so it needs neither the internet nor Java. (Run with --mock <port> it IS the stand-in server.)
const http = require('http');
if (process.argv[2] === '--mock') {
  const port = +process.argv[3];
  http.createServer((req, res) => {
    let body = ''; req.on('data', c => { body += c; });
    req.on('end', () => {
      res.setHeader('Content-Type', 'application/json');
      if (req.url === '/v2/languages') return res.end('[{"name":"English (US)","code":"en","longCode":"en-US"}]');
      const text = new URLSearchParams(body).get('text') || '', matches = [];
      let i = text.indexOf('dont'); if (i >= 0) matches.push({message: "Possible spelling mistake found.", shortMessage: 'Spelling', offset: i, length: 4, replacements: [{value: "don't"}], rule: {id: 'MORFOLOGIK_RULE_EN_US', issueType: 'misspelling', category: {id: 'TYPOS'}}});
      i = text.indexOf('This are'); if (i >= 0) matches.push({message: 'The verb does not agree.', offset: i, length: 8, replacements: [{value: 'This is'}, {value: 'These are'}], rule: {id: 'THIS_NNS', issueType: 'grammar', category: {id: 'GRAMMAR'}}});
      i = text.indexOf('very good'); if (i >= 0) matches.push({message: 'Consider a stronger word.', offset: i, length: 9, replacements: [{value: 'excellent'}], rule: {id: 'VERY_ADJ', issueType: 'style', category: {id: 'STYLE'}}});
      res.end(JSON.stringify({matches}));
    });
  }).listen(port, '127.0.0.1');
  return;
}
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path'), zlib = require('zlib'), {spawn} = require('child_process');
const LT = require('../lib/languagetool'), CL = require('../renderer/languagetool.js'), TC = require('../renderer/textcheck.js');

// ---- a tiny zip writer (deflate), only for the test
const T = new Int32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c; });
const crc = b => { let c = -1; for (const x of b) c = T[(c ^ x) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; };
function makeZip(files) {
  const locals = [], central = []; let off = 0;
  for (const [name, content] of Object.entries(files)) {
    const nb = Buffer.from(name), data = Buffer.from(content), comp = name.endsWith('/') ? Buffer.alloc(0) : zlib.deflateRawSync(data), method = comp.length ? 8 : 0;
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(method, 8); h.writeUInt32LE(crc(data), 14); h.writeUInt32LE(comp.length, 18); h.writeUInt32LE(data.length, 22); h.writeUInt16LE(nb.length, 26);
    locals.push(h, nb, comp);
    const c = Buffer.alloc(46); c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(method, 10); c.writeUInt32LE(crc(data), 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(data.length, 24); c.writeUInt16LE(nb.length, 28); c.writeUInt32LE(off, 42);
    central.push(c, nb); off += 30 + nb.length + comp.length;
  }
  const cd = Buffer.concat(central), end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(Object.keys(files).length, 8); end.writeUInt16LE(Object.keys(files).length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...locals, cd, end]);
}

(async () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'lt-test-'));
  try {
    // ---- zip reader: strips the top folder, keeps contents, refuses a path that escapes
    const good = path.join(tmp, 'good.zip'); fs.writeFileSync(good, makeZip({'LanguageTool-9.9/': '', 'LanguageTool-9.9/languagetool-server.jar': 'JAR'.repeat(5000), 'LanguageTool-9.9/libs/a.jar': 'A'}));
    LT.unzip(good, path.join(tmp, 'out'), {strip: 1});
    assert.equal(fs.readFileSync(path.join(tmp, 'out', 'languagetool-server.jar'), 'utf8').length, 15000); assert.equal(fs.readFileSync(path.join(tmp, 'out', 'libs', 'a.jar'), 'utf8'), 'A');
    const evil = path.join(tmp, 'evil.zip'); fs.writeFileSync(evil, makeZip({'x/../../escape.txt': 'no'}));
    assert.throws(() => LT.unzip(evil, path.join(tmp, 'out2'), {strip: 0}), /outside/); assert.ok(!fs.existsSync(path.join(tmp, 'escape.txt')));
    assert.throws(() => LT.unzip(path.join(tmp, 'good.zip.nope'), path.join(tmp, 'o3')), /ENOENT/); fs.writeFileSync(path.join(tmp, 'junk.zip'), 'not a zip'); assert.throws(() => LT.unzip(path.join(tmp, 'junk.zip'), path.join(tmp, 'o4')), /not a zip/);
    assert.equal(LT.parseMajor('openjdk version "17.0.9" 2023'), 17); assert.equal(LT.parseMajor('java version "1.8.0_301"'), 8); assert.equal(LT.parseMajor('nothing'), 0);

    // ---- install -> status -> check -> disable -> remove (with the stand-in download and the stand-in server)
    const app = path.join(tmp, 'app'), data = path.join(tmp, 'data'); fs.mkdirSync(app); fs.mkdirSync(data);
    const m = LT.create({appDir: app, userData: data, urls: {lt: 'file://' + good.replace(/\\/g, '/')}, java: 'java', launcher: (port) => spawn(process.execPath, [__filename, '--mock', String(port)], {stdio: 'ignore'})});
    assert.equal(m.status().installed, false); assert.equal((await m.check('hello')).ok, false);
    // not a LanguageTool zip -> refused, nothing left behind
    const bad = path.join(tmp, 'bad.zip'); fs.writeFileSync(bad, makeZip({'Other/readme.txt': 'x'}));
    const mb = LT.create({appDir: app, userData: data, urls: {lt: 'file://' + bad}, java: 'java', launcher: () => null});
    await assert.rejects(mb.install(), /not LanguageTool/); assert.equal(mb.status().installed, false);
    const seen = []; const st = await m.install(p => seen.push(p.phase));
    assert.equal(st.installed, true); assert.ok(seen.includes('done') && seen.includes('unpack')); assert.ok(fs.existsSync(path.join(app, 'languagetool', 'lt', 'languagetool-server.jar')), 'installed inside the app folder');
    assert.ok(!fs.existsSync(path.join(app, 'languagetool', '_download')), 'download scratch removed');
    const r = await m.check("I dont know. This are good and very good.");
    assert.equal(r.ok, true, r.error); assert.equal(r.matches.length, 3); assert.equal(r.matches[1].replacements.length, 2); assert.equal(m.status().running, true);
    m.setEnabled(false); assert.equal((await m.check('x')).ok, false); assert.equal(m.status().running, false); m.setEnabled(true);
    assert.equal((await m.check('I dont know')).ok, true);
    await m.remove(); assert.equal(m.status().installed, false); assert.ok(!fs.existsSync(path.join(app, 'languagetool')));
    // an app folder that cannot be written -> the data folder is used
    const ro = path.join(tmp, 'ro-file'); fs.writeFileSync(ro, 'a file, so a folder cannot be made inside it');
    const m2 = LT.create({appDir: ro, userData: data, urls: {lt: 'file://' + good.replace(/\\/g, '/')}, java: 'java', launcher: (port) => spawn(process.execPath, [__filename, '--mock', String(port)], {stdio: 'ignore'})});
    await m2.install(); assert.ok(fs.existsSync(path.join(data, 'languagetool', 'lt', 'languagetool-server.jar')), 'fell back to the data folder'); await m2.remove();

    // ---- conversion into hits, merged with the built-in check
    const text = "I dont know. This are good and very good. {{char}} dont.";
    const raw = [{offset: 2, length: 4, message: 'Possible spelling mistake found.', replacements: ["don't"], rule: 'MORFOLOGIK_RULE_EN_US', category: 'TYPOS', type: 'misspelling'}, {offset: 13, length: 8, message: 'The verb does not agree.', replacements: ['This is', 'These are'], rule: 'THIS_NNS', category: 'GRAMMAR'}, {offset: 31, length: 9, message: 'Consider a stronger word.', replacements: ['excellent'], rule: 'VERY_ADJ', category: 'STYLE'}, {offset: 42, length: 8, message: 'masked', replacements: ['x'], rule: 'R', category: 'GRAMMAR'}];
    const hits = CL.convert(text, raw, TC.mask(text));
    assert.equal(hits.length, 3, 'the hit inside {{char}} is dropped'); assert.equal(hits[0].kind, 'spelling'); assert.equal(hits[1].kind, 'grammar'); assert.deepEqual(hits[1].suggest, ['This is', 'These are']); assert.equal(hits[2].kind, 'wording'); assert.equal(hits[2].fix, 'excellent'); assert.equal(hits[2].soft, true);
    TC.setProvider(t => t === text ? hits : null);
    const merged = TC.check(text);
    const sp = merged.find(h => h.text === 'dont'); assert.ok(sp && sp.kind === 'spelling' && sp.suggest.includes("don't"), 'LanguageTool replacement joins the built-in spelling hit');
    assert.ok(merged.some(h => h.text === 'This are' && h.src === 'languagetool'), 'LanguageTool grammar hit is added');
    assert.ok(merged.some(h => h.text === 'very good' && h.kind === 'wording'), 'style hint is added');
    TC.setProvider(null); const plain = TC.check(text); assert.ok(!plain.some(h => h.src === 'languagetool'), 'without the provider: exactly the built-in check');
    // a spelling hit the built-in list did NOT flag is not added (names stay safe)
    TC.setProvider(() => [{start: 0, end: 1, kind: 'spelling', msg: 'x', suggest: ['y'], src: 'languagetool'}]); assert.ok(!TC.check('Hannah went home.').some(h => h.src === 'languagetool')); TC.setProvider(null);
    console.log('languagetool self-test passed');
  } catch (e) { console.error(e); process.exitCode = 1; }
  finally { fs.rmSync(tmp, {recursive: true, force: true}); process.exit(process.exitCode || 0); }
})();
