'use strict';
// Greeting passages: the reply is split into exactly the number of passages the template asks for, whatever the number of blank-line blocks (9 or 10 blocks for 6 passages used to give 5),
// and a numbered reply ([1] ... [6]) keeps each passage whole even with blank lines inside it.
const fs = require('fs'), path = require('path'), assert = require('assert');
const w = {}; new Function('window', fs.readFileSync(path.join(__dirname, '..', 'renderer', 'storybrief.js'), 'utf8'))(w);
const SB = w.StoryBrief, spec = {greeting: {count: 6}};
for (let n = 6; n <= 24; n++) assert.strictEqual(SB.parse('GREETING:\n' + Array.from({length: n}, (_, i) => `*Block ${i + 1}.*`).join('\n\n'), spec).paras.length, 6, `${n} blocks give 6 passages`);
const marked = [1, 2, 3, 4, 5, 6].map(i => `[${i}]\n*a${i}*\n\n"q${i}"\n\n*b${i}*`).join('\n\n'), r = SB.parse('GREETING:\n' + marked, spec).paras;
assert.strictEqual(r.length, 6); assert.ok(r[2].includes('a3') && r[2].includes('q3') && r[2].includes('b3') && !r[2].includes('a4') && !r[2].includes('[3]'), 'a numbered passage keeps its own parts');
assert.strictEqual(SB.parse('GREETING:\n*One.*\n\n*Two.*', spec).paras.length, 2, 'fewer blocks than passages is still reported as short');
// the request asks for the numbered layout
const src = fs.readFileSync(path.join(__dirname, '..', 'lib', 'aiBotWriter.js'), 'utf8');
assert.ok((src.match(/PASSAGE_MARKS\(spec\.greeting\.count\)/g) || []).length === 2, 'both Greeting requests ask for numbered passages');
console.log('Passages self-test passed: exactly the template\'s number of passages for any block count; numbered passages stay whole.');
