'use strict';
/* PolicyWeights, the community author's rules: every weight is between 0 and 0.8; a template's own PolicyWeights line gets numbers (never words) from the
 * auto-writer, is held at 0.8 or less, and carries the guardrail line. */
const fs = require('fs'), vm = require('vm'), path = require('path'), assert = require('assert');
const PW = require('../renderer/policyweights.js');
const win = {}; vm.runInNewContext(fs.readFileSync(path.join(__dirname, '..', 'renderer', 'autofill.js'), 'utf8'), {window: win, console});
const A = win.BBAuto;

// every weight on the author's lists is at 0.8 or less, including the ones she printed at .9 and 1
for (const cat of PW.CATS) for (const e of PW.poolText([cat], 'x', 500).split('\n').filter(l => /: [\d.]+/.test(l))) {
  const v = parseFloat(/: ([\d.]+)/.exec(e)[1]); assert(v <= 0.8, `${cat}: ${e} is above 0.8`);
}
assert(PW.info('PlayerAgency').value <= 0.8 && PW.info('NurturingDrive').value <= 0.8, 'listed values are held at 0.8');
for (const w of ['Tease: 0.9', 'PlayerAgency: 1', 'Dread: .81']) assert(PW.check({weights: w}, {}).errors.some(e => /never above 0\.8/.test(e)), `${w} is refused`);
assert(!PW.check({weights: 'Dread: .7; Tease: 0.8'}, {}).errors.length, '0.8 itself is fine');
assert(PW.repair([{name: 'Dread', value: 0.95}, {name: 'Tease', value: 1}], {}).items.every(i => i.value <= 0.8), 'the AI\'s weights are brought down to 0.8');

// the auto-writer: number boxes get numbers
const spec = {id: 'x', name: 'Misunderstanding', tags: {archetypes: []}, rules: {}};
for (const arch of ['', 'Dandere', 'Kuudere', 'Tsundere', 'Deredere', 'Yandere']) {
  const C = A.context(spec, {names: {1: 'Anna Whitaker', 2: 'James Dalton'}, header: {}, f: {}}, {fields: {'The Setup': 'She works late and you find a letter.'}}); if (arch) C.arch = arch;
  for (const label of ['Tease', 'Reassure', 'EscalateTouch', 'ExplicitLine', 'CheckConsent', 'Formality', 'Something else']) {
    const r = A.writeField({key: 'k', mode: 'field', label, hint: '0.0-1.0', group: '', block: '', ctx: label + ': '}, C, new Set());
    assert(r && r.single && /^0?\.\d+$/.test(r.text) && parseFloat(r.text) <= 0.8, `${arch || 'default'} ${label}: "${r && r.text}" is not a number up to 0.8`);
  }
}

// a template's own PolicyWeights line
const body = 'Scenario: { x }\nAnna PolicyWeights { Tease: 0.9; Reassure: 1; EscalateTouch: 0.3; ExplicitLine: .2; CheckConsent: 0.85; Formality: 0.5 }\nSystem Rules {\n[USER AGENCY HARD LOCK]\nNever.\n[END USER AGENCY HARD LOCK]\n[CANON LOCK]: x\n}';
const out = PW.settleOwn(body, 'Anna', ['loyal']);
assert(/Tease: 0\.8; Reassure: 0\.8; EscalateTouch: 0\.3; ExplicitLine: \.2; CheckConsent: 0\.8; Formality: 0\.5/.test(out), 'numbers above 0.8 are brought down: ' + out.split('\n')[1]);
assert((out.match(/\[POLICYWEIGHT GUARDRAILS\]/g) || []).length === 1, 'one guardrail line');
assert(out.indexOf('[END USER AGENCY HARD LOCK]') < out.indexOf('[POLICYWEIGHT GUARDRAILS]') && out.indexOf('[POLICYWEIGHT GUARDRAILS]') < out.indexOf('[CANON LOCK]'), 'the guardrails sit after the User Agency lock, like the app\'s own block');
assert(/Tease, Reassure, EscalateTouch, ExplicitLine, CheckConsent, Formality are tone and pacing dials only/.test(out) && /stays loyal/.test(out), 'the dials are named in the guardrail, with the lane rule');
assert.strictEqual(PW.settleOwn(out, 'Anna', ['loyal']), out, 'running it twice changes nothing');
const empty = 'Anna PolicyWeights { Tease: [0.0-0.8]; Reassure: [0.0-0.8] }\nSystem Rules {';
assert.strictEqual(PW.settleOwn(empty, 'Anna', []), empty, 'empty boxes are left alone and get no guardrail yet');
assert.strictEqual(PW.settleOwn('no weights here', 'Anna', []), 'no weights here');
// a saved draft or Scenario that already holds words in the number boxes is repaired
const ph = {mode: 'field', label: 'Tease', hint: '0.0-1.0'};
for (const t of ['no attraction.', 'devoted, quick to act.', "You're smiling.", '0.9', '1', '-0.2']) assert(A.badNumberBox(ph, t), `"${t}" is recognised as wrong`);
for (const t of ['0.4', '.3', '0', '0.8', '']) assert(!A.badNumberBox(ph, t), `"${t}" is left alone`);
assert(!A.badNumberBox({hint: 'Two to three sentences: who the characters are'}, 'anything'), 'only number boxes are touched');
const wordy = 'Scenario: { holds a grudge }\nAnna Whitaker PolicyWeights { Tease: no attraction.; Reassure:optimistic despite setbacks.; EscalateTouch: devoted, quick to act.; ExplicitLine: You\'re smiling.; CheckConsent: devoted, quick to act.; Formality: openly warm, cheerful. }\nSystem Rules {\n[USER AGENCY HARD LOCK]\nx\n[END USER AGENCY HARD LOCK]\n}';
const mended = PW.settleOwn(wordy, 'Anna Whitaker', []);
assert(/PolicyWeights \{ Tease: 0\.4; Reassure:0\.6; EscalateTouch: 0\.3; ExplicitLine: 0\.2; CheckConsent: 0\.8; Formality: 0\.5 \}/.test(mended), 'words in the line become numbers: ' + mended.split('\n')[1]);
assert(/\[POLICYWEIGHT GUARDRAILS\]/.test(mended), 'and the guardrails go in');
// nothing that tells the AI or the user to use the full 0 to 1 range is left
const rd = f => fs.readFileSync(path.join(__dirname, '..', f), 'utf8');
for (const f of ['lib/aiBotWriter.js', 'renderer/trackers.js', 'renderer/app.js', 'resources/rules/weekly_blueprint_rules.txt'])
  if (fs.existsSync(path.join(__dirname, '..', f))) assert(!/PolicyWeights are numbers from 0 to 1|8 weights from 0 to 1|each 0 to 1,|0 to 1\)\. Edit freely/.test(rd(f)), `${f} still says 0 to 1`);
// the Scenario's opening box is the card's story, never a trait line such as "holds a grudge"
{
  const C = A.context(spec, {names: {1: 'Anna Whitaker', 2: 'James Dalton'}, header: {}, f: {}}, {fields: {'The Setup': 'You find a letter in her bag. She is at work late again.', "Character's Relationship to You": '{{user}}\'s wife'}});
  for (const hint of ['Two to three sentences: who {{user}} and [Name] are, the misleading situation involving [Name2] and what {{user}} has seen, the pressure that keeps her from explaining, and the live situation the bot starts in. Never decide {{user}}\'s feelings or choices.',
    'Two to three sentences: who {{user}} and [Name] are, where the relationship stands today, the source-defined emotional betrayal with [Name2] in plain non-graphic words, and the live situation the bot starts in.']) {
    const r = A.writeField({key: 'k', mode: 'field', label: 'Scenario', hint, group: '', block: '', ctx: 'Scenario: { '}, C, new Set());
    assert(r && r.single && /^\{\{user\}\} is /.test(r.text) && /letter in her bag/.test(r.text) && r.text.split(/[.!?]\s/).length <= 4, 'the opening is the card\'s story: ' + (r && r.text));
    assert(!/grudge|worried out loud|sharp-tongued|flirts by/.test(r.text), 'no trait line in the opening: ' + r.text);
  }
}
{
  const open = {hint: 'Two to three sentences: who {{user}} and [Name] are, the misleading situation'};
  assert(A.staleOpening(open, 'holds a grudge', true), 'an auto-written trait line in the opening box is replaced');
  assert(!A.staleOpening(open, 'holds a grudge', false), 'text you typed or the AI wrote is never replaced');
  assert(!A.staleOpening(open, '{{user}} is her husband. You find a letter.', true), 'a story opening is kept');
  assert(!A.staleOpening({hint: 'something else'}, 'holds a grudge', true), 'other boxes are not touched');
}
console.log('PolicyWeights rules self-test passed: every weight 0 to 0.8, number boxes get numbers, a template\'s own line is capped and carries the guardrails.');
