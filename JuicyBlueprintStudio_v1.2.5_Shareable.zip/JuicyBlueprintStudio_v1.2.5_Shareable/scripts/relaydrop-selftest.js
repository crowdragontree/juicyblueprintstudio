// A connection cut in the middle of a reply is retried from what already arrived, and the message says WHY (not just "terminated"): the network's reason, seconds in, bytes and characters received.
'use strict';
const assert = require('assert'), http = require('http'), fs = require('fs'), os = require('os'), path = require('path');
process.env.JBS_RETRY_SCALE = '0.001';
const {Relay} = require('../lib/aiRelay');
const chunk = t => `data: ${JSON.stringify({choices: [{delta: {content: t}}]})}\n\n`;
let hits = 0;
const srv = http.createServer((req, res) => {
  req.resume(); req.on('end', () => {
    hits++; res.writeHead(200, {'content-type': 'text/event-stream'});
    if (hits === 1) { res.write(chunk('She stands in the doorway and ')); setTimeout(() => req.socket.destroy(), 80); return; }   // the connection dies mid-reply
    res.write(chunk('does not look at you.')); res.write('data: [DONE]\n\n'); res.end();
  });
});
srv.listen(0, '127.0.0.1', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jbs-drop-')); fs.writeFileSync(path.join(dir, 'ai.json'), JSON.stringify({relay: `http://127.0.0.1:${srv.address().port}`, token: 't'}));
  const relay = new Relay({appDir: dir, userData: dir}), events = [];
  try {
    const r = await relay.write([{role: 'user', content: 'hi'}], {onEvent: e => events.push(e)});
    assert.ok(/doorway/.test(r.text) && /does not look at you/.test(r.text), 'kept what arrived and carried on: ' + r.text);
    assert.strictEqual(hits, 2, 'one retry');
    assert.ok(events.length === 1 && /connection to the relay was cut/.test(events[0]) && /\d+ s into the reply/.test(events[0]) && /\d+ bytes \(\d+ characters\) received/.test(events[0]) && !/^terminated/.test(events[0]), 'the message says why: ' + events[0]);
    const log = fs.readFileSync(path.join(dir, 'ai-connection.log'), 'utf8'); assert.ok(/try 1/.test(log) && /characters/.test(log), 'written to ai-connection.log: ' + log);
    console.log('Relay drop self-test passed:', events[0]);
  } catch (e) { console.error(e); process.exitCode = 1; } finally { srv.close(); process.exit(process.exitCode || 0); }
});
