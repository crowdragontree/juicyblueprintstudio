#!/usr/bin/env node
'use strict';
/* One source, three places.
 *
 * The Introduction Designer lives in three places: Juicy Blueprint Studio, the stand-alone JuicyChat Creator Tool
 * (github.com/crowdragontree/webp-maker) and the single-file web page on GitHub Pages. They share the SAME designer files;
 * only the small "host" that saves templates and copies code differs:
 *
 *   shared (edit these here, in Studio):  core.js layout.js looks.js simple.js app.js style.css index.html  + tests/
 *   Studio host        host.js + preload.js                 (stay in Studio)
 *   Creator Tool host  creator-bridge.js + inline-host.js   (stay in the webp-maker repo, never overwritten)
 *   Web page host      portable-host.js                     (here; inlined into the single file)
 *
 * Usage (from the Studio folder):
 *   node scripts/sync-designer.js --repo ../webp-maker --pages ../webp-maker/docs/introduction-designer/index.html
 *   node scripts/sync-designer.js --repo ../webp-maker --pages <file> --check     (changes nothing; exits 1 when something is out of date)
 *   --repo   only the Creator Tool copy      --pages   only the single-file page      (give either or both)
 */
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const SRC = path.join(__dirname, '..', 'introduction-designer');
const SHARED = ['core.js', 'layout.js', 'looks.js', 'simple.js', 'app.js', 'style.css'];
const PAGE_SCRIPTS = ['core.js', 'layout.js', 'looks.js', 'portable-host.js', 'app.js', 'simple.js'];   // load order of the single-file page
const HOST_MARK = '<!--HOST-->';
const read = f => fs.readFileSync(path.join(SRC, f), 'utf8');
const testFiles = () => fs.readdirSync(path.join(SRC, 'tests')).filter(f => f.endsWith('.test.js')).sort();

// ---- Creator Tool repo: the shared files copied as they are, the page with its own host script ----
function repoFiles() {
  const out = new Map();
  for (const f of SHARED) out.set(f, read(f));
  if (!read('index.html').includes(HOST_MARK)) throw new Error('index.html lost its ' + HOST_MARK + ' marker.');
  out.set('index.html', read('index.html').replace(HOST_MARK, '<script src="creator-bridge.js"></script>'));
  for (const t of testFiles()) out.set('tests/' + t, fs.readFileSync(path.join(SRC, 'tests', t), 'utf8'));
  return out;
}

// ---- Single-file page: everything inline, a Content-Security-Policy that names every script by its SHA-256 ----
const sha = text => 'sha256-' + crypto.createHash('sha256').update(text, 'utf8').digest('base64');
function pageHtml() {
  let html = read('index.html');
  const css = read('style.css');
  if (/<\/style/i.test(css)) throw new Error('style.css contains </style>.');
  const scripts = PAGE_SCRIPTS.map(f => {
    const code = read(f);
    if (/<\/script/i.test(code)) throw new Error(f + ' contains </script>; it cannot be inlined.');
    return code;
  });
  const csp = `default-src 'none'; script-src ${scripts.map(s => `'${sha(s)}'`).join(' ')}; style-src 'unsafe-inline'; img-src https: data:; connect-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'`;
  html = html.replace(/<meta http-equiv="Content-Security-Policy"[^>]*>/, `<meta http-equiv="Content-Security-Policy" content="${csp}">`);
  html = html.replace('<link rel="stylesheet" href="style.css">', () => `<style>${css}</style>`);
  const tags = /<script src="[^"]+"><\/script>/g;
  if (!html.includes(HOST_MARK)) throw new Error('index.html lost its ' + HOST_MARK + ' marker.');
  html = html.replace(HOST_MARK, '');
  const first = html.search(tags);
  if (first < 0) throw new Error('index.html has no script tags.');
  html = html.replace(tags, '');
  const inline = scripts.map(code => `<script>${code}</script>`).join('\n');
  html = html.replace('</body>', () => inline + '\n</body>');
  return html;
}

// ---- writing / checking ----
function put(file, text, check, problems) {
  const have = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : null;
  if (have === text) return;
  if (check) { problems.push(file); return; }
  fs.mkdirSync(path.dirname(file), {recursive: true}); fs.writeFileSync(file, text);
  console.log('  wrote ' + file);
}
function run(argv) {
  const arg = n => { const i = argv.indexOf(n); return i >= 0 ? argv[i + 1] : null; };
  const check = argv.includes('--check'), repo = arg('--repo'), pages = arg('--pages'), problems = [];
  if (!repo && !pages) { console.error('Give --repo <webp-maker folder> and/or --pages <index.html>. See the top of this file.'); return 2; }
  if (repo) {
    const dir = path.join(path.resolve(repo), 'introduction-designer');
    if (!fs.existsSync(dir)) { console.error('Not a Creator Tool checkout (no introduction-designer folder): ' + repo); return 2; }
    for (const [name, text] of repoFiles()) put(path.join(dir, name), text, check, problems);
  }
  if (pages) put(path.resolve(pages), pageHtml(), check, problems);
  if (check) {
    if (problems.length) { console.error('Out of date (run the sync without --check):\n  ' + problems.join('\n  ')); return 1; }
    console.log('Everything is in sync.');
  } else console.log('Done.');
  return 0;
}
module.exports = {repoFiles, pageHtml, sha, SHARED, PAGE_SCRIPTS, HOST_MARK};
if (require.main === module) process.exitCode = run(process.argv.slice(2));
