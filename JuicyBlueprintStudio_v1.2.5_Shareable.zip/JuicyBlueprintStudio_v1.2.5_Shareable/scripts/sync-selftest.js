// The designer's three copies stay identical: the Creator Tool files, and the single-file page whose CSP must name every script by hash.
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path'), cp = require('child_process');
const S = require('./sync-designer.js');
const page = S.pageHtml();
const csp = page.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/)[1];
const allowed = new Set([...csp.matchAll(/'(sha256-[^']+)'/g)].map(m => m[1]));
const inline = [...page.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
assert.equal(inline.length, S.PAGE_SCRIPTS.length, 'one inline script per file');
assert.equal(allowed.size, inline.length, 'one hash per script');
for (const code of inline) assert.ok(allowed.has(S.sha(code)), 'a script is missing from the CSP');
assert.ok(!/<script[^>]*\ssrc=/i.test(page), 'no external script');
assert.ok(!/<link\b/i.test(page), 'no external stylesheet');
assert.ok(!page.includes(S.HOST_MARK), 'the host marker is replaced');
assert.ok(/default-src 'none'/.test(csp) && /connect-src 'none'/.test(csp) && !/'unsafe-eval'/.test(csp), 'strict CSP');
assert.ok(page.indexOf('introHost') < page.indexOf("IntroDesigner={"), 'the host is defined before the designer starts');
const files = S.repoFiles();
for (const f of S.SHARED) assert.ok(files.has(f), f);
const idx = files.get('index.html');
assert.ok(idx.indexOf('creator-bridge.js') > -1 && idx.indexOf('creator-bridge.js') < idx.indexOf('app.js'), 'Creator Tool host loads before app.js');
assert.ok(idx.indexOf('looks.js') < idx.indexOf('app.js') && idx.indexOf('app.js') < idx.indexOf('simple.js'), 'script order');
// a fake Creator Tool checkout: sync, then --check passes; change a file and it fails
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'sync-test-')); const out = path.join(tmp, 'page', 'index.html');
try {
  fs.mkdirSync(path.join(tmp, 'repo', 'introduction-designer'), {recursive: true});
  fs.writeFileSync(path.join(tmp, 'repo', 'introduction-designer', 'inline-host.js'), '// theirs');
  const run = (...a) => cp.spawnSync(process.execPath, [path.join(__dirname, 'sync-designer.js'), '--repo', path.join(tmp, 'repo'), '--pages', out, ...a], {encoding: 'utf8'});
  assert.equal(run().status, 0); assert.equal(run('--check').status, 0, 'in sync right after syncing');
  assert.equal(fs.readFileSync(path.join(tmp, 'repo', 'introduction-designer', 'inline-host.js'), 'utf8'), '// theirs', "the Creator Tool's own host files are never touched");
  fs.appendFileSync(path.join(tmp, 'repo', 'introduction-designer', 'core.js'), '\n// edited');
  assert.equal(run('--check').status, 1, 'an edited copy is reported');
} finally { fs.rmSync(tmp, {recursive: true, force: true}); }
console.log('Designer sync self-test passed: shared files, Creator Tool copy and single-file page (CSP hashes) agree.');
