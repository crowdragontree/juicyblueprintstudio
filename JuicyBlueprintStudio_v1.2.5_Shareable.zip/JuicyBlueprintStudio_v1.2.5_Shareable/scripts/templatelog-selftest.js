// Bot template change log: what changed when a template is updated or added, and when a built-in one changes with an app update. Plain text, no AI.
'use strict';
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
const TL = require('../lib/templateLog');
const A = ['[CRITICAL INFORMATION: Keep the total between 7,900 and 8,700 characters.]', '', '[VOICE LOCK]: Write in the present tense.', 'Never mention the weather.', '', '[ENDING RULE]: End on an open question.'].join('\n');
const B = ['[CRITICAL INFORMATION: Keep the total between 7,900 and 8,700 characters.]', '', '[VOICE LOCK]: Write in the past tense.', 'Never mention the weather.', '', '[NEW RULE]: Name the setting once.'].join('\n');
const sp = TL.split(A);
assert.deepStrictEqual(sp.map(s => s.title), ['CRITICAL INFORMATION', 'VOICE LOCK', 'ENDING RULE'], 'sections by label');
const e = TL.entries(A, B), by = k => e.filter(x => x.kind === k).map(x => x.title);
assert.deepStrictEqual(by('changed'), ['VOICE LOCK']); assert.deepStrictEqual(by('added'), ['NEW RULE']); assert.deepStrictEqual(by('removed'), ['ENDING RULE']);
const l = TL.make({file: '7._Some_Template_October_2026_v2.txt', kind: 'updated', from: 'new.txt', oldText: A, newText: B});
assert.ok(/1 section changed · 1 section added · 1 section removed/.test(l.summary), l.summary);
assert.strictEqual(l.name, '7. Some Template'); assert.ok(l.entries[0].diff.changed[0].parts.some(([op, s]) => op > 0 && /past/.test(s)), 'the changed words are marked');
assert.strictEqual(TL.make({file: 'a.txt', kind: 'updated', oldText: A, newText: A + '\n\n  '}), null, 'same wording: no log');
const sp2 = TL.make({file: 'a.txt', kind: 'updated', oldText: A, newText: A.replace('present tense.', 'present   tense.')}); assert.strictEqual(sp2, null, 'only spacing: no log');
const ad = TL.make({file: '9._New_One.txt', kind: 'added', from: '9._New_One.txt', newText: A}); assert.deepStrictEqual(ad.sections, ['CRITICAL INFORMATION', 'VOICE LOCK', 'ENDING RULE']); assert.ok(/New template: 3 sections/.test(ad.summary));
assert.ok(/VOICE LOCK/.test(TL.logText(l)) && /past/.test(TL.logText(l)), 'copyable text');
// built-in templates changed by an app update
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jbs-tl-')), ud = path.join(tmp, 'ud'), bi = path.join(tmp, 'bi'), mine = path.join(ud, 'bot-templates'); fs.mkdirSync(bi, {recursive: true}); fs.mkdirSync(mine, {recursive: true});
fs.writeFileSync(path.join(bi, '1._One.txt'), A); fs.writeFileSync(path.join(bi, '2._Two.txt'), A);
assert.deepStrictEqual(TL.checkBuiltIns({userData: ud, builtInDir: bi, userDir: mine}), [], 'first run: nothing to compare yet');
assert.deepStrictEqual(TL.checkBuiltIns({userData: ud, builtInDir: bi, userDir: mine}), [], 'unchanged: nothing');
fs.writeFileSync(path.join(bi, '1._One.txt'), B); fs.writeFileSync(path.join(bi, '3._Three.txt'), B);
fs.writeFileSync(path.join(mine, '2._Two.txt'), 'your own copy'); fs.writeFileSync(path.join(bi, '2._Two.txt'), B);
const up = TL.checkBuiltIns({userData: ud, builtInDir: bi, userDir: mine});
assert.deepStrictEqual(up.map(x => [x.file, x.kind]).sort(), [['1._One.txt', 'builtin'], ['3._Three.txt', 'added']], 'changed and new built-in templates are listed; one you replaced yourself is not');
assert.deepStrictEqual(TL.checkBuiltIns({userData: ud, builtInDir: bi, userDir: mine}), [], 'listed once');
console.log('Template change log self-test passed: sections, changed words, spacing-only, new template, app-update changes');
