// Self-test of the local spelling / grammar / wording check (renderer/textcheck.js). It needs no network and no AI.
const assert = require('assert'), path = require('path');
const TC = require(path.join(__dirname, '..', 'renderer', 'textcheck.js'));
const kinds = (t, o) => TC.check(t, o).map(h => h.kind + ':' + h.text.toLowerCase());
const has = (t, k, o) => assert.ok(kinds(t, o).some(x => x.startsWith(k)), `expected ${k} in "${t}", got ${kinds(t, o)}`);
const none = (t, o) => assert.deepEqual(TC.check(t, o).map(h => h.text + ' -> ' + h.msg), [], `unexpected hit in "${t}"`);
has('She walked into the kithcen and sat.', 'spelling:kithcen');
has('He recieved the letter.', 'spelling:recieved');
assert.equal(TC.check('She dont know.')[0].fix, "doesn't"); assert.equal(TC.check('I dont know.')[0].fix, "don't");
has('The colour of her dress.', 'spelling:colour');
none('Aoife Hayes rode the van. Jonathan waved.', {names: ['Aoife Hayes', 'Jonathan Wright']});
none('"Mmm," she said. "Ahhh, nooo, hmm."');
none('{{user}} looked at {{char}} and ![](image1) [Likeable NTR] https://app.jcimg.ca/abc.webp');
none("She'd said it, they'll see, y'all know, it's Jonathan's van, the Joneses' house, couldn't, mustn't, o'clock.");
none('Her mother-in-law drove a half-ton pickup to the well-known diner. Never pre-play it.');
none('It was 3:30 p.m. on Tuesday. Mr. Smith left. Dr. Lee stayed.');
none('Does she have a minute? Does he have time? If she were here, she would know. The choices in it are hers.');
none('He said that that was fine. She had had enough.');
none('An hour later an honest man left an umbrella. A university student rode a one-way bus. An FBI agent and a UFO.');
none('She wanted him to stay... then she left. Wait... what?');
has('The the cat sat.', 'grammar:the the'); has('She ate a apple.', 'grammar:a'); has('He found an book.', 'grammar:an');
has('She have a car.', 'grammar:have'); has('They was late.', 'grammar:was'); has('He could of left.', 'grammar:of');
has('It was bigger then him.', 'grammar:then'); has('She left. he stayed.', 'grammar:h'); has('word,word and more', 'grammar:,');
has('Hello.There you are', 'grammar:.'); has('i think so', 'grammar:i'); has('Its a long way.', 'grammar:its'); has('He had alot of money.', 'grammar:alot');
has('Is that okay ?', 'grammar: ?'); has('Two  spaces.', 'grammar:  ');
has('She has a work van that has been sick since spring.', 'wording:a work van'); has('He drives a car that is dying.', 'wording:a car');
has('She has a habit she does not tell him about.', 'wording'); has('There is a secret she keeps from him.', 'wording');
has('Something is wrong with her.', 'wording'); has('He utilized the tools.', 'wording:utilized'); has('Her heart skipped a beat.', 'wording'); has('It was a symphony of sound.', 'wording');
none('The van needs a new engine and costs more than they have.');
none('She is tired. He is sick. The car is dead and the phone is broken.');
// the sentence that started this: both problems are found, and a fix is applied exactly
const card = 'She has a side job habit she does not share with him and a work van that has been sick since spring.';
const hits = TC.check(card); assert.equal(hits.filter(h => h.kind === 'wording').length, 2);
const vanFix = hits.find(h => h.fix && /van/.test(h.text)); assert.ok(vanFix, 'a plain rewrite is offered for the sick van');
assert.equal(TC.apply(card, [{start: vanFix.start, end: vanFix.end, replacement: vanFix.fix}]), 'She has a side job habit she does not share with him and a work van that has needed repairs since spring.');
assert.equal(TC.apply('a  b', [{start: 1, end: 3, replacement: ' '}]), 'a b');
assert.equal(TC.apply('She recieved it. she dont know.', TC.check('She recieved it. she dont know.').filter(h => h.fix != null || h.suggest).map(h => ({start: h.start, end: h.end, replacement: h.fix != null ? h.fix : h.suggest[0]}))), "She received it. She doesn't know.");
const big = 'She walked into the kitchen and put the kettle on while the snow came down against the window. '.repeat(120);
const t0 = Date.now(); TC.check(big); assert.ok(Date.now() - t0 < 1500, 'a long text is checked quickly');
// "mouth" where the usual word is "lips": a smiling or twitching mouth is flagged with a soft lips fix, a kissing or watering mouth is not
const lips = s => TC.check(s).filter(h => h.kind === 'wording' && /lips/i.test(h.fix || ''));
assert.equal(lips('Her mouth curved into a smile.')[0].fix, 'lips curved'); assert.ok(lips('Her mouth curved into a smile.')[0].soft);
assert.equal(lips('Her mouth curves into a smile.')[0].fix, 'lips curve'); assert.equal(lips('The mouth was twitching.')[0].fix, 'lips were twitching'); assert.equal(lips('Mouth tightened.')[0].fix, 'Lips tightened');
assert.equal(lips('Her mouth pressed into a thin line.')[0].fix, 'lips pressed'); assert.equal(lips('The corners of her mouth lifted.')[0].fix, 'lips'); assert.equal(lips('A smile played at the corner of her mouth.')[0].fix, 'lips');
for (const ok of ['Her mouth pressed against his neck.', 'His mouth opened and her mouth watered.', 'Her mouth lifted to meet his.', 'Her lips curved into a smile.']) assert.equal(lips(ok).length, 0, ok);
console.log('Text check self-test passed: spelling, grammar and wording rules, with no AI and no network.');
// "she said it quietly": the "it" points at nothing, and the fix is "she said quietly"
assert.equal(TC.check('She said it quietly, eyes down.')[0].fix, 'said'); assert.equal(TC.check('She said it was fine.').length, 0); assert.equal(TC.apply('She said it without looking up.', [{start: 4, end: 11, replacement: 'said'}]), 'She said without looking up.');
// "Ignore this" and "Add to dictionary": a phrase or word the creator dismissed is never flagged again (a fake storage stands in for the browser's, a fake LanguageTool for the extra checker)
{
  const store = {}, p = require.resolve(path.join(__dirname, '..', 'renderer', 'textcheck.js'));
  global.self = {localStorage: {getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; }}};
  delete require.cache[p]; const T2 = require(p); delete global.self;
  const text = 'She stayed quiet, looking down, one arm on the table, and they were gonna leave. She kithcen.';
  const spot = w => { const i = text.indexOf(w); return {start: i, end: i + w.length}; };
  T2.setProvider(() => [Object.assign(spot('gonna'), {kind: 'wording', msg: 'Informal word', src: 'languagetool'}), Object.assign(spot('one arm on the table'), {kind: 'wording', msg: 'Wording note', src: 'languagetool'})]);
  const before = T2.check(text); assert.ok(before.some(h => h.text === 'gonna') && before.some(h => h.text === 'one arm on the table') && before.some(h => h.text === 'kithcen'), 'all three flagged first: ' + before.map(h => h.text));
  assert.ok(T2.ignorePhrase('one arm on the table')); assert.ok(T2.addWord('gonna')); assert.ok(T2.addWord('kithcen'));
  assert.deepEqual(T2.check(text).map(h => h.text), [], 'still flagged after ignoring: ' + T2.check(text).map(h => h.text));
  assert.ok(T2.unignoreAll()); assert.equal(T2.check(text).length, 3, 'flags come back after clearing the ignore list');
}
console.log('Ignore / add-to-dictionary self-test passed.');
