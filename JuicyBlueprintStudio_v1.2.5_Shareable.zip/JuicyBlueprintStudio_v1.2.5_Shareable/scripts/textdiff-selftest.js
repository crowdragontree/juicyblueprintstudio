'use strict';
// The change log of the Weekly Blueprint update panel: added, removed and reworded lines, the changed words, and the blueprint diff that carries it.
const assert = require('assert'), TD = require('../lib/textDiff'), BP = require('../lib/blueprint');
const old = 'FIRST LINE stays.\nBakadere stays lovable chaos with sincere attachment while being plainly sexual.\nThis rule goes away completely.\nLast line stays.';
const now = 'FIRST LINE stays.\nBakadere keeps lovable chaos in her personality while being plainly sexual and charged.\nLast line stays.\nA brand new rule is added at the end.';
const d = TD.sectionDiff(old, now);
assert.deepEqual(d.added, ['A brand new rule is added at the end.']); assert.deepEqual(d.removed, ['This rule goes away completely.']); assert.equal(d.changed.length, 1); assert.equal(d.same, 2);
const c = d.changed[0], ins = c.parts.filter(p => p[0] === 1).map(p => p[1].trim()), del = c.parts.filter(p => p[0] === -1).map(p => p[1].trim());
assert.ok(ins.includes('keeps') && del.includes('stays'), 'the changed words are marked'); assert.equal(c.parts.map(p => p[0] === -1 ? '' : p[1]).join('').trim(), c.after, 'put together, the unchanged and inserted words are the new line');
assert.equal(c.parts.map(p => p[0] === 1 ? '' : p[1]).join('').trim(), c.before, 'put together, the unchanged and removed words are the old line');
// spacing only, nothing, a new section, a very long line
assert.equal(TD.sectionDiff('a b\nc', 'a   b\n\n c').spacingOnly, true); assert.equal(TD.sectionDiff('', '').spacingOnly, true);
const all = TD.sectionDiff('', 'one\ntwo'); assert.deepEqual(all.added, ['one', 'two']);
const many = TD.sectionDiff('', Array.from({length: 60}, (_, i) => `rule number ${i} says something different`).join('\n')); assert.equal(many.added.length, 40); assert.equal(many.more.added, 20);
const big = 'word '.repeat(300) + 'old ending', big2 = 'word '.repeat(300) + 'new ending', lp = TD.sectionDiff(big, big2).changed[0]; assert.ok(lp.parts[0][1].length < 120 && /…/.test(lp.parts[0][1]), 'a long unchanged stretch is shortened');
assert.ok(/\[-.*-\]/.test(TD.logText([{title: 'T', kind: 'changed', diff: d}])) && /\+ A brand new rule/.test(TD.logText([{title: 'T', kind: 'changed', diff: d}])));
// the blueprint diff carries the log
const rules = body => `INTRODUCTION TEXT\n${'x'.repeat(220)}\n\nSMUTTY SUNDAY RULES\n${body}\n\nOTHER SECTION\nstays the same\n`;
const sch = txt => ({types: {}, sections: BP.parseRules(txt).sections, approvedTags: []}), a = sch(rules('Line one.\nLine two is old.')), b = sch(rules('Line one.\nLine two is now new.\nLine three.'));
const df = BP.diff(a, b); assert.deepEqual(df.sectionsChanged, ['SMUTTY SUNDAY RULES']); assert.equal(df.sectionLog.length, 1); assert.equal(df.sectionLog[0].diff.changed.length, 1); assert.deepEqual(df.sectionLog[0].diff.added, ['Line three.']);
const same = BP.diff(a, a); assert.equal(same.sectionLog.length, 0);
console.log('textdiff self-test passed');
