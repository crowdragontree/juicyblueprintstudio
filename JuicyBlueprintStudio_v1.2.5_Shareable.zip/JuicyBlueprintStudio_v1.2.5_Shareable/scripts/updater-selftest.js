'use strict';
// Update clean-up and release notes: only the app's own, unchanged, no-longer-shipped files are removed; notes are found for both editions' changelog layouts.
const fs = require('fs'), os = require('os'), path = require('path'), assert = require('assert');
const U = require('../lib/updater');
const mk = (root, files) => { for (const [f, c] of Object.entries(files)) { const p = path.join(root, f); fs.mkdirSync(path.dirname(p), {recursive: true}); fs.writeFileSync(p, c); } };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'jbs-upd-test-')), app = path.join(tmp, 'app'), v1 = path.join(tmp, 'v1'), v2 = path.join(tmp, 'v2');
mk(v1, {'main.js': 'm1', 'lib/a.js': 'a', 'lib/old.js': 'old', 'resources/bot-templates/t_v1.txt': 'T1', 'resources/bot-templates/mine.txt': 'shipped', 'gone/only.txt': 'x', 'node_modules/x/i.js': 'nm'});
mk(v2, {'main.js': 'm2', 'lib/a.js': 'a2', 'resources/bot-templates/t_v2.txt': 'T2', 'resources/bot-templates/mine.txt': 'shipped'});
const list1 = U.shippedFiles(v1), list2 = U.shippedFiles(v2);
assert.ok(!Object.keys(list1).some(k => k.startsWith('node_modules')), 'KEEP parts are not listed');
// the installed app = v1 files + things the user added or edited
mk(app, {'main.js': 'm1', 'lib/a.js': 'a', 'lib/old.js': 'old', 'resources/bot-templates/t_v1.txt': 'T1 edited by the user', 'resources/bot-templates/mine.txt': 'shipped', 'gone/only.txt': 'x', 'node_modules/x/i.js': 'nm',
  'resources/bot-templates/my_own_template.txt': 'user file', 'languagetool/lt.jar': 'jar', 'notes.txt': 'user notes'});
mk(tmp, {'outside.txt': 'must stay'});
const hostile = Object.assign({}, list1, {'../outside.txt': require('crypto').createHash('sha1').update('must stay').digest('hex'), 'node_modules/x/i.js': 'x'});
const r = U.removeStale(app, hostile, list2);
assert.deepStrictEqual(r.removed.sort(), ['gone/only.txt', 'lib/old.js'], 'removed: ' + r.removed);
assert.deepStrictEqual(r.kept, ['resources/bot-templates/t_v1.txt'], 'an edited file is left alone');
assert.ok(!fs.existsSync(path.join(app, 'gone')), 'folder left empty is removed');
for (const f of ['main.js', 'lib/a.js', 'resources/bot-templates/mine.txt', 'resources/bot-templates/my_own_template.txt', 'languagetool/lt.jar', 'notes.txt', 'node_modules/x/i.js']) assert.ok(fs.existsSync(path.join(app, f)), f + ' must stay');
assert.ok(fs.existsSync(path.join(tmp, 'outside.txt')), 'nothing outside the app folder is touched');
assert.deepStrictEqual(U.removeStale(app, null, list2), {removed: [], kept: []}, 'no earlier list: nothing is removed');
// release notes: heading "v1.2.1" (Shareable) and "Juicy Blueprint Studio v1.2.1" (older layout), only versions newer than the one installed
const notes = path.join(tmp, 'n1'); fs.mkdirSync(notes); fs.writeFileSync(path.join(notes, 'CHANGELOG.txt'), 'Juicy Blueprint Studio v1.2.1\n\n- one\n- two\n\nv1.2.0\n\n- old\n');
let n = U.notesFrom(notes, '1.2.0'); assert.deepStrictEqual(n.map(x => [x.version, x.lines.length]), [['1.2.1', 2]]);
fs.writeFileSync(path.join(notes, 'CHANGELOG.txt'), 'v1.2.1\n\n- one\n\nv1.2.0\n\n- old\n'); n = U.notesFrom(notes, '1.2.0'); assert.deepStrictEqual(n.map(x => x.version), ['1.2.1']);
const here = path.join(__dirname, '..'); n = U.notesFrom(here, '1.2.4'); assert.ok(n.length === 1 && n[0].version === require('../package.json').version && n[0].lines.length >= 1, 'this build\'s own changelog gives notes for its own version');
// the real install path: first install has no earlier list (nothing removed) and writes one; the next removes what the newer version dropped
(async () => {
  const a2 = path.join(tmp, 'app2'), s1 = path.join(tmp, 's1'), s2 = path.join(tmp, 's2'), s3 = path.join(tmp, 's3');
  const pkg = JSON.stringify({version: '1', dependencies: {}});
  mk(a2, {'package.json': pkg, 'old_at_start.txt': 'was there before lists existed'});
  mk(s1, {'package.json': pkg, 'main.js': '1', 'lib/x.js': 'x', 'lib/y.js': 'y'}); mk(s2, {'package.json': pkg, 'main.js': '2', 'lib/x.js': 'x'}); mk(s3, {'package.json': pkg, 'main.js': '3', 'lib/x.js': 'x'});
  const up = new U.Updater({appDir: a2, currentVersion: '1.0.0', edition: 'personal'});
  const go = (root, name) => { up.pending = {tmp: path.join(tmp, 'junk_' + name), root, version: name, name, size: 1}; return up.install(); };
  let x = await go(s1, '1.1.0'); assert.strictEqual(x.removedFiles, 0); assert.ok(fs.existsSync(path.join(a2, 'old_at_start.txt')), 'files from before lists existed are never guessed at');
  assert.ok(fs.existsSync(path.join(a2, '.shipped-files.json')));
  x = await go(s2, '1.2.0'); assert.strictEqual(x.removedFiles, 1); assert.ok(!fs.existsSync(path.join(a2, 'lib/y.js')) && fs.existsSync(path.join(a2, 'lib/x.js')));
  x = await go(s3, '1.3.0'); assert.strictEqual(x.removedFiles, 0); assert.strictEqual(fs.readFileSync(path.join(a2, 'main.js'), 'utf8'), '3');
  // GitHub Releases as the update source: the newest asset for this edition wins, drafts, prereleases and links off github.com are ignored
  assert.deepStrictEqual(U.githubOf('https://github.com/Owner/repo-name'), {owner: 'Owner', repo: 'repo-name'}); assert.strictEqual(U.githubOf('https://drive.google.com/drive/folders/abcdefghijk'), null);
  const realFetch = global.fetch, asset = (n, u) => ({name: n, browser_download_url: u || `https://github.com/o/r/releases/download/x/${n}`});
  global.fetch = async () => ({ok: true, status: 200, json: async () => [{draft: false, prerelease: false, assets: [asset('JuicyBlueprintStudio_v1.2.4_Shareable.zip'), asset('JuicyBlueprintStudio_v1.2.5_Personal.zip')]}, {draft: false, prerelease: false, assets: [asset('JuicyBlueprintStudio_v1.2.5_Shareable.zip'), asset('JuicyBlueprintStudio_v9.0_Shareable.zip', 'https://evil.example/x.zip')]}, {draft: true, prerelease: false, assets: [asset('JuicyBlueprintStudio_v8.0_Shareable.zip')]}, {draft: false, prerelease: true, assets: [asset('JuicyBlueprintStudio_v7.0_Shareable.zip')]}]});
  assert.strictEqual((await U.latestOnGithub({owner: 'o', repo: 'r'}, 'share')).name, 'JuicyBlueprintStudio_v1.2.5_Shareable.zip'); assert.strictEqual((await U.latestOnGithub({owner: 'o', repo: 'r'}, 'personal')).name, 'JuicyBlueprintStudio_v1.2.5_Personal.zip');
  global.fetch = async () => ({ok: false, status: 404}); await assert.rejects(() => U.latestOnGithub({owner: 'o', repo: 'r'}, 'share'), /public/);
  global.fetch = realFetch;
  fs.rmSync(tmp, {recursive: true, force: true});
  console.log('Updater self-test passed: stale files removed, edited/own files kept, nothing outside touched, release notes found.');
})().catch(e => { console.error(e); process.exit(1); });
